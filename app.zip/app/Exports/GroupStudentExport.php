<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithHeadings;
use App\Models\Group;
use App\Models\GroupSession;
use App\Models\GroupStudent;
use App\Models\StageLevel;

class GroupStudentExport implements FromCollection ,WithMapping,WithHeadings
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public $id;
    function __construct($id){
        $this->id = $id;
        
    }

    public function map($groups): array
    {
        
        return [
                                                                                            
            ($groups->lead)?$groups->lead->getName():'', 
            ($groups->lead)?$groups->lead->id:'' ,
            ($groups->lead)?$groups->lead->mobile_1:'',
             $groups->level->name ,
           
             ($groups->lead_payment() )?$groups->lead_payment()->rest.' EGP ':'done',
             ($groups->books)?'done':'pay',
             $groups->activation,
             ($groups->harvest_certificate)?'done':'pay' ,
             ($groups->cambridge_certificate)?'done':'pay' ,
             $groups->certification, 
             $groups->absence_per ?? 0 , 
             $groups->per_exam ,
             

       ];

    }
    // public function query()
    // {
    //     // return Appointment::with('client:id,name')->whereIn('id', $this->selectedRows);
    //     return $this->groups;
    // }

    
    public function headings(): array
    {
        return [
            'Name',
            'Id',
            'Mobile',
            'Start Level',
            'Payment',
            'Book',
            'Activation',
            'Harvest Certificates',
            'Cambridge Certificates',
            'Absence',
            'Exam',

        ];
    }
    public function Collection()
    {
        $id = $this->id;
        $group = Group::with('students.lead.attendances')->withCount('students', 'sessions')->find($id);
        
        // $similar_groups = Group::where('track_id',$group->track_id)
        //                         ->where('course_id',$group->course_id)
        //                         ->where('discipline_id',$group->discipline_id)
        //                         ->where('timeframe_id',$group->timeframe_id)
        //                         ->where('level_id',$group->level_id)
        //                         ->where('round_id',$group->round_id)
        //                         ->where('id','!=',$group->id)
        //                         ->get();

        $groups = $group->students;
        return $groups;
    }
}
