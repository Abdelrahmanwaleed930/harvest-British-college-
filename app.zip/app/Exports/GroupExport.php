<?php

namespace App\Exports;

use App\Models\User;
use App\Models\Group;
use App\Models\Branch;
use App\Models\Employee;
use App\Models\GroupStudent;
use App\Models\GroupSession;
use App\Models\StageLevel;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
// use Modules\User\Entities\User;
use Illuminate\Contracts\View\View;


use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithHeadings;
// use Maatwebsite\Excel\Concerns\WithEvents;
class GroupExport implements FromCollection , WithMapping ,WithHeadings
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public $request;
    
    function __construct($request){
        $this->request = $request;
        
    }

    public function map($groups): array
    {
        return [
                                                                                            
             $groups->id ,
             $groups->created_at ,
             $groups->code ,
            $groups->parent->id ?? 'Parent' , 
             $groups->round->title ,
             config('system_variables.timeframes.days')[$groups->days] ,
             $groups->discipline->name ,
             $groups->branch->name ,
             $groups->room->name ,
             $groups->instructor->name ?? '' ,
             $groups->interval->name ,
             $groups->startDate ,
             $groups->endDate ,
             $groups->level->name ,
    
              $groups->students_count ,
              $groups->sessions_count ,
             
              $groups->status,
            

        ];

    }
    // public function query()
    // {
    //     // return Appointment::with('client:id,name')->whereIn('id', $this->selectedRows);
    //     return $this->groups;
    // }

    
    public function headings(): array
    {
        return [
            'Id',
            'Created At',
            'Code',
            'Parent Group ID',
            'Round',
            'Days',
            'Discipline',
            'Branch',
            'Room',
            'Instructor',
            'Interval',
            'Started',
            'Ended',
            'Level',
            'Students',
            'Sessions',
            'Status',
        ];
    }
    public function Collection()
    {
        $request = $this->request;
        // dd($request);
        
        $branches = Branch::pluck('name', 'id')->toArray();
        
        $groupsQuery = Group::with('subRound')->withCount('students', 'sessions');

        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $groupsQuery->where('code','like','%'.$request->get('search').'%');
        }
        
        if($request->has('discipline_id') && $request->get('discipline_id') != null && $request->get('discipline_id') != ''){
            $groupsQuery->where('discipline_id',$request->get('discipline_id'));
        }
        
        if($request->has('track_id') && $request->get('track_id') != null && $request->get('track_id') != ''){
            $groupsQuery->where('track_id',$request->get('track_id'));
        }
            
        if($request->has('course_id') && $request->get('course_id') != null && $request->get('course_id') != ''){
            $groupsQuery->where('course_id',$request->get('course_id'));
        }
        
        if($request->has('level_id') && $request->get('level_id') != null && $request->get('level_id') != ''){
            $groupsQuery->where('level_id',$request->get('level_id'));
        }
        
        if($request->has('timeframe_id') && $request->get('timeframe_id') != null && $request->get('timeframe_id') != ''){
            $groupsQuery->where('timeframe_id',$request->get('timeframe_id'));
        }
        
        if($request->has('round_id') && $request->get('round_id') != null && $request->get('round_id') != ''){
            $groupsQuery->where('round_id',$request->get('round_id'));
        }
        if($request->has('days') && $request->get('days') != null && $request->get('days') != ''){
            $groupsQuery->where('days',$request->get('days'));
        }
            
        if($request->has('interval_id') && $request->get('interval_id') != null && $request->get('interval_id') != ''){
            $groupsQuery->where('interval_id',$request->get('interval_id'));
            $request->instructor_id = '';
        }
        
        if($request->has('sub_round_id') && $request->get('sub_round_id') != null && $request->get('sub_round_id') != ''){
            $groupsQuery->where('sub_round_id',$request->get('sub_round_id'));
        }
        
        if($request->has('branch_id') && $request->get('branch_id') != '' && $request->get('branch_id') != null){
            $groupsQuery->where('branch_id',$request->get('branch_id'));
        }else{
            $branches_ids = auth()->user()->branches->pluck('id')->toArray();
            $groupsQuery->whereIn('branch_id',$branches_ids);
        }
        
        if($request->has('instructor_id') && $request->get('instructor_id') != '' && $request->get('instructor_id') != null){
            $groupsQuery->where('instructor_id',$request->get('instructor_id'));
        }
        
        if($request->has('room_id') && $request->get('room_id') != '' && $request->get('room_id') != null){
            $groupsQuery->where('room_id',$request->get('room_id'));
        }
        
        if($request->has('admin_id') && $request->get('admin_id') != '' && $request->get('admin_id') != null){
            $groupsQuery->where('admin_id',$request->get('admin_id'));
        }
    
        if($request->has('status') && $request->get('status') != '' && $request->get('status') != null){
            if($request->get('status') == 'complete'){
                $groupsQuery->whereHas('subRound',function($query){
                    $query->where('end_date','<',date('Y-m-d'));
                });
            } 
            if($request->get('status') == 'upcoming'){
                $groupsQuery->whereHas('subRound',function($query){
                    $query->where('start_date','>',date('Y-m-d'));
                });
            }
            if($request->get('status') == 'running'){
                $groupsQuery->whereHas('subRound',function($query){
                    $query->where('start_date','<=',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
                });
            }
        }
        // dd($request);

        $groupsQuery = $groupsQuery->get();
        return $groupsQuery;

    }
}
