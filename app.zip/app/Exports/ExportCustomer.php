<?php

namespace App\Exports;


use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\FromCollection;
use App\Models\Lead;
use DB;
use App\Models\SubRound;
use App\Models\Branch;
use App\Models\Employee;
use App\Models\StageLevel;
use App\Models\Timeframe;
use App\Models\LeadSource;
use App\Models\Round;
use App\Models\KnowChannel;
use App\Models\Interval;
use App\Models\Group;
use App\Models\OldCustomerPayment;
use App\Models\CustomerTrack;
use App\Models\Country;
use App\Models\Governorate;
use App\Models\City;
use App\Models\PlacementApplicant;
use App\Models\LeadCase;
use App\Models\LeadPayment;
use App\Models\LabelType;
use App\Models\Track;
use App\Models\DisciplineCategory;
use App\Models\GroupSessionAttendance;
use Illuminate\Http\Request;
use App\Models\TrainingService;
use Auth;


class ExportCustomer implements FromCollection ,WithMapping,WithHeadings
{
    public $data;
    function __construct($request)
    {
        $this->data = $request;
    }
    
    public function map($leads): array
    {
        $pt_level = $leads->getPT($this->data->track_id);
        if($pt_level != null && $pt_level != ''){
            $leads_pt_level=$pt_level->level;
        }
        else{
            $leads_pt_level = '-';
        }
     
        if ($leads->customerTracks->count() > 0){
            $lead_total=($leads->customerTracks[0]->total)??' ';
            $lead_used=($leads->customerTracks[0]->used)??' ' ;
            $lead_remain=($leads->customerTracks[0]->total - $leads->customerTracks[0]->used)??' ' ;
        }
        else{
            $lead_total=0;
            $lead_used=0;
            $lead_remain=0;
            
        }
        
        return [
                                                                                            
            $leads->created_at, 
            $leads->getName() ,
            $leads->mobile_1,
            $leads->prefer_branch->name ?? '' ,
            $leads->first_branch->name  ?? '' ,
            $leads->branch->name ?? '' ,
            $leads->transfer_branch->name ?? '' ,
            $leads->assignedEmployee->name ?? '' ,
            $leads->old_customer ? 'Yes' : 'No' ,
            $leads->lead_source->name ?? '' ,
            $leads->customer_type ?? '' ,
            $leads->lastFollowup(2)->updated_at ?? '' ,
            $leads->lastFollowup(2)->labelType->name ?? '' ,
            $leads_pt_level ?? ' ',
            //($leads->current_level_name)? $leads->current_level_name : ' -',
            $leads->payments()->sum('rest') ,
            $leads->first_branch->name  ?? '' ,
            $leads->first_branch->name  ?? '' ,
            $lead_total,
            $lead_used,
            $lead_remain,
            $leads->cases_count,
            $leads->invoices_count,
       ];

    }
  

    
    public function headings(): array
    {
        return [
            'Registration At',
            'Name',
            'Mobile',
            'Prefer Branch',
            'Transfer out',
            'Branch',
            'Transfer to',
            'Assigned Employee',
            'Old Customer',
            'Lead Source',
            'Customer Type',
            'Last Follow Up Date',
            'Status',
            'PT',
            'Current Level',
            'UnPaid',
            'Total',
            'Used',
            'Remain',
            'Follow Up',
            'Payments'
        ];
    }
    public function Collection()
    {
        
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        
        $track = $this->data->track_id;
        $type = ($this->data->type != '' && $this->data->type != null)?$this->data->type:2;
        $leadsQuery = Lead::leftJoin('placement_applicants','placement_applicants.lead_id','=','leads.id')
            ->leftJoin('group_waiting_lists','group_waiting_lists.lead_id','=','leads.id')
            ->whereRaw('(placement_applicants.track_id = '.$track.' or placement_applicants.track_id is null)')
            ->whereRaw('(group_waiting_lists.track_id = '.$track.' or (leads.type = 2 and leads.prefered_track_id = '.$track.' and group_waiting_lists.track_id is null))');            //->where('leads.type', $type);
        
        $registration_from = null;
        $registration_to = null;
        if ($this->data->registration_daterange && $this->data->registration_daterange != null && $this->data->registration_daterange!= ''){
            $daterange = explode(' - ',$this->data->registration_daterange);
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            // $registration_to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
        } 
       
      
        $leadsQuery->whereIn('leads.branch_id', array_keys($employeeBranches));
        
        // return $leadsQuery->get;
        $labelsType=$this->data->label_type;
        if($this->data->label_type && $this->data->label_type != null && $this->data->label_type != ''){
            
            $leadsQuery->with('lastcase')->whereHas('lastcase',function($q) use ($labelsType)
            {
                $q->where('label_type_id',$labelsType);

            });
        }
        
        if($this->data->agent && $this->data->agent != null &&$this->data->agent != ''){
            $leadsQuery->where('leads.assigned_employee_id',$this->data->agent);
        }
        
        if($this->data->assignedToMe && $this->data->assignedToMe != null && $this->data->assignedToMe != ''){
            $leadsQuery->where('leads.assigned_employee_id', auth()->id());
        }
        
        if($this->data->know_channel && $this->data->know_channel != null && $this->data->know_channel != ''){
            $leadsQuery->where('leads.know_channel_id', $this->data->know_channel );
        }
        
        if ($this->data->lead_source && $this->data->lead_source != null && $this->data->lead_source != '') {
            $leadsQuery->where('leads.lead_source_id', $this->data->lead_source);
        }
        
        if($this->data->groups_ids && $this->data->groups_ids!= null && $this->data->groups_ids != ''){
            $groups_students_ids = GroupStudent::whereIn('group_id',explode(',',$this->data->groups_ids))->pluck('lead_id');
            $leadsQuery->whereIn('leads.id',$groups_students_ids);
        }
        if($this->data->leads_ids && $this->data->leads_ids != null && $this->data->leads_ids != ''){
            $leadsQuery->whereIn('leads.id',explode(',',$this->data->leads_ids));
        }
        
        
        if($this->data->select_assigned && $this->data->select_assigned != null && $this->data->select_assigned != ''){
            if ($this->data->select_assigned === '0') {
                $leadsQuery->whereNull('leads.assigned_employee_id');
            } elseif ($this->data->select_assigned === '1') {
                $leadsQuery->whereNotNull('leads.assigned_employee_id');
            }
        }
        if($this->data->has_unpaid && $this->data->has_unpaid != null && $this->data->has_unpaid != ''){
            if ($this->data->has_unpaid === '0') {
                $leadsQuery->whereHas('payments' ,function($query){
                    $query->where('rest',0 );
                });
            } elseif ($this->data->has_unpaid === '1') {
                $leadsQuery->whereHas('payments' ,function($query){
                    $query->where('rest' ,'>' ,0 );
                });
            }
        }
        
        
        if ($this->data->current_branches && $this->data->current_branches != null && $this->data->current_branches != '') {
            $leadsQuery->whereIn('leads.branch_id', $this->data->current_branches);
        }
        if ($this->data->transfer_branches && $this->data->transfer_branches != null && $this->data->transfer_branches != '') {
            $leadsQuery->whereIn('leads.transfer_branch_id', $this->data->transfer_branches);
        }
        if ($this->data->first_branch_id && $this->data->first_branch_id != null && $this->data->first_branch_id != '') {
            $leadsQuery->whereIn('leads.first_branch_id', $this->data->first_branch_id);
        }
        if($this->data->has_followup&& $this->data->has_followup != null && $this->data->has_followup != ''){
            if ($this->data->has_followup === '0') {
                $leadsQuery->doesntHave('cases');
            } elseif ($this->data->has_followup === '1') {
                $leadsQuery->has('cases');
            }
        }
        if ($registration_from != null && $registration_to != '') {
            $leadsQuery->whereBetween('leads.created_at', [$registration_from, $registration_to]);
        }
        
        
        if($this->data->course_id && $this->data->course_id != null && $this->data->course_id != ''){
         
            $leadsQuery->whereIn('placement_applicants.level',$stageLevels->pluck('value'));
        }
        
        if($this->data->customer_type && $this->data->customer_type != null && $this->data->customer_type != ''){
            $leadsQuery->where('leads.customer_type',$this->data->customer_type);
        }
        
        if($this->data->level_id && $this->data->level_id != null && $this->data->level_id != ''){
            if($type == 2){
                $stage_level = StageLevel::find($this->data->level_id);
                $leadsQuery->where('placement_applicants.level',$stage_level->value);
            }
        }
        
        $leadsCount = $leadsQuery->count();
        $leads = $leadsQuery->select('leads.*','placement_applicants.level as pt_level','group_waiting_lists.level_id as last_level_id')
            ->withCount('invoices','cases')
            ->with('lastcase','branch','customerTracks','getWaitingList','payments','assignedEmployee')
            ->latest()->get();
  
        return $leads;
    }
}
