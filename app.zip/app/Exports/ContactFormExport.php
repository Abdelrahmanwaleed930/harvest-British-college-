<?php

namespace App\Exports;

use App\Models\User;
use App\Models\ContactUs;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithHeadings;

class ContactFormExport implements FromCollection , WithMapping ,WithHeadings
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public $request;
    function __construct($request){
        $this->request = $request;
        
    }

    public function map($forms): array
    {
        return [
                         
             $forms->id ,
             $forms->created_at,
             $forms->name ,
             $forms->email ,
             $forms->phone,
             $forms->message ,
            

        ];

    }
    
    public function headings(): array
    {
        return [
            'Id',
            'created_at',
            'Name',
            'Email',
            'Mobile',
            'Message',
            'Action',
        ];
    }
    public function Collection()
    {
        $request = $this->request;
        $forms = new ContactUs;

        $daterange_from = null;
        $daterange_to = null;
        $reg_to=null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '')
         {
            $daterange = explode(' - ',$request->get('daterange'));
            $daterange_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $daterange_to= date_format($reg_to,"Y-m-d");;
            
        }

        if ($daterange_from != null && $daterange_to != '') {
            $forms=ContactUs::whereBetween('created_at', [$daterange_from, $daterange_to]);
            
            
        }
       
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $forms=ContactUs::where('name', 'like', '%' . $request->get('search') . '%')
                        ->orWhere('phone', 'like', '%' . $request->get('search') . '%')
                        ->orWhere('email', 'like', '%' . $request->get('search') . '%');
        }
        
        
        
        $formCount = $forms->count();
        $forms = $forms->latest()->get();
        return $forms;
    }
}
