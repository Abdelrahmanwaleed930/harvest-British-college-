<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ExecuseModel;
use Flash;
use Auth;
use DB; 
class ExecuseController extends Controller
{
   public function index(){
        $employeedepartment =auth()->user();
        $department_manager = DB::table('department_managers')->where('department_id',$employeedepartment->department_id)->first();
        $excuses = ExecuseModel::with('employee','department');  
        
        if($employeedepartment->job_id == 20)
        {
            $excuses = $excuses->whereHas('employee', function ($query) use($employeedepartment) {
                                $query->where('current_branch', $employeedepartment->current_branch)->where('job_id','!=',20);
                            });
            
        }elseif($employeedepartment->job_id == 19){
            $excuses = $excuses->whereHas('employee', function ($query)use($employeedepartment)  {
                                $query->where('job_id',20)->where('job_id','!=',19);
                            });
        }elseif($department_manager != null){
             $excuses = $excuses->whereHas('employee', function ($query) use($employeedepartment) {
                                $query->where('department_id',$employeedepartment->department_id)->where('id','!=',$employeedepartment->id); 
                            });
             
        }elseif($employeedepartment->job_id == 15 ||$employeedepartment->job_id == 16 || $employeedepartment->job_id == 43 ){
            
            $excuses = ExecuseModel::whereNotNull('status'); 
        }else{
            $excuses = ExecuseModel::where('employee_id' ,$employeedepartment->id); 
        }
        $excuses = $excuses->orderBy('created_at' , 'DESC')->get();
        
        return view('Execuse.index',compact('excuses')); 
    }
    public function create(){
        
        $excuses = ExecuseModel::get();
        
        return view('Execuse.create',compact('excuses')); 
    }
    public function store(Request $request){
        $employee = Auth::user();
        $credentials = $request->validate([
            'time_from' => 'required',
            'time_to' => 'required',
            'day' => 'required',
        ]);
        $startdateArrey = explode("-", $request->day);
        $execuse_count = ExecuseModel::where('month',$startdateArrey[1])->where('employee_id',$employee->id)
        ->where('status','approve')->count();
        if($execuse_count >= 2)
        {
             Flash::error('you have all Execuses in this Month');
            
            
        }else{
            $excuses = new ExecuseModel;
            $excuses->employee_id = $employee->id;
            $excuses->department_id = $employee->department_id;
            $excuses->time_from = $request->time_from;
            $excuses->time_to = $request->time_to;
            $excuses->month = $startdateArrey[1];
            $excuses->day = $request->day;
            $excuses->save();
             Flash::success('Execuse created successfully.');
        }
        
        
       
        return redirect()->back(); 
    }
    public function show($id){}
    public function edit($id){
        $excuses = ExecuseModel::find($id);
        return view('Execuse.edit',compact('excuses')); 
    }
    public function update($id ,Request $request){
        $excuses = ExecuseModel::find($id);
         $credentials = $request->validate([
            'employee_id' => 'required',
            'time_from' => 'required',
            'time_to' => 'required',
            'day' => 'required',
            'status' => 'required',
        ]);
        $excuses->employee_id = $request->employee_id;
        $excuses->time_from = $request->time_from;
        $excuses->time_to = $request->time_to;
        $excuses->day = $request->day;
        $excuses->status = $request->status;
        $excuses->save();
        
        Flash::success('Execuse updated successfully.');
        return redirect()->back(); 
    }
    public function destroy($id){
        
        $excuses = ExecuseModel::find($id);
        $excuses->delete();
        Flash::success('Execuse deleted successfully.');
        return redirect()->back(); 
        
        
    }
    
    public function changeStatusExecuse($id,$status){
   
        $Execuse=ExecuseModel::find($id);
        if ($Execuse->status == 'pending'){
           $Execuse->status=$status;            
           $Execuse->save();
        }
       
        Flash::success('Change Execuse status successfully.');
        return redirect()->back();
    }
    
    public function confirmExecuse($id,$confirm){
    
        $Execuse=ExecuseModel::find($id);
        if ($Execuse->confirm_mang == 'pending'){
           $Execuse->confirm_mang = $confirm;            
           $Execuse->created_by_id=auth()->user()->id;            
           $Execuse->save();
        }
       
        Flash::success('Change Execuse status successfully.');
        return redirect()->back();
    }
}
