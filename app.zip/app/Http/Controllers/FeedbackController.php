<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateFeedbackRequest;
use App\Http\Requests\UpdateFeedbackRequest;
use App\Http\Controllers\AppBaseController;
use App\Models\Feedback;
use App\Models\LabelType;
use Illuminate\Http\Request;
use Flash;
use DB;
use Response;

class FeedbackController extends AppBaseController
{
    /**
     * Display a listing of the Feedback.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var Feedback $feedback */
        $feedback = Feedback::paginate(10);

        return view('feedback.index')
            ->with('feedback', $feedback);
    }

    /**
     * Show the form for creating a new Feedback.
     *
     * @return Response
     */
    public function create()
    {
        $labelTypes = LabelType::where('status', 1)->select(DB::raw('concat(category,"-",name) as name'), 'id')->get()->pluck('name','id');

        return view('feedback.create', compact('labelTypes'));
    }

    /**
     * Store a newly created Feedback in storage.
     *
     * @param CreateFeedbackRequest $request
     *
     * @return Response
     */
    public function store(CreateFeedbackRequest $request)
    {
        $input = $request->all();

        /** @var Feedback $feedback */
        $feedback = Feedback::create($input);

        Flash::success('Feedback saved successfully.');

        return redirect(route('admin.feedbacks.index'));
    }

    /**
     * Display the specified Feedback.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var Feedback $feedback */
        $feedback = Feedback::find($id);

        if (empty($feedback)) {
            Flash::error('Feedback not found');

            return redirect(route('admin.feedbacks.index'));
        }

        return view('feedback.show')->with('feedback', $feedback);
    }

    /**
     * Show the form for editing the specified Feedback.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var Feedback $feedback */
        $feedback = Feedback::find($id);

        if (empty($feedback)) {
            Flash::error('Feedback not found');

            return redirect(route('admin.feedbacks.index'));
        }
        $labelTypes = LabelType::where('status', 1)->select(DB::raw('concat(category,"-",name) as name'), 'id')->get()->pluck('name', 'id');

        return view('feedback.edit', compact('feedback', 'labelTypes'));
    }

    /**
     * Update the specified Feedback in storage.
     *
     * @param int $id
     * @param UpdateFeedbackRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateFeedbackRequest $request)
    {
        /** @var Feedback $feedback */
        $feedback = Feedback::find($id);

        if (empty($feedback)) {
            Flash::error('Feedback not found');

            return redirect(route('admin.feedbacks.index'));
        }

        $feedback->fill($request->all());
        $feedback->save();

        Flash::success('Feedback updated successfully.');

        return redirect(route('admin.feedbacks.index'));
    }

    /**
     * Remove the specified Feedback from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var Feedback $feedback */
        $feedback = Feedback::find($id);

        if (empty($feedback)) {
            Flash::error('Feedback not found');

            return redirect(route('admin.feedbacks.index'));
        }

        $feedback->delete();

        Flash::success('Feedback deleted successfully.');

        return redirect(route('admin.feedbacks.index'));
    }
}
