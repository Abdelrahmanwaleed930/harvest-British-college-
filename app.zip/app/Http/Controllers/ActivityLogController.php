<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ActivityLog;

class ActivityLogController extends Controller
{
    //
    public function index()
    {
        $activities = ActivityLog::orderBy('created_at','desc')->paginate(20);
        // dd($activities[]->subject);
        
          return view('activity_log.index')->with('activities',$activities);
        
    }
}
