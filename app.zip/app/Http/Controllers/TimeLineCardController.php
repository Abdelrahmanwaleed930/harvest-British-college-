<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\TimeLineCard;
use App\Models\TimeLineCardSections;
use App\Models\Group;
use App\Models\GroupSession;
use App\Models\SectionsTimeLineCard;
use App\Models\Branch;
use App\Models\Employee;
use App\Models\Track;
use App\Models\StageLevel;
use App\Models\GroupSessionAttendance;
use Flash;

class TimeLineCardController extends Controller
{
     public function index(Request $request){
        
         $TimeLineCard = TimeLineCard::with('SectionsTimeLineCard','instructor','group','group_sessions','branch');
           $daterange_from = null;
        $daterange_to = null;
        $reg_to=null;
        
        $groups = Group::where('instructor_id',346)->with('subRound')->withCount('students', 'sessions')
         ->whereHas('subRound',function($query){
                    $query->where('start_date','<=',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
                })->pluck('code','id')->toArray();
        $sessions =[];
           $levels=  Track::find(2)->stageLevels->pluck('name', 'id')->toArray();
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            
            $daterange = explode(' - ',$request->get('daterange'));
            $daterange_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $daterange_to= date_format($reg_to,"Y-m-d");
            
        }
        
       
        // if($request->has('group_id') && $request->get('group_id') != '' && $request->get('group_id') != null){
        //     $TimeLineCard = $TimeLineCard->where('group_id',$request->get('group_id'));
        //     $groups = Group::find($request->get('group_id'));
        // }
        // if($request->has('session_id') && $request->get('session_id') != '' && $request->get('session_id') != null){
        //     $TimeLineCard = $TimeLineCard->where('session_id',$request->get('session_id'));
        //     $sessions = GroupSession::find($request->get('session_id'));
        // }
        if($request->has('level_id') && $request->get('level_id') != '' && $request->get('level_id') != null){
            $TimeLineCard = $TimeLineCard->where('level_id',$request->get('level_id'));
           
        }

        if ($daterange_from != null && $daterange_to != '') {
            $TimeLineCard->whereBetween('created_at', [$daterange_from, $daterange_to]);
        }
         
         
         
         $TimeLineCard=$TimeLineCard->get(); 
         $TimeLineCardcount = $TimeLineCard->count();

        
        return view('TimeLineCard.index',compact('TimeLineCard','levels','sessions','groups','TimeLineCardcount')); 
    }
    public function create(){
        $branches = Branch::where('status',1)->pluck('name' ,'id');
        $TimeLineCardSections = TimeLineCardSections::get();
          $groups = [];
         $levels=  Track::find(2)->stageLevels->pluck('name', 'id')->toArray();

        $instructors=[];
        // $groups =[];
        $sessions =[];
        
        return view('TimeLineCard.create',compact('branches','levels' ,'instructors' ,'groups','sessions','TimeLineCardSections')); 
    }
    public function store(Request $request){
        // dd($request->all());
        $credentials = $request->validate([
            'group_id' => 'required',
            'session_id' => 'required',
            'level_id' => 'required',
        ]);
        
        // return $level;
        $no_of_student = GroupSessionAttendance::where('group_id',$request->group_id)->count();
        // return $no_of_student;
        $TimeLineCardSections = TimeLineCardSections::select('id','title')->get();
        $TimeLineCard = new TimeLineCard;
        $TimeLineCard->instructor_id = auth()->user()->id;
        $TimeLineCard->group_id = $request->group_id;
        $TimeLineCard->session_id = $request->session_id;
        $TimeLineCard->no_of_student = $no_of_student;
        $TimeLineCard->level_id = $request->level_id;
        $TimeLineCard->save();
        
        foreach($TimeLineCardSections as $key => $section){
            $SectionsTimeLineCard = new SectionsTimeLineCard;
            $SectionsTimeLineCard->timeline_card_sections_id   = $section->id;
            $SectionsTimeLineCard->timeline_card_id = $TimeLineCard->id;
            $SectionsTimeLineCard->score = $request->score[$key];
            $SectionsTimeLineCard->functions = $request->functions[$key];
            $SectionsTimeLineCard->objective = $request->objective[$key];
            $SectionsTimeLineCard->statement = $request->statement[$key];
            $SectionsTimeLineCard->save();
        }
        
        $sumscore = SectionsTimeLineCard::where('timeline_card_id',$TimeLineCard->id)->sum('score');

        $TimeLine = TimeLineCard::find($TimeLineCard->id);
        $TimeLine->score = $sumscore;
        $TimeLine->save();
        
        Flash::success(' TimeLineCard Create successfully.');
        
         return redirect(route('admin.TimeLineCard.index'));
    }
    public function edit(Request $request ,$id){
        $TimeLineCard = TimeLineCard::find($id);
        
        $branches = Branch::where('status',1)->pluck('name' ,'id');
         $TimeLineCardSections = TimeLineCardSections::get();
        // $instructors=Employee::where('account_Type', 'ESL Account Profile')
        // ->where('status',1)->whereHas('branches', function ($query) use ($TimeLineCard) {
        //                         $query->where('id', $TimeLineCard->branch_id);
        //                     })->get()->pluck('name','id')->toArray();
        
        $groups = Group::where('instructor_id',346)
        ->pluck('code','id')->toArray();
        $sessions = GroupSession::where('group_id',$TimeLineCard->group_id)
        ->pluck('date','id')->toArray();
         $SectionsTimeLineCard =  SectionsTimeLineCard::where('timeline_card_id',$TimeLineCard->id)->get();
          
        return view('TimeLineCard.edit',compact('TimeLineCard','SectionsTimeLineCard','branches'  ,'groups','sessions','TimeLineCardSections')); 

    }
    public function update($id,Request $request){
         $credentials = $request->validate([
            'group_id' => 'required',
            'session_id' => 'required',
            'level_id' => 'required',
        ]);
        
        $TimeLineCardSections = TimeLineCardSections::select('id','title')->get();
         $SectionsTimeLineCard = SectionsTimeLineCard::where('timeline_card_id',$id)->get();
         
        // dd($request->all());
        

        $no_of_student = GroupSessionAttendance::where('group_id',$request->group_id)->count();
        // return $no_of_student;
        $TimeLineCard = TimeLineCard::find($id);
        $TimeLineCard->instructor_id = auth()->user()->id;
        $TimeLineCard->group_id = $request->group_id;
        $TimeLineCard->session_id = $request->session_id;
        $TimeLineCard->no_of_student = $no_of_student;
        $TimeLineCard->level_id = $request->level_id;
    
        $TimeLineCard->save();
        
        foreach($SectionsTimeLineCard as $key => $section){
        
        $SectionsTimeLineCard[$key]->score = $request->score[$key];
        $SectionsTimeLineCard[$key]->functions = $request->functions[$key];
        $SectionsTimeLineCard[$key]->objective = $request->objective[$key];
        $SectionsTimeLineCard[$key]->statement = $request->statement[$key];
        $SectionsTimeLineCard[$key]->save();
        }
         $sumscore = SectionsTimeLineCard::where('timeline_card_id',$TimeLineCard->id)->sum('score');

        $TimeLine = TimeLineCard::find($TimeLineCard->id);
        $TimeLine->score = $sumscore;
        $TimeLine->save();
        
        Flash::success('TimeLineCard  updated successfully.');
         return redirect(route('admin.TimeLineCard.index'));
        
       
    }
    public function show($id){
         $TimeLineCard = TimeLineCard::with('SectionsTimeLineCard.TimeLineCardSections')->find($id); 
        // return $TimeLineCard->TimeLineCardSections;
        return view('TimeLineCard.show',compact('TimeLineCard' )); 
        
    }
    public function destroy($id){
        $TimeLineCard = TimeLineCard::find($id);
        $TimeLineCard->delete();
        Flash::success(' TimeLineCard delete  successfully.');
        
        return redirect(route('admin.TimeLineCard.index'));
    }
   
   
    
}
