<?php

namespace App\Http\Controllers;

use App\Http\Controllers\AppBaseController;
use App\Models\ServiceFee;
use App\Models\TrainingService;
use App\Models\Installment;
use App\Models\PaymentPlan;
use Illuminate\Http\Request;
use Flash;
use Response;

class ServiceFeeController extends AppBaseController
{
    /**
     * Display a listing of the ServiceFee.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var ServiceFee $serviceFees */
        $serviceFees = ServiceFee::all();

        return view('service_fees.index')
            ->with('serviceFees', $serviceFees);
    }

    /**
     * Show the form for creating a new ServiceFee.
     *
     * @return Response
     */
    public function create()
    {
        
        $services = TrainingService::pluck('title', 'id');
        $paymentPlans = PaymentPlan::where('status', 1)->pluck('title', 'id');
        return view('service_fees.create' ,compact('services','paymentPlans'));
    }
    
    public function storee(Request $request){
        
        $serviceFee = new ServiceFee;
        $serviceFee->training_service_id = $request->training_service_id;
        $serviceFee->fees = $request->fees;
        $serviceFee->payment_plan_id = $request->payment_plan_id;
                $serviceFee->type = $request->type;

        $serviceFee->save();
        
        if($request->payment_plan_id == 1 )
        {
            $installment = new Installment;
            $installment->installmentable_type = 'App\\Models\\ServiceFee';
            $installment->installmentable_id =$serviceFee->id;
            $installment->deposit = $request->deposit;
            $installment->first_payment =   $request->first_payment;
            $installment->first_due_date =  $request->first_due_date;
            $installment->second_payment =  $request->second_payment;
            $installment->second_due_date = $request->second_due_date;
            $installment->third_payment =   $request->third_payment;
            $installment->third_due_date =  $request->third_due_date;
            $installment->fourth_payment =   $request->fourth_payment;
            $installment->fourth_due_date =  $request->fourth_due_date;
            $installment->save();
        }
        
         Flash::success('ServiceFees saved successfully.');

        return redirect(route('admin.serviceFees.index'));
        
    }

    /**
     * Display the specified ServiceFee.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var ServiceFee $serviceFee */
        $serviceFee = ServiceFee::find($id);

        if (empty($serviceFee)) {
            Flash::error('Service Fee not found');

            return redirect(route('admin.serviceFees.index'));
        }

        return view('service_fees.show')->with('serviceFee', $serviceFee);
    }
    public function updatee($id , Request $request)
    {
        $serviceFee = ServiceFee::find($id);
        $serviceFee->training_service_id = $request->training_service_id;
        $serviceFee->fees = $request->fees;
        $serviceFee->payment_plan_id = $request->payment_plan_id;
                        $serviceFee->type = $request->type;

        $serviceFee->save();
        
        if($serviceFee->payment_plan_id == 1 )
        {
            
           $installment = Installment::where('installmentable_id' , $serviceFee->id)
                                     ->where('installmentable_type','App\\Models\\ServiceFee')->first();
        
            $installment->deposit = $request->deposit;
            $installment->first_payment =   $request->first_payment;
            $installment->first_due_date =  $request->first_due_date;
            $installment->second_payment =  $request->second_payment;
            $installment->second_due_date = $request->second_due_date;
            $installment->third_payment =   $request->third_payment;
            $installment->third_due_date =  $request->third_due_date;
            $installment->fourth_payment =   $request->fourth_payment;
            $installment->fourth_due_date =  $request->fourth_due_date;
            $installment->save();
        }
        
         Flash::success('ServiceFees updated successfully.');

        return redirect(route('admin.serviceFees.index'));
        
    }

    /**
     * Show the form for editing the specified ServiceFee.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var ServiceFee $serviceFee */
        $serviceFee = ServiceFee::find($id);
        $installment = Installment::where('installmentable_id' , $serviceFee->id)
                                  ->where('installmentable_type','App\\Models\\ServiceFee')->first();
        
        $services = TrainingService::pluck('title', 'id');
        $paymentPlans = PaymentPlan::where('status', 1)->pluck('title', 'id');

        if (empty($serviceFee)) {
            Flash::error('Service Fee not found');

            return redirect(route('admin.serviceFees.index'));
        }

        return view('service_fees.edit', compact('serviceFee' ,'services' ,'paymentPlans','installment' ));
    }

    /**
     * Remove the specified ServiceFee from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var ServiceFee $serviceFee */
        $serviceFee = ServiceFee::find($id);

        if (empty($serviceFee)) {
            Flash::error('Service Fee not found');

            return redirect(route('admin.serviceFees.index'));
        }

        $serviceFee->delete();

        Flash::success('Service Fee deleted successfully.');

        return redirect(route('admin.serviceFees.index'));
    }
}
