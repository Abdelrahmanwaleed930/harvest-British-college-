<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Monitoring;
use App\Models\Branch;
use App\Models\MonitoringSections;
use App\Models\SectionsMonitoring;
use App\Models\MonitoringSectionTopic;
use App\Models\StageLevel;
use App\Models\Employee;
use App\Models\Group;
use App\Models\Track;
use App\Models\GroupSession;
use Flash;
use DB;

class MonitoringController extends Controller
{
    public function index(Request $request){
        
         
        $monitoring = Monitoring::where('senior_id',auth()->user()->id)->orderBy('created_at','desc');
        $daterange_from = null;
        $daterange_to = null;
        $reg_to=null;
        $instructors=[];
        $seniors=[];
        $groups =[];
        $sessions =[];
        $levels=  Track::find(2)->stageLevels->pluck('name', 'id')->toArray();
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            
            $daterange = explode(' - ',$request->get('daterange'));
            $daterange_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $daterange_to= date_format($reg_to,"Y-m-d");
            
        }
        
        if($request->has('branch_id') && $request->get('branch_id') != '' && $request->get('branch_id') != null){
            $monitoring = $monitoring->where('branch_id',$request->get('branch_id'));
            
        }
        if($request->has('instructor_id') && $request->get('instructor_id') != '' && $request->get('instructor_id') != null){
            $monitoring = $monitoring->where('instructor_id',$request->get('instructor_id'));
            $instructors = Employee::find($request->get('instructor_id'));
        }
        if($request->has('senior_id') && $request->get('senior_id') != '' && $request->get('senior_id') != null){
            $monitoring = $monitoring->where('senior_id',$request->get('senior_id'));
            $seniors = Employee::find($request->get('senior_id'));
        }
        if($request->has('group_id') && $request->get('group_id') != '' && $request->get('group_id') != null){
            $monitoring = $monitoring->where('group_id',$request->get('group_id'));
            $groups = Group::find($request->get('group_id'));
        }
        if($request->has('session_id') && $request->get('session_id') != '' && $request->get('session_id') != null){
            $monitoring = $monitoring->where('session_id',$request->get('session_id'));
            
        }
        if($request->has('level_id') && $request->get('level_id') != '' && $request->get('level_id') != null){
            $monitoring = $monitoring->where('level_id',$request->get('level_id'));
            
        }

        if ($daterange_from != null && $daterange_to != '') {
            $monitoring->whereBetween('created_at', [$daterange_from, $daterange_to]);
        }
        
         $monitoringcount = $monitoring->count();
        $monitoring = $monitoring->latest()->paginate(10);

         $branches = Branch::pluck('name' ,'id');
        return view('Monitoring.index',compact('monitoring','levels','seniors','branches','instructors','groups','sessions','monitoringcount' )); 
    
    }
    public function create(){
        $branches = Branch::where('status',1)->pluck('name' ,'id');
        $monitoringsections = MonitoringSections::get();
        // $MonitoringSectionTopic = MonitoringSectionTopic::get();
        $instructors=[];
        $groups =[];
        $sessions =[];
        $levels=[];
        
        return view('Monitoring.create',compact('branches','levels' ,'instructors' ,'groups','sessions','monitoringsections')); 
    }
    public function store(Request $request){
        
        // return $request->all();
        $credentials = $request->validate([
            'branch_id' => 'required',
            'instructor_id' => 'required',
            'group_id' => 'required',
            'session_id' => 'required',
            'level_id' => 'required', 
        ]);
        
        $monitoring = new Monitoring;
        $monitoring->instructor_id = $request->instructor_id;
        $monitoring->senior_id = auth()->user()->id;
        $monitoring->group_id = $request->group_id;
        $monitoring->branch_id = $request->branch_id;
        $monitoring->session_id = $request->session_id;
        $monitoring->level_id = $request->level_id;
        $monitoring->save();
        
        foreach($request->monitoring_sections_topic_id as $key => $topic){
            $topics = MonitoringSectionTopic::find($topic);
            $sectionsmonitoring = new SectionsMonitoring;
            $sectionsmonitoring->monitoring_sections_topic_id = $topic;
            $sectionsmonitoring->monitoring_id = $monitoring->id;
             $score = $request->score_type[$topic];
            $sectionsmonitoring->score = $topics->$score;
            $sectionsmonitoring->score_type = $request->score_type[$topic];
            $sectionsmonitoring->comment = $request->comment[$topic];
        
            $sectionsmonitoring->action = $request->action[$topic];           
            $sectionsmonitoring->monitoring_sections_id = $request->monitoring_sections_id[$topic];
                
            $sectionsmonitoring->save();
        }
        $sumscore =  SectionsMonitoring::where('monitoring_id',$monitoring->id)->get()->sum('score');
        $total = ($sumscore /165 ) * 100 ;

        $monitor = Monitoring::find($monitoring->id);
        $monitor->score = $total;
        $monitor->save();
        
        Flash::success(' Monitoring Create successfully.');
        
         return redirect(route('admin.Monitoring.mentorindex'));
    }
    
    public function edit(Request $request ,$id){
        $monitoring = Monitoring::with('SectionsMonitoring')->find($id);
        
        $branches = Branch::where('status',1)->pluck('name' ,'id');
         $monitoringsections = MonitoringSections::get();
        $instructors=Employee::where('account_Type', 'ESL Account Profile')
        ->where('status',1)->whereHas('branches', function ($query) use ($monitoring) {
                                $query->where('id', $monitoring->branch_id);
                            })->get()->pluck('name','id')->toArray();   
        $groups = Group::where('instructor_id',$monitoring->instructor_id)
        ->pluck('code','id')->toArray();
        $sessions =GroupSession::where('id',$monitoring->session_id)->pluck('date','id')->toArray();
      $levels = StageLevel::where('id',$monitoring->level_id)->pluck('name','id')->toArray();
         $sectionsmonitoring =  SectionsMonitoring::where('monitoring_id',$monitoring->id)->get();
          
        return view('Monitoring.edit',compact('monitoring','sessions','sectionsmonitoring','branches' ,'levels','instructors' ,'groups','monitoringsections')); 

    }
    public function update($id,Request $request){
        // dd($request->all());
        $credentials = $request->validate([
            'branch_id' => 'required',
            'instructor_id' => 'required',
            'group_id' => 'required',
            'session_id' => 'required',
            'level_id' => 'required', 
        ]);
        $monitoringsections = MonitoringSections::select('id','title')->get();
         //$sectionsmonitoring = SectionsMonitoring::where('monitoring_id',$id)->get();
        // dd($request->all());
        $monitoring = Monitoring::find($id);
        $monitoring->instructor_id = $request->instructor_id;
        $monitoring->senior_id = auth()->user()->id;
        $monitoring->group_id = $request->group_id;
        $monitoring->branch_id = $request->branch_id;
        $monitoring->session_id = $request->session_id;;
        $monitoring->level_id = $request->level_id;
        $monitoring->save();
        if($request->monitoring_sections_topic_id != null && count($request->monitoring_sections_topic_id) > 0)
        {
             SectionsMonitoring::where('monitoring_id',$monitoring->id)->delete();
            
            foreach($request->monitoring_sections_topic_id as $key => $topic){
                $topics = MonitoringSectionTopic::find($topic);
                $sectionsmonitoring = new SectionsMonitoring;
              
                $sectionsmonitoring->monitoring_sections_id   = $request->monitoring_sections_id[$topic];
                $sectionsmonitoring->monitoring_sections_topic_id = $topic;
                $sectionsmonitoring->monitoring_id = $monitoring->id;
                $score = $request->score_type[$topic];
                $sectionsmonitoring->score = $topics->$score; 
                $sectionsmonitoring->score_type = $request->score_type[$topic];
                $sectionsmonitoring->comment = $request->comment[$topic];
            
                $sectionsmonitoring->action = $request->action[$topic];           
                    
                $sectionsmonitoring->save();
            }
        }
      
       
        $sumscore =  SectionsMonitoring::where('monitoring_id',$monitoring->id)->get()->sum('score');
        $total = ($sumscore /165 ) * 100 ;
        
        
        $monitor = Monitoring::find($monitoring->id);
        $monitor->score = $total;
        $monitor->save();
        
        Flash::success('Monitor  updated successfully.');
         return redirect(route('admin.Monitoring.mentorindex'));
        
       
    }
    public function show($id){
        $monitoring = Monitoring::find($id); 
        
        $sectionsmonitoring =  SectionsMonitoring::where('monitoring_id',$monitoring->id)->get();
        $monitoringsections = MonitoringSections::get();
        return view('Monitoring.show',compact('monitoring','monitoringsections','sectionsmonitoring')); 
        
    }
    public function destroy($id){
        $monitoring = Monitoring::find($id);
        $monitoring->delete();
        Flash::success(' Monitoring delete  successfully.');
        
        return redirect(route('admin.Monitoring.mentorindex'));
    }
    public function getinstructor(Request $request){
        $instructors=[];
        $branches=[];
         $branches = Branch::where('status',1)->pluck('name', 'id');
         $instructors = Employee::where('account_Type', 'ESL Account Profile')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->where('id', $request->branch_id);
                            })->select('first_name', 'last_name','id')->get();       
        
        return $instructors;
    }
    public function getlevel(Request $request){
        $levels =[];
        
        $levels = Group::where('instructor_id',$request->instructor_id)
        ->with('subRound')->withCount('students', 'sessions')->whereHas('subRound',function($query){
                    $query->where('start_date','<=',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
                })->pluck('level_id');
        $level = StageLevel::whereIn('id',$levels)->get();
        return $level;
    }
    public function getgroup(Request $request){
        $group=[];
        $group = Group::where('instructor_id',$request->instructor_id)->where('level_id' , $request->level_id)
        ->with('subRound')->withCount('students', 'sessions')->whereHas('subRound',function($query){
                    $query->where('start_date','<=',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
                })->get();
                    
        return $group;
    }
    public function getsession(Request $request){
        $sessions=[];
        $sessions = GroupSession::where('group_id',$request->group_id)
        ->select('date','id')->get();
    
        return $sessions;
    }
    
    public function mentorindex(Request $request){
        
        $monitoring = Monitoring::orderBy('created_at','desc');
        $daterange_from = null;
        $daterange_to = null;
        $reg_to=null;
        $instructors=[];
        $seniors=[];
        $groups =[];
        $sessions =[];
        $levels=  Track::find(2)->stageLevels->pluck('name', 'id')->toArray();
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            
            $daterange = explode(' - ',$request->get('daterange'));
            $daterange_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $daterange_to= date_format($reg_to,"Y-m-d");
            
        }
        
        if($request->has('branch_id') && $request->get('branch_id') != '' && $request->get('branch_id') != null){
            $monitoring = $monitoring->where('branch_id',$request->get('branch_id'));
            
        }
        if($request->has('instructor_id') && $request->get('instructor_id') != '' && $request->get('instructor_id') != null){
            $monitoring = $monitoring->where('instructor_id',$request->get('instructor_id'));
            $instructors = Employee::find($request->get('instructor_id'));
        }
        if($request->has('senior_id') && $request->get('senior_id') != '' && $request->get('senior_id') != null){
            $monitoring = $monitoring->where('senior_id',$request->get('senior_id'));
            $seniors = Employee::find($request->get('senior_id'));
        }
        if($request->has('group_id') && $request->get('group_id') != '' && $request->get('group_id') != null){
            $monitoring = $monitoring->where('group_id',$request->get('group_id'));
            $groups = Group::find($request->get('group_id'));
        }
        if($request->has('session_id') && $request->get('session_id') != '' && $request->get('session_id') != null){
            $monitoring = $monitoring->where('session_id',$request->get('session_id'));
            
        }
        if($request->has('level_id') && $request->get('level_id') != '' && $request->get('level_id') != null){
            $monitoring = $monitoring->where('level_id',$request->get('level_id'));
            
        }

        if ($daterange_from != null && $daterange_to != '') {
            $monitoring->whereBetween('created_at', [$daterange_from, $daterange_to]);
        }
        
         $monitoringcount = $monitoring->count();
        $monitoring = $monitoring->latest()->paginate(10);

         $branches = Branch::pluck('name' ,'id');
        return view('Monitoring.seniorindex',compact('monitoring','levels','seniors','branches','instructors','groups','sessions','monitoringcount' )); 
    }
}

