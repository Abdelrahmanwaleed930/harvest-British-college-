<?php

namespace App\Http\Controllers;

use App\Http\Controllers\AppBaseController;
use App\Models\Question;
use App\Models\StageLevel;
use App\Models\Track;
use App\Models\Answer;
use Illuminate\Http\Request;
use Flash;
use Response;

class QuestionController extends AppBaseController
{
    /**
     * Display a listing of the Question.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        
        /** @var Question $questions */
        $questionsQuery = Question::whereNotIn('id', function ($query) {
            $query->select('id')->from('questions')
                ->where('skill', 'Writing')->whereNotNull('parent_id');
        });
        
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $questionsQuery->where('question','like','%'.$request->get('search').'%');
        }
        if($request->has('skill') && $request->get('skill') != null && $request->get('skill') != ''){
            $questionsQuery->where('skill', $request->get('skill'));
        }
        
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id')->toArray();
        $courses = [];
        $stageLevels = [];
        
        if($request->has('track_id') && $request->get('track_id') != null && $request->get('track_id') != ''){
            $courses = Track::where('status',1)->where('parent_id',$request->get('track_id'))->pluck('title','id');
            $questionsQuery->where('track_id',$request->get('track_id'));
        }
        
        if($request->has('course_id') && $request->get('course_id') != null && $request->get('course_id') != ''){
            $questionsQuery->where('course_id',$request->get('course_id'));
            $stageLevels = Track::find($request->get('course_id'))->stageLevels->pluck('name', 'id')->toArray();
        }
        
        if($request->has('level_id') && $request->get('level_id') != null && $request->get('level_id') != ''){
            $questionsQuery->where('level_id',$request->get('level_id'));
        }
        $questions_count = $questionsQuery->count();
        $questions = $questionsQuery->with('course','level')->orderBy('id','desc')->paginate($per_page);
        
        return view('questions.index',compact('questions','tracks','courses','stageLevels','questions_count'));
    }

    /**
     * Show the form for creating a new Question.
     *
     * @return Response
     */
    public function create()
    {
        $listeningparagraphs = Question::whereNull('parent_id')->where('skill', 'Listening')->where('level_id',99)->get()->pluck('paragraph', 'id');
        $readingparagraphs = Question::whereNull('parent_id')->where('skill', 'Reading')->where('level_id',99)->get()->pluck('paragraph', 'id');
        
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id');
        $courses=[];
        $levels=[];

        return view('questions.create',compact('readingparagraphs','listeningparagraphs','tracks','courses','levels'));
    }
    public function store(Request $request){
        $credentials = $request->validate([
            'skill' => 'required',
            'question' => 'required',
            'ideas' => 'nullable|required_if:skill,Writing|array|between:2,4',
            'parent_id' => 'nullable',
            'track_id' => 'required',
            'course_id' => 'required',
            'level_id' => 'required',
        ]);
        if($request->skill == 'Vocabulary' || $request->skill == 'Grammar')
        {
            $request->validate([
                'answers' => 'required|array',
                'is_correct'=>'required'
            ]);
        }
        if(($request->skill == 'Reading' || $request->skill == 'Listening') && $request->parent_id != null)
        {
            $request->validate([
                'answers' => 'required|array|between:2,4',
                'is_correct'=>'required'
            ]);
        }
        
        if( $request->skill == 'Writing' && $request->photo != null)
        {
            $request->validate([
                'photo' => 'image',
            ]);
        }
        if( $request->skill == 'Listening' && $request->photo != null)
        {
            $request->validate([
                'photo' => 'mimes:mp3',
            ]);
        }
        if ($request->photo) {
            $file = $request->photo->store('/');
            $credentials['photo'] = $file;
            if (env('APP_ENV') == 'production') {
                rename(storage_path('app/' . $file), '/home/harvestc/public_html/uploads/' . $file);
            } else {
                rename(storage_path('app/' . $file), public_path('uploads/' . $file));
            }
        }
        
        $question =new  Question;
        $question->skill = $request->skill;
        $question->question = $request->question;
        $question->photo = $request->photo;
      if($request->skill == 'Reading'){
           $question->parent_id = $request->parent_idr;
        }elseif($request->skill == 'Listening'){
           $question->parent_id = $request->parent_idl;
            
        }
        $question->track_id = $request->track_id;
        $question->course_id = $request->course_id;
        $question->level_id = $request->level_id;
        $question->save();

        if ($request->skill == 'Writing') {
            foreach ($request->ideas as $idea) {
                Question::create([
                    'skill' => 'Writing',
                    'parent_id' => $question->id,
                    'question' => $idea
                ]);
            }
        }
        if (isset($request->answers)) {
            foreach ($request->answers as $key => $answer) {
                if($answer !='' && $answer != null){
                    Answer::create([
                        'question_id' => $question->id,
                        'answer' => $answer,
                        'is_correct' => $request->is_correct == $key
                    ]);
                     
                 }
            }
        }
        
        Flash::success(' Question saved successfully.');
        
         return redirect(route('admin.questions.index'));
    }

    /**
     * Display the specified Question.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var Question $question */
        $question = Question::find($id);

        if (empty($question)) {
            Flash::error('Question not found');

            return redirect(route('admin.questions.index'));
        }

        return view('questions.show')->with('question', $question);
    }

    /**
     * Show the form for editing the specified Question.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var Question $question */
        $question = Question::find($id);
        $ideas = $question->children->pluck('question', 'id')->toArray();
        
        $tracks = Track::whereNull('parent_id')->pluck('title', 'id')->toArray();
        $courses = Track::whereNotNull('parent_id')->get();
        $courses = $courses->groupBy('parent_id');
        
        $levels = StageLevel::join('stages','stages.id','=','stage_levels.stage_id')
            ->select('stages.track_id','stage_levels.id','stage_levels.name','stage_levels.value')->get();
        $levels = $levels->groupBy('track_id');   
       

        
        if (empty($question)) {
            Flash::error('Question not found');

            return redirect(route('admin.questions.index'));
        }

        return view('questions.edit')->with('question', $question)->with('ideas', $ideas)->with('tracks',$tracks)->with('courses',$courses)
        ->with('levels',$levels);
    }
    public function update(Request $request , $id){
          $question = Question::find($id);
          $credentials = $request->validate([
            'question' => 'required',
            'ideas' => 'nullable|required_if:skill,Writing|array|between:2,4',
            'parent_id' => 'nullable',
            'track_id' => 'required',
            'course_id' => 'required',
            'level_id' => 'required',
        ]);
        if($request->skill == 'Vocabulary' || $request->skill == 'Grammar')
        {
            $request->validate([
                'answers' => 'required|array',
                'is_correct'=>'required'
            ]);
        }
        if(($request->skill == 'Reading' || $request->skill == 'Listening') && $request->parent_id != null)
        {
            $request->validate([
                'answers' => 'required|array|between:2,4',
                'is_correct'=>'required'
            ]);
        }
        
        if( $request->skill == 'Writing' && $request->photo != null)
        {
            $request->validate([
                'photo' => 'image',
            ]);
        }
        if( $request->skill == 'Listening' && $request->photo != null)
        {
            $request->validate([
                'photo' => 'mimes:mp3',
            ]);
        }
        if ($request->photo) {
            $file = $request->photo->store('/');
            $request->photo = $file;
            if (env('APP_ENV') == 'production') {
                rename(storage_path('app/' . $file), '/home/harvestc/public_html/uploads/' . $file);
            } else {
                rename(storage_path('app/' . $file), public_path('uploads/' . $file));
            }
        }
        else {
           $request->photo = $question->photo;
        }
        
        $question->question = $request->question;
        $question->photo = $request->photo;
  
        $question->track_id = $request->track_id;
        $question->course_id = $request->course_id;
        $question->level_id = $request->level_id;
        $question->save();
        $answers = Answer::where('question_id' ,$question->id)->get();


         if ($request->skill == 'Writing') {
            // foreach ($request->ideas as $key => $value) {
            //     $idea = Question::find($key);
            //     $idea->update([
            //         'question' => $value
            //     ]);
            // }
            foreach ($answers as $key => $answer) {
                $answers[$key]->answer = $request->ideas[$key];
                $answers[$key]->save();
            }
        }
        if (isset($request->answers)) {
            // foreach ($request->answers as $key => $value) {
            //     $answer = Answer::find($key);
            //     $answer->update([
            //         'answer' => $value,
            //         'is_correct' => $data['is_correct'] == $key
            //     ]);
            // }
            foreach($answers as $key => $answer){
             $answers[$key]->answer = $request->answers[$key];
             $answers[$key]->is_correct = $request->is_correct == $key;
             $answers[$key]->save();
            }
        }
        
        
        Flash::success(' Question Updated successfully.');
        
         return redirect(route('admin.questions.index'));
          
    }

    /**
     * Remove the specified Question from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var Question $question */
        $question = Question::find($id);

        if (empty($question)) {
            Flash::error('Question not found');

            return redirect(route('admin.questions.index'));
        }

        $question->delete();

        Flash::success('Question deleted successfully.');

        return redirect(route('admin.questions.index'));
    }
}
