<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests\CreateHrBoardingSectionsRequest;
use App\Http\Requests\UpdateHrBoardingSectionsRequest;

use App\Models\HrBoardingSections;

use Flash;
use Response;
class HrBoardingSectionsController extends Controller
{
    public function index()
    {
        $HrBoardingSections = HrBoardingSections::get();
        
        return view('HrBoardingSections.index',compact('HrBoardingSections'));
    }
    public function create()
    {
        return view('HrBoardingSections.create');
    }
    public function store(CreateHrBoardingSectionsRequest $request)
    {
        $input = $request->all();
        $HrBoardingSection = HrBoardingSections::create($input);
        
        Flash::success('HrBoardingSection saved successfully.');
        return redirect(route('admin.HrBoardingSections.index'));
    }
    public function show($id)
    {
        $HrBoardingSection = HrBoardingSections::find($id);
        if (empty($HrBoardingSection)) {
            Flash::error('Event not found');

            return redirect(route('admin.HrBoardingSections.index'));
        }
        
        return view('HrBoardingSections.show',compact('HrBoardingSection'));
    }
    public function edit($id)
    {
        $HrBoardingSection = HrBoardingSections::find($id);
        if (empty($HrBoardingSection)) {
            Flash::error('HrBoardingSections not found');

            return redirect(route('admin.HrBoardingSections.index'));
        }
        
        return view('HrBoardingSections.edit',compact('HrBoardingSection'));
    }
    public function update(UpdateHrBoardingSectionsRequest $request , $id)
    {
        $HrBoardingSection = HrBoardingSections::find($id);
        $data =  $request->all();
        if (empty($HrBoardingSection)) {
            Flash::error('HrBoardingSection not found');

            return redirect(route('admin.HrBoardingSections.index'));
        }
        $HrBoardingSection->update($data);
        Flash::success('HrBoardingSection updated successfully.');
        return redirect(route('admin.HrBoardingSections.index'));
    }
    public function destroy($id)
    {
        $HrBoardingSection = HrBoardingSections::find($id);
        if (empty($HrBoardingSection)) {
            Flash::error('HrBoardingSection not found');

            return redirect(route('admin.HrBoardingSections.index'));
        }
        $HrBoardingSection->delete();
        
        Flash::success('HrBoardingSections Deleted successfully.');
        return redirect(route('admin.HrBoardingSections.index'));
    }
}
