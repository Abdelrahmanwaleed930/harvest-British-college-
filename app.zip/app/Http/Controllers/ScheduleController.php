<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Flash;
use App\Models\Round;
use App\Models\Group;
use App\Models\Room;
use App\Models\Employee;
use App\Models\Track;
use App\Models\Timeframe;
use App\Models\GroupStudent;
// use App\Models\Round;
use App\Models\Lead;
use DB;

use App\Models\Branch;
use App\Models\SubRound;

use App\Models\DisciplineCategory;
use Illuminate\Support\Facades\Auth;

class ScheduleController extends Controller
{
    public function schedulePerRound(Request $request)
    {
        //dd('ddd');
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $rounds = Round::all();
        $instructors =[];
        //$current_day = '2022-06-01';
        $current_day = date('Y-m-d');
        
        $groups = Group::whereHas('subRound',function($query) use ($current_day){
            $query->where('start_date','<=',$current_day)->where('end_date','>=',$current_day);
        });
        if($request->branch_id != '' && $request->branch_id != null){
            $groups->where('branch_id',$request->branch_id); 
        }
        if($request->instructor_id != '' && $request->instructor_id != null){
            $groups->where('instructor_id',$request->instructor_id);
            $instructors =Employee::where('account_Type', 'ESL Account Profile')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->where('id', $request->branch_id);
                            })->select('first_name','last_name', 'id')->get()->pluck('name','id');
        }     
        $groups = $groups->with('sessions.attendances','sessions','studentexam','track','subRound','course','timeframe','round','discipline','branch','room','instructor','admin','interval','level')
        ->withCount('students','sessions','studentexam')->get(); 
       
        $groups = $groups->groupBy('round_id');          
        
        return view('schedule.schedulePerRound',compact('employeeBranches','groups','rounds','instructors'));
    }
    
    public function schedulePerRoundNext(Request $request)
    {
        //dd($request->all());
        $round = Round::find($request->round_id);
        if($request->branch_id != null && $request->branch_id != ''){
            $groups = Group::where('branch_id',$request->branch_id)->where('round_id',$round->id)->whereIn('sub_round_id',explode(',',$request->sub_rounds_ids));
        }else{
            $groups = Group::where('round_id',$round->id)->whereIn('sub_round_id',explode(',',$request->sub_rounds_ids));
        }
        $groups = $groups->with('sessions.attendances','sessions','studentexam','track','subRound','course','timeframe','round','discipline','branch','room','instructor','admin','interval','level')
        ->withCount('students','sessions','studentexam')->get();
        
        //dd($groups);
        if($request->type == 'next'){
            $nextSubRound = $round->nextSubRound($request->date);
            
            $next_date = ($nextSubRound != null && count($nextSubRound) > 0)?$nextSubRound->max('end_date'):date('Y-m-d');
            $previous_date = ($nextSubRound != null && count($nextSubRound) > 0)?$nextSubRound->min('start_date'):date('Y-m-d');
        }else{
            $previousSubRound = $round->previousSubRound($request->date);
            
            $next_date = ($previousSubRound != null && count($previousSubRound) > 0)?$previousSubRound->max('end_date'):date('Y-m-d');
            $previous_date = ($previousSubRound != null && count($previousSubRound) > 0)?$previousSubRound->min('start_date'):date('Y-m-d');
        }
        
        //dd($next_date,$previous_date,$request->date);
        //$groups = $groups->groupBy('round_id');
        //dd($groups);
        $html = view('schedule.schedulePerRoundTable',compact('round','groups','next_date','previous_date'))->render();
        return $html;
    }
    
    /*
    public function schedulePerRound(Request $request)
    {
        //dd('ddd');
        // $branches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $branches = Branch::pluck('name', 'id')->toArray();
        $id = auth()->user()->branches->pluck('id');
        // return $id;
        $rounds = Round::all();
        //$current_day = '2022-06-01';
        $current_day = date('Y-m-d');
        // $groups = new Group;
        $disciplines = DisciplineCategory::pluck('name', 'id')->toArray();

        $admins=[];
        $instructors=[];
        $rooms=[];
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id');
        //$this->rounds = Round::pluck('title', 'id')->toArray();
        $courses = [];
        $stageLevels = [];
        $timeframes = [];
        $roundss = [];
        $daysData = [];
        $intervals = [];
        $subRounds = [];
        //whereHas('subRound',function($query) use ($current_day){
            // ->where('start_date','<=',$current_day)->where('end_date','>',$current_day); })

            
        $groups=Group::with('subRound')
            ->whereHas('interval',function($query){
                $query->orderBy('pattern','asc');
            })->withCount('students', 'sessions');
        // return $groups->get();
        
        $groups = $groups->withCount('students','sessions');


        if($request->has('discipline_id') && $request->get('discipline_id') != null && $request->get('discipline_id') != ''){
            $groups->where('discipline_id',$request->get('discipline_id'));
        }
        // if($request->has('branch_id') && $request->get('branch_id') != '' && $request->get('branch_id') != null){
        //     $admins = Employee::where('account_Type', 'Operations Account')->where('status',1)
        //                     ->whereHas('branches', function ($query) use ($request) {
        //                         $query->where('id', $request->get('branch_id'));
        //                     })->get()->pluck('name', 'id')->toArray();
                            
        //     $instructors = Employee::where('account_Type', 'ESL Account Profile')->where('status',1)
        //                     ->whereHas('branches', function ($query) use ($request) {
        //                         $query->where('id', $request->get('branch_id'));
        //                     })->get()->pluck('name', 'id')->toArray();
        //                     // dd($request);

        // }
        if($request->has('branch_id') && $request->get('branch_id') != '' && $request->get('branch_id') != null){
            // $groupsQuery->where('branch_id',$request->get('branch_id'));
            // $rooms = Room::where('branch_id', $request->get('branch_id'))->pluck('name', 'id');
            $groups=$groups->where('branch_id',$request->branch_id)->whereHas('subRound',function($query) use ($current_day){
                $query->where('start_date','<=',$current_day)->where('end_date','>',$current_day);
            });
            $rooms = Room::where('branch_id', $request->get('branch_id'))->pluck('name', 'id');
            
            
            // return view('schedule.schedulePerRound',compact('employeeBranches','groups','rounds'));
           
        }
        else{
            $groups=$groups->whereIn('branch_id',$id)->with('subRound');

        }
        // if($request->branch_id != '' && $request->branch_id != null){
            
        //     $groups=$groups->where('branch_id',$request->branch_id)->whereHas('subRound',function($query) use ($current_day){
        //         $query->where('start_date','<=',$current_day)->where('end_date','>',$current_day);
        //     });
        //     $rooms = Room::where('branch_id', $request->get('branch_id'))->pluck('name', 'id');
            
        //     $groups = $groups->withCount('students','sessions')->get();

            
        //     $groups = $groups->groupBy('round_id');
        //     // return $groups;
        //     //dd($groups);
        //     // return view('schedule.schedulePerRound',compact('employeeBranches','groups','rounds'));
        // }

        if($request->has('instructor_id') && $request->get('instructor_id') != '' && $request->get('instructor_id') != null){
            $groups->where('instructor_id',$request->get('instructor_id'));
        }
        
        if($request->has('room_id') && $request->get('room_id') != '' && $request->get('room_id') != null){
            $groups->where('room_id',$request->get('room_id'));
        }
        
        if($request->has('admin_id') && $request->get('admin_id') != '' && $request->get('admin_id') != null){
            $groups->where('admin_id',$request->get('admin_id'));
        }
        if($request->has('track_id') && $request->get('track_id') != null && $request->get('track_id') != ''){
            $courses = Track::where('status',1)->where('parent_id',$request->get('track_id'))->pluck('title','id');
            $groups->where('track_id',$request->get('track_id'));
        }
        
        if($request->has('course_id') && $request->get('course_id') != null && $request->get('course_id') != ''){
            $groups->where('course_id',$request->get('course_id'));
            $stageLevels = Track::find($request->get('course_id'))->stageLevels->pluck('name', 'id')->toArray();
            $timeframe_ids = DB::table('timeframe_courses')->where('course_id',$request->get('course_id'))->pluck('timeframe_id')->toArray();
            $timeframes = Timeframe::whereIn('id',$timeframe_ids)->where('status',1)->pluck('title','id')->toArray();
        }
        
        if($request->has('level_id') && $request->get('level_id') != null && $request->get('level_id') != ''){
            $groups->where('level_id',$request->get('level_id'));
        }
        
        if($request->has('timeframe_id') && $request->get('timeframe_id') != null && $request->get('timeframe_id') != ''){
            $groups->where('timeframe_id',$request->get('timeframe_id'));
            $roundss = Round::where('timeframe_id',$request->get('timeframe_id'))->pluck('title', 'id')->toArray();
        }
        
        if($request->has('round_id') && $request->get('round_id') != null && $request->get('round_id') != ''){
            $groups->where('round_id',$request->get('round_id'));
            $round = Round::with('timeframe.intervals')->find($request->get('round_id'));

            $daysData = $round->timeframe->days;
            $intervals = $round->timeframe->intervals->pluck('name', 'id')->toArray();
            
        }
        if($request->has('days') && $request->get('days') != null && $request->get('days') != ''){
            $groups->where('days',$request->get('days'));
            $subRounds = SubRound::where('days', $request->get('days'))
                                -> where('round_id', $request->get('round_id'))
                                -> whereDate('start_date', '>=', now())
                                -> orderBy('start_date')->pluck('start_date', 'id');
        }
        
        if($request->has('interval_id') && $request->get('interval_id') != null && $request->get('interval_id') != ''){
            $groups->where('interval_id',$request->get('interval_id'));
            $request->instructor_id = '';
        }
        
        if($request->has('sub_round_id') && $request->get('sub_round_id') != null && $request->get('sub_round_id') != ''){
            $groups->where('sub_round_id',$request->get('sub_round_id'));
        }
        if($request->has('status') && $request->get('status') != '' && $request->get('status') != null){
            if($request->get('status') == 'complete'){
                $groups->whereHas('subRound',function($query){
                    $query->where('end_date','<',date('Y-m-d'));
                });
            } 
            if($request->get('status') == 'upcoming'){
                $groups->whereHas('subRound',function($query){
                    $query->where('start_date','>',date('Y-m-d'));
                });
            }
            if($request->get('status') == 'running'){
                $groups->whereHas('subRound',function($query){
                    $query->where('start_date','<=',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
                });
            }
        }

        
        
        
        $groups = $groups->with('parent', 'round', 'discipline', 'branch', 'room', 'instructor', 'interval')
        ->orderBy('round_id')
            ->orderBy('sub_round_id')
            ->orderBy('days')
            ->orderBy('interval_id')
            
        ->get();
        
        // $groups = $groups->withCount('students','sessions')->get();

            
            
        $groups = $groups->groupBy('round_id');
        //return $groups;
        //dd($rounds);
        return view('schedule.schedulePerRound',compact('branches','rounds','roundss','groups','disciplines','rooms','admins','instructors','courses','tracks','courses','stageLevels','timeframes','daysData','intervals','subRounds'));
    }
    
    public function schedulePerRoundNext(Request $request)
    {
        //dd($request->all());
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        
        
        // return $request->branch_id;
        $round = Round::find($request->round_id);
        $groups = Group::where('round_id',$round->id)
        ->whereIn('sub_round_id',explode(',',$request->sub_rounds_ids))
        ->whereHas('interval',function($query){
                $query->orderBy('sort','desc');
            });
        if($request->has('branch_id') && $request->get('branch_id') != '' && $request->get('branch_id') != null){
            
            $groups=$groups->where('branch_id',$request->branch_id);
            
        }
        else{
            $groups=$groups->whereIn('branch_id',array_keys($employeeBranches));

        }
        
        $groups = $groups->withCount('students','sessions')->orderBy('round_id')
            ->orderBy('sub_round_id')
            ->orderBy('days')
            ->orderBy('interval_id')
            ->get();
        
        
        $groups = $groups->groupBy('round_id');
        //dd($previousSubRound,$nextSubRound);
        if($request->type == 'next'){
            $nextSubRound = $round->nextSubRound($request->date);
            
            $next_date = ($nextSubRound != null && count($nextSubRound) > 0)?$nextSubRound->max('end_date'):date('Y-m-d');
            $previous_date = ($nextSubRound != null && count($nextSubRound) > 0)?$nextSubRound->min('start_date'):date('Y-m-d');
        }else{
            $previousSubRound = $round->previousSubRound($request->date);
            
            $next_date = ($previousSubRound != null && count($previousSubRound) > 0)?$previousSubRound->max('end_date'):date('Y-m-d');
            $previous_date = ($previousSubRound != null && count($previousSubRound) > 0)?$previousSubRound->min('start_date'):date('Y-m-d');
        }
        

        $html = view('schedule.schedulePerRoundTable',compact('round','groups','next_date','previous_date'))->render();
        return $html;
    }
    */
    public function getsubtrackgroup(Request $request)
    {
        // $tracks=[];
        $subtrack=[];
        $subtrack = Track::where('status',1)->where('parent_id' , $request->track_id)->select('title', 'id')->get();

        return json_decode($subtrack);

    }
    public function getlevels(Request $request)
    {
        $stageLevels=[];
        // $stageLevels = Track::find($request->course_id)->stageLevels;
        $stageLevels = Track::find($request->course_id)->stageLevels;
        // $levels = Track::where('status',1)->where('levels' , $request->levels)->get();
        return $stageLevels;
    }

    public function gettimeframes(Request $request){
        $timeframes=[];
        $timeframe_ids=[];
        $timeframe_ids = DB::table('timeframe_courses')->where('course_id',$request->course_id)->pluck('timeframe_id');
        $timeframes = Timeframe::whereIn('id',$timeframe_ids)->where('status',1)->get();
     
        return  $timeframes;
    }

    // public function getsubtrackdata(Request $request)
    // {
    //     $data = [];
    //     $stageLevels = Track::find($request->course_id)->stageLevels->pluck('name', 'id');
    //     $timeframe_ids = DB::table('timeframe_courses')->where('course_id',$request->course_id)->pluck('timeframe_id')->toArray();
    //     $timeframes = Timeframe::whereIn('id',$timeframe_ids)->where('status',1)->pluck('title','id')->toArray();
    //     $data = array_merge($stageLevels , $timeframes);
    //     return $data;

    // }
    public function getround(Request $request)
    {
        $round=[];
        $round = Round::where('timeframe_id',$request->timeframe_id)->select('title', 'id')->get();

        // $round = Round::find($request->round_id);
       return $round;
    }
    public function getsubround(Request $request){
        $round=[];
        
        $round = Round::find($request->round_id);
        $subround=[];
        $subround=SubRound::where('round_id',$round->id)->select('id','start_date')->get();
        return $subround ;

    }

    public function getinterval(Request $request)
    {
        $round = Round::with('timeframe.intervals')->find($request->round_id);

            // $daysData = $round->timeframe->days;
        $intervals=[];
        $intervals = $round->timeframe->intervals;
            
        return $intervals;
    }

    public function getday(Request $request)
    {
        // $daysData=[];
        $round = Round::with('timeframe.intervals')->find($request->round_id);

        $daysData = $round->timeframe->days;
        $html1 ='<option></option>';
        
        // for( $i = 0; $i < $length; $i++) {
        //                     // $html1 +=  data2[i] ;
        //     $html1 += '<option value="' + $daysData[$i] + '" >' + $datasData[$i] + '</option>';
        //  }
        foreach ($daysData as $data) {
            $html1 .= '<option value="' .$data . '" >' .config('system_variables.timeframes.days')[$data] . '</option>';
        }
        // sel2.html(html1);
       


        // return $daysData;
        return $html1;

    }
    

    public function getemployee(Request $request)
    {
        $branches=[];
        $admins=[];
        $branches = Branch::pluck('name', 'id');
        $admins = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->where('id', $request->branch_id);
                            })->select('first_name', 'last_name','id')->get();
        return $admins ;

    }

    public function getinstructor(Request $request)
    {
        
        $branches=[];
        $instructors=[];
        $branches = Branch::pluck('name', 'id');                            
        $instructors = Employee::where('account_Type', 'ESL Account Profile')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->where('id', $request->branch_id);
                            })->select('first_name','last_name', 'id')->get();

        return $instructors;


    }

    public function getroom(Request $request)
    {
        $rooms=[];
        $rooms = Room::where('branch_id', $request->branch_id)->select('name', 'id')->get();
        return $rooms;

    }



    




}