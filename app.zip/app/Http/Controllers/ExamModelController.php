<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ExamModel;
use App\Models\Question;
use App\Models\Track;
use App\Models\ExamModelQuestion;
use Flash;

class ExamModelController extends Controller
{
    //

    public function index(Request $request)
    {
        $exams = ExamModel::orderBy('created_at','desc');
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id');
        $per_page = 10;
        if($request->has('per_page') && $request->get('per_page') != null && $request->get('per_page') != ''){
            $per_page = $request->get('per_page');
        }

        $daterange_from = null;
        $daterange_to = null;
        $reg_to=null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $daterange_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $daterange_to= date_format($reg_to,"Y-m-d");;
            
        }

        if ($daterange_from != null && $daterange_to != '') {
            $exams->whereBetween('created_at', [$daterange_from, $daterange_to]);
        }
        $courses=[];
        
        if($request->has('track_id') && $request->get('track_id') != null && $request->get('track_id') != ''){
            $courses = Track::where('status',1)->where('parent_id',$request->get('track_id'))->pluck('title','id');
            $exams->where('track_id',$request->get('track_id'));
        }
        $stageLevels=[];
        
        if($request->has('course_id') && $request->get('course_id') != null && $request->get('course_id') != ''){
            $exams->where('course_id',$request->get('course_id'));
            $stageLevels = Track::find($request->get('course_id'))->stageLevels->pluck('name', 'id')->toArray();
            }
        
        if($request->has('level_id') && $request->get('level_id') != null && $request->get('level_id') != ''){
            $exams->where('level_id',$request->get('level_id'));
        }
        

        if ($daterange_from != null && $daterange_to != '') {
            $exams->whereBetween('created_at', [$daterange_from, $daterange_to]);
        }
        $exams = $exams->paginate($per_page);

        return view('exams_models.index',compact('exams' ,'tracks' ,'stageLevels' ,'courses'));

    }

    public function create(Request $request)
    {
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id');    
        $courses=[];
        $stageLevels=[];

        // dd($exam );
        return view('exams_models.create',compact('tracks','courses','stageLevels'));
       


    }
    public function store(Request $request)
    {
        //dd($request->all());
        $validator = $request->validate([
            'track_id' => 'required',
            'course_id' => 'required',
            'level_id'=>'required',
            'title'=>'required',
        ]);
        $exam = new ExamModel ;
        $exam->track_id = $request->track_id;
        $exam->course_id = $request->course_id;
        $exam->level_id = $request->level_id;
        $exam->title = $request->title;
        
        $exam->save();

        $question1 = Question::where('track_id',$exam->track_id)
        ->where('course_id',$exam->course_id)->where('level_id',$exam->level_id)
        ->where('skill', 'Vocabulary')->with('answers')->limit(20)->inRandomOrder()->get();
        // dd($question1[0]->id);
        $array =[];
        
        foreach ($question1 as $key => $question) {
            $exam_model_question =new ExamModelQuestion ;    
            $exam_model_question->skill = $question1[$key]->skill;
            $exam_model_question->question_id = $question1[$key]->id;
            $exam_model_question->exam_model_id =$exam->id;
            $exam_model_question->save();
        }
        // dd($question1->count());
        // dd($array);
        
        // for ($i=0 ; $i<20; $i++) {
            
        //     // array_push($array , $key);
        //     $exam_model_question->skill = 'Vocabulary';
        //     $exam_model_question->question_id = $question1[$i]->id;
        //     // $exam_model_question->exam_model_id = $exam->id;
        //     $exam_model_question->save();
        // }
        

        
        $question2 = Question::where('track_id',$exam->track_id)
        ->where('course_id',$exam->course_id)->where('level_id',$exam->level_id)
        ->where('skill', 'Grammar')->with('answers')->limit(20)->inRandomOrder()->get();

        foreach ($question2 as $key => $question) {
            $exam_model_question =new ExamModelQuestion ;    
            $exam_model_question->skill = $question2[$key]->skill;
            $exam_model_question->question_id = $question2[$key]->id;
            $exam_model_question->exam_model_id = $exam->id;
            $exam_model_question->save();
        }

        $paragraphs = Question::where('track_id',$exam->track_id)
            ->where('course_id',$exam->course_id)->where('level_id',$exam->level_id)
            ->where('skill', 'Reading')->whereNull('parent_id')
            ->with('children.answers')
            ->limit(2)->inRandomOrder()->get()->map(function ($para) {
                $para->setRelation('children', $para->children->take(5));
                return $para;
            });
            $questions1 = collect();
            foreach($paragraphs as $paragraph){
                foreach($paragraph->children as $question){
                    $questions1->push($question);
                }
            }
            foreach ($questions1 as $key => $question) {
                $exam_model_question =new ExamModelQuestion ;    
                
                $exam_model_question->skill = $question->skill;
                $exam_model_question->question_id = $question->id;
                $exam_model_question->parent_id = $question->parent_id;
                $exam_model_question->exam_model_id = $exam->id;
                $exam_model_question->save();
            }


            $paragraphs2 = Question::where('track_id',$exam->track_id)
            ->where('course_id',$exam->course_id)->where('level_id',$exam->level_id)
            ->where('skill', 'Listening')->whereNull('parent_id')
            ->with('children.answers')
            ->limit(1)->inRandomOrder()->get()->map(function ($para) {
                $para->setRelation('children', $para->children->take(10));
                return $para;
            });
            $questions2 = collect();
            foreach($paragraphs2 as $paragraph){
                foreach($paragraph->children as $question){
                    $questions2->push($question);
                }
            }
            foreach ($questions2 as $key => $question) {

                $exam_model_question =new ExamModelQuestion ;    
                $exam_model_question->skill = $question->skill;
                $exam_model_question->question_id = $question->id;
                $exam_model_question->exam_model_id = $exam->id;
                $exam_model_question->parent_id = $question->parent_id;
                $exam_model_question->save();
            }
            
            $question3 = Question::where('track_id',$exam->track_id)
            ->where('course_id',$exam->course_id)
            ->where('level_id',$exam->level_id)->where('skill', 'Writing')->whereNull('parent_id')
            ->with('children')
            ->limit(2)->inRandomOrder()->get();
            foreach ($question3 as $key => $question) {
                $exam_model_question =new ExamModelQuestion ;    
                $exam_model_question->skill = $question3[$key]->skill;
                $exam_model_question->question_id = $question3[$key]->id;
                $exam_model_question->exam_model_id = $exam->id;
                $exam_model_question->save();
            }
            // dd($array);

        
        Flash::success(' Exam Create successfully.');
        return redirect(route('admin.examsModels.index'));

    }


    // public function showquestion



    public function show( $id)
    {
        $exam = ExamModel::with('exam_model_questions')->find($id);

        $exam_model_question = ExamModelQuestion::with('question.answers')->with('question.parent')->where('exam_model_id' , $exam->id)->get();
        
        
        $question = ExamModelQuestion::where('exam_model_id' , $exam->id)->pluck('question_id')->toArray();
             
        $Reading_questions = Question::whereIn('id' , $question)->where('skill','Reading')->with('answers','parent')->get()->groupBy('parent_id');
        $Listening_questions = Question::whereIn('id' , $question)->where('skill','Listening')->with('answers','parent')->get()->groupBy('parent_id');
        //dd($Listening_questions);
        return view('exams_models.show',compact('exam' ,'exam_model_question','Reading_questions','Listening_questions'));

    }
    
    public function destroy($id)
    {
        $exam_model = ExamModel::find($id);

        if (empty($exam_model)) {
            Flash::error('Exam Model not found');

            return redirect(route('admin.examsModels.index'));
        }

        $exam_model->delete();

        Flash::success('Exam Model deleted successfully.');

        return redirect(route('admin.examsModels.index'));

    }
}
