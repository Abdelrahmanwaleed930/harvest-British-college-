<?php

namespace App\Http\Controllers;

use App\Http\Controllers\AppBaseController;
use App\Exports\GroupStudentExport;
use App\Models\Group;
use App\Models\GroupSession;
use App\Models\GroupStudent;
use App\Models\StageLevel;
use Illuminate\Http\Request;
use App\Models\CustomerTrack;
use App\Models\MessageLog;
use App\Models\Lead;
use App\Models\WhatsApp;
use App\Models\StudentExam;

use Maatwebsite\Excel\Facades\Excel;
use Flash;
use Response;

use Auth;
// use Response;
use Spatie\Activitylog\Contracts\Activity;

class GroupStudentController extends AppBaseController
{
    /**
     * Display the specified Group.
     *
     * @param int $id
     *
     * @return Response
     */

    public function show($id)
    {
        /** @var Group $group */
        //dd($id);
        $group = Group::with('students.lead.attendances')->with('students',function($query){
                                    $query->where('Confirmation',1)->where('finance_status',1);
                                })->withCount('students', 'sessions' )->find($id);
        // return $group;
        $similar_groups = Group::where('track_id',$group->track_id)
                                ->where('course_id',$group->course_id)
                                ->where('discipline_id',$group->discipline_id)
                                /*->where('timeframe_id',$group->timeframe_id)*/
                                ->where('level_id',$group->level_id)
                                //->where('round_id',$group->round_id)
                                ->whereHas('subRound',function($query){
                                    $query->where('end_date','>=',date('Y-m-d'));
                                })->where('id','!=',$group->id)
                                ->withCount('students')->orderBy('interval_id')->get();
        //dd($similar_groups);
        $totalstudentexam = StudentExam::where('group_id' , $group->id)->count();
         $totalstudentexamcorrect = GroupStudent::where('group_id' , $group->id)->whereNotNull('exam_per')->count();
        $pastSessions = GroupSession::where('group_id', $group->id)->where('status', '!=', 1)->count();
        
        $next_level = StageLevel::join('stages','stages.id','=','stage_levels.stage_id')
                                ->where('stages.track_id',$group->course_id)->where('stage_levels.id','>',$group->level_id)
                                ->orderBy('stage_levels.id')->select('stage_levels.*')->first();
        
        $upgrade_groups = [];
        if($next_level != null){
            
            $upgrade_groups = Group::leftJoin('sub_rounds','sub_rounds.id','=','groups.sub_round_id')
                ->where('groups.track_id',$group->track_id)
                ->where('groups.course_id',$group->course_id)
                ->where('groups.discipline_id',$group->discipline_id)
                ->where('groups.timeframe_id',$group->timeframe_id)
                ->where('groups.round_id',$group->round_id)
                ->where('groups.level_id',$next_level->id)
                ->where('groups.branch_id',$group->branch_id)
                ->where('sub_rounds.end_date','>=',date('Y-m-d'))
                //->where('parent_id',($group->parent_id != null && $group->parent_id != '')?$group->parent_id:$group->id)
                ->orderBy('sub_rounds.start_date')->select('groups.*')->get();
            
            //dd($upgrade_group);
            // return $group;
            if(count($upgrade_groups) == 0){
                    
                $upgrade_groups = Group::leftJoin('sub_rounds','sub_rounds.id','=','groups.sub_round_id')
                    ->where('groups.track_id',$group->track_id)
                    ->where('groups.course_id',$group->course_id)
                    ->where('groups.timeframe_id',$group->timeframe_id)
                    ->where('groups.round_id',$group->round_id)
                    ->where('groups.level_id',$next_level->id)
                    //->where('groups.days',$group->days)
                    ->where('sub_rounds.end_date','>=',date('Y-m-d'))
                    ->where('groups.discipline_id',$group->discipline_id)
                    ->where('groups.branch_id',$group->branch_id)
                    //->where('instructor_id',$group->instructor_id)
                    //->where('interval_id',$group->interval_id)
                    //->where('parent_id',($group->parent_id != null && $group->parent_id != '')?$group->parent_id:$group->id)
                    ->orderBy('sub_rounds.start_date')->select('groups.*')->get();
            }
            //dd($upgrade_group);
        }

            
        if (empty($group)) {
            Flash::error('Group  not found');

            return redirect(route('admin.groups.index'));
        }
        
        /*
        if($group->students != null && count($group->students) > 0){
            foreach($group->students as $student){
                $student_exam = StudentExam::where('lead_id',$student->lead_id)->where('student_id',$student->id)->where('group_id',$student->group_id)->with('lead')->first();
                $lead = $student->lead;
                if($student_exam != null && $student_exam != ''){
                    
                    //dd($student_exam,$lead);
                    if($student->exam_status != null && $student->exam_status != ''){
                        if($student->exam_status == 'fail'){
                            $lead->type = 2;
                            $lead->customer_type = "fail";
                            $lead->save();
                            
                            GroupWaitingList::where('lead_id',$lead->id)->delete();
                            $waiting_list = new GroupWaitingList;
                            $waiting_list->create([
                                'lead_id' => $lead->id,
                                'level_id' => $student->level_id,
                                'timeframes' =>  $group->timeframe_id,
                                'discipline_id' => $group->discipline_id,
                            ]);
                            
                        }elseif($student->exam_status == 'pass'){
                            $customer_track = CustomerTrack::where('lead_id',$lead->id)->first();
                            
                            if($customer_track != null && $customer_track != ''){
                                if($customer_track->total > $customer_track->used){
                                    
                                    $lead->customer_type = "current";
                                    $lead->save();
                                    
                                    if($next_level != null){
                                        $upgrade_group = Group::leftJoin('sub_rounds','sub_rounds.id','=','groups.sub_round_id')
                                            ->where('groups.track_id',$group->track_id)
                                            ->where('groups.course_id',$group->course_id)
                                            ->where('groups.discipline_id',$group->discipline_id)
                                            ->where('groups.timeframe_id',$group->timeframe_id)
                                            ->where('groups.round_id',$group->round_id)
                                            ->where('groups.level_id',$next_level->id)
                                            ->where('groups.branch_id',$group->branch_id)
                                            ->where('sub_rounds.end_date','>=',date('Y-m-d'))
                                            ->where('parent_id',($group->parent_id != null && $group->parent_id != '')?$group->parent_id:$group->id)
                                            ->orderBy('sub_rounds.start_date')->select('groups.*')->first();
                                        
                                        //dd($upgrade_group);
                                        // return $group;
                                        if(! ($upgrade_group != null && $upgrade_group != '')){
                                                
                                            $upgrade_group = Group::leftJoin('sub_rounds','sub_rounds.id','=','groups.sub_round_id')
                                                ->where('groups.track_id',$group->track_id)
                                                ->where('groups.course_id',$group->course_id)
                                                ->where('groups.timeframe_id',$group->timeframe_id)
                                                ->where('groups.round_id',$group->round_id)
                                                ->where('groups.level_id',$next_level->id)
                                                //->where('groups.days',$group->days)
                                                ->where('sub_rounds.end_date','>=',date('Y-m-d'))
                                                ->where('groups.discipline_id',$group->discipline_id)
                                                ->where('groups.branch_id',$group->branch_id)
                                                //->where('instructor_id',$group->instructor_id)
                                                //->where('interval_id',$group->interval_id)
                                                //->where('parent_id',($group->parent_id != null && $group->parent_id != '')?$group->parent_id:$group->id)
                                                ->orderBy('sub_rounds.start_date')->select('groups.*')->first();
                                        }
                                        
                                        $check_group_student = GroupStudent::where('level_id',$next_level->id)->where('lead_id',$lead->id)->first();
                                        if($upgrade_group != null && $upgrade_group != ' '){
                                            //dd($upgrade_group);
                                            $sessions = GroupSession::with('level')->where('group_id', $upgrade_group->id)->get();
                                            if(! $check_group_student){
                                                $group_student = GroupStudent::create([
                                                    'group_id' => $upgrade_group->id,
                                                    'lead_id' => $lead->id,
                                                    'level_id' => $next_level->id,
                                                    'payment' => $student->payment,
                                                    'lead_payment_id' => $student->lead_payment_id,
                                                    'Confirmation'=>1,
                                                ]);
                                                
                                                foreach ($sessions as $session) {
                                                    $session->attendances()->create([
                                                        'lead_id' => $lead->id,
                                                        'group_id' => $session->group_id,
                                                        'level_id' => $session->level_id,
                                                    ]);
                                                }
                                                
                                                $customer_track->used += 1;
                                                $customer_track->save();
                                            }
                                        
                                        }
                                    }
                                }
                                else{
                                    $lead->type = 2;
                                    $lead->customer_type = "activation";
                                    $lead->save(); 
                                    
                                    GroupWaitingList::where('lead_id',$lead->id)->delete();
                                    
                                    $waiting_list = new GroupWaitingList;
                                    $waiting_list->create([
                                        'lead_id' => $lead->id,
                                        'level_id' => $next_level->id,
                                        'timeframes' =>  $student->group->timeframe_id,
                                        'discipline_id' => $student->group->discipline_id,
                                    ]);
                                }
                            }
                        }else{
                            
                        }
                    }
                }else{
                    $attendance_count = $lead->attendances->where('lead_id',$lead->id)->where('group_id',$group->id)->where('attendance',1)->count();
                    
                    if($attendance_count <= 1){
                        
                        $lead->type = 2;
                        $lead->customer_type = "missing";
                        $lead->save();
                        
                        GroupStudent::where('id',$student->id)->delete();
                        
                        GroupWaitingList::where('lead_id',$lead->id)->delete();
                        $waiting_list = new GroupWaitingList;
                        $waiting_list->create([
                            'lead_id' => $lead->id,
                            'level_id' => $student->level_id,
                            'timeframes' =>  $group->timeframe_id,
                            'discipline_id' => $group->discipline_id,
                        ]);
                    }
                }
                
            }
        }
        */
        return view('group_students.show', compact('group', 'pastSessions','similar_groups','next_level','upgrade_groups','totalstudentexamcorrect','totalstudentexam'));
    }

    public function levelsTransferStudents(Request $request)
    {
        
        $students_ids = $request->students_ids;
        if($students_ids != null && count($students_ids) > 0 && $request->upgrade_group_id != null && $request->upgrade_group_id != ''){
            $current_group = Group::findOrFail($request->upgrade_group_id);
            $sessions = GroupSession::with('level')->where('group_id', $request->upgrade_group_id)->get();

            foreach($students_ids as $student_id){
                $check_group_student = GroupStudent::where('level_id',$request->next_level_id)->where('lead_id',$student_id)->first();
                $current_group_student = GroupStudent::where('group_id',$request->current_group_id)->where('lead_id',$student_id)->first();
                if(! $check_group_student){
                    $group_student = GroupStudent::create([
                        'group_id' => $request->upgrade_group_id,
                        'lead_id' => $student_id,
                        'level_id' => $request->next_level_id,
                        'payment' => $current_group_student->payment,
                        'lead_payment_id' => $current_group_student->lead_payment_id,
                        'Confirmation' => 1,
                        'finance_status' => 1,
                    ]);
                    
                    $lead = Lead::find($student_id);
                    $lead->customer_type = "current";
                    $lead->save();
                    
                    $customer_track = CustomerTrack::where('lead_id',$student_id)->where('track_id',$current_group->track_id)->where('course_id',$current_group->course_id)->first();
                    $customer_track->used += 1;
                    $customer_track->save();
                    
                    foreach ($sessions as $session) {
                        $session->attendances()->create([
                            'lead_id' => $student_id,
                            'group_id' => $session->group_id,
                            'level_id' => $session->level_id,
                        ]);
                        
                        
                    }
                    if($current_group->course_id == 13)
                    {
                        // create student exam
                         $group_student = GroupStudent::where('group_id',$current_group->id)->where('lead_id',$student_id)->where('level_id',$current_group->level_id)->first();
                        $student_exam = StudentExam::updateOrCreate([
                            'group_id' => $current_group->id,
                            'lead_id' => $student_id,
                            'track_id' => $current_group->track_id,
                            'course_id' => $current_group->course_id,
                            'level_id' => $current_group->level_id,
                            'student_id' => $group_student->id,
                            'finish'=>1,
                        ]);
                        
                    }
                    // $lead = Lead::where('id',$student_id)->first();
                    $customer_track->last_group_id = $current_group->id;
                    $customer_track->last_level_id = $current_group->level_id;
                    $customer_track->save();
                    
                
                     activity('Group student')
                       ->causedBy(Auth::user()->id)
                       ->performedOn($current_group)
                       ->withProperties(['student_id' =>$student_id ])
                       ->log('Level Transfer Student');
        
                }
                
            }
            /*
            $mobiles = Lead::whereIn('id',$students_ids)->pluck('mobile_1')->toArray();

            $group = $current_group;
            $buttons = [
                'templateButtons' => [
                    ['index' => 1, 'urlButton' => ['displayText' => 'Visit your profile', 'url' => 'https://harvestcollege.co.uk/customerPortal/courses']],
                ],
            ];
            $whatsApp = new WhatsApp;
               
            $msg = 'جاهزين نبدأ رحلتنا؟😎
              معاك Harvest  هنكون بنتابع معاك دايما من 11صباحا ل9 مساءا ماعدا الجمعة
              حابين حابين نأكد مع حضرتك ان بداية موعدك الدراسى يوم'. config('system_variables.timeframes.days')[$group->days]  .  
              'من الساعة '. $group->interval->name .'
              فى دبلومة '. $group->course->title .' 
              فى الفترة '. $group->subRound->start_date  .'-'.  $group->subRound->end_date .'
              فى فرع '. $group->branch->name  .'
              
              بنتمنالك يوم سعيد و وقت مميز تقضيه معانا🌸
              Have a nice day🌸
              لتأكيد الحجز';
            $whatsApp->send($mobiles, $msg ,$buttons);
      
            $log = MessageLog::create([
                'type' => 2,
                'content' => $msg
            ]);
            $log->leads()->sync(array_keys($mobiles));
            */
                  
            Flash::success('students transfered successfully');
        }else{
            Flash::error('please select students first and upgrate group');
        }
  
        return redirect()->back();
    }      
    
    public function edit($id)
    {
        $student = GroupStudent::findOrFail($id);
        $group = $student->group;
        
        return view('group_students.edit', compact('student','group'));
    }
    
    public function update($id,Request $request)
    {
        //dd($request->all());
        $student = GroupStudent::findOrFail($id);
        $data = $request->except('_token','_method');
        $student->update($data);
        
        
         activity('Group student')
           ->causedBy(Auth::user()->id)
           ->performedOn($student->lead)
           ->withProperties(['group_student_id' =>$student->group_id ])
           ->log('update Group Student');
        
        return redirect()->route('admin.groupStudents.show',$student->group_id);
    }
    public function exportstudentexcel($id)
    {
        return Excel::download(new GroupStudentExport( $id ), 'groupstudent_'.date('Y-m-d H:i').'.xlsx'); 

    }
    public function setconfirmation($group_id,$lead_id,Request $request){
        // $customer = Lead::find($)
        
        $students = GroupStudent::where('lead_id',$lead_id)->where('group_id' , $group_id);
       
        $confirmation =$request->Confirmation;
        $students = $students->update(['Confirmation'=>$confirmation]);
        if($confirmation == 1)
        {
            $customer_track = CustomerTrack::where('lead_id',$lead_id)->first();
            $customer_track->used += 1;
            $customer_track->save();
        }
    
        return redirect('/groupStudents/'. $group_id);
    }

    
}
