<?php

namespace App\Http\Controllers;

use Flash;
use Response;
use DB;
use App\Models\Lead;
use App\Models\Offer;
use App\Models\SubRound;
use App\Models\Branch;
use App\Models\Employee;
use App\Models\StageLevel;
use App\Models\Timeframe;
use App\Models\LeadSource;
use App\Models\Round;
use App\Models\KnowChannel;
use App\Models\Interval;
use App\Models\Group;
use App\Models\OldCustomerPayment;
use App\Models\CustomerTrack;
use App\Models\Country;
use App\Models\Governorate;
use App\Models\City;
use App\Models\LeadSourceTrack;
use App\Models\MessageLog;
use App\Models\GroupStudent;
use App\Models\SubPayment;
use App\Models\CustomerJob;
use App\Models\PlacementApplicant;
use App\Models\LeadCase;
use App\Models\LeadPayment;
use App\Models\LabelType;
use App\Models\GroupWaitingList;
use App\Models\University;
use App\Models\Track;
use App\Models\Invoice;
use App\Models\RefundRequest;
use App\Models\DisciplineCategory;
use App\Models\GroupSessionAttendance;
use Illuminate\Http\Request;
use App\Models\TrainingService;
use App\Http\Requests\CreateLeadRequest;
use App\Http\Requests\CreateCustomerRequest;
use App\Http\Requests\UpdateLeadRequest;
use App\Http\Controllers\AppBaseController;
use App\Imports\CustomerImport;
use App\Exports\ExportCustomer;
use App\Exports\ExportClient;
use Maatwebsite\Excel\Facades\Excel;
use Auth;

use Spatie\Activitylog\Contracts\Activity;


class CustomerController extends AppBaseController
{
    /**
     * Display a listing of the Lead.
     *
     * @param Request $request
     *
     * @return Response
     */
     
     public function show_wait_customer_confirm(Request $request){
        
        $show_wait_customer_confirm = GroupStudent::leftJoin('placement_applicants','placement_applicants.lead_id','=','group_students.lead_id')
        ->leftJoin('customer_tracks','customer_tracks.lead_id','=','group_students.lead_id')->with('lead');
        
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $show_wait_customer_confirm->whereHas('lead',function ($query) use ($request){
                $query->where('name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('mobile_1', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('email', 'like', '%' . $request->get('search') . '%');
            });
        }  
        if($request->has('group_id') && $request->get('group_id') != null && $request->get('group_id') != ''){
            $show_wait_customer_confirm->where('group_students.group_id',$request->get('group_id'));
        }
        if ($request->has('branch_id') && $request->get('branch_id') != null && $request->get('branch_id') != '') {
            $show_wait_customer_confirm->whereHas('lead',function ($query) use ($request){
                $query->where('branch_id', $request->get('branch_id') );
            });
        }
        
        $show_wait_customers_confirm=$show_wait_customer_confirm->where('Confirmation',0)->where('finance_status',0)->paginate(10);
        $total = $show_wait_customer_confirm->where('Confirmation',0)->where('finance_status',0)->count();
        return view('customers.customer_confirm',compact('show_wait_customers_confirm','total','employeeBranches'));
    } 
    public function show_wait_finance_confirm(Request $request){
        
        $show_wait_finance = GroupStudent::leftJoin('placement_applicants','placement_applicants.lead_id','=','group_students.lead_id')
        ->leftJoin('customer_tracks','customer_tracks.lead_id','=','group_students.lead_id')->with('lead');
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $show_wait_finance->whereHas('lead',function ($query) use ($request){
                $query->where('name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('mobile_1', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('email', 'like', '%' . $request->get('search') . '%');
            });
        }
        $total = $show_wait_finance->where('Confirmation',1)->where('finance_status',0)->count();
       $show_wait_finance_confirm=$show_wait_finance->where('Confirmation',1)->where('finance_status',0)->paginate(10);
        
        
        return view('customers.finance_confirm',compact('show_wait_finance_confirm','total'));
    }  
    public function financesetconfirmation($group_id,$lead_id,Request $request){
        
        $students = GroupStudent::where('lead_id',$lead_id)->where('group_id' , $group_id);
        $group1 = Group::find($group_id);  
        $confirmation =$request->Confirmation;
        $students = $students->update(['finance_status'=>$confirmation , 'finance_employee_id'=>Auth::user()->id]);
        if($confirmation == 1)
        {
            $customer_track = CustomerTrack::where('lead_id',$lead_id)->first();
            $customer_track->used += 1;
            $customer_track->last_group_id = $group_id;
            $customer_track->last_level_id = $group1->level_id;
            $customer_track->save();
        }else{
            
            GroupStudent::where('lead_id',$lead_id)->where('group_id' , $group_id)->delete();
            GroupSessionAttendance::where('lead_id',$lead_id)->where('group_id',$group_id)->delete();
            $group = Group::find($group_id);
            GroupWaitingList::where('lead_id',$lead_id)->delete();
            $waiting_list = new GroupWaitingList;
            $waiting_list->create([
                'lead_id' => $lead_id,
                'level_id' => $group->level_id,
                'track_id' => $group->track_id,
                'course_id' => $group->course_id,
                'timeframes' => $group->timeframe_id,
                'discipline_id' => $group->discipline_id,
            ]);
            $lead = Lead::find($lead_id);
            $lead->type = 2;
            $lead->customer_type = "reject";
            $lead->save();
        
        }
        
    
       return redirect()->back();
    }
    public function showpackage($id){
         $lead = CustomerTrack::where('lead_id' , $id)->first(); 
        
       return view('customers.updatepackage',compact('lead'));
        
    }
     public function updatepackage(Request $request,$id){
        $customer = CustomerTrack::where('lead_id' , $id)->first();
        $customer->total = $request->total;
        $customer->used = $request->used;
        $customer->save();
        $redirect_url = route('admin.database.index').'?type=2';
        return redirect($redirect_url);
        
    }
    
    public function operationInquiryDelete(Request $request)
    {
        if ($request->ids != null && count($request->ids) > 0) {
            LeadCase::whereIn('id', $request->ids)->delete();

            Flash::success('Deleted Successfully.');

            $this->show_delete = false;
            $this->selected = [];
        } else {
            Flash::error('Selected Leads is required.');
        }
        return 0;
    }
    
    public function operationInquiryAssign(Request $request)
    {
        //dd($request->all());
        if (!$request->employee_id) {
            Flash::error('Assigned Employee is required.');
        } elseif ($request->ids != null && count($request->ids) > 0) {
            LeadCase::whereIn('id', $request->ids)->update(['employee_id' => $request->employee_id]);

            Flash::success('Assigned Successfully.');
        } else {
            Flash::error('Selected Inquiries is required.');
        }
        return 0;
    }
    
    public function operationInquiry($status,Request $request)
    {
        //dd('dddd');
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $agents = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        
        //$leadSources = LeadSource::where('id', '!=', 6)->where('status',1)->pluck('name', 'id')->toArray();
        //$knowChannels = KnowChannel::pluck('name', 'id')->toArray();
        //$services = TrainingService::pluck('title', 'id')->toArray();
        //$offers = Offer::pluck('title', 'id')->toArray();
        
        $labelTypes = LabelType::where('status', 1)->where('category', 4)->pluck('name', 'id')->toArray();
        
        //$labelTypes_without_not_interested = $labelTypes;
        //unset($labelTypes_without_not_interested[12]);
        $followupsQuery = LeadCase::leftJoin('leads','leads.id','=','lead_cases.lead_id')
            //->where('lead_cases.status', 0)
            ->whereIn('lead_cases.label_type_id',array_keys($labelTypes))
            /*->whereDate('lead_cases.date', '<=', now())*/;
        if($status == 'open'){
            $followupsQuery->where('lead_cases.status', 0);
        }else{
            $followupsQuery->where('lead_cases.status', 1);
        }
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $followupsQuery->where(function ($query) use ($request){
                $query->where('leads.name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.mobile_1', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.email', 'like', '%' . $request->get('search') . '%');
            });
        }
        $registration_from = null;
        $registration_to = null;
        if ($request->has('registration_daterange') && $request->get('registration_daterange') != null && $request->get('registration_daterange') != '') {
            $daterange = explode(' - ',$request->get('registration_daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
        }
         if ($registration_from != null && $registration_to != '') {
            
            $followupsQuery->whereBetween('lead_cases.created_at', [$registration_from, $registration_to]);
        }
        if ($request->has('branches') && $request->get('branches') != null && $request->get('branches') != '') {
            $followupsQuery->whereIn('leads.branch_id', $request->get('branches'));
        }else {
            $followupsQuery->whereIn('leads.branch_id', array_keys($employeeBranches));
        }
        if($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
            $followupsQuery->where('leads.assigned_employee_id', $request->get('agent'));
        }
        if(!auth()->user()->can('followup manager')){
            //dd('ddd');
            $followupsQuery->where('lead_cases.employee_id', auth()->id());
        }
        if($request->has('label_type_id') && $request->get('label_type_id') != null && $request->get('label_type_id') != ''){
            $followupsQuery->where('lead_cases.label_type_id', $request->get('label_type_id'));
        }
        $followupsCount = $followupsQuery->count();
        $followups = $followupsQuery->select('lead_cases.id','lead_cases.created_at','lead_cases.branch_id','lead_cases.employee_id','lead_cases.lead_id','lead_cases.label_type_id','lead_cases.action_id','lead_cases.date')->with('lead')->orderBy('lead_cases.id','desc')->paginate($per_page);
    // return $followups;
        return view('customers.operationInquiry',compact('followupsCount','followups'/*,'leadSources','knowChannels','services','offers'*/,'labelTypes','agents','employeeBranches'));
    }
    
    public function complainInquiry($status,Request $request)
    {
        //dd('dddd');
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $agents = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        $labelTypes = LabelType::where('status', 1)->where('category', 7)->pluck('name', 'id')->toArray();
        
        $followupsQuery = LeadCase::leftJoin('leads','leads.id','=','lead_cases.lead_id')
            
            ->whereIn('lead_cases.label_type_id',array_keys($labelTypes));
        if($status == 'open'){
            $followupsQuery->where('lead_cases.status', 0);
        }else{
            $followupsQuery->where('lead_cases.status', 1);
        }
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $followupsQuery->where(function ($query) use ($request){
                $query->where('leads.name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.mobile_1', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.email', 'like', '%' . $request->get('search') . '%');
            });
        }
        $registration_from = null;
        $registration_to = null;
        if ($request->has('registration_daterange') && $request->get('registration_daterange') != null && $request->get('registration_daterange') != '') {
            $daterange = explode(' - ',$request->get('registration_daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
        }
         if ($registration_from != null && $registration_to != '') {
            
            $followupsQuery->whereBetween('lead_cases.created_at', [$registration_from, $registration_to]);
        }
        if ($request->has('branches') && $request->get('branches') != null && $request->get('branches') != '') {
            $followupsQuery->whereIn('leads.branch_id', $request->get('branches'));
        }else {
            $followupsQuery->whereIn('leads.branch_id', array_keys($employeeBranches));
        }
        if($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
            $followupsQuery->where('leads.assigned_employee_id', $request->get('agent'));
        }
        if(!auth()->user()->can('followup manager')){
            //dd('ddd');
            $followupsQuery->where('lead_cases.employee_id', auth()->id());
        }
        if($request->has('label_type_id') && $request->get('label_type_id') != null && $request->get('label_type_id') != ''){
            $followupsQuery->where('lead_cases.label_type_id', $request->get('label_type_id'));
        }
        $followupsCount = $followupsQuery->count();
        $followups = $followupsQuery->select('lead_cases.id','lead_cases.select_employee_id','lead_cases.created_at','lead_cases.branch_id','lead_cases.employee_id','lead_cases.lead_id','lead_cases.label_type_id','lead_cases.action_id','lead_cases.date')->with('lead')->orderBy('lead_cases.id','desc')->paginate($per_page);
        return view('customers.complain',compact('followupsCount','followups','labelTypes','agents','employeeBranches'));
    }
    
    public function index(Request $request)
    {
        //dd($request->all());
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $branches = Branch::where('status',1)->pluck('name', 'id');
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id')->toArray();
        //$this->rounds = Round::pluck('title', 'id')->toArray();
        $disciplines = DisciplineCategory::pluck('name', 'id')->toArray();
        
        //dd($courses);
        $agents = [];
        if($request->has('current_branches') && $request->get('current_branches') != '' && $request->get('current_branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            /*->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('current_branches'));
                            })->*/->whereIn('current_branch' , $request->get('current_branches'))->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->get()->pluck('name', 'id')->toArray();
        }
        
        $registration_from = null;
        $registration_to = null;
        if ($request->has('registration_daterange') && $request->get('registration_daterange') != null && $request->get('registration_daterange') != ''){
            $daterange = explode(' - ',$request->get('registration_daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            // $registration_to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
        } 
        $leadSources = LeadSource::where('id', '!=', 6)->where('status',1)->pluck('name', 'id')->toArray();
        $knowChannels = KnowChannel::pluck('name', 'id')->toArray();
        $type = ($request->type != '' && $request->type != null)?$request->type:2;
        $track = $request->track_id;
        $label_type = LabelType::where('status',1)->where('category',$request->type)->pluck('name','id')->toArray();

        // return $labelTypes;
        
        $leadsQuery = Lead::leftJoin('placement_applicants','placement_applicants.lead_id','=','leads.id')
            ->whereRaw('(placement_applicants.track_id = '.$track.' or placement_applicants.track_id is null)');
            //->where('leads.type', $type);
        
        // dd($leadsQuery);
        if($type == 2){
         $leadsQuery->leftJoin('group_waiting_lists','group_waiting_lists.lead_id','=','leads.id')
                ->whereRaw('(group_waiting_lists.track_id = '.$track.' or (leads.type = 2 and leads.prefered_track_id = '.$track.' and group_waiting_lists.track_id is null))');
            
        }elseif($type == 3){
            $leadsQuery->leftJoin('customer_tracks','customer_tracks.lead_id','=','leads.id')
                ->where('customer_tracks.track_id', $track)
                ->whereNotNull('customer_tracks.last_level_id')
                ->whereNotNull('customer_tracks.last_group_id');
        }else{
            
        }
        
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $leadsQuery->where(function ($query) use ($request){
                $query->where('leads.name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.mobile_1', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.email', 'like', '%' . $request->get('search') . '%');
            });
        }elseif(auth()->user()->can('leads leadsAssign')){
            
            $leadsQuery->whereIn('leads.branch_id', array_keys($employeeBranches));
        }else{
             $leadsQuery->where('leads.assigned_employee_id', auth()->id());
        }
        //dd(implode(',',array_keys($employeeBranches)));
        if($request->has('lead_type') && $request->get('lead_type') != null && $request->get('lead_type') != ''){
            $leadsQuery->where('leads.type', $request->get('lead_type'));
        }
        
        // return $leadsQuery->get;
        $labelsType=$request->get('label_type');
        if($request->has('label_type') && $request->get('label_type') != null && $request->get('label_type') != ''){
            
            $leadsQuery->with('lastcase')->whereHas('lastcase',function($q) use ($labelsType)
            {
                $q->where('label_type_id',$labelsType);

            });
        }
        
        // if($request->has('lead_type') && $request->get('lead_type') != null && $request->get('lead_type') != ''){
        //     $leadsQuery->where('type', $request->get('lead_type'));
        // }
        
        if($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
            $leadsQuery->where('leads.assigned_employee_id', $request->get('agent'));
        }
        
        if($request->has('assignedToMe') && $request->get('assignedToMe') != null && $request->get('assignedToMe') != ''){
            $leadsQuery->where('leads.assigned_employee_id', auth()->id());
        }
        
        if($request->has('know_channel') && $request->get('know_channel') != null && $request->get('know_channel') != ''){
            $leadsQuery->where('leads.know_channel_id', $request->get('know_channel'));
        }
        
        if ($request->has('lead_source') && $request->get('lead_source') != null && $request->has('lead_source') != '') {
            $leadsQuery->where('leads.lead_source_id', $request->get('lead_source'));
        }
        
        if($request->has('groups_ids') && $request->groups_ids != null && $request->groups_ids != ''){
            $groups_students_ids = GroupStudent::whereIn('group_id',explode(',',$request->groups_ids))->pluck('lead_id');
            $leadsQuery->whereIn('leads.id',$groups_students_ids);
        }
        if($request->has('leads_ids') && $request->leads_ids != null && $request->leads_ids != ''){
            $leadsQuery->whereIn('leads.id',explode(',',$request->leads_ids));
        }
        
        
        if($request->has('select_assigned') && $request->get('select_assigned') != null && $request->get('select_assigned') != ''){
            if ($request->get('select_assigned') === '0') {
                $leadsQuery->whereNull('leads.assigned_employee_id');
            } elseif ($request->get('select_assigned') === '1') {
                $leadsQuery->whereNotNull('leads.assigned_employee_id');
            }
        }
        if($request->has('has_unpaid') && $request->get('has_unpaid') != null && $request->get('has_unpaid') != ''){
            if ($request->get('has_unpaid') === '0') {
                $leadsQuery->whereHas('payments' ,function($query){
                    $query->where('rest',0 );
                });
            } elseif ($request->get('has_unpaid') === '1') {
                $leadsQuery->whereHas('payments' ,function($query){
                    $query->where('rest' ,'>' ,0 );
                });
            }
        }
        
        if ($request->has('current_branches') && $request->get('current_branches') != null && $request->get('current_branches') != '') {
            $leadsQuery->whereIn('leads.branch_id', $request->get('current_branches'));
        }
        if ($request->has('transfer_branches') && $request->get('transfer_branches') != null && $request->get('transfer_branches') != '') {
            $leadsQuery->whereIn('leads.transfer_branch_id', $request->get('transfer_branches'));
        }
        if ($request->has('first_branch_id') && $request->get('first_branch_id') != null && $request->get('first_branch_id') != '') {
            $leadsQuery->whereIn('leads.first_branch_id', $request->get('first_branch_id'));
        }
        if($request->has('has_followup') && $request->get('has_followup') != null && $request->get('has_followup') != ''){
            if ($request->get('has_followup') === '0') {
                $leadsQuery->doesntHave('cases');
            } elseif ($request->get('has_followup') === '1') {
                $leadsQuery->has('cases');
            }
        }
        /*if ($registration_from != null && $registration_to != '') {
            $leadsQuery->whereBetween('created_at', [$registration_from, $registration_to]);
        }
        */
        
        $courses = [];
        $stageLevels = [];
        $stageLevelss = [];
        $timeframes = [];
        $rounds = [];
        $daysData = [];
        $intervals = [];
        $subRounds = [];
        // $stage_level=[];
        
       
        $courses = Track::where('status',1)->where('parent_id',$track)->pluck('title','id');
          
        
        if($request->has('course_id') && $request->get('course_id') != null && $request->get('course_id') != ''){
         
            $stageLevels = Track::find($request->course_id)->stageLevels;
            // dd($stageLevelss);
            
            $leadsQuery->whereIn('group_waiting_lists.level_id',$stageLevels->pluck('id'));
            $stageLevels = $stageLevels->pluck('name','id');
            
        }
        
        if($request->has('customer_type') && $request->get('customer_type') != null && $request->get('customer_type') != ''){
            $leadsQuery->where('leads.customer_type',$request->customer_type);
        }
        
        if($request->has('level_id') && $request->get('level_id') != null && $request->get('level_id') != ''){
            if($type == 2){
                //$stage_level = StageLevel::find($request->get('level_id'));
                $leadsQuery->where('group_waiting_lists.level_id',$request->get('level_id'));
            }
        }
        if($type == 2){
            if ($registration_from != null && $registration_to != '') {
                
                $leadsQuery->whereBetween('leads.trans_customer', [$registration_from, $registration_to]);
            }
        }
        else{
             if ($registration_from != null && $registration_to != '') {
                
                $leadsQuery->whereBetween('leads.customer_to_client', [$registration_from, $registration_to]);
            }
        }
        
        if($type == 3 && ($request->discipline_id || $request->course_id || $request->timeframe_id || $request->round_id || $request->days || $request->interval_id || $request->sub_round_id)){
            $groupsQuery = Group::has('students')
            ->with('groupsessionAttendance','sessions','track','course','timeframe','round','subRound','discipline','branch','instructor','admin','interval','sessions');
           
            if($request->has('discipline_id') && $request->get('discipline_id') != null && $request->get('discipline_id') != ''){
                $groupsQuery->where('discipline_id',$request->get('discipline_id'));
            }
            
          
            $groupsQuery->where('track_id',$track);
            
            
            if($request->has('course_id') && $request->get('course_id') != null && $request->get('course_id') != ''){
                $groupsQuery->where('course_id',$request->get('course_id'));
                // dd($groupsQuery);
                $timeframe_ids = DB::table('timeframe_courses')->where('course_id',$request->get('course_id'))->pluck('timeframe_id')->toArray();
                $timeframes = Timeframe::whereIn('id',$timeframe_ids)->where('status',1)->pluck('title','id')->toArray();
            }
            
            if($request->has('timeframe_id') && $request->get('timeframe_id') != null && $request->get('timeframe_id') != ''){
                $groupsQuery->where('timeframe_id',$request->get('timeframe_id'));
                $rounds = Round::where('timeframe_id',$request->get('timeframe_id'))->pluck('title', 'id')->toArray();
            }
            
            if($request->has('round_id') && $request->get('round_id') != null && $request->get('round_id') != ''){
                $groupsQuery->where('round_id',$request->get('round_id'));
                $round = Round::with('timeframe.intervals')->find($request->get('round_id'));

                $daysData = $round->timeframe->days;
                $intervals = $round->timeframe->intervals->pluck('name', 'id')->toArray();
                
            }
            if($request->has('days') && $request->get('days') != null && $request->get('days') != ''){
                $groupsQuery->where('days',$request->get('days'));
                $subRounds = SubRound::where('days', $request->get('days'))
                                    -> where('round_id', $request->get('round_id'))
                                    -> whereDate('start_date', '>=', now())
                                    -> orderBy('start_date')->pluck('start_date', 'id');
            }
            
            if($request->has('interval_id') && $request->get('interval_id') != null && $request->get('interval_id') != ''){
                $groupsQuery->where('interval_id',$request->get('interval_id'));
            }
            /*
            $attendance = $request->attendance;
            if($request->has('attendance') && $request->get('attendance') != null && $request->get('attendance') != ''){
                
                    $sessions_attendance = GroupSessionAttendance::whereIn('group_id',$groupsQuery->pluck('id')->toArray())
                    ->whereNotNull('attendance')
                    ->select('lead_id',DB::raw('count(case when attendance = 1 then attendance end) as attending , count(case when attendance = 0 then attendance end) as absent'))
                    ->groupBy('lead_id')->get();
                    if($sessions_attendance != null && count($sessions_attendance) > 0){
                        // $groupsQuery = $sessions_attendance->where('attending',$request->get('attendance'));
                        $groupsQuery = $groupsQuery->with(['groupsessionAttendance'=>function($q)use($attendance){
                                    $q->where('attendance' ,$attendance);
                                }]);
                    }
                    else{
                        $groupsQuery = $groupsQuery->with(['groupsessionAttendance'=>function($q)use($attendance){
                            $q->where('attendance' ,$attendance);
                        }]);
                        
                        
                        // $groupsQuery = $sessions_attendance->where('attending',$request->get('attendance'));
                    }
                    
                    return $groupsQuery->get();
            
                
            }
            */
            if($request->has('sub_round_id') && $request->get('sub_round_id') != null && $request->get('sub_round_id') != ''){
                $groupsQuery->whereIn('sub_round_id',$request->get('sub_round_id'));
            }
            
            $groups_ids = $groupsQuery->pluck('id')->toArray();
            
            
            if($request->has('level_id') && $request->get('level_id') != null && $request->get('level_id') != ''){
                $leads_in_groups = GroupStudent::select('lead_id',DB::raw('MAX(level_id) as last_level_id'))->whereIn('group_id',$groups_ids)->groupBy('lead_id')->having('last_level_id',$request->get('level_id'))->pluck('lead_id')->toArray();
            }else{
                $leads_in_groups = GroupStudent::whereIn('group_id',$groups_ids)->pluck('lead_id')->toArray();
            }
            
            $leadsQuery->whereIn('id',array_unique($leads_in_groups));
        }
        $leadsCount = 0;
        
        if($type == 2){
            $leadsQuery->select('leads.id','leads.trans_customer','leads.customer_to_client','leads.mobile_1','leads.f_name','leads.m_name','leads.l_name',
                'leads.name','leads.name_en','leads.name_ar','leads.type','leads.customer_type','leads.branch_id','leads.first_branch_id','leads.transfer_branch_id',
                'leads.assigned_employee_id',
                'placement_applicants.level as pt_level','group_waiting_lists.level_id as last_level_id');
        }elseif($type == 3){
            $leadsQuery->select('leads.id','leads.trans_customer','leads.customer_to_client','leads.mobile_1','leads.f_name','leads.m_name','leads.l_name',
                'leads.name','leads.name_en','leads.name_ar','leads.type','leads.customer_type','leads.branch_id','leads.first_branch_id','leads.transfer_branch_id',
                'leads.assigned_employee_id',
                'placement_applicants.level as pt_level','customer_tracks.last_level_id','customer_tracks.last_group_id');
        }else{
            
        }
        
        $leads = $leadsQuery->withCount('invoices','cases')
        ->with('lastcase','branch','payments','assignedEmployee','getLastGroup')
        ->OrderBy('leads.trans_customer','desc')
        ->OrderBy('leads.customer_to_client','desc')
        //dd($leads->toSql());
        ->paginate($per_page);
        //  $leads; 
        //dd($leads[0]);
        
        // dd($request->all());
        return view('customers.index',compact('rounds','label_type','daysData','intervals','subRounds','stageLevels','timeframes','leads','leadsCount','employeeBranches','agents','leadSources','knowChannels','branches','tracks','disciplines','courses'));
    }
    
    public function getsubtrackdb(Request $request)
    {
        $subtrack=[];
        $subtrack = Track::where('status',1)->where('parent_id' , $request->track_id)->select('title', 'id')->get();

        return json_decode($subtrack);

    }
    public function getleveldb(Request $request){
        $stageLevels=[];
        // $stageLevels = Track::find($request->course_id)->stageLevels;
        $stageLevels = Track::find($request->course_id)->stageLevels;
        // $levels = Track::where('status',1)->where('levels' , $request->levels)->get();
        return $stageLevels;

    }
    
    public function gettimeframesdb(Request $request){
        $timeframes=[];
        $timeframe_ids=[];
        $timeframe_ids = DB::table('timeframe_courses')->where('course_id',$request->course_id)->pluck('timeframe_id');
        $timeframes = Timeframe::whereIn('id',$timeframe_ids)->where('status',1)->get();
     
        return  $timeframes;
    }

    public function getrounddb(Request $request)
    {
        $round=[];
        $round = Round::where('timeframe_id',$request->timeframe_id)->select('title', 'id')->get();

        // $round = Round::find($request->round_id);
       return $round;
    }
    public function getsubrounddb(Request $request){
        $round=[];
        
        $round = Round::find($request->round_id);
        $subround=[];
        $subround=SubRound::where('round_id',$round->id)->select('id','start_date')->get();
        return $subround ;

    }

    public function getintervaldb(Request $request)
    {
        $round = Round::with('timeframe.intervals')->find($request->round_id);

            // $daysData = $round->timeframe->days;
        $intervals=[];
        $intervals = $round->timeframe->intervals;
            
        return $intervals;
    }

    public function getdaydb(Request $request)
    {
        // $daysData=[];
        $round = Round::with('timeframe.intervals')->find($request->round_id);

        $daysData = $round->timeframe->days;
        $html1 ='<option></option>';
        
        // for( $i = 0; $i < $length; $i++) {
        //                     // $html1 +=  data2[i] ;
        //     $html1 += '<option value="' + $daysData[$i] + '" >' + $datasData[$i] + '</option>';
        //  }
        foreach ($daysData as $data) {
            $html1 .= '<option value="' .$data . '" >' .config('system_variables.timeframes.days')[$data] . '</option>';
        }
        // sel2.html(html1);
       


        // return $daysData;
        return $html1;

    }
    
    public function uploadExcelCustomers(Request $request)
    {
        //dd($request->all());
        if($request->hasFile('excel')){
            $file = $request->file('excel')->store('/');
            Excel::import(new CustomerImport, storage_path('app/' . $file));
            Flash::success('Imported Successfully.');
            
            /*
            activity('Customers')
               ->causedBy(Auth::user()->id)
               ->performedOn($lead)
               ->log('upload Excel customer');*/
        }else{
            Flash::success('excel file is required.');
        }
        return redirect()->back();
    }
    
    /**
     * Show the form for creating a new Lead.
     *
     * @return Response
     */
    public function create()
    {
        $sources = LeadSource::where('status',1)->pluck('name', 'id');
        $channels = KnowChannel::where('status',1)->pluck('name', 'id');
        $offers = Offer::pluck('title', 'id');
        $branches = Branch::where('status',1)->pluck('name', 'id');
        $services = TrainingService::pluck('title', 'id');
        $employees = Employee::where('status',1)->where('account_Type','Operations Account')->get()->pluck('name', 'id');
        $timeframes = Timeframe::pluck('title', 'id');
        
        $countries = Country::where('status',1)->pluck('name', 'id')->toArray();
        $jobs = CustomerJob::where('status',1)->pluck('name', 'id')->toArray();
        $univercities = University::where('status',1)->orderBy('name')->pluck('name', 'id')->toArray();
        $nationalities = Country::where('status',1)->pluck('nationality', 'id')->toArray();
        $governorates = Governorate::select('id','name','country_id')->where('status',1)->get();
        $governorates = $governorates->groupBy('country_id');
        //dd($governorates);
        $cities = City::select('id','name','gov_id')->where('status',1)->get();
        $cities = $cities->groupBy('gov_id');
        
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id')->toArray();
        //$this->rounds = Round::pluck('title', 'id')->toArray();
        $disciplines = DisciplineCategory::pluck('name', 'id')->toArray();
        $courses = Track::select('parent_id','title','id')->where('status',1)->whereNotNull('parent_id')->get();
        $courses = $courses->groupBy('parent_id');
        
        $stageLevels = StageLevel::join('stages','stages.id','=','stage_levels.stage_id')
                                ->select('stage_levels.id','stage_levels.name','stages.track_id')
                                ->get();
        $stageLevels = $stageLevels->groupBy('track_id');
        //dd($stageLevels);
        return view('customers.create', compact('disciplines','tracks','courses','stageLevels','governorates','cities','nationalities','univercities','jobs','countries','sources', 'channels', 'offers', 'branches', 'services', 'employees', 'timeframes'));
    }

    /**
     * Store a newly created Lead in storage.
     *
     * @param CreateLeadRequest $request
     *
     * @return Response
     */

    public function store(CreateCustomerRequest $request)
    {
        $input = $request->except('track_id','sub_track_id','current_level','num_of_levels','discipline_id','timeframe_id','interval','harvest_certificate','cambridge_certificate','books','total_amount','paid');

        if($request->country == 1)
        {
            $request->validate([
                'mobile_1' => 'required|digits:11|starts_with:0|unique:leads,mobile_1',
            ]);
        }
        else {
            // dd($input);
            $request->validate([
                'mobile_1' => 'required|unique:leads,mobile_1',
            ]);

        }
        $input['type'] = 2;
        $input['old_customer'] = 1;
        $input['assigned_employee_id'] = auth()->id();
        $input['password'] = 'Harvest@123';
        
        $input['register_from'] = 'admin_panel';
        $input['name_en'] = $request->f_name.' '.$request->m_name.' '.$request->l_name;
        $lead = Lead::create($input);
        
        $level = null;

        
        if(isset($request->current_level) && $request->current_level !== ''){
            $level = StageLevel::find($request->current_level);
            //dd($level);
            if($level != null && $level != ''){
                $lead->update(['pt_level' => $level->value]);
            }
            $checkGroupWaitingList = GroupWaitingList::where('lead_id',$lead->id)->where('level_id',$level->id)->first();
            $intervals_ids = [];
            $interval_timeframe = DB::table('interval_timeframe')->where('timeframe_id',$request->payment_timeframe_id)->pluck('interval_id')->toArray();
            if($request->interval == 'am'){
                $intervals_ids = Interval::whereIn('id',$interval_timeframe)->where('pattern','AM')->pluck('id')->toArray();
            }
            if($request->interval == 'pm'){
                $intervals_ids = Interval::whereIn('id',$interval_timeframe)->where('pattern','PM')->pluck('id')->toArray();
            }
                
            if($checkGroupWaitingList != null && $checkGroupWaitingList != ''){
                $checkGroupWaitingList->update([
                    'level_id' => $level->id,
                    'timeframes' => $request->payment_timeframe_id,
                    //'intervals' => implode(',',$intervals_ids),
                    'discipline_id' => $request->discipline_id
                ]);
            }else{
                GroupWaitingList::create([
                    'lead_id' => $lead->id,
                    'level_id' => $level->id,
                    'timeframes' => $request->payment_timeframe_id,
                    //'intervals' => implode(',',$intervals_ids),
                    'discipline_id' => $request->discipline_id
                ]);
            }
        }
        
        //dd($request->current_level,$level);
        $customerTrack = CustomerTrack::where('lead_id',$lead->id)->where('track_id',$request->track_id)->where('course_id',$request->sub_track_id)->first();
        
        if ($customerTrack){
            if($customerTrack->used == 0){
                $customerTrack->update([
                    'track_id' => $request->track_id,
                    'course_id' => $request->sub_track_id,
                    'level_id' => ($level != null)?$level->id:null,
                    'total' => $request->num_of_levels,
                ]);
            }
        }else{
            $customerTrack = CustomerTrack::create([
                'lead_id' => $lead->id,
                'track_id' => $request->track_id,
                'course_id' => $request->sub_track_id,
                'level_id' => ($level != null)?$level->id:null,
                'total' => $request->num_of_levels,
                'used' => 0,
            ]);
        }
        
        $old_customer_payment = OldCustomerPayment::where('customer_id',$lead->id)->first();
        
        if($old_customer_payment != null && $old_customer_payment != ''){
            $old_customer_payment->update([
                'course_id' => $request->sub_track_id,
                'level_id' => ($level != null)?$level->id:null,
                'harvest_certificate' => $request->harvest_certificate,
                'cambridge_certificate' => $request->cambridge_certificate,
                'books' => $request->books
            ]);
        }else{
            $add = new OldCustomerPayment;
            $add->create([
                'customer_id' => $lead->id,
                'course_id' => $request->sub_track_id,
                'level_id' => ($level != null)?$level->id:null,
                'harvest_certificate' => $request->harvest_certificate,
                'cambridge_certificate' => $request->cambridge_certificate,
                'books' => $request->books
            ]);
        }
        
        $check_payment = LeadPayment::where('lead_id',$lead->id)->whereNull('paymentable_type')->whereNull('paymentable_id')->whereNull('payment_method_id')->first();
        if($check_payment != null && $check_payment != ''){
            $payment_data = [
                'lead_id' => $lead->id,
                'employee_id' => auth()->user()->id,
                'amount' => $request->total_amount,
                'include_books' => $request->books,
            ];
            if($request->total_amount > $request->paid){
                $payment_data['payment_plan_id'] = 3;
                $payment_data['rest'] = ($request->total_amount - $request->paid);
            }else{
                $payment_data['payment_plan_id'] = 2;
                $payment_data['rest'] = 0;
            }
            $check_payment->update($payment_data);
            
            if($request->total_amount > $request->paid){
                SubPayment::where('lead_payment_id',$check_payment->id)->delete();
                
                $deposit = new SubPayment;
                $deposit->create([
                    'lead_payment_id' => $check_payment->id,
                    'amount' => $request->paid,
                    'employee_id' => auth()->user()->id,
                    'payment_method_id' => 1,
                    'branch_id' => $lead->branch_id,
                    'due_date' => date('Y-m-d'),
                    'paid' => 1,
                    'type' => 1
                ]);
                
                $sub_payment = new SubPayment;
                $sub_payment->create([
                    'lead_payment_id' => $check_payment->id,
                    'amount' => ($request->total_amount - $request->paid),
                    'employee_id' => auth()->user()->id,
                    'branch_id' => $lead->branch_id,
                    'due_date' => date('Y-m-d',strtotime('+ 7 days')),
                    'paid' => 0,
                    'type' => 2
                ]);
            }
        }else{
            $dataa=[
                'employee_id'=>auth()->user()->id,
                'lead_id' => $lead->id,
                'branch_id'=>auth()->user()->branch_id,
                'total_price' => $request->paid,
            ];
            $invoice = Invoice::create($dataa);
            
            $payment = new LeadPayment;
            $payment_data = [
                'lead_id' => $lead->id,
                'amount' => $request->total_amount,
                'employee_id' => auth()->user()->id,
                'include_books' => $request->books,
                'invoice_id'=>$invoice->id,
            ];
            if($request->total_amount > $request->paid){
                $payment_data['payment_plan_id'] = 3;
                $payment_data['rest'] = ($request->total_amount - $request->paid);
            }else{
                $payment_data['payment_plan_id'] = 2;
                $payment_data['rest'] = 0;
            }
            
            $payment = $payment->create($payment_data);
            
            if($request->total_amount > $request->paid){
                $deposit = new SubPayment;
                $deposit->create([
                    'lead_payment_id' => $payment->id,
                    'amount' => $request->paid,
                    'employee_id' => auth()->user()->id,
                    'payment_method_id' => 1,
                    'branch_id' => $lead->branch_id,
                    'due_date' => date('Y-m-d'),
                    'paid' => 1,
                    'type' => 1
                ]);
                
                $sub_payment = new SubPayment;
                $sub_payment->create([
                    'lead_payment_id' => $payment->id,
                    'amount' => ($request->total_amount - $request->paid),
                    'employee_id' => auth()->user()->id,
                    'branch_id' => $lead->branch_id,
                    'due_date' => date('Y-m-d',strtotime('+ 7 days')),
                    'paid' => 0,
                    'type' => 2
                ]);
            }
        }
        Flash::success('Customer saved successfully.');
        
            activity('Customers')
               ->causedBy(Auth::user()->id)
               ->performedOn($lead)
               ->log('create new customer');
        $redirect_url = route('admin.database.index').'?type=2';
        return redirect($redirect_url);
    }

    /**
     * Display the specified Lead.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id , Request $request)
    {
        $lead = Lead::find($id);
        
        if (empty($lead)) {
            Flash::error('Customer not found');

            return redirect(route('admin.database.index'));
        }
        // $invoices = LeadPayment::where('lead_id',$lead->id);
        $invoices = Invoice::with('lead', 'paymentMethod' ,'lead_payments', 'lead_payments.subPayments')->where('lead_id', $lead->id)->get();
        $RefundRequests = RefundRequest::where('lead_id', $lead->id)->get();
        // $invoices = LeadPayment::where('lead_id', $lead->id)->withCount(['subPayments' => function ($query) {
        //     $query->where('paid', 0);
        // }])->with('subPayments')->get();
        
        
        $groups_ids = DB::table('group_students')->where('lead_id',$lead->id)->pluck('group_id');
        $groups = Group::whereIn('id',$groups_ids)->orderBy('level_id','desc')->get();
        $msgs_ids = DB::table('lead_message_log')->where('lead_id',$lead->id)->pluck('message_log_id');
        $msgs = MessageLog::whereIn('id',$msgs_ids)->orderBy('id','desc')->get();

        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        
        
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $agents = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        $labelTypes = LabelType::where('status', 1)->where('category', 4)->pluck('name', 'id')->toArray();
      
        $followupsQuery = LeadCase::leftJoin('leads','leads.id','=','lead_cases.lead_id')
            ->whereIn('lead_cases.label_type_id',array_keys($labelTypes))->where('lead_id', $lead->id);
        
        $followupsCount = $followupsQuery->count();
        $followups = $followupsQuery->select('lead_cases.id','lead_cases.created_at','lead_cases.branch_id','lead_cases.employee_id','lead_cases.lead_id','lead_cases.label_type_id','lead_cases.action_id','lead_cases.date')->with('lead')->orderBy('lead_cases.id','desc')->paginate($per_page);
        

        $leadCases = LeadCase::where('lead_id', $lead->id)->orderBy('id','desc')->get();
        $leadSources = LeadSource::where('id', '!=', 6)->where('status',1)->pluck('name', 'id')->toArray();
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id')->toArray();

        return view('customers.show',compact('lead', 'RefundRequests','leadCases','invoices' , 'groups' , 'msgs','followupsCount','followups','labelTypes','agents','employeeBranches','leadSources','tracks'));
    }

public function updateLeadSource(Request $request, $leadId)
{
    // Find the lead or fail if not found
    $lead = Lead::findOrFail($leadId);
    
    // Validate the lead source ID and track ID to ensure they're valid options
    $request->validate([
        'lead_source_id' => 'required|exists:lead_sources,id',
        'track_id' => 'required|exists:tracks,id',  // Validate track_id
    ]);
   
    // Retrieve the selected lead source ID and track ID from the request
    $leadSourceId = $request->input('lead_source_id');
    $trackId = $request->input('track_id');

    // Retrieve the related lead source track for the given lead or create a new one if not found
    $leadSourceTrack = LeadSourceTrack::where('lead_id', $lead->id)->first();

    // If a related lead source track is not found, create a new one
    if (!$leadSourceTrack) {
        $leadSourceTrack = new LeadSourceTrack();
        $leadSourceTrack->lead_id = $lead->id;  // Set the lead_id to the current lead's ID
    }

    // Get the branch_id from the Lead model
    $branchId = $lead->branch_id;  // Assuming the 'branch_id' is a field in the Lead model

    // Update or set the lead source information
    $leadSourceTrack->lead_source_b_id = $leadSourceTrack->lead_source_a_id ?? $lead->lead_source_id;  // Retain the previous value or set null
    $leadSourceTrack->lead_source_a_id = $leadSourceId;  // Update with the new selected lead source
    $leadSourceTrack->lead_source_c_id = 22;  // Set to a default value as per your logic
    $leadSourceTrack->track_id = $trackId;  // Set the track ID
    $leadSourceTrack->branch_id = $branchId;  // Add the branch_id from the Lead model

    // Add the employee_id from the authenticated user
    $leadSourceTrack->employee_id = Auth::user()->id;  // Assuming employee_id is in the User model

    // Save the updated or newly created lead source track
    $leadSourceTrack->save();

    // Update the lead source ID
    $lead->lead_source_id = $leadSourceId;

    // Save the updated lead
    $lead->save();

    // Redirect with a success message
    return redirect()->route('admin.database.show', [$lead->id])
                     ->with('success', 'Lead source updated successfully');
}


    /**
     * Show the form for editing the specified Lead.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $lead = Lead::find($id);

        if (empty($lead)) {
            Flash::error('Customer not found');

            return redirect(route('admin.database.index'));
        }
        
        if(! $lead->f_name){
            $lead->f_name = (isset($lead->name['en']))?$lead->name['en']:'';
        }
        
        if(! $lead->name_ar){
            $lead->name_ar = (isset($lead->name['ar']))?$lead->name['ar']:'';
        }
        
        $sources = LeadSource::where('status',1)->pluck('name', 'id');
        $channels = KnowChannel::where('status',1)->pluck('name', 'id');
        $offers = Offer::pluck('title', 'id');
        $branches = Branch::where('status',1)->pluck('name', 'id');
        $services = TrainingService::pluck('title', 'id');
        $employees = Employee::where('status',1)->where('account_Type','Operations Account')->get()->pluck('name', 'id');
        $timeframes = Timeframe::pluck('title', 'id');
        
        
        $countries = Country::where('status',1)->pluck('name', 'id')->toArray();
        $jobs = CustomerJob::where('status',1)->pluck('name', 'id')->toArray();
        $univercities = University::where('status',1)->orderBy('name')->pluck('name', 'id')->toArray();
        $nationalities = Country::where('status',1)->pluck('nationality', 'id')->toArray();
        $governorates = Governorate::select('id','name','country_id')->where('status',1)->get();
        $governorates = $governorates->groupBy('country_id');
        
        $cities = City::select('id','name','gov_id')->where('status',1)->get();
        $cities = $cities->groupBy('gov_id');
        
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id')->toArray();
        //$this->rounds = Round::pluck('title', 'id')->toArray();
        $disciplines = DisciplineCategory::pluck('name', 'id')->toArray();
        $courses = Track::select('parent_id','title','id')->where('status',1)->whereNotNull('parent_id')->get();
        $courses = $courses->groupBy('parent_id');
        
        $stageLevels = StageLevel::join('stages','stages.id','=','stage_levels.stage_id')
                                ->select('stage_levels.id','stage_levels.name','stages.track_id')
                                ->get();
        $stageLevels = $stageLevels->groupBy('track_id');
        
        $old_customer_payment = OldCustomerPayment::where('customer_id',$lead->id)->first();
        $customer_track = null;
        $groupWaitingList = null;
        $lead_payment = null;
        
        if($old_customer_payment != null && $old_customer_payment != ''){
            $customer_track = CustomerTrack::where('lead_id',$lead->id)->where('course_id',$old_customer_payment->course_id)->First();
            $groupWaitingList = GroupWaitingList::where('lead_id',$lead->id)->where('level_id',$old_customer_payment->level_id)->first();
            $lead_payment = LeadPayment::where('lead_id',$lead->id)->whereNull('paymentable_type')->whereNull('paymentable_id')->whereNull('payment_method_id')->first();
            if(! ($lead_payment != null && $lead_payment != '')){
                $old_customer_payment->delete();
                $old_customer_payment = null;
            }
        }
        //dd($old_customer_payment,$customer_track);

        $intervals = Interval::where('status',1)->pluck('name','id');
        // dd($lead);
        return view('customers.edit', compact('intervals','groupWaitingList','lead_payment','old_customer_payment','customer_track','tracks','disciplines','courses','stageLevels','governorates','cities','nationalities','univercities','jobs','countries','lead', 'sources', 'channels', 'offers', 'branches', 'services', 'employees', 'timeframes'));
    }
    

    /**
     * Update the specified Lead in storage.
     *
     * @param int $id
     * @param UpdateLeadRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateLeadRequest $request)
    {
         $lead = Lead::find($id);
        
        if (empty($lead)) {
            Flash::error('Customer not found');

            return redirect(route('admin.database.index'));
        }

        if($request->country == 1) {
            // dd($input);
         $request->validate([
                'mobile_1' => 'required|digits:11|starts_with:0|unique:leads,mobile_1,'.$request->segment(2),
            ]);

        }
       

         $pt_applicants = PlacementApplicant::where('lead_id',$lead->id)->get();
        //dd($pt_applicants);
        if($lead->mobile_1 != $request->mobile_1){
            foreach($pt_applicants as $pt_applicant){
                $pt_applicant->mobile = $request->mobile_1;
                $pt_applicant->save();
            }
        }
        
        $input = $request->except('dob');   
         $input['dob'] = date_format(date_create($request->dob),'Y-m-d');
         
        $input['name_en'] = $request->f_name.' '.$request->m_name.' '.$request->l_name;
        $lead->update($input);
        
        if($request->has('track_id') && $request->has('sub_track_id') && $request->has('num_of_levels') && $request->has('discipline_id') &&
          $request->track_id != null && $request->track_id != '' && $request->sub_track_id != '' && $request->sub_track_id != null && 
          $request->num_of_levels != null && $request->num_of_levels != '' && $request->discipline_id != null && $request->discipline_id != ''){
            $level = null;
            if($lead->type == 2){
                if(isset($request->current_level) && $request->current_level !== ''){
                    $level = StageLevel::find($request->current_level);
                    //dd($level);
                    if($level != null && $level != ''){
                        $lead->update(['pt_level' => $level->value]);
                    }
                    $checkGroupWaitingList = GroupWaitingList::where('lead_id',$lead->id)->delete();
                    
                    GroupWaitingList::create([
                        'lead_id' => $lead->id,
                        'level_id' => $level->id,
                        'track_id' => $request->track_id,
                        'sub_track_id' => $request->sub_track_id,
                        'timeframes' => $request->payment_timeframe_id,
                        //'intervals' => implode(',',$request->interval),
                        'discipline_id' => $request->discipline_id
                    ]);
                    
                }
                
                //dd($request->current_level,$level);
                $customerTrack = CustomerTrack::where('lead_id',$lead->id)->delete();
                
                $customerTrack = CustomerTrack::create([
                    'lead_id' => $lead->id,
                    'track_id' => $request->track_id,
                    'course_id' => $request->sub_track_id,
                    'level_id' => ($level != null)?$level->id:null,
                    'total' => $request->num_of_levels,
                    'used' => 0,
                ]);
            
            }
            
            $old_customer_payment = OldCustomerPayment::where('customer_id',$lead->id)->delete();
            
            $add = new OldCustomerPayment;
            $add->create([
                'customer_id' => $lead->id,
                'course_id' => $request->sub_track_id,
                'level_id' => ($level != null)?$level->id:null,
                'harvest_certificate' => $request->harvest_certificate,
                'cambridge_certificate' => $request->cambridge_certificate,
                'books' => $request->books
            ]);
            
            $check_payment = LeadPayment::where('lead_id',$lead->id)->whereNull('paymentable_type')->whereNull('paymentable_id')->whereNull('payment_method_id')->first();
            if($check_payment != null && $check_payment != ''){
                $payment_data = [
                    'lead_id' => $lead->id,
                    'employee_id' => auth()->user()->id,
                    'amount' => $request->total_amount,
                    'include_books' => $request->books,
                ];
                if($request->total_amount > $request->paid){
                    $payment_data['payment_plan_id'] = 3;
                    $payment_data['rest'] = ($request->total_amount - $request->paid);
                }else{
                    $payment_data['payment_plan_id'] = 2;
                    $payment_data['rest'] = 0;
                }
                $check_payment->update($payment_data);
                
                if($request->total_amount > $request->paid){
                    SubPayment::where('lead_payment_id',$check_payment->id)->delete();
                    
                    $deposit = new SubPayment;
                    $deposit->create([
                        'lead_payment_id' => $check_payment->id,
                        'amount' => $request->paid,
                        'employee_id' => auth()->user()->id,
                        'payment_method_id' => 1,
                        'branch_id' => $lead->branch_id,
                        'due_date' => date('Y-m-d'),
                        'paid' => 1,
                    ]);
                    
                    $sub_payment = new SubPayment;
                    $sub_payment->create([
                        'lead_payment_id' => $check_payment->id,
                        'amount' => ($request->total_amount - $request->paid),
                        'employee_id' => auth()->user()->id,
                        'branch_id' => $lead->branch_id,
                        'due_date' => date('Y-m-d',strtotime('+ 7 days')),
                        'paid' => 0,
                    ]);
                }
            }else{
                $dataa=[
                    'employee_id'=>auth()->user()->id,
                    'lead_id' => $lead->id,
                    'branch_id'=>auth()->user()->branch_id,
                    'total_price' => $request->paid,
                ];
                $invoice = Invoice::create($dataa);
                
                $payment = new LeadPayment;
                $payment_data = [
                    'lead_id' => $lead->id,
                    'amount' => $request->total_amount,
                    'employee_id' => auth()->user()->id,
                    'include_books' => $request->books,
                    'invoice_id'=>$invoice->id,
                ];
                if($request->total_amount > $request->paid){
                    $payment_data['payment_plan_id'] = 3;
                    $payment_data['rest'] = ($request->total_amount - $request->paid);
                }else{
                    $payment_data['payment_plan_id'] = 2;
                    $payment_data['rest'] = 0;
                }
                
                $payment = $payment->create($payment_data);
                
                if($request->total_amount > $request->paid){
                    $deposit = new SubPayment;
                    $deposit->create([
                        'lead_payment_id' => $payment->id,
                        'amount' => $request->paid,
                        'employee_id' => auth()->user()->id,
                        'payment_method_id' => 1,
                        'branch_id' => $lead->branch_id,
                        'due_date' => date('Y-m-d'),
                        'paid' => 1,
                        'type' => 1
                    ]);
                    
                    $sub_payment = new SubPayment;
                    $sub_payment->create([
                        'lead_payment_id' => $payment->id,
                        'amount' => ($request->total_amount - $request->paid),
                        'employee_id' => auth()->user()->id,
                        'branch_id' => $lead->branch_id,
                        'due_date' => date('Y-m-d',strtotime('+ 7 days')),
                        'paid' => 0,
                        'type' => 2
                    ]);
                }
            }
        }   
        Flash::success('Customer updated successfully.');
        
        
            activity('Customers')
               ->causedBy(Auth::user()->id)
               ->performedOn($lead)
               ->log('update customer');

        return redirect(route('admin.database.index').'?type=2&track_id=1');

    }
    public function updatelevel($id, Request $request)
    {
        $lead = Lead::find($id);
        // return $lead;
        // dd($lead);
        if (empty($lead)) {
            Flash::error('Customer not found');

            return redirect(route('admin.database.index'));
        }

        
        if($request->has('track_id') && $request->has('sub_track_id') && $request->has('num_of_levels') && $request->has('discipline_id') &&
          $request->track_id != null && $request->track_id != '' && $request->sub_track_id != '' && $request->sub_track_id != null && 
          $request->num_of_levels != null && $request->num_of_levels != '' && $request->discipline_id != null && $request->discipline_id != ''){
            $level = null;
            if($lead->type == 2){
                if(isset($request->current_level) && $request->current_level !== ''){
                    $level = StageLevel::find($request->current_level);
                    //dd($level);
                    if($level != null && $level != ''){
                        $lead->update(['pt_level' => $level->value]);
                    }
                    $checkGroupWaitingList = GroupWaitingList::where('lead_id',$lead->id)->delete();
                    
                    GroupWaitingList::create([
                        'lead_id' => $lead->id,
                        'level_id' => $level->id,
                        'track_id' => $request->track_id,
                        'sub_track_id' => $request->sub_track_id,
                        'timeframes' => $request->payment_timeframe_id,
                        //'intervals' => implode(',',$request->interval),
                        'discipline_id' => $request->discipline_id
                    ]);
                    
                }
                
                //dd($request->current_level,$level);
                $customerTrack = CustomerTrack::where('lead_id',$lead->id)->delete();
                
                $customerTrack = CustomerTrack::create([
                    'lead_id' => $lead->id,
                    'track_id' => $request->track_id,
                    'course_id' => $request->sub_track_id,
                    'level_id' => ($level != null)?$level->id:null,
                    'total' => $request->num_of_levels,
                    'used' => 0,
                ]);
            
            }
            
        }   
        Flash::success('Customer level updated successfully.');
        
        
            activity('Customers')
               ->causedBy(Auth::user()->id)
               ->performedOn($lead)
               ->log('update customer level');

        return redirect(route('admin.database.index').'?type=2&track_id='.$request->track_id);

    }

    /**
     * Remove the specified Lead from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        $lead = Lead::find($id);

        if (empty($lead)) {
            Flash::error('Customer not found');

            return redirect(route('admin.database.index'));
        }

        $lead->delete();
                
            activity('Customers')
               ->causedBy(Auth::user()->id)
               ->performedOn($lead)
               ->log('delete customer');


        Flash::success('Customer deleted successfully.');

        return redirect(route('admin.database.index'));
    }


    public function resetpassword(Request $request)
    {
        $lead = Lead::find($request->leadid);
        $lead->update([
            'password' => "Harvest@123",
        ]);
        
        
        if($request->flag == 'lead_flag')
        {
           activity('Leads')
           ->causedBy(Auth::user()->id)
           ->performedOn($lead)
           ->log('resetpassword lead');
        }
        else{
            
           activity('Customer')
           ->causedBy(Auth::user()->id)
           ->performedOn($lead)
           ->log('resetpassword customer');
        }
        
        return response()->json(['message' => 'Password reset successfully to Harvest@123']);
    }
    
    public function exportcustomerexcel(Request $request)
    {
        return Excel::download(new ExportCustomer($request), 'customer_'.date('Y-m-d H:i').'.xlsx'); 

    }
    public function exportclientexcel(Request $request)
    {
        return Excel::download(new ExportClient($request), 'client'.date('Y-m-d H:i').'.xlsx'); 

    }
}
