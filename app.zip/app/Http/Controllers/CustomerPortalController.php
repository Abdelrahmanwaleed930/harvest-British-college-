<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\AppBaseController;
use App\Models\Branch;
use App\Models\Offer;
use App\Models\Lead;
use App\Models\LeadPayment;
use App\Models\StudentExam;
use App\Models\ExtraItem;
use App\Models\SubPayment;
use App\Models\Safe;
use App\Models\Question;
use App\Models\Answer;

use App\Models\SafeTrancation;
use Mail;
use DB;
use File;
use Laracasts\Flash\Flash;
use App\Mail\PaymentInvoice;
use App\Models\PlacementApplicant;
use App\Models\PlacementKidsApplicant;
use App\Models\CertificateRequest;
use App\Models\CustomerTrack;
use App\Models\LeadCase;
use App\Models\StageLevel;
use App\Models\StudentExamAnswer;
use App\Models\ContactUs;
use App\Models\GroupWaitingList;
use App\Models\ItemCategory;
use App\Models\TrainingService;
use App\Models\ServiceFee;
use App\Models\ExamModel;
use App\Models\GroupStudent;
use App\Models\ExamModelQuestion;

use Illuminate\Database\Eloquent\Relations\MorphTo;
use Auth;

class CustomerPortalController extends AppBaseController
{
    
    public function start_exam($studentId)
    {
        $user = Auth::guard('customer')->user();
        
        $student = GroupStudent::findOrFail($studentId);

        // dd($exam_model);
        //$this->type = 2;
        $applicant = StudentExam::updateOrCreate([
            'group_id' => $student->group_id,
            'lead_id' => $student->lead_id,
            'track_id' => $student->group->track_id,
            'course_id' => $student->group->course_id,
            'level_id' => $student->group->level_id,
            'student_id' => $student->id,
        ]);
        
        session()->remove('redirectToStudentExam');
        session()->remove('contactBranchId');
        
        if($applicant->step == 1){
            $exam_model = ExamModel::where('level_id' ,$student->group->level_id)
                ->limit(1)->inRandomOrder()->first();

            $applicant->update([
                'exam_model_id' => $exam_model->id,    
            ]);
            //dd($applicant);
            return view('customers_portal.exams.index',compact('applicant','student'));
        }elseif($applicant->step == 2){
            // dd($applicant);
            
            // $questions = Question::where('track_id',$applicant->track_id)
            // ->where('course_id',$applicant->course_id)->where('level_id',$applicant->level_id)
            // ->where('skill', 'Vocabulary')->with('answers')->limit(20)->inRandomOrder()->get();
            $question = ExamModelQuestion::where('exam_model_id' , $applicant->exam_model_id)
                ->where('skill', 'Vocabulary')->pluck('question_id')->toArray();

            $questions = Question::whereIn('id' , $question)->with('answers')->get();
            
            $shown_ques = $questions[0]->id;
            
            return view('customers_portal.exams.vocabulary',compact('applicant','student','questions','shown_ques'));
            
        }elseif($applicant->step == 3){
             
             $question = ExamModelQuestion::where('exam_model_id' , $applicant->exam_model_id)
             ->where('skill', 'Grammar')->pluck('question_id')->toArray();

            //  return $question;
             $questions = Question::whereIn('id' , $question)->with('answers')->get();
            
            //  return $questions;
            
             $shown_ques = $questions[0]->id;
             

            return view('customers_portal.exams.grammar ' ,compact('applicant','student','questions','shown_ques'));
        }elseif($applicant->step == 4){

            $question = ExamModelQuestion::where('exam_model_id' , $applicant->exam_model_id)
             ->where('skill', 'Reading')->pluck('question_id')->toArray();
             
            $questions = Question::whereIn('id' , $question)->with('answers','parent')->get();
            // return $questions;

            // $shown_ques = $questions[0]->id;
            
            return view('customers_portal.exams.reading' ,compact('applicant','student','questions'));
        }elseif($applicant->step == 5){
            
            $question = ExamModelQuestion::where('exam_model_id' , $applicant->exam_model_id)
             ->where('skill', 'Listening')->pluck('question_id')->toArray();

            $questions = Question::whereIn('id' , $question)->with('answers','parent')->get();
            
            return view('customers_portal.exams.listening',compact('applicant','student' ,'questions'));
        }elseif($applicant->step == 6){
            
            $question = ExamModelQuestion::where('exam_model_id' , $applicant->exam_model_id)
             ->where('skill', 'Writing')->pluck('question_id')->toArray();
             
            $questions = Question::whereIn('id' , $question)->whereNull('parent_id')
            ->with('children')
            ->get();
            // dd($questions);
            return view('customers_portal.exams.writing',compact('applicant','student','questions'));
        }elseif ($applicant->step == 7){
            return redirect()->route('customer.show_exam_result',$applicant->id);
        }
        else{
            return redirect()->route('customer.student_exam',$studentId);
        }
        
    }
    
    public function post_start_exam(Request $request)
    {
        $applicant = StudentExam::find($request->applicationId);
        $student = GroupStudent::findOrFail($request->studentId);
        $applicant->step += 1;
        $applicant->save();
        $exam_model = ExamModel::where('level_id' ,$student->group->level_id)
        ->limit(1)->inRandomOrder()->first();
        
        return redirect()->route('customer.student_exam',$request->studentId );
    }
    
    public function post_exam_vocabulary(Request $request)
    {
        
        $point = 0.5;
        $applicant = StudentExam::find($request->applicationId);
        $show_next_msg = false;
        $answers = [];
        $answers =$request->answers;
        
        if(count($answers) == 20){
            $correctCount = Answer::whereIn('id', array_values($answers))->sum('is_correct', 1);
            
            $score = $correctCount * $point;
            $applicant->update(['vocabulary_score' => $score,'step' => 3]);
            
            $wronganswers = Answer::whereIn('id', array_values($answers))->where('is_correct', 0)->get();
            // dd($wronganswers);
            foreach($wronganswers as $wronganswer){
                StudentExamAnswer::create([
                    'student_exam_id' => $applicant->id,
                    'question_id' => $wronganswer->question_id,
                    'type' => 'Vocabulary',
                    'answer' => $wronganswer->id
                ]);
            }
        }
        return redirect()->route('customer.student_exam',$request->studentId);
    }
    public function post_exam_grammar(Request $request)
    {
        
        $point = 0.5;
        $applicant = StudentExam::find($request->applicationId);
        $show_next_msg = false;
        $answers = [];
        $answers =$request->answers;
        
        if(count($answers) == 20){
            $correctCount = Answer::whereIn('id', array_values($answers))->sum('is_correct', 1);
            $score = $correctCount * $point;
            
            $wronganswers = Answer::whereIn('id', array_values($answers))->where('is_correct', 0)->get();
            foreach($wronganswers as $wronganswer){
                StudentExamAnswer::create([
                    'student_exam_id' => $applicant->id,
                    'question_id' => $wronganswer->question_id,
                    'type' => 'Grammar',
                    'answer' => $wronganswer->id
                ]);
            }
            $applicant->update(['grammar_score' => $score,'step' => 4]);
        }
        return redirect()->route('customer.student_exam',$request->studentId);
    }
    public function post_exam_reading(Request $request)
    {
        $applicant = StudentExam::find($request->applicationId);
        $limit = 3;
        $answers = [];
        $show_next_msg = false;
         
        $answers =$request->answers;

        //  dd($request->all());
        $point = 1.5;
        if(count($answers) == 10){
            $correctCount = Answer::whereIn('id', array_values($answers))->sum('is_correct', 1);
            $score = $correctCount * $point;
            $applicant->update(['reading_score' => $score,'step' => 5]);
            
            $wronganswers = Answer::whereIn('id', array_values($answers))->where('is_correct', 0)->get();
            foreach($wronganswers as $wronganswer){
                StudentExamAnswer::create([
                    'student_exam_id' => $applicant->id,
                    'question_id' => $wronganswer->question_id,
                    'type' => 'Reading',
                    'answer' => $wronganswer->id
                ]);
            }
            return redirect()->route('customer.student_exam',$request->studentId);
        }
        return redirect()->route('customer.student_exam',$request->studentId);
    }
    public function post_exam_listening(Request $request)
    {
        $applicant = StudentExam::find($request->applicationId);
        $limit = 10;
        $answers = [];
        $show_next_msg = false;
        $answers =$request->answers;
        
        $paragraphLimit = 1;
        $point = 1;
        if(count($answers) == $limit){
            $correctCount = Answer::whereIn('id', array_values($answers))->sum('is_correct', 1);
            $score = $correctCount * $point;
            $applicant->update(['listening_score' => $score,'step' => 6]);
            
            $wronganswers = Answer::whereIn('id', array_values($answers))->where('is_correct', 0)->get();
            foreach($wronganswers as $wronganswer){
                StudentExamAnswer::create([
                    'student_exam_id' => $applicant->id,
                    'question_id' => $wronganswer->question_id,
                    'type' => 'Listening',
                    'answer' => $wronganswer->id
                ]);
            }
            
            
        }
        return redirect()->route('customer.student_exam',$request->studentId);
    }
    
    public function post_exam_writing(Request $request)
    {
        //dd($request->all());
        $applicant = StudentExam::find($request->applicationId);
        $answers =$request->answers;
        // dd($request->all());
        $applicant->update(['step' => 7,'finish' => 1]);
        $temp=[];
        if($answers != null && count($answers) > 0){
            // StudentExamAnswer::where('student_exam_id',$applicant->id)->delete();
            //dd($this->applicant,$this->answers);
            foreach($answers as $key => $answerss){
                $temp = (implode('<br/>',$answerss));
                StudentExamAnswer::create([
                    'student_exam_id' => $applicant->id,
                    'question_id' => $key,
                    'type' => 'text',
                    'answer' => $temp
                ]);
            }
        }
        
        return redirect()->route('customer.show_exam_result',$applicant->id);
    }

    public function show_answer($exam_model,$id)
    {
        
        // $exam_model_questions = ExamModelQuestion::where('exam_model_id',$exam_model)->with('question.answers')->get();
        $exam_model_question = ExamModelQuestion::with('question.answers')->with('question.parent')->where('exam_model_id' , $exam_model)->get();
        
        $student_answer = StudentExamAnswer::where('student_exam_id',$id)->pluck('answer','question_id')->toArray();
        
        
        $question = ExamModelQuestion::where('exam_model_id' , $exam_model)->pluck('question_id')->toArray();
             
        $questions = Question::whereIn('id' , $question)->with('answers','parent')->get();
         $Reading_questions = Question::whereIn('id' , $question)->where('skill','Reading')->with('answers','parent')->get()->groupBy('parent_id');
        $Listening_questions = Question::whereIn('id' , $question)->where('skill','Listening')->with('answers','parent')->get()->groupBy('parent_id');
        
        // return $student_answer;
        
        return view('customers_portal.exams.show_answer', compact('exam_model_question','Reading_questions','Listening_questions' ,'student_answer' ,'questions'));
    }
    
    public function operation_inquiry()
    {
        return view('customers_portal.operations_inquiries');
    }
    
    public function moreItemsRequests()
    {
        $categories = ItemCategory::where('status',1)->whereNotIn('id',[2,3,5])->get();
        $categoriesBook = ItemCategory::where('status',1)->where('id',1)->get();
        $categoriesFreeze = ItemCategory::where('status',1)->where('id',6)->get();
        $categoriesTransfer = ItemCategory::where('status',1)->where('id',7)->get();
        $categoriesMackeup = ItemCategory::where('status',1)->where('id',8)->get();
        $categoriesRE_Entry = ItemCategory::where('status',1)->where('id',9)->get();
        
        return view('customers_portal.moreItemsRequests',
        compact('categories','categoriesBook','categoriesFreeze','categoriesTransfer','categoriesMackeup','categoriesRE_Entry'));
    }
    
    public function technical_tracker()
    {
        $user = Auth::guard('customer')->user();
        
        if($user->getPT() != null && $user->getPT() != ''){
            $pt_result = $user->getPT();
            $total_pt = $pt_result->vocabulary_score + $pt_result->grammar_score + $pt_result->reading_score + $pt_result->listening_score + $pt_result->speaking_score + $pt_result->writing_score+ $pt_result->evaluation_score;
        }elseif($user->getKidsPT() != null && $user->getKidsPT() != ''){
            $pt_result = $user->getKidsPT();
            $total_pt = $pt_result->vocabulary_score + $pt_result->grammar_score + $pt_result->reading_score + $pt_result->listening_score + $pt_result->speaking_score + $pt_result->writing_score+ $pt_result->evaluation_score;
        }
        else{
            $pt_result = null;
            $total_pt = 0;
        }
        
        
        $exams_result = StudentExam::where('finish',1)->where('lead_id',$user->id)->get();
        
        return view('customer.technical_tracker',compact('pt_result','total_pt','exams_result'));
    }
    
    public function contact_up_post(Request $request)
    {
        $data = $request->except('_token');
        $contact = new ContactUs;
        $contact->create($data);
        
        Flash::success('Request sended successfully.');
        return redirect()->back();
    }
    
    public function ptResultPrint($pt_app_id)
    {
        $customer = Auth::guard('customer')->user();
        $ptApplicant = PlacementApplicant::findOrFail($pt_app_id);
        
        return view('customers_portal.pt_result_print',compact('ptApplicant','customer'));
    }
    
    public function contact_us()
    {
        $branches = Branch::where('status',1)->get();
        return view('customers_portal.contact_us',compact('branches'));
    }
    
    public function print_exam_result($stud_exam_id)
    {
        $customer = Auth::guard('customer')->user();
        $applicant = StudentExam::findOrFail($stud_exam_id);
        
        return view('customers_portal.print_exam_result',compact('applicant','customer'));
    }
    
    public function show_exam_result($stud_exam_id)
    {
        $customer = Auth::guard('customer')->user();

        $applicant = StudentExam::findOrFail($stud_exam_id);
        
        return view('customers_portal.exam_result',compact('applicant','customer'));
    }
    
    public function updateProfile(Request $request)
    {
        $user = Auth::guard('customer')->user();
        if($user->mobile_1 != $request->mobile_1){
            $credentials = $request->validate([
                'mobile_1' => 'required|digits_between:8,15|unique:leads',
            ]);
        }
        $data = $request->except('_token','name');
        if($request->has('name')){
            $data['name'] = ['en' => $request->name,'ar' => $request->name];
        }
        $user->update($data);
        
        return redirect()->back();
    }
    
    public function update_profile(Request $request)
    {
        $customer = Auth::guard('customer')->user();
        
        $credentials = $request->validate([
            'f_name' => 'required|regex:/(^([a-zA-Z\s]+)(\d+)?$)/u',
            'l_name' => 'required|regex:/(^([a-zA-Z\s]+)(\d+)?$)/u',
            'm_name' => 'required|regex:/(^([a-zA-Z\s]+)(\d+)?$)/u',
            'name_ar' => 'required|string',
            'gender' => 'required',
            'mobile_1' => 'required|digits_between:8,15|unique:leads,mobile_1,'.$customer->id,
            'mobile_2' => 'nullable|string|unique:leads,mobile_1,'.$customer->id,
            'email' => 'nullable|email',
        ]);
        
        
        $data = $request->except('_token','image');
        
        if($request->hasFile('image') ){
            $file = $request->file('image');
            
            if($customer->image != null && $customer->image != ''){
                $file_path = '/home/harvestc/public_html/uploads/leads/';
                unlink(sprintf($file_path . '%s', $customer->image));
            }
            
            $file_name = rand(11111,99999).'-'.$file->getClientOriginalName();
            $file->storeAs('/uploads/leads', $file_name);
            $data['image'] = $file_name;
            
            File::move(storage_path('app/uploads/leads/'.$file_name), '/home/harvestc/public_html/uploads/leads/'.$file_name);
            
        }
        
        $customer->update($data);
        Flash::success('Profile updated successfully.');
        return redirect()->back();
    }
    
    public function servicesPayment($service_id)
    {
        $user = null;
        if(Auth::guard('customer')->check()){
            $user = Auth::guard('customer')->user();
        }
        //dd($user);
        $branches = Branch::select('id','name')->where('status',1)->get();
        
        $service = ServiceFee::with('trainingService')->findOrFail($service_id);
        return view('customer.servicesPayment',compact('service','branches','user'));
    }
    
    public function showPayment($offer_id)
    {
        $user = null;
        if(Auth::guard('customer')->check()){
            $user = Auth::guard('customer')->user();
        }
        //dd($user);
        $branches = Branch::select('id','name')->where('status',1)->get();
        $offer = Offer::findOrFail($offer_id);
        //dd(number_format(2000,2,'.',''));
        return view('customer.show_payment',compact('branches','offer','user'));
    }
    
    public function itemPayment($item_id)
    {
        
        $user = Auth::guard('customer')->user();
        $item = ExtraItem::findOrFail($item_id);
        return view('customer.item_payment',compact('item','user'));
    }
    
    public function calcDueDate($date, $after)
    {
        if ($after > 12) {
            return $date->addWeeks($after == 13 ? 1 : 2)->format('Y-m-d');
        } else {
            return $date->addMonths($after)->format('Y-m-d');
        }
    }
    
    public function show_payment_details($id)
    {
        //dd(auth()->user());
        $leadPayment=LeadPayment::
            //leftjoin('payment_methods','payment_methods.id','lead_payments.payment_method_id')
            leftjoin('payment_plans','payment_plans.id','lead_payments.payment_plan_id')
            ->leftjoin('employees','employees.id','lead_payments.employee_id')
            ->leftjoin('leads','leads.id','lead_payments.lead_id')
            ->leftjoin('branches','branches.id','leads.branch_id')
            ->where('lead_payments.id',$id)
            ->where('lead_payments.lead_id',auth()->user()->id)
            ->select([
                'leads.id as leadId',
                DB::raw('concat(COALESCE(leads.f_name,"")," ",COALESCE(leads.m_name,"")," ",COALESCE(leads.l_name,"")) as leadName'),
                'leads.mobile_1 as leadPhone',
                'payment_plans.id as planeId',
                'payment_plans.title as planeTitle',
                'lead_payments.id as InvoiceNo',
                'lead_payments.paymentable_type',
                'lead_payments.paymentable_id',
                'lead_payments.amount as total',
                'lead_payments.employee_id',
                'lead_payments.discount',
                'lead_payments.rest',
                'branches.id as branchId',
                'branches.name as branchName',
                'employees.id as employeeId',
                'employees.first_name',
                'employees.middle_name',
                'employees.last_name',
                'payment_status',
                'payment_method',
                'merchantRefNumber',
                'fawryFees',
                'payment_method_id',
                'reference_num',
            ])
            ->first();
        if (!$leadPayment){
            Flash::error('Lead payment not found');
            return redirect()->back();
        }
        /*
        $leadName=json_decode($leadPayment->leadName);
        $leadPayment->leadName =$leadName->en;
        */
        $allSubPayment=SubPayment::where('sub_payments.lead_payment_id',$id)
            ->leftjoin('payment_methods','payment_methods.id','sub_payments.payment_method_id')
            ->select([
                'sub_payments.id',
                'sub_payments.amount',
                'sub_payments.due_date',
                'sub_payments.created_at',
                'sub_payments.lead_payment_id',
                'sub_payments.paid',
                'sub_payments.reference_num',
                'sub_payments.payment_status',
                'sub_payments.paymentMethod',
                'sub_payments.merchantRefNumber',
                'payment_methods.id as methodId',
                'payment_methods.title as methodName'
            ])
            ->orderBy('sub_payments.due_date', 'DESC')
            ->get();
        return view('customers_portal.show_payment',compact('leadPayment','allSubPayment'));
    }

    
    public function print_payment($id)
    {
        $leadPayment = LeadPayment::with(['lead', 'paymentPlan', 'subPayments', 'paymentable' => function (MorphTo $morphTo) {
            $morphTo->morphWith([
                'App\\Models\\Offer' => ['services.trainingService', 'items'],
                'App\\Models\\ExtraItem' => ['itemCategory'],
            ]);
        }])->find($id);

        if (empty($leadPayment)) {
            Flash::error('Lead Payment not found');

            return redirect(route('customer.payments'));
        }

        $leadPayment->increment('print_count');

        return view('customers_portal.print_invoice')->with('leadPayment', $leadPayment);
    }
    
    public function saveServicesPayment(Request $request)
    {
        $service = ServiceFee::with('trainingService')->findOrFail($request->service_id);
        $user = null;
        
        if(Auth::guard('customer')->check()){
            $user = Auth::guard('customer')->user();
        }else{
            $check_user = Lead::where('mobile_1',$request->mobile_1)->first();
            if($check_user != null && $check_user != ''){
                $user = $check_user;
                
                Auth::guard('customer')->login($user);
            }else{
                $credentials = $request->validate([
                    'f_name' => 'required|string|max:255',
                    'l_name' => 'required|string|max:255',
                    'email' => 'required|string|email',
                    'gender' => 'required|string',
                    'branch_id' => 'required',
                    'mobile_1' => 'required|digits_between:8,15|unique:leads',
                ]);
        
                $user = Lead::Create([
                    'name' => ['en' => $request->f_name, 'ar' => $request->f_name],
                    'f_name' => $request->f_name,
                    'l_name' => $request->l_name,
                    'gender' => $request->gender,
                    'mobile_1' => $request->mobile_1,
                    'email' => $request->email,
                    'lead_source_id' => 16,
                    'type' => 2,
                    'branch_id' => $request->branch_id,
                    'password' => 'Harvest@123',
                    'register_from' => 'register_form',
                ]);
                Auth::guard('customer')->login($user);
            }
                
        }
        
        if($service->checkReservation($user->id)){
            $data['paymentable_type'] = 'App\Models\ServiceFee';
            $data['paymentable_id'] = $service->id;
            $data['amount'] = $service->fees;
            $data['lead_id'] = $user->id;
            $data['branch_id'] = $user->branch_id;
            $data['payment_plan_id'] = 2;
            $data['rest'] = 0;
            $data['payment_method_id'] = $request->payment_method_id;
            $data['reference_num'] = $request->referenceNumber;
            $data['payment_status'] = $request->orderStatus;
            $data['payment_method'] = $request->paymentMethod;
            $data['merchantRefNumber'] = $request->merchantRefNumber;
            $data['fawryFees'] = $request->fawryFees;
            //dd($data);
            $payment = LeadPayment::create($data);
            
            if($payment->payment_method == 'PayAtFawry' || $payment->payment_status != 'PAID'){
                $now = now();
                $amount = $service->fees;
                
                $payment->payment_plan_id = 3;
                $payment->rest = $amount;
                $payment->save();
                
                $subPayment = array(
                    'amount' => $amount,
                    'payment_date' => $now->format('Y-m-d'),
                    'due_date' => $now->format('Y-m-d'),
                    'paid' => 0,
                    'branch_id' => $user->branch_id,
                    'payment_method_id' => $request->payment_method_id,
                    'reference_num' => $request->referenceNumber,
                    'payment_status' => $request->orderStatus,
                    'paymentMethod' => $request->paymentMethod,
                    'merchantRefNumber' => $request->merchantRefNumber,
                    'fawryFees' => $request->fawryFees,
                );
                
                $payment->subPayments()->create($subPayment);
            }else{
                $paid = $payment->amount;
                $safe = Safe::where('is_hq', 1)->first();
                if (!$safe) {
                    Flash::error('No HQ safe found.');
                    return null;
                }
                
                $safe->increment('balance', $paid);
                if ($safe->is_hq){
                    $senderSafe = Safe::where('branch_id', $user->branch_id)
                        ->where('is_manager',1)->where('is_hq', 0)->first();
                    SafeTrancation::create([
                        'sender' => $senderSafe->employee_id,
                        'receiver' => $safe->employee_id,
                        'safe_sender' => $senderSafe->id,
                        'safe_receiver' => $safe->id,
                        'amount' => $paid,
                        //'description' => ,
                        'payment_methods_id' => $request->payment_method_id,
                        'status' => 'approve',
                    ]);
                }
            }
                
            $msg = "Your purchase was successful. Invoice Number:" . $payment->id;

            if ($user->email){
                $payment->load('lead', 'paymentPlan', 'subPayments', 'paymentable');
    
                Mail::to($user->email)->send(new PaymentInvoice($payment));
            }

            Flash::success('Lead Payment saved successfully.');

        }
        return redirect()->route('customer.payments');
        
    }
    
    public function saveItemPayment(Request $request)
    {
        //dd($request->all());
        $item = ExtraItem::findOrFail($request->item_id);
        $user = Auth::guard('customer')->user();
        //dd($item,$user->id,$item->checkReservation($user->id),$item);
        
        if($item->checkReservation($user->id)){
            $data['paymentable_type'] = 'App\Models\ExtraItem';
            $data['paymentable_id'] = $item->id;
            $data['amount'] = $item->price;
            $data['lead_id'] = $user->id;
            $data['branch_id'] = $user->branch_id;
            $data['payment_plan_id'] = 2;
            $data['rest'] = 0;
            $data['payment_method_id'] = $request->payment_method_id;
            $data['reference_num'] = $request->referenceNumber;
            $data['payment_status'] = $request->orderStatus;
            $data['payment_method'] = $request->paymentMethod;
            $data['merchantRefNumber'] = $request->merchantRefNumber;
            $data['fawryFees'] = $request->fawryFees;
            //dd($data);
            $payment = LeadPayment::create($data);
            
            if($payment->payment_status != 'PAID'){
                $now = now();
                $amount = $service->fees;
                
                $payment->payment_plan_id = 3;
                $payment->rest = $amount;
                $payment->save();
                
                $subPayment = array(
                    'amount' => $amount,
                    'payment_date' => $now->format('Y-m-d'),
                    'due_date' => $now->format('Y-m-d'),
                    'paid' => 0,
                    'branch_id' => $user->branch_id,
                    'payment_method_id' => $request->payment_method_id,
                    'reference_num' => $request->referenceNumber,
                    'payment_status' => $request->orderStatus,
                    'paymentMethod' => $request->paymentMethod,
                    'merchantRefNumber' => $request->merchantRefNumber,
                    'fawryFees' => $request->fawryFees,
                );
                
                $payment->subPayments()->create($subPayment);
                
                if($item->id == 28){
                    $check_pt = PlacementApplicant::where('mobile',$user->mobile_1)->first();
                    
                    $check_kids_pt = PlacementKidsApplicant::where('mobile',$user->mobile_1)->first();
                    
                    if($check_pt != null && $check_pt != ''){
                        $check_pt->update(['finish' => 0]);
                    }
                    if($check_kids_pt != null && $check_kids_pt != ''){
                        $check_kids_pt->update(['finish' => 0]);
                    }
                }
            }else{
                $paid = $payment->amount;
                $safe = Safe::where('is_hq', 1)->first();
                if (!$safe) {
                    Flash::error('No HQ safe found.');
                    return null;
                }
                
                $safe->increment('balance', $paid);
                if ($safe->is_hq){
                    $senderSafe = Safe::where('branch_id', $user->branch_id)
                        ->where('is_manager',1)->where('is_hq', 0)->first();
                    SafeTrancation::create([
                        'sender' => $senderSafe->employee_id,
                        'receiver' => $safe->employee_id,
                        'safe_sender' => $senderSafe->id,
                        'safe_receiver' => $safe->id,
                        'amount' => $paid,
                        //'description' => ,
                        'payment_methods_id' => $request->payment_method_id,
                        'status' => 'approve',
                    ]);
                }
            }
            if(in_array($item->id,[2,3])){
                $request_data = [
                    'name' => $user->getName(),
                    'email' => $user->email,
                    'phone' => $user->mobile_1,
                    'display_name' => $request->print_name,
                    'certificate_id' => $item->id,
                    'invoice_id' => $payment->id,
                ];
                $certificate_request = CertificateRequest::create($request_data);
            }
            
            if($item->send_operation_inquiry != null && $item->send_operation_inquiry != ''){
                
                $data = [
                    'lead_id' => $user->id,
                    //'employee_id' => $this->customer->assigned_employee_id,
                    'branch_id' => $user->branch_id,
                    'label_type_id' => $item->send_operation_inquiry,
                    'customer_notes' => 'Paid by fawry online',
                    'type' => 4,
                    'status' => 0,
                    'follow_up_type' => 3,
                    'serial' => time(),
                ];
                $leadCase = LeadCase::create($data);
            }
            $msg = "Your purchase was successful. Invoice Number:" . $payment->id;

            if ($user->email){
                $payment->load('lead', 'paymentPlan', 'subPayments', 'paymentable');
    
                Mail::to($user->email)->send(new PaymentInvoice($payment));
            }

            Flash::success('Lead Payment saved successfully.');

        }
        return redirect()->route('customer.payments');
    }

    public function savePayment(Request $request)
    {
        //dd($request->all());
        $user = null;
        $offer = Offer::findOrFail($request->offer_id);
        
        if(Auth::guard('customer')->check()){
            $user = Auth::guard('customer')->user();
        }else{
            $check_user = Lead::where('mobile_1',$request->mobile_1)->first();
            if($check_user != null && $check_user != ''){
                $user = $check_user;
                
                Auth::guard('customer')->login($user);
            }else{
                $credentials = $request->validate([
                    'f_name' => 'required|string|max:255',
                    'l_name' => 'required|string|max:255',
                    'email' => 'required|string|email',
                    'gender' => 'required|string',
                    'branch_id' => 'required',
                    'mobile_1' => 'required|digits_between:8,15|unique:leads',
                ]);
        
                $user = Lead::Create([
                    'name' => ['en' => $request->f_name, 'ar' => $request->f_name],
                    'f_name' => $request->f_name,
                    'l_name' => $request->l_name,
                    'gender' => $request->gender,
                    'mobile_1' => $request->mobile_1,
                    'email' => $request->email,
                    'lead_source_id' => 16,
                    'type' => 2,
                    'branch_id' => $request->branch_id,
                    'password' => 'Harvest@123',
                    'register_from' => 'register_form',
                ]);
                Auth::guard('customer')->login($user);
            }
                
        }
        
        if($offer->checkReservation($user->id)){
            $data['paymentable_type'] = 'App\Models\Offer';
            $data['paymentable_id'] = $offer->id;
            $data['amount'] = $offer->fees;
            $data['lead_id'] = $user->id;
            $data['branch_id'] = $user->branch_id;
            $data['payment_plan_id'] = $offer->payment_plan_id;
            
            $data['include_books'] = $offer->include_books;
            
            $payment = LeadPayment::create($data);
            $installment = $offer->installment;
            $now = now();
            //dd($installment);
            $amount = $offer->fees;
            $subPayments = [];
            $subPayments[0] = [
                'amount' => $installment ? $installment->deposit : $amount,
                'payment_date' => $now->format('Y-m-d'),
                'due_date' => $now->format('Y-m-d'),
                'paid' => ($request->orderStatus == 'PAID')?1:0,
                'branch_id' => $user->branch_id,
                'payment_method_id' => $request->payment_method_id,
                'reference_num' => $request->referenceNumber,
                'payment_status' => $request->orderStatus,
                'paymentMethod' => $request->paymentMethod,
                'merchantRefNumber' => $request->merchantRefNumber,
                'fawryFees' => $request->fawryFees,
            ];
            if ($installment) {
                $first_due_date = $this->calcDueDate($now, $installment->first_due_date);
                $subPayments[1] = [
                    'amount' => $installment->first_payment,
                    'due_date' => $first_due_date
                ];
    
                if ($installment->second_payment) {
                    $second_due_date = $this->calcDueDate($now, $installment->second_due_date);
                    $subPayments[2] = [
                        'amount' => $installment->second_payment,
                        'due_date' => $second_due_date
                    ];
                }
    
                if ($installment->third_payment) {
                    $third_due_date = $this->calcDueDate($now, $installment->third_due_date);
                    $subPayments[3] = [
                        'amount' => $installment->third_payment,
                        'due_date' => $third_due_date
                    ];
                }
    
                if ($installment->fourth_payment) {
                    $fourth_due_date = $this->calcDueDate($now, $installment->fourth_due_date);
                    $subPayments[4] = [
                        'amount' => $installment->fourth_payment,
                        'due_date' => $fourth_due_date,
                    ];
                }
            }
            //dd($subPayments);
            if($offer->payment_plan_id == 1 || $offer->payment_plan_id == 3){
                $paid = 0;
                //$discount = $payment->discount ?? 0;
                foreach ($subPayments as $key => $subPayment) {
                    if ($key === 0) {
                        $paid = $subPayment['amount'];
                    }
                    if ($key === 1 && $offer->payment_plan_id == 3){
                        $subPayment['amount'] = $payment->amount - /*$discount -*/ $paid;
                    }
                    if($subPayment['amount'] > 0){
                        $payment->subPayments()->create($subPayment);
                    }
                }
                
                $rest = $payment->amount - /*$discount -*/ $paid;
                $rest = $rest < 0 ? 0 : $rest;
                $payment->update(['rest' => $rest]);
            }else{
                $paid = $payment->amount;
                $payment->update(
                    [
                        'payment_method_id' => $subPayments[0]['payment_method_id'],
                        'reference_num' => $subPayments[0]['reference_num'],
                        'payment_status' => $subPayments[0]['payment_status'],
                        'payment_method' => $subPayments[0]['paymentMethod'],
                        'merchantRefNumber' => $subPayments[0]['merchantRefNumber'],
                        'fawryFees' => $subPayments[0]['fawryFees']
                    ]
                );
                
                if($payment->payment_method == 'PayAtFawry' || $payment->payment_status != 'PAID'){
                    $now = now();
                    $amount = $service->fees;
                    
                    $payment->payment_plan_id = 3;
                    $payment->rest = $amount;
                    $payment->save();
                    
                    $subPayment = array(
                        'amount' => $amount,
                        'payment_date' => $now->format('Y-m-d'),
                        'due_date' => $now->format('Y-m-d'),
                        'paid' => 0,
                        'branch_id' => $user->branch_id,
                        'payment_method_id' => $request->payment_method_id,
                        'reference_num' => $request->referenceNumber,
                        'payment_status' => $request->orderStatus,
                        'paymentMethod' => $request->paymentMethod,
                        'merchantRefNumber' => $request->merchantRefNumber,
                        'fawryFees' => $request->fawryFees,
                    );
                    
                    $payment->subPayments()->create($subPayment);
                
                }
            }
            if($payment->payment_status == 'PAID'){
                $safe = Safe::where('is_hq', 1)->first();
                if (!$safe) {
                    Flash::error('No HQ safe found.');
                    return null;
                }
                
                $safe->increment('balance', $paid);
                if ($safe->is_hq){
                    $senderSafe = Safe::where('branch_id', $user->branch_id)
                        ->where('is_manager',1)->where('is_hq', 0)->first();
                    SafeTrancation::create([
                        'sender' => $senderSafe->employee_id,
                        'receiver' => $safe->employee_id,
                        'safe_sender' => $senderSafe->id,
                        'safe_receiver' => $safe->id,
                        'amount' => $paid,
                        //'description' => ,
                        'payment_methods_id' => $request->payment_method_id,
                        'status' => 'approve',
                    ]);
                }
            }
            $msg = "Your purchase was successful. Invoice Number:" . $payment->id;
            $user->update(['type' => 2]);
            //PlacementApplicant::where('mobile', $user->mobile_1)->delete();
            $offersFee = $offer->services;
            //dd($offer);
            if($offer->has_levels == 1 && $offersFee != null && count($offersFee) > 0){
                foreach ($offersFee as $offer){
                    $trainingService = $offer->trainingService;
                    $trackId = $trainingService->track_id;
                    $courseId = $trainingService->course_id;
                    $levelId = $trainingService->levels[0]->id;
                    $levelsCount = $trainingService->levels->count();
                    $groupLevel = $trainingService->levels[0];
    
                    $customerTrack = CustomerTrack::where('lead_id',$user->id)->where('course_id', $courseId)->first();
    
                    if ($customerTrack) {
                        $customerTrack->increment('total', $levelsCount);
                    } else {
                        $customerTrack = CustomerTrack::create([
                            'lead_id' => $user->id,
                            'track_id' => $trackId,
                            'course_id' => $courseId,
                            'level_id' => $levelId,
                            'total' => $levelsCount,
                            'used' => 0,
                        ]);
                    }
                }
                
                $timeframesString = implode(',', $offer->timeframes->pluck('id')->toArray());
                $intervalsString = implode(',', $offer->intervals->pluck('id')->toArray());
                $disciplinesIds = $offer->disciplines->pluck('id')->toArray();
                GroupWaitingList::create([
                    'lead_id' => $user->id,
                    'level_id' => $groupLevel->id,
                    'timeframes' => $timeframesString,
                    'intervals' => $intervalsString,
                    'lead_payment_id' => $payment->id,
                    'discipline_id' => ($disciplinesIds != null && count($disciplinesIds) > 0)?$disciplinesIds[0]->id:null
                ]);
                
            }elseif($offer->has_levels == 0 && $offer->num_levels > 0 && $user->pt_level !== '' && $user->pt_level !== null){
                $course = $offer->course;
                
                $stage_levels = StageLevel::leftJoin('stages','stages.id','=','stage_levels.stage_id')->where('stages.track_id',$offer->course_id)->where('stage_levels.value','>=',$user->pt_level)->take($offer->num_levels)->pluck('stage_levels.id')->toArray();
                
                $check_cusTrack = CustomerTrack::where('lead_id',$user->id)->where('track_id',$offer->track_id)->where('course_id',$offer->course_id)->first();
                $groupLevel = StageLevel::find($stage_levels[0]);
                //dd($stage_levels);
                if($stage_levels != null && count($stage_levels) > 0 && ! $check_cusTrack){
                    $customerTrack = CustomerTrack::create([
                        'lead_id' => $user->id,
                        'track_id' => $offer->track_id,
                        'course_id' => $offer->course_id,
                        'level_id' => $stage_levels[0],
                        'total' => $offer->num_levels,
                        'used' => 0,
                    ]);
                    
                    //dd($stage_levels,$training_service_levels,$total,$training_services->pluck('id'));
                    $timeframesString = implode(',', $offer->timeframes->pluck('id')->toArray());
                    $intervalsString = implode(',', $offer->intervals->pluck('id')->toArray());
                    $disciplinesIds = $offer->disciplines->pluck('id')->toArray();
                    GroupWaitingList::create([
                        'lead_id' => $user->id,
                        'level_id' => $stage_levels[0],
                        'timeframes' => $timeframesString,
                        'intervals' => $intervalsString,
                        'lead_payment_id' => $payment->id,
                        'discipline_id' => ($disciplinesIds != null && count($disciplinesIds) > 0)?$disciplinesIds[0]->id:null
                    ]);
                    
                }
            }else{
                
            }
            
            if ($user->email) {
                $payment->load('lead', 'paymentPlan', 'subPayments', 'paymentable');
    
                Mail::to($user->email)->send(new PaymentInvoice($payment));
            }
    
            // $sms = new SMS;
            // $mobile = $user->mobile_1;
            // $sms->send($mobile, $msg);
    
            // $log = MessageLog::create([
            //     'type' => 1,
            //     'content' => $msg
            // ]);
            // $log->leads()->sync($user->id);
    
            Flash::success('Lead Payment saved successfully.');

        }
        return redirect()->route('customer.payments');
    }
    
    public function ptResult()
    {
        $customer = Auth::guard('customer')->user();
        $ptApplicant = PlacementApplicant::where('mobile', $customer->mobile_1)->latest()->first();
        
        
        return view('customers_portal.pt_result',compact('ptApplicant','customer'));
    }

    public function ptKidsResult()
    {
        $customer = Auth::guard('customer')->user();
        $ptApplicant = PlacementKidsApplicant::where('mobile', $customer->mobile_1)->latest()->first();
        
        
        return view('customers_portal.kids_pt_result',compact('ptApplicant','customer'));
    }
    
    public function ptKidsResultPrint($pt_app_id)
    {
        $customer = Auth::guard('customer')->user();
        $ptApplicant = PlacementKidsApplicant::findOrFail($pt_app_id);
        
        return view('customers_portal.kids_pt_result_print',compact('ptApplicant','customer'));
    }

    public function courses()
    {
        return view('customers_portal.courses');
    }

    public function payments()
    {
        return view('customers_portal.payments');
    }

    public function profile()
    {
        return view('customers_portal.profile');
    }

    public function setconfirmation($group_id,Request $request){
        $customer = Auth::guard('customer')->user();
        
        $students = GroupStudent::where('lead_id',$customer->id)->where('group_id' , $group_id);
       
        $confirmation =$request->Confirmation;
        $students = $students->update(['Confirmation'=>$confirmation]);
        if($confirmation == 1)
        {
            $customer_track = CustomerTrack::where('lead_id',$customer->id)->first();
            $customer_track->used += 1;
            $customer_track->save();
        }
    
        return redirect('/customerPortal/courses');
        


    }
}
