<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Flash;
use Auth;
use App\Models\EmployeeDevice;
use App\Models\Branch;
use App\Models\Employee;


class EmployeeDeviceController extends Controller
{
    public function index(Request $request){
        
     $EmployeeDevices = EmployeeDevice::with('branch','employee')->get();
     
     return view('EmployeeDevice.index' , compact('EmployeeDevices'));
        
    }
    public function show(Request $request ,$id){
        $EmployeeDevice = EmployeeDevice::with('branch','employee')->find($id);
        
        return view('EmployeeDevice.show',compact('EmployeeDevice'));
        
    }
    public function create(Request $request){
        $branch = Branch::where('status',1)->pluck('name','id');
        $employee = [];
        
        return view('EmployeeDevice.create',compact('branch','employee'));
        
    }
    public function store(Request $request){
        $validator = $request->validate([
            'branch_id' => 'required',
            'employee_id' => 'required',
        ]);
       
        $EmployeeDevice = new EmployeeDevice;
        $EmployeeDevice->branch_id =$request->branch_id;
        $EmployeeDevice->employee_id =$request->employee_id;
        $EmployeeDevice->serial_number =$request->serial_number;
        $EmployeeDevice->version =$request->version;
        $EmployeeDevice->os =$request->os;
        $EmployeeDevice->os_installation =$request->os_installation;
        $EmployeeDevice->computer_type =$request->computer_type;
        $EmployeeDevice->cpu_type =$request->cpu_type;
        $EmployeeDevice->system_memory =$request->system_memory;
        $EmployeeDevice->max_memory_capacity =$request->max_memory_capacity;
        $EmployeeDevice->type =$request->type;
        $EmployeeDevice->bios_type =$request->bios_type;
        $EmployeeDevice->hand_disk_size =$request->hand_disk_size;
        $EmployeeDevice->accessories = json_encode($request->accessories);
        $EmployeeDevice->save();
        Flash::success(' Employee Device Created successfully.');
        return redirect(route('admin.EmployeeDevice.index'));
    
    }
    public function edit(Request $request , $id){
       $EmployeeDevice = EmployeeDevice::find($id);
       $branch = Branch::where('status',1)->where('id',$EmployeeDevice->branch_id)->pluck('name','id');
       $employee = Employee::where('status',1)->where('id',$EmployeeDevice->employee_id)->get()->pluck('name','id');
       
       return view('EmployeeDevice.edit',compact('EmployeeDevice','branch','employee'));
        
    }
    public function update(Request $request , $id){
         $validator = $request->validate([
            'branch_id' => 'required',
            'employee_id' => 'required',
        ]);
        $accessories = json_decode($request->accessories);
        $EmployeeDevice = EmployeeDevice::find($id);
        $EmployeeDevice->branch_id =$request->branch_id;
        $EmployeeDevice->employee_id =$request->employee_id;
        $EmployeeDevice->serial_number =$request->serial_number;
        $EmployeeDevice->version =$request->version;
        $EmployeeDevice->os =$request->os;
        $EmployeeDevice->os_installation =$request->os_installation;
        $EmployeeDevice->computer_type =$request->computer_type;
        $EmployeeDevice->cpu_type =$request->cpu_type;
        $EmployeeDevice->system_memory =$request->system_memory;
        $EmployeeDevice->max_memory_capacity =$request->max_memory_capacity;
        $EmployeeDevice->type =$request->type;
        $EmployeeDevice->bios_type =$request->bios_type;
        $EmployeeDevice->hand_disk_size =$request->hand_disk_size;
        $EmployeeDevice->accessories =$accessories;
        $EmployeeDevice->save();
        Flash::success('Employee Device Updated successfully.');
        return redirect(route('admin.EmployeeDevice.index'));
    }
    public function destroy(Request $request,$id){
        
        $EmployeeDevice = EmployeeDevice::find($id);
        $EmployeeDevice->delete();
        Flash::success('Employee Device Deleted successfully.');
        return redirect(route('admin.EmployeeDevice.index'));
     
    }
}
