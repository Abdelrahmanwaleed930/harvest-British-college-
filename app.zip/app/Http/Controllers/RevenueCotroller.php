<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\Employee;
use App\Models\LeadPayment;
use App\Models\SubPayment;
use App\Models\PaymentMethod;
use App\Models\PaymentPlan;
use Illuminate\Http\Request;
use \DateTime;
use Flash;
use DB;
use Illuminate\Support\Facades\Auth;

use Spatie\Activitylog\Contracts\Activity;


class RevenueCotroller extends Controller
{
    public function fawryPaymentdelete(Request $request)
    {
        $lead_payment = LeadPayment::findOrFail($request->InvoiceNo);
        
        if($lead_payment->payment_plan_id == 1 || $lead_payment->payment_plan_id == 3){
            //dd('ddd');
            SubPayment::where('lead_payment_id',$lead_payment->id)->delete();
        }
        $lead_payment->delete();
        
        
         activity('Debtor')
           ->causedBy(Auth::user()->id)
           ->performedOn($lead_payment)
           
           ->log('Delete Debtor Invoices');

        
        return redirect()->route('admin.debtor.index');
    }
    
    public function revenue(Request $request)
    {
        $user=Auth::user();
        //dd($user->branches);
        //  return $allBranches['id'];
        
        $allpayment_methods = PaymentMethod::where('status' , 1)->get();
        $paymentMethodsid = $allpayment_methods->pluck('id')->toArray();
        $paymentMethods= $request->payment_method;
        
        $allpaymentplan = PaymentPlan::where('status' , 1)->get();
        $paymentplansid  = $allpaymentplan->pluck('id')->toArray();
        $paymentplans = $request->payment_plan;
        
        $reference_number = $request->reference_number;
        
          $allBranches=Branch::where('status',1)->pluck('name','id');
        
        $branchesID=[];
        foreach ($allBranches as $key => $branch){
            array_push($branchesID , $key);
        }
       
        // return $branchesID;

        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $ellEmployees = Employee::where('account_Type', 'Operations Account')->where('status',1)
                ->whereHas('branches', function ($query) use ($request) {
                    $query->whereIn('id', $request->get('branches'));
                })->get();
        }else{
            $ellEmployees = Employee::where('account_Type', 'Operations Account')->where('status',1)
                ->whereHas('branches', function ($query) use ($branchesID) {
                    $query->whereIn('id', $branchesID);
                })->get();
        }
        $CurrentDate = (new DateTime('now'))->format('Y-m-d');
        $Employee =Employee::where('account_Type', 'Operations Account')->where('status',1)->get()->pluck('name','id')->toArray();
        $StartDate = null;
        $EndDate = null;
        $reg_to=null;
        if($request -> daterange != null && $request -> daterange != ''){
            $daterange = explode(' - ',$request -> daterange);
            $StartDate = date_format(date_create($daterange[0]),'Y-m-d');
            // $EndDate = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $EndDate= date_format($reg_to,"Y-m-d");
            
        }
        $registration_from = null;
        $registration_to = null;
        $reg_to=null;
        if ($request->has('registration_daterange') && $request->get('registration_daterange') != null && $request->get('registration_daterange') != '') {
            $daterange = explode(' - ',$request->get('registration_daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            // $registration_to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
            
        }
        
        $Branches = $request->branches;
        $employee = $request->ellEmployee;
        $status = $request->status;
        $category = $request->category;
        $type = $request->type;
        
        $allRevenue = SubPayment::with('Owner')->join('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
            ->leftjoin('payment_methods','payment_methods.id','sub_payments.payment_method_id')
            ->leftjoin('payment_plans','payment_plans.id','lead_payments.payment_plan_id')
            ->leftjoin('employees','employees.id','sub_payments.employee_id')
            ->leftjoin('leads','leads.id','lead_payments.lead_id')
            ->leftjoin('branches','branches.id','sub_payments.branch_id')
            ->whereIn('lead_payments.payment_plan_id',[1,3])
            ->whereNotNull('lead_payments.paymentable_type')->whereNotNull('lead_payments.paymentable_id')
            ->where('sub_payments.paid',1);

        $oldPayments = SubPayment::join('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
            ->leftjoin('payment_methods','payment_methods.id','sub_payments.payment_method_id')
            ->leftjoin('payment_plans','payment_plans.id','lead_payments.payment_plan_id')
            ->leftjoin('employees','employees.id','sub_payments.employee_id')
            ->leftjoin('leads','leads.id','lead_payments.lead_id')
            ->leftjoin('branches','branches.id','sub_payments.branch_id')
            ->whereIn('lead_payments.payment_plan_id',[1,3])
            ->whereNull('lead_payments.paymentable_type')
            ->where('sub_payments.paid',1)->with('Owner')
            // ->whereRaw('sub_payments.created_at != DATE_FORMAT(lead_payments.created_at, "%Y-%m-%d")');
            ->whereRaw('sub_payments.updated_at !=sub_payments.created_at');
            
        $all_leads_payments = LeadPayment::with('Owner')->leftjoin('payment_plans','payment_plans.id','lead_payments.payment_plan_id')
            ->leftjoin('employees','employees.id','lead_payments.employee_id')
            ->leftjoin('leads','leads.id','lead_payments.lead_id')
            ->leftjoin('branches','branches.id','lead_payments.branch_id')
            ->where('payment_plan_id',2)->where('rest',0)
            ->whereNotNull('lead_payments.paymentable_type')->whereNotNull('lead_payments.paymentable_id');


        $revenueallmount=($oldPayments->sum('sub_payments.amount') + $allRevenue->sum('sub_payments.amount') + ($all_leads_payments->sum('lead_payments.amount')) - $all_leads_payments->sum('lead_payments.discount'));
        //dd($revenueallmount,$allRevenue->sum('sub_payments.amount'),$all_leads_payments->sum('lead_payments.amount'));
        if(!$StartDate && !$reg_to && !$request->has('Action')){
            //dd('dddd');
            $allRevenue->where('sub_payments.due_date',$CurrentDate);
            $oldPayments->where('sub_payments.due_date',$CurrentDate);
            $all_leads_payments->where('lead_payments.created_at','like','%'.$CurrentDate.'%');
        }
        /*if($StartDate != null && $EndDate != '')
        {
            $allRevenue = $allRevenue->whereBetween('sub_payments.due_date', [$StartDate, $EndDate]);
            $all_leads_payments = $all_leads_payments->whereBetween('lead_payments.created_at', [$StartDate, $EndDate]);;
        }*/
        if($StartDate){
            //dd('ssss');
            $all_leads_payments->where('lead_payments.created_at','>=',$StartDate);
            $allRevenue->where('sub_payments.due_date','>=',$StartDate);
            $oldPayments->where('sub_payments.due_date','>=',$StartDate);
        }
        
        if($EndDate){
            $all_leads_payments->where('lead_payments.created_at','<',$EndDate);
            $allRevenue->where('sub_payments.due_date','<',$EndDate);
            $oldPayments->where('sub_payments.due_date','<',$EndDate);
        }
        if ($registration_from != null && $registration_to != '') {
            $allRevenue->whereBetween('leads.created_at', [$registration_from, $registration_to]);
            $oldPayments->whereBetween('leads.created_at', [$registration_from, $registration_to]);
            $all_leads_payments->whereBetween('leads.created_at', [$registration_from, $registration_to]);
        }
        //dd($CurrentDate,$allRevenue->get());
        if($type != null && $type != ''){
            $allRevenue->where('leads.type',$type);
            $oldPayments->where('leads.type',$type);
            $all_leads_payments->where('leads.type','<=',$type);
        }
        if ($request->has('branches') && count($Branches) !=0 &&  !in_array(0,$Branches) ){
            $allRevenue->whereIn('sub_payments.branch_id', $Branches);
            $oldPayments->whereIn('sub_payments.branch_id', $Branches);
            $all_leads_payments->whereIn('lead_payments.branch_id', $Branches);
            
        }else{
            $allRevenue->whereIn('sub_payments.branch_id',$branchesID);
            $oldPayments->whereIn('sub_payments.branch_id',$branchesID);
            $all_leads_payments->whereIn('lead_payments.branch_id',$branchesID);

        }
        if($request->has('search') && $request->get('search') != null && $request->  get('search') != ''){
            $all_leads_payments->where(function ($query) use ($request){
                $query->where('leads.name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.mobile_1', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.email', 'like', '%' . $request->get('search') . '%');
            });
            $oldPayments->where(function ($query) use ($request){
                $query->where('leads.name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.mobile_1', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.email', 'like', '%' . $request->get('search') . '%');
            });
            $allRevenue->where(function ($query) use ($request){
                $query->where('leads.name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.mobile_1', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.email', 'like', '%' . $request->get('search') . '%');
            });
        }
        if ($request->has('ellEmployee') && $employee !='' ){
            $allRevenue->where('sub_payments.owner_id', $request->get('ellEmployee'));
            $oldPayments->where('lead_payments.owner_id', $request->get('ellEmployee'));
            $all_leads_payments->where('lead_payments.owner_id', $request->get('ellEmployee'));
        }
        
        if ($request->has('employee_id') && $request->get('employee_id') !='' ){
            $allRevenue->where('sub_payments.employee_id', $request->get('employee_id'));
            $oldPayments->where('lead_payments.employee_id', $request->get('employee_id'));
            $all_leads_payments->where('lead_payments.employee_id', $request->get('employee_id'));
        }
        
        if ($request->has('status') && $status !='' ){
            if ($status == 0){
                $allRevenue->where('lead_payments.rest', 0);
                $oldPayments->where('lead_payments.rest', 0);
                $all_leads_payments->where('lead_payments.rest', 0);
            }else{
                $allRevenue->where('lead_payments.rest','!=', 0);
                $oldPayments->where('lead_payments.rest','!=', 0);
                $all_leads_payments->where('lead_payments.rest','!=', 0);
            }
        }
        if ($request->has('category') && $category !='' ){
            $allRevenue->where('lead_payments.paymentable_type', $category);
            $oldPayments->where('lead_payments.paymentable_type', $category);
            $all_leads_payments->where('lead_payments.paymentable_type', $category);
        }
         
        if ($request->has('payment_method') && count($paymentMethods) != 0 &&  !in_array(0, $paymentMethods)) {
            // dd($paymentMethods);
            $allRevenue->whereIn('sub_payments.payment_method_id', $paymentMethods);
            $oldPayments->whereIn('sub_payments.payment_method_id', $paymentMethods);
            $all_leads_payments->whereIn('lead_payments.payment_method_id', $paymentMethods);
        } 
        if ($request->has('offer_type') && $request->get('offer_type') != null &&  $request->get('offer_type') != ' ') {
            // dd($paymentMethods);
            $allRevenue->where('sub_payments.type', $request->get('offer_type'));
            
            $all_leads_payments->where('lead_payments.type', $request->get('offer_type'));
        } 
        
        if ($request->has('payment_plan') && count($paymentplans) != 0 &&  !in_array(0, $paymentplans)) {
            // dd($paymentplans);
            $allRevenue->whereIn('lead_payments.payment_plan_id', $paymentplans);
            $oldPayments->whereIn('lead_payments.payment_plan_id', $paymentplans);
            $all_leads_payments->whereIn('lead_payments.payment_plan_id', $paymentplans);
        } 
        
        if($request->has('reference_number') && $request->reference_number != null && $request->reference_number !='' )
        {
            // dd($reference_number);
            $allRevenue->where('lead_payments.reference_num' , $reference_number);
            $oldPayments->where('lead_payments.reference_num' , $reference_number);
            $all_leads_payments->where('lead_payments.reference_num' , $reference_number);

        }
        //dd($all_leads_payments->toSql());
        $revenueCount=$oldPayments->count() + $allRevenue->count() + $all_leads_payments->count();

        // $allcount = $allRevenue->where('sub_payments.paid',1)->count();
        // return $allcount;

        $revenueTotalAmount = (($oldPayments->sum('sub_payments.amount') + $allRevenue->sum('sub_payments.amount') + ($all_leads_payments->sum('lead_payments.amount')) - $all_leads_payments->sum('lead_payments.discount')));
        //dd($revenueTotalAmount,$allRevenue->sum('sub_payments.amount'),$all_leads_payments->sum('lead_payments.amount'),$all_leads_payments->pluck('lead_payments.amount'));
        $allRevenue = $allRevenue->select([
                'sub_payments.id',
                'sub_payments.amount',
                'sub_payments.due_date',
                'sub_payments.created_at',
                'sub_payments.lead_payment_id',
                'sub_payments.payment_status',
                'sub_payments.reference_num',
                'sub_payments.upload_bill',
                'sub_payments.type',
                'sub_payments.owner_id',
                'leads.id as leadId',
                DB::raw('concat(COALESCE(leads.f_name,"")," ",COALESCE(leads.m_name,"")," ",COALESCE(leads.l_name,"")) as leadName'),
                'leads.mobile_1 as leadPhone',
                'leads.type as leadType',
                'leads.email as leadEmail',
                'leads.lead_source_id',
                'leads.created_at as register',
                'payment_plans.id as planeId',
                'payment_plans.title as planeTitle',
                'payment_methods.id as methodId',
                'payment_methods.title as methodName',
                'lead_payments.id as InvoiceNo',
                'lead_payments.created_at as InvoiceDate',
                'lead_payments.paymentable_type',
                'lead_payments.paymentable_id',
                'lead_payments.amount as total',
                'lead_payments.employee_id',
                'lead_payments.discount',
                'lead_payments.payment_method_id',
                'lead_payments.payment_plan_id',
                'sub_payments.type as offer_type',

                'lead_payments.rest',
                'branches.id as branchId',
                'branches.name as branchName',
                'employees.id as employeeId',
                'employees.first_name',
                'employees.middle_name',
                'employees.last_name'
            ])
            ->orderBy('sub_payments.due_date', 'DESC')->get();
        
        $oldPayments = $oldPayments->select([
                'sub_payments.id',
                'sub_payments.amount',
                'sub_payments.due_date',
                'sub_payments.created_at',
                'sub_payments.owner_id',
                'sub_payments.lead_payment_id',
                'sub_payments.payment_status',
                'sub_payments.reference_num',
                'sub_payments.upload_bill',
                'leads.id as leadId',
                DB::raw('concat(COALESCE(leads.f_name,"")," ",COALESCE(leads.m_name,"")," ",COALESCE(leads.l_name,"")) as leadName'),
                'leads.mobile_1 as leadPhone',
                'leads.type as leadType',
                'leads.email as leadEmail',
                'leads.created_at as register',
                'payment_plans.id as planeId',
                'payment_plans.title as planeTitle',
                'payment_methods.id as methodId',
                'payment_methods.title as methodName',
                'lead_payments.id as InvoiceNo',
                'lead_payments.created_at as InvoiceDate',
                'lead_payments.paymentable_type',
                'lead_payments.paymentable_id',
                'lead_payments.amount as total',
                'lead_payments.employee_id',
                'lead_payments.discount',
                'lead_payments.payment_method_id',
                'lead_payments.payment_plan_id',

                'lead_payments.rest',
                'branches.id as branchId',
                'branches.name as branchName',
                'employees.id as employeeId',
                'employees.first_name',
                'employees.middle_name',
                'employees.last_name'
            ])
            ->orderBy('sub_payments.due_date', 'DESC')->get();
        
         $all_leads_payments = $all_leads_payments->select([
                'lead_payments.created_at',
                'leads.id as leadId',
                DB::raw('concat(COALESCE(leads.f_name,"")," ",COALESCE(leads.m_name,"")," ",COALESCE(leads.l_name,"")) as leadName'),
                'leads.mobile_1 as leadPhone',
                'leads.type as leadType',
                'leads.email as leadEmail',
                'leads.created_at as register',
                'payment_plans.id as planeId',
                'payment_plans.title as planeTitle',
                'lead_payments.id as InvoiceNo',
                'lead_payments.paymentable_type',
                'lead_payments.paymentable_id',
                'lead_payments.amount as total',
                'lead_payments.employee_id',
                'lead_payments.owner_id',
                'lead_payments.discount',
                'lead_payments.type as offer_type',
                'lead_payments.rest',
                'lead_payments.payment_method_id',
                'lead_payments.reference_num',
                'lead_payments.upload_bill',
                'lead_payments.payment_status',
                'branches.id as branchId',
                'branches.name as branchName',
                'employees.id as employeeId',
                'employees.first_name',
                'employees.middle_name',
                'employees.last_name'
            ])
            ->orderBy('lead_payments.created_at', 'DESC')->get();
        /*
        foreach ($allRevenue as $revenue){
            $leadName=json_decode($revenue->leadName);
            $revenue->leadName =$leadName->en;
        }
        */
        // return $allRevenue;
        
        return view('revenue.revenue')->with('allBranches', $allBranches)->with('ellEmployees', $ellEmployees)
            ->with('revenueCount', $revenueCount)->with('revenueTotalAmount', $revenueTotalAmount)
            ->with('allRevenue', $allRevenue)->with('oldPayments', $oldPayments)->with('all_leads_payments',$all_leads_payments)
            ->with('allpayment_methods',$allpayment_methods)
            ->with('allpayment_plans',$allpaymentplan)
            ->with('revenueallmount',$revenueallmount)
            ->with('Employee',$Employee);

    }
    
    public function leadsAssign(Request $request)
    {
        //dd($request->all());
        if (!$request->employee_id) {
            Flash::error('Assigned Employee is required.');
        } elseif ($request->ids != null && count($request->ids) > 0) {
            $leads = SubPayment::whereIn('lead_payment_id', $request->ids)->get();
            
            foreach($leads as $lead){
                $assign_from = $lead->assigned_employee_id;
                $lead->update(['employee_id' => $request->employee_id]);
                    
            }
            Flash::success('Assigned Successfully.');
        } else {
            Flash::error('Selected Employees is required.');
        }
        return 0;
    }

    public function debtor(Request $request)
    {
        $user=Auth::user();
        //dd($request->all());
         $allBranches=$user->branches;
        $branchesID=[];
        
        $allpayment_methods = PaymentMethod::where('status' , 1)->get();
        $paymentMethodsid = $allpayment_methods->pluck('id')->toArray();
        $paymentMethods= $request->payment_method;
        
        $allpaymentplan = PaymentPlan::where('status' , 1)->get();
        $paymentplansid  = $allpaymentplan->pluck('id')->toArray();
        $paymentplans = $request->payment_plan;
        
        $reference_number = $request->reference_number;

        foreach ($allBranches as $branch){
            array_push($branchesID,$branch->id);
        }
        $ellEmployees=[];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $ellEmployees = Employee::where('account_Type', 'Operations Account')->where('status',1)
                           ->whereIn('current_branch' , $request->get('branches'))->get()->pluck('name', 'id')->toArray();
        }else{
            $ellEmployees = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($branchesID) {
                                $query->whereIn('id', array_keys($branchesID));
                            })->get()->pluck('name', 'id')->toArray();
        }
        
        $agents = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                           ->whereIn('current_branch' , $request->get('branches'))->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($branchesID) {
                                $query->whereIn('id', array_keys($branchesID));  
                            })->get()->pluck('name', 'id')->toArray();
        }
        
        $CurrentDate = (new DateTime('now'))->format('Y-m-d');
        
        $StartDate = null;
        $EndDate = null;
        if($request -> daterange != null && $request -> daterange != ''){
            $daterange = explode(' - ',$request -> daterange);
            $StartDate = date_format(date_create($daterange[0]),'Y-m-d');
            //EndDate = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $EndDate= date_format($reg_to,"Y-m-d");
        }
        
        $Branches = $request->branches;
        $employee = $request->ellEmployee;
        $status = $request->status;
        $category = $request->category;
        $type = $request->type;
        
         $allRevenue=SubPayment::leftjoin('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
            ->leftjoin('payment_methods','payment_methods.id','sub_payments.payment_method_id')
            ->leftjoin('payment_plans','payment_plans.id','lead_payments.payment_plan_id')
            ->leftjoin('employees','employees.id','sub_payments.employee_id')
            ->leftjoin('leads','leads.id','lead_payments.lead_id')
            // ->leftjoin('lead_last_cases','lead_last_cases.lead_id','leads.id')
            // ->leftjoin('lead_cases','lead_cases.lead_id','lead_payments.lead_id')
            ->leftjoin('branches','branches.id','leads.branch_id')
            ->where('sub_payments.paid',0)->with('employee');


            $revenueallAmount=$allRevenue->whereNull('sub_payments.merchantRefNumber')
            ->whereNull('sub_payments.paymentMethod')
            ->whereNull('sub_payments.payment_status')
            ->sum('sub_payments.amount');
                           
        if (!$StartDate && !$EndDate && !$request->has('Action')){
            $allRevenue=$allRevenue->where('sub_payments.due_date','<=',$CurrentDate);
       //        $allRevenue = $allRevenue->where('sub_payments.due_date','<=',$CurrentDate);

        }
        
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $allRevenue->where(function ($query) use ($request){
                $query->where('leads.f_name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.mobile_1', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.id', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.email', 'like', '%' . $request->get('search') . '%');
            });
        }
        
       
        if ($request->has('payment_plan') && count($paymentplans) != 0 &&  !in_array(0, $paymentplans)) {
            $allRevenue = $allRevenue->whereIn('lead_payments.payment_plan_id', $paymentplans);
        } else {
            $allRevenue = $allRevenue->whereIn('lead_payments.payment_plan_id', $paymentplansid);
        }
        if($request->has('reference_number') && $request->reference_number != null && $request->reference_number !='' )
        {
           $allRevenue = $allRevenue->where('sub_payments.reference_num' , $reference_number);
        }

        if($StartDate && $EndDate){
            $allRevenue = $allRevenue->whereBetween('sub_payments.due_date',[$StartDate,$EndDate]);
        }
        /*
        if($EndDate){
            $allRevenue = $allRevenue->where('sub_payments.due_date','<=',$EndDate);
        }
        */
        //dd($allRevenue->get());
        if($type != null && $type != ''){
            $allRevenue = $allRevenue->where('leads.type',$type);
        }

        if ($request->has('branches') && count($Branches) !=0 &&  !in_array(0,$Branches) ){
            $allRevenue=$allRevenue->whereIn('branches.id', $Branches);
        }else{
            $allRevenue=$allRevenue->whereIn('branches.id',$branchesID);

        }
        
        if ($request->has('ellEmployee') && $employee !='' ){
            $allRevenue=$allRevenue->where('leads.assigned_employee_id', $employee);
        }

        if ($request->has('status') && $status !='' ){
            if ($status == 0){
                $allRevenue=$allRevenue->where('lead_payments.rest', 0);
            }else{
                $allRevenue=$allRevenue->where('lead_payments.rest','!=', 0);

            }
        }

        if ($request->has('category') && $category !='' ){
            $allRevenue=$allRevenue->where('lead_payments.paymentable_type', $category);
        }
        

        
        $allRevenue=$allRevenue->whereNull('sub_payments.merchantRefNumber')
        ->whereNull('sub_payments.paymentMethod')
        ->whereNull('sub_payments.payment_status');
       
            
        $revenueTotalAmount=$allRevenue->sum('sub_payments.amount');
            
        $revenueCount=$allRevenue->count();
        
         $allRevenue = $allRevenue->select([
                'sub_payments.id',
                'sub_payments.amount',
                'sub_payments.due_date',
                'sub_payments.created_at',
                'sub_payments.payment_status',
                'sub_payments.lead_payment_id',
                'sub_payments.reference_num',
                // 'sub_payments.reference_num',
                'sub_payments.paymentMethod',
                'sub_payments.payment_status',
                'sub_payments.employee_id',

                'leads.id as leadId',
                DB::raw('concat(COALESCE(employees.first_name,"")," ",COALESCE(employees.middle_name,"")," ",COALESCE(employees.last_name,"")) as employeeName'),
                DB::raw('concat(COALESCE(leads.f_name,"")," ",COALESCE(leads.m_name,"")," ",COALESCE(leads.l_name,"")) as leadName'),
                'leads.mobile_1 as leadPhone',
                'leads.email as leadEmail',
                'leads.assigned_employee_id  as employee',
                'payment_plans.id as planeId',
                'payment_plans.title as planeTitle',
                'payment_methods.id as methodId',
                'payment_methods.title as methodName',
                'lead_payments.id as InvoiceNo',
                'lead_payments.paymentable_type as category',
                'lead_payments.amount as total',
                // 'lead_payments.employee_id',
                'lead_payments.discount',
                'lead_payments.rest',
                'branches.id as branchId',
                'branches.name as branchName',
                // 'employees.id as employeeId',
                'employees.first_name',
                'employees.middle_name',
                'employees.last_name',
            ])
            ->with('employee')->orderBy('sub_payments.due_date', 'DESC')->get(); 
            // ->with('employee')->orderBy('sub_payments.due_date', 'DESC')->first(); 
            
        // return $allRevenue[0]->leadPayment->lead->assignedEmployee->name;
        
        return view('revenue.debtor')->with('allBranches', $allBranches)->with('ellEmployees', $ellEmployees)
            ->with('revenueCount', $revenueCount)->with('revenueTotalAmount', $revenueTotalAmount)

            ->with('agents', $agents)
            ->with('allRevenue', $allRevenue)
            ->with('allpayment_methods',$allpayment_methods)
            ->with('allpayment_plans',$allpaymentplan)
            ->with('revenueallAmount',$revenueallAmount);

    }
    
    public function debtoronline(Request $request)
    {
        $user=Auth::user();
        //dd($user->branches);
        $allBranches=$user->branches;
        $branchesID=[];

        
        $allpayment_methods = PaymentMethod::where('status' , 1)->get();
        $paymentMethodsid = $allpayment_methods->pluck('id')->toArray();
        $paymentMethods= $request->payment_method;
        
        $allpaymentplan = PaymentPlan::where('status' , 1)->get();
        $paymentplansid  = $allpaymentplan->pluck('id')->toArray();
        $paymentplans = $request->payment_plan;
        
        $reference_number = $request->reference_number;
        
        foreach ($allBranches as $branch){
            array_push($branchesID,$branch->id);
        }
        
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $ellEmployees = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })->get();
        }else{
            $ellEmployees = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($branchesID) {
                                $query->whereIn('id', $branchesID);
                            })->get();
        }
        $CurrentDate = (new DateTime('now'))->format('Y-m-d');
        
        $StartDate = null;
        $EndDate = null;
        if($request -> daterange != null && $request -> daterange != ''){
            $daterange = explode(' - ',$request -> daterange);
            $StartDate = date_format(date_create($daterange[0]),'Y-m-d');
            // $EndDate = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $EndDate= date_format($reg_to,"Y-m-d");
        }
        
        $Branches = $request->branches;
        $employee = $request->ellEmployee;
        $status = $request->status;
        $category = $request->category;
        $type = $request->type;
        
        $allRevenue=SubPayment::leftjoin('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
            ->leftjoin('payment_methods','payment_methods.id','sub_payments.payment_method_id')
            ->leftjoin('payment_plans','payment_plans.id','lead_payments.payment_plan_id')
            ->leftjoin('employees','employees.id','sub_payments.employee_id')
            ->leftjoin('leads','leads.id','lead_payments.lead_id')
            ->leftjoin('branches','branches.id','leads.branch_id')
            ->where('sub_payments.paid',0);

            $revenueallAmount=$allRevenue->whereNotNull('sub_payments.merchantRefNumber')
            ->whereNotNull('sub_payments.paymentMethod')
            ->whereNotNull('sub_payments.payment_status')
            ->sum('sub_payments.amount');
           


        
        if (!$StartDate && !$EndDate && !$request->has('Action')){
            $allRevenue=$allRevenue->where('sub_payments.due_date','<=',$CurrentDate);
       //        $allRevenue = $allRevenue->where('sub_payments.due_date','<=',$CurrentDate);

        } 
        //dd($allRevenue->get());
        if($StartDate && $EndDate){
            $allRevenue = $allRevenue->whereBetween('sub_payments.due_date',[$StartDate,$EndDate]);
        }
        /*
        if($EndDate){
            $allRevenue = $allRevenue->where('sub_payments.due_date','<=',$EndDate);
        }*/
        if($type != null && $type != ''){
            $allRevenue = $allRevenue->where('leads.type',$type);
        }
        if ($request->has('branches') && count($Branches) !=0 &&  !in_array(0,$Branches) ){
            $allRevenue=$allRevenue->whereIn('branches.id', $Branches);
        }else{
            $allRevenue=$allRevenue->whereIn('branches.id',$branchesID);

        }
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $allRevenue->where(function ($query) use ($request){
                $query->where('leads.f_name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.mobile_1', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.id', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.email', 'like', '%' . $request->get('search') . '%');
            });
        }
            
        // if ($request->has('payment_method') && count($paymentMethods) != 0 &&  !in_array(0, $paymentMethods)) {
        //     // dd($paymentMethods);
        //     $allRevenue = $allRevenue->whereIn('lead_payments.payment_method_id', $paymentMethods);
        //     // $all_leads_payments = $all_leads_payments->whereIn('lead_payments.payment_method_id', $paymentMethods);
        // } else {
        //     $allRevenue = $allRevenue->whereIn('lead_payments.payment_method_id', $paymentMethodsid);
        //     // $all_leads_payments = $all_leads_payments->whereIn('lead_payments.payment_method_id', $paymentMethodsid);
        // }
        // if ($request->has('payment_plan') && count($paymentplans) != 0 &&  !in_array(0, $paymentplans)) {
        //     // dd($paymentplans);
        //     $allRevenue = $allRevenue->whereIn('lead_payments.payment_plan_id', $paymentplans);
        //     // $all_leads_payments = $all_leads_payments->whereIn('lead_payments.payment_plan_id', $paymentplans);
        // } else {
        //     $allRevenue = $allRevenue->whereIn('lead_payments.payment_plan_id', $paymentplansid);
        //     // $all_leads_payments = $all_leads_payments->whereIn('lead_payments.payment_plan_id', $paymentplansid);
        // }
        // $reference_number = $request->reference_number;
        if($request->has('reference_number') && $request->reference_number != null && $request->reference_number !='' )
       {
        // dd($reference_number);
        $allRevenue = $allRevenue->where('sub_payments.reference_num', $reference_number);
        // $all_leads_payments = $all_leads_payments->where('lead_payments.reference_num' , $reference_number);


      }  

        if ($request->has('ellEmployee') && $employee !='' ){
            $allRevenue=$allRevenue->where('lead_payments.employee_id', $employee);
        }

        if ($request->has('status') && $status !='' ){
            if ($status == 0){
                $allRevenue=$allRevenue->where('lead_payments.rest', 0);
            }else{
                $allRevenue=$allRevenue->where('lead_payments.rest','!=', 0);

            }
        }

        if ($request->has('category') && $category !='' ){
            $allRevenue=$allRevenue->where('lead_payments.paymentable_type', $category);
        }

        
        // $allRevenue=$allRevenue->whereNull('sub_payments.merchantRefNumber')
        // ->whereNull('sub_payments.paymentMethod')
        // ->whereNull('sub_payments.payment_status');
        $allRevenue=$allRevenue->whereNotNull('sub_payments.merchantRefNumber')
        ->whereNotNull('sub_payments.paymentMethod')
        ->whereNotNull('sub_payments.payment_status');
        
            
        $revenueTotalAmount=$allRevenue->sum('sub_payments.amount');
        
        $revenueCount=$allRevenue->count();
        $allRevenue = $allRevenue->select([
                'sub_payments.id',
                'sub_payments.amount',
                'sub_payments.due_date',
                'sub_payments.created_at',
                'sub_payments.payment_status',
                'sub_payments.lead_payment_id',
                'sub_payments.merchantRefNumber',
                'sub_payments.reference_num',
                'sub_payments.paymentMethod',
                'sub_payments.payment_status',

                'leads.id as leadId',
                DB::raw('concat(COALESCE(leads.f_name,"")," ",COALESCE(leads.m_name,"")," ",COALESCE(leads.l_name,"")) as leadName'),
                'leads.mobile_1 as leadPhone',
                'leads.email as leadEmail',
                'payment_plans.id as planeId',
                'payment_plans.title as planeTitle',
                'payment_methods.id as methodId',
                'payment_methods.title as methodName',
                'lead_payments.id as InvoiceNo',
                'lead_payments.paymentable_type as category',
                'lead_payments.amount as total',
                'lead_payments.employee_id',
                'lead_payments.reference_num',
                'lead_payments.payment_method_id',
                'lead_payments.payment_plan_id',

                'lead_payments.discount',
                'lead_payments.rest',
                'branches.id as branchId',
                'branches.name as branchName',
                'employees.id as employeeId',
                'employees.first_name',
                'employees.middle_name',
                'employees.last_name'
        ])
        ->orderBy('sub_payments.due_date', 'DESC')->get();
            
        // return ($allRevenue);
        return view('revenue.debtoronline')->with('allBranches', $allBranches)->with('ellEmployees', $ellEmployees)
            ->with('revenueCount', $revenueCount)->with('revenueTotalAmount', $revenueTotalAmount)

            ->with('allRevenue', $allRevenue)
            ->with('allpayment_methods',$allpayment_methods)
            ->with('allpayment_plans',$allpaymentplan)
            ->with('revenueallAmount',$revenueallAmount);

    }
    
    public function details($id)
    {
        $leadPayment=LeadPayment::
     //            ->leftjoin('payment_methods','payment_methods.id','sub_payments.payment_method_id')
            leftjoin('payment_plans','payment_plans.id','lead_payments.payment_plan_id')
            ->leftjoin('employees','employees.id','lead_payments.employee_id')
            ->leftjoin('leads','leads.id','lead_payments.lead_id')
            ->leftjoin('branches','branches.id','leads.branch_id')
            ->where('lead_payments.id',$id)
            ->select([
                'leads.id as leadId',
                DB::raw('concat(COALESCE(leads.f_name,"")," ",COALESCE(leads.m_name,"")," ",COALESCE(leads.l_name,"")) as leadName'),
                'leads.mobile_1 as leadPhone',
                'payment_plans.id as planeId',
                'payment_plans.title as planeTitle',
                'lead_payments.id as InvoiceNo',
                'lead_payments.paymentable_type',
                'lead_payments.paymentable_id',
                'lead_payments.amount as total',
                'lead_payments.employee_id',
                'lead_payments.discount',
                'lead_payments.rest',
                'branches.id as branchId',
                'branches.name as branchName',
                'employees.id as employeeId',
                'employees.first_name',
                'employees.middle_name',
                'employees.last_name',
                'lead_payments.payment_method_id',
                'lead_payments.reference_num',
                'lead_payments.upload_bill',
                'lead_payments.payment_status',
                'lead_payments.payment_method',
                'lead_payments.merchantRefNumber',
                'lead_payments.fawryFees',
            ])
            ->first();
        if (!$leadPayment){
            Flash::error('Lead payment not found');
            return redirect()->back();
        }
        /*
        $leadName=json_decode($leadPayment->leadName);
        $leadPayment->leadName =$leadName->en;
        */
        $allSubPayment=SubPayment::where('sub_payments.lead_payment_id',$id)
            ->leftjoin('payment_methods','payment_methods.id','sub_payments.payment_method_id')
            ->select([
                'sub_payments.id',
                'sub_payments.amount',
                'sub_payments.due_date',
                'sub_payments.created_at',
                'sub_payments.lead_payment_id',
                'sub_payments.paid',
                'sub_payments.reference_num',
                'sub_payments.upload_bill',
                'sub_payments.payment_status',
                'sub_payments.paymentMethod',
                'sub_payments.merchantRefNumber',
                'payment_methods.id as methodId',
                'payment_methods.title as methodName'
            ])
            ->orderBy('sub_payments.due_date', 'DESC')
            ->get();
        return view('revenue.details')->with('leadPayment', $leadPayment)->with('allSubPayment', $allSubPayment);

    }
    
    public function debtor_report(Request $request){
        $view_type = 'branches';
        if($request->has('view_type')){
            $view_type = $request->get('view_type');
        }
        $branches = Branch::where('status',1)->select('id','name')->get();
         $debtor = SubPayment::where('paid',0)->whereIn('branch_id',$branches)->whereNull('merchantRefNumber')
                ->whereNull('paymentMethod')->whereNull('payment_status')->selectRaw('*, sum(amount) as amount ')
                ->select('amount','branch_id')->groupBy('branch_id')->get();
                
         $onlinedebtor=SubPayment::where('paid',0)->whereIn('branch_id',$branches)->whereNotNull('merchantRefNumber')
        ->whereNotNull('paymentMethod')->whereNotNull('payment_status')->selectRaw('*, sum(amount) as amount ')
                ->select('amount','branch_id')->groupBy('branch_id')->get();
                
         $allDebtor=SubPayment::where('paid',0)->whereIn('branch_id',$branches)->selectRaw('*, sum(amount) as amount ')
                ->select('amount','branch_id')->groupBy('branch_id')->get();       
       
       return view('revenue.debtor_report',compact('debtor','onlinedebtor','allDebtor','view_type','branches'));
        
    }
    
    public function total_cash_day(Request $request){
        $user = Auth::user();
        $reg_to = null;
        $branches = $user->branches;
        $dates = [];
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != ''){
            $daterange = explode(' - ',$request->get('daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
            
            $period = new \DatePeriod(
                new \DateTime($registration_from),
                new \DateInterval('P1D'),
                new \DateTime($registration_to)
            );
            
            foreach ($period as $key => $value) {
                $dates[$key]['date'] = $value->format('Y-m-d');
            }
        }
        else{
            $dates[0]['date'] = date('Y-m-d');
        }
            
            if($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != ''){
                $cash_amount= LeadPayment::where('payment_plan_id',2)
                    ->whereNotNull('branch_id')
                    ->whereNotNull('payment_method_id')
                    //->where('created_at','like',$date['date'].'%')
                    ->whereBetween('created_at',[$registration_from,$registration_to])
                    ->groupBy(DB::raw('DATE(created_at)'),'branch_id' , 'type')
                    ->select(DB::raw('DATE(created_at) as day_date'),'branch_id','type',DB::raw('sum(amount) as cash_amount'))
                    ->get()->groupBy('day_date');
                    
                    
                $sub_payment = SubPayment::join('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
                             ->whereIn('lead_payments.payment_plan_id',[1,3])
                             ->whereNotNull('lead_payments.paymentable_type')->whereNotNull('lead_payments.paymentable_id')
                             ->where('sub_payments.paid',1)
                             ->whereBetween('sub_payments.due_date',[$registration_from,$registration_to])   
                             // ->where('sub_payments.due_date','like',$date['date'].'%')
                             ->groupBy(DB::raw('DATE(sub_payments.due_date)'),'sub_payments.branch_id','sub_payments.type')
                             ->select(DB::raw('DATE(sub_payments.due_date) as day_date'),'sub_payments.branch_id','sub_payments.type',DB::raw('sum(sub_payments.amount) as cash_amount'))
                             ->get()->groupBy('day_date');   
                $oldPayments = SubPayment::join('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
                             ->leftjoin('employees','employees.id','sub_payments.employee_id')
                             ->leftjoin('branches','branches.id','sub_payments.branch_id')
                             ->whereIn('lead_payments.payment_plan_id',[1,3])
                             ->whereNull('lead_payments.paymentable_type')
                             ->where('sub_payments.paid',1)
                             ->whereRaw('sub_payments.updated_at != sub_payments.created_at')
                             ->groupBy(DB::raw('DATE(sub_payments.due_date)'),'sub_payments.branch_id','sub_payments.type')
                             ->select(DB::raw('DATE(sub_payments.due_date) as day_date'),'sub_payments.branch_id','sub_payments.type'
                                     ,DB::raw('sum(sub_payments.amount) as cash_amount'))
                             ->get()->groupBy('day_date'); 
                   
            }else{
                $cash_amount= LeadPayment::where('payment_plan_id',2)
                                         ->whereNotNull('branch_id')
                                         ->whereNotNull('payment_method_id')
                                         //->where('created_at','like',$date['date'].'%')
                                         ->where('created_at','like','%'.date('Y-m-d').'%')
                                         ->groupBy(DB::raw('DATE(created_at)'),'branch_id' , 'type')
                                         ->select(DB::raw('DATE(created_at) as day_date'),'branch_id','type',DB::raw('sum(amount) as cash_amount'))
                                         ->get()->groupBy('day_date');
                    
                $sub_payment = SubPayment::join('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
                                         ->whereIn('lead_payments.payment_plan_id',[1,3])
                                         ->whereNotNull('lead_payments.paymentable_type')->whereNotNull('lead_payments.paymentable_id')
                                         ->where('sub_payments.paid',1)
                                        //  ->whereBetween('sub_payments.due_date',[$registration_from,$registration_to])   
                                          ->where('sub_payments.due_date','like','%'.date('Y-m-d').'%')
                                         ->groupBy(DB::raw('DATE(sub_payments.due_date)'),'sub_payments.branch_id','sub_payments.type')
                                         ->select(DB::raw('DATE(sub_payments.due_date) as day_date'),'sub_payments.branch_id','sub_payments.type',DB::raw('sum(sub_payments.amount) as cash_amount'))
                                         ->get()->groupBy('day_date');    
                             
                $oldPayments = SubPayment::join('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
                                         ->leftjoin('employees','employees.id','sub_payments.employee_id')
                                         ->leftjoin('branches','branches.id','sub_payments.branch_id')
                                         ->whereIn('lead_payments.payment_plan_id',[1,3])
                                         ->whereNull('lead_payments.paymentable_type')
                                         ->where('sub_payments.paid',1)
                                         ->whereRaw('sub_payments.updated_at !=sub_payments.created_at')
                                         ->where('sub_payments.due_date','like','%'.date('Y-m-d').'%')
                                         ->groupBy(DB::raw('DATE(sub_payments.due_date)'),'sub_payments.branch_id','sub_payments.type')
                                         ->select(DB::raw('DATE(sub_payments.due_date) as day_date'),'sub_payments.branch_id','sub_payments.type',DB::raw('sum(sub_payments.amount) as cash_amount'))
                                         ->get()->groupBy('day_date');
            }
            foreach($cash_amount as $date => $day_cash_amount){
                $cash_amount[$date] = $day_cash_amount->groupBy('branch_id');
                foreach($cash_amount[$date] as $keyy =>$cash){
                    $cash_amount[$date][$keyy] = $cash->pluck('cash_amount','type')->toArray();
                    // return $cash_amount[$date];
                    
                }
            }
            foreach($sub_payment as $date => $day_cash_amount){
                $sub_payment[$date] = $day_cash_amount->groupBy('branch_id');
                foreach($sub_payment[$date] as $keyy =>$cash){
                    $sub_payment[$date][$keyy] = $cash->pluck('cash_amount','type')->toArray();
                }
            }
            foreach($oldPayments as $date => $day_cash_amount){
                $oldPayments[$date] = $day_cash_amount->groupBy('branch_id');
                foreach($oldPayments[$date] as $keyy =>$cash){
                    $oldPayments[$date][$keyy] = $cash->pluck('cash_amount','type')->toArray();
                }
            }
            
        return view('revenue.total_cash',compact('dates','branches','dates','cash_amount','sub_payment','oldPayments'));
    
    }
}
