<?php

namespace App\Http\Controllers;

use Flash;
use Response;
use DB;
use Illuminate\Http\Request;
use App\Mail\PlacementTestResult;
use App\Models\PlacementApplicant;
use Illuminate\Support\Facades\Mail;
use App\Http\Controllers\AppBaseController;
use App\Http\Requests\CreatePlacementApplicantRequest;
use App\Http\Requests\UpdatePlacementApplicantRequest;
use App\Models\Lead;
use App\Models\LeadPayment;
use App\Models\Employee;
use App\Models\Offer;
use App\Models\TrainingService;
use App\Models\CustomerTrack;
use App\Models\GroupWaitingList;
use Auth;

class InstructorPortalPTController extends AppBaseController
{
    /**
     * Display a listing of the PlacementApplicant.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var PlacementApplicant $placementApplicants */
        //$testProcess = round(microtime(true) * 1000);
        $istructor = Auth::user();
        
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        
        $employeeBranches = auth()->user()->branches->pluck('name','id')->toArray();
        
        $registration_from = null;
        $registration_to = null;
        if ($request->has('registration_daterange') && $request->get('registration_daterange') != null && $request->get('registration_daterange') != '') {
            $daterange = explode(' - ',$request->get('registration_daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $registration_to = date_format(date_create($daterange[1]),'Y-m-d');
        }
        
        $placementApplicantsQuery = PlacementApplicant::where('instructor_id',$istructor->id);
        
        if ($request->has('search') && $request->get('search') != null && $request->get('search') != '') {
            //dd($request->get('search'));
            $placementApplicantsQuery->where('name', 'like', '%' . request('search') . '%')
                ->orWhere('mobile', 'like', '%' . request('search') . '%')
                ->orWhere('email', 'like', '%' . request('search') . '%');
        }
        
        if ($request->has('status') && $request->get('status') != null && $request->get('status') != '') {
            //dd($request->get('status'));
            $placementApplicantsQuery->where('status', request('status'));
        }
        
        if ($request->has('branches') && $request->get('branches') != null && $request->get('branches') != '') {
            //dd($request->get('branches'));
            $placementApplicantsQuery->whereIn('branch_id', $request->get('branches'));
        }
        
        if ($registration_from != null && $registration_to != '') {
            //dd($registration_from,$registration_to);
            $placementApplicantsQuery->whereBetween('created_at', [$registration_from, $registration_to]);
        }
        $ptApplicantCount = $placementApplicantsQuery->count();
        $placementApplicants = $placementApplicantsQuery->latest()->paginate(20);
        //dd(round(microtime(true) * 1000) - $testProcess);
        return view('instructor.PT_requests.index', compact('placementApplicants','ptApplicantCount','employeeBranches'));
    }

    /**
     * Display the specified PlacementApplicant.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var PlacementApplicant $placementApplicant */
        //$testProcess = round(microtime(true) * 1000);
        $placementApplicant = PlacementApplicant::find($id);

        if (empty($placementApplicant)) {
            Flash::error('Placement Applicant not found');

            return redirect(route('instructor.PT_requests.index'));
        }
        //dd(round(microtime(true) * 1000) - $testProcess);
        return view('instructor.PT_requests.show')->with('placementApplicant', $placementApplicant);
    }

    /**
     * Show the form for editing the specified PlacementApplicant.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var PlacementApplicant $placementApplicant */
        //$testProcess = round(microtime(true) * 1000);
        $placementApplicant = PlacementApplicant::with('answers')->find($id);

        if (empty($placementApplicant)) {
            Flash::error('Placement Applicant not found');

            return redirect(route('instructor.PT_requests.index'));
        }
        //dd(round(microtime(true) * 1000) - $testProcess);
        return view('instructor.PT_requests.edit')->with('placementApplicant', $placementApplicant);
    }

    /**
     * Update the specified PlacementApplicant in storage.
     *
     * @param int $id
     * @param UpdatePlacementApplicantRequest $request
     *
     * @return Response
     */
    public function update($id, UpdatePlacementApplicantRequest $request)
    {
        /** @var PlacementApplicant $placementApplicant */
        $placementApplicant = PlacementApplicant::find($id);
        
        if (empty($placementApplicant)) {
            Flash::error('Placement Applicant not found');

            return redirect(route('instructor.PT_requests.index'));
        }

        $placementApplicant->fill($request->all());
        $placementApplicant->save();

        Lead::where('mobile_1', $placementApplicant->mobile)->update(['pt_level' => $placementApplicant->level]);
        $lead = Lead::where('mobile_1', $placementApplicant->mobile)->first();
        
        if($lead != null && $lead != ''){
            $payments = LeadPayment::where('lead_id',$lead->id)->where('paymentable_type','App\\Models\\Offer')->whereNull('group_id')->get();
            if($payments != null && count($payments) > 0){
                foreach($payments as $payment){
                    $offer = Offer::with('timeframes', 'intervals')->find($payment->paymentable_id);
                    if($offer->has_levels == 0){
                        $course = $offer->course;
                        $stage_levels = DB::table('stage_levels')->leftJoin('stages','stages.id','=','stage_levels.stage_id')
                                                ->where('stages.track_id',$offer->course_id)
                                                ->where('stage_levels.value','>=',$lead->pt_level)->take($offer->num_levels)->pluck('stage_levels.id')->toArray();
                        //dd($stage_levels,$check_cusTrack);
                        if($stage_levels != null && count($stage_levels) > 0){
                            $checkCustomerTrack = CustomerTrack::where('lead_id',$lead->id)->first();
                            if($checkCustomerTrack != null && $checkCustomerTrack != ''){
                                if($checkCustomerTrack->used == 0){
                                    $checkCustomerTrack->update([
                                        'track_id' => $offer->track_id,
                                        'course_id' => $offer->course_id,
                                        'level_id' => $stage_levels[0],
                                        'total' => $offer->num_levels,
                                    ]);
                                }
                            }else{
                                $customerTrack = CustomerTrack::create([
                                    'lead_id' => $lead->id,
                                    'track_id' => $offer->track_id,
                                    'course_id' => $offer->course_id,
                                    'level_id' => $stage_levels[0],
                                    'total' => $offer->num_levels,
                                    'used' => 0,
                                ]);
                            }
                            //dd($stage_levels,$training_service_levels,$total,$training_services->pluck('id'));
                            $timeframesString = implode(',', $offer->timeframes->pluck('id')->toArray());
                            $intervalsString = implode(',', $offer->intervals->pluck('id')->toArray());
                            
                            $checkGroupWaitingList = GroupWaitingList::where('lead_id',$lead->id)->first();
                            if($checkGroupWaitingList != null && $checkGroupWaitingList != ''){
                                $checkGroupWaitingList->update([
                                    'level_id' => $stage_levels[0],
                                    'timeframes' => $timeframesString,
                                    'intervals' => $intervalsString,
                                    'lead_payment_id' => $payment->id
                                ]);
                            }else{
                                GroupWaitingList::create([
                                    'lead_id' => $lead->id,
                                    'level_id' => $stage_levels[0],
                                    'timeframes' => $timeframesString,
                                    'intervals' => $intervalsString,
                                    'lead_payment_id' => $payment->id
                                ]);
                            }
                            
                        }
                    }
                }
            }else{
                $payments = LeadPayment::where('lead_id',$lead->id)->whereNull('paymentable_type')->whereNull('group_id')->get();
                if($payments != null && count($payments) > 0){
                    foreach($payments as $payment){
                        $checkCustomerTrack = CustomerTrack::where('lead_id',$lead->id)->first();
                        if($checkCustomerTrack != null && $checkCustomerTrack != ''){
                            $stage_levels = DB::table('stage_levels')->leftJoin('stages','stages.id','=','stage_levels.stage_id')
                                                ->where('stages.track_id',$checkCustomerTrack->course_id)
                                                ->where('stage_levels.value','>=',$lead->pt_level)->take($checkCustomerTrack->num_levels)->pluck('stage_levels.id')->toArray();
                        
                            if($checkCustomerTrack->used == 0){
                                $checkCustomerTrack->update([
                                    'level_id' => $stage_levels[0],
                                ]);
                            }
                            
                            $checkGroupWaitingList = GroupWaitingList::where('lead_id',$lead->id)->first();
                            if($checkGroupWaitingList != null && $checkGroupWaitingList != ''){
                                $checkGroupWaitingList->update([
                                    'level_id' => $stage_levels[0],
                                ]);
                            }else{
                                GroupWaitingList::create([
                                    'lead_id' => $lead->id,
                                    'level_id' => $stage_levels[0],
                                ]);
                            }
                            
                            DB::table('old_customers_payment')->where('customer_id',$lead->id)->update(['level_id' => $stage_levels[0]]);
                        }
                    }
                }
            }
            
        }
        Flash::success('Placement Applicant updated successfully.');

        return redirect(route('instructor.PT_requests.index'));
    }


    
}
