<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\HrGroups;
use App\Models\HrGroupSession;
use App\Models\HrGroupSessionAttendance;
use App\Models\HrGroupTrainee;
use Flash;

class HrGroupSessionAttendanceController extends Controller
{
    public function index(){
        
    }
    public function update($id,Request $request)
    {
        
        $presents = ($request->has('presents') && $request->get('presents') != null && $request->get('presents') != '' && count($request->get('presents')) > 0)?$request->get('presents'):[];
        
        $groupSession = HrGroupSession::find($id);
        $group = HrGroups::withCount('hr_group_session')->find($groupSession->hr_group_id);

        $attendances = HrGroupSessionAttendance::where('hr_group_session_id', $id)->get();
        
        foreach ($attendances as $attendance) {
            $attendance->update(['attendance' => in_array($attendance->id, $presents) ? 1 : 0]);

            $absentCount = HrGroupSessionAttendance::where([
                'job_application_id' => $attendance->job_application_id,
                'hr_group_id' => $attendance->hr_group_id,
                'hr_group_session_id' => $attendance->level_id,
                'attendance' => 0,
            ])->count();
            //dd($absentCount);
            $student = HrGroupTrainee::where([
                'job_application_id' => $attendance->job_application_id,
                'hr_group_id' => $attendance->hr_group_id,
            ])->first();

            if ($absentCount > 1) {
                $student->absence_per = ($absentCount / $group->sessions_count) * 100;
            }
        }

        
        Flash::success('Attendance saved successfully.');
        
        return redirect('/HrSession?group='.$group->id);
    }
    
}
