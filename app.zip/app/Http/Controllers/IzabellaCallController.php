<?php

namespace App\Http\Controllers;
use App\Models\Lead;
use App\Models\Employee;
use App\Models\IzabellaCall;
use Auth;

use Illuminate\Http\Request;

class IzabellaCallController extends Controller
{
    public function calloutbound(Request $request){
        try{
            $employee = Employee::where('izabella_code',$request->izabella_code)->first();
            $lead =  Lead::where('mobile_1', $request->phone)->first();
            
            $izabellacall = new IzabellaCall;
            $izabellacall->employee_id = $employee->id ?? ' ';
            $izabellacall->izabella_code = $request->izabella_code;
            $izabellacall->type = $request->status;
            $izabellacall->phone = $request->phone;
            $izabellacall->date = $request->date;
            $izabellacall->lead_id = $lead->id;
            if($lead != null && $lead != '' && $lead != ' ')
            {
             if($lead->type == 1)
             {
                 $url =  route('admin.leads.show',$lead->id);
                 $this->content['message'] = 'Show Lead Profile';
             }else{
                 $url =  route('admin.database.show',$lead->id);
                 $this->content['message'] = 'Show Customer Or Client Profile';
             }
            }else{
                  $url =  route('admin.leads.create');
                  $this->content['message'] = 'Create a new lead';
            }
            $izabellacall->url = $url;
            
            $izabellacall->save();
            $status = 200;
        }catch(Exception $e){
           $this->content['message'] = "server error ".$e;
           $status = 500;
        }
        return response()->json($this->content, $status);
    
    }
    
    public function updatecall(Request $request){
        
        $employee = auth()->user()->id;
        $calls = IzabellaCall::where('employee_id',$employee)->where('status',0)->get();
        foreach($calls as $call)
        {
          $call->update(['status'=>1]);   
        }
        
        return response()->json(['urls' => $calls->pluck('url')->toArray()]);
        
    }
   
}
