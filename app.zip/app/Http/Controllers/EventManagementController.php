<?php

namespace App\Http\Controllers;

use App\Http\Controllers\AppBaseController;
use Illuminate\Http\Request;
use Flash;
use Response;

class EventManagementController extends AppBaseController
{
    /**
     * Display a listing of the Exam.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var Exam $exams */
        $exams = Exam::all();

        return view('exams.index')
            ->with('exams', $exams);
    }

    public function calendar(Request $request) {
        return view('eventmanagement.calendar');
            
    }

    
}
