<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Flash;
use App\Models\Round;
use App\Models\Group;
use App\Models\Track;
use App\Models\DisciplineCategory;
use App\Models\GroupSessionAttendance;
use App\Models\SubRound;
use App\Models\GroupSession;
use App\Models\Timeframe;
use App\Models\Room;
use App\Models\Lead;
use App\Models\Branch;
use App\Models\PaymentMethod;
use App\Models\GroupStudent;
use App\Models\Employee;
use App\Models\MakeupSession;
use App\Models\CustomerTrack;
use App\Models\StudentExam;
use App\Models\Instructor;
use App\Models\Vacation;
use App\Models\Resignation;
use App\Models\MonitoringSections;
use App\Models\SectionsMonitoring;
use App\Models\Monitoring;
use App\Models\VacationHistory;
use DB;
use Auth;
use File;

class InstructorPortalController extends Controller
{
    
    public function requestVacation(Request $request, $id)
    {
        $validator = $request->validate(
            [
                'startdate' => 'required',
                'enddate' => 'required|after_or_equal:startdate',
                'type' => 'required'
            ]
        );
        $startdateArrey = explode("-", $request->startdate);

        $vacation = Vacation::where('year', $startdateArrey[0])->where('employee_id', $id)->first();
        $start = strtotime($request->startdate);
        $end = strtotime($request->enddate);
        $datediff = $end - $start;

        $days = round($datediff / (60 * 60 * 24));
        $days = $days + 1;
        if (!$vacation || $days > $vacation[$request->type]) {
            Flash::error('you not have vacation in this year');
            return redirect()->back();
        }
        $newVacationHistory = new VacationHistory();
        $newVacationHistory->employee_id = $id;
        $newVacationHistory->vacations_id = $vacation->id;
        $newVacationHistory->type = $request->type;
        $newVacationHistory->start = $request->startdate;
        $newVacationHistory->end = $request->enddate;
        $newVacationHistory->days = $days;
        $newVacationHistory->save();
        Flash::success('your vacation requested successfully.');
        return redirect()->back();
    }
    public function updateProfile(Request $request, $id)
    {
        $validator = $request->validate(
            [
                'phone' => 'required',
                'address' => 'required',
                'emergency_name' => 'required',
                'emergency_relation' => 'required',
                'emergency_phone' => 'required',
                'image'=>'nullable|image',

            ]
        );

        $employee = Employee::find($id);
        $employee->phone = $request->phone;
        $employee->address = $request->address;
        $employee->emergency_name = $request->emergency_name;
        $employee->emergency_relation = $request->emergency_relation;
        $employee->emergency_phone = $request->emergency_phone;
        
        if($request->hasFile('image')){
            $file = $request->file('image');
            
            $file_name = rand(11111,99999).'-'.$file->getClientOriginalName();
            $file->storeAs('/uploads/profile_picture', $file_name);
            $employee->image = $file_name;
            
            File::move(storage_path('app/uploads/profile_picture/'.$file_name), '/home/harvestc/public_html/uploads/profile_picture/'.$file_name);
        }
        $employee->save();
        return redirect()->back();
    }

    public function updatePassword(Request $request, $id)
    {
        $validator = $request->validate(
            [
                'password' => 'required|confirmed'
            ]
        );
        //        $pass=bcrypt($request->password);
        $pass = $request->password;
        $employee = Employee::find($id);
        $employee->password = $pass;
        $employee->save();
        return redirect()->back();
    }
    
    public function getProfile()
    {
        $employee = Auth::user();
        $branches = Branch::pluck('name','id')->toArray();

        //        dd($employee->safe()->first());
        $transferPaymentMethods = PaymentMethod::where('status', 1)->where('transfer', 1)->get();
        $depositPaymentMethods = PaymentMethod::where('status', 1)->where('deposit', 1)->get();

        // $normalSafe = Safe::where('status',1)->where('employee_id', $employee->id)->where('is_manager',0)->first();
        // if ($normalSafe) {
        //     $allSafes = Safe::where('status',1)
        //                 ->whereHas('employee',function($query){
        //                     $query->where('status',1);
        //                 })
        //                 ->where('is_manager', 1)->where('branch_id', $normalSafe->branch_id)->get();
        //     //dd($allSafes);
        //     $sefeHistories = SafeTrancation::where(function ($query) use ($normalSafe) {
        //         $query->where('safe_sender', '=', $normalSafe->id)
        //             ->orWhere('safe_receiver', '=', $normalSafe->id);
        //     })->orderBy('id', 'DESC')->get();
        // } else {
        //     $allSafes = null;
        //     $sefeHistories = null;
        // }
        
        // $branchSafe = Safe::where('status',1)->where('employee_id', $employee->id)->where('is_manager', 1)->first();

        // if ($branchSafe) {
        //     $allBranchesSafes = Safe::where('status',1)->where('branch_id', '!=', $branchSafe->branch_id)->where('is_hq', 1)->where('is_manager', 1)->get();
        //     $branchSefeHistories = SafeTrancation::where(function ($query) use ($branchSafe) {
        //         $query->where('safe_sender', '=', $branchSafe->id)
        //             ->orWhere('safe_receiver', '=', $branchSafe->id);
        //     })->orderBy('id', 'DESC')->get();
        // } else {
        //     $allBranchesSafes = null;
        //     $branchSefeHistories = null;
        // }


        $employeeVacation = Vacation::where('employee_id', $employee->id)->orderBy('id', 'DESC')->get();
        $employeeVacationHistory = VacationHistory::where('employee_id', $employee->id)->orderBy('id', 'DESC')->get();

        return view('instructor.profile.profile', compact('employee','branches', 'employeeVacation', 'employeeVacationHistory'));
    }
    
    public function storeresignations(Request $request){


        // return $request;
        $user = auth()->user()->id;
        $resignations = new Resignation;
        $resignations->employee_id = $user;
        $resignations->hire_date = $request->hire_date;
        $resignations->date_of_resign = $request->date_of_resign;
        $resignations->Reason = $request->Reason;
        $resignations->branch_id = $request->branch_id;

        $resignations->save();

        Flash::success('Resignation Added successfully.');
        return redirect('instructorPortal/getProfile');


    }

    public function downloadFile($id, $fileName, $fileMime)
    {
        $employee = Employee::find($id);
        $name = '/' . $employee[$fileName];
        $namArrey = explode(".", $name);
        $mime = $employee[$fileMime];
        //        $filePath = public_path().$name;
        $filePath = "/home/harvestc/public_html" . $name;

        $headers = array(
            'Content-Type: ' . $mime,
        );
        return \Illuminate\Support\Facades\Response::download($filePath, $fileName . '.' . $namArrey[count($namArrey) - 1], $headers);
    }
    
    
 
    
    
    
    
    
    
    
    
    
    public function schedule(Request $request)
    {
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        
        //$current_day = '2022-06-01';
        $current_day = date('Y-m-d');
        
        $groups = Group::where('instructor_id',auth()->user()->id)->whereIn('branch_id',array_keys($employeeBranches))->whereHas('subRound',function($query) use ($current_day){
            $query->where('start_date','<=',$current_day)->where('end_date','>',$current_day);
        });
        
        $groups = $groups->withCount('students','sessions')->get();
        
        $rounds = Round::whereIn('id',$groups->pluck('round_id')->toArray())->get();
        
        $groups = $groups->groupBy('round_id');
        
        
        //dd($groups);
        //return view('schedule.schedulePerRound',compact('employeeBranches','rounds'));
        
        return view('instructor.schedule.index',compact('employeeBranches','groups','rounds'));
    }
    
    public function scheduleNext(Request $request)
    {
        //dd($request->all());
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        
        $round = Round::find($request->round_id);
        $groups = Group::where('instructor_id',auth()->user()->id)->whereIn('branch_id',array_keys($employeeBranches))->where('round_id',$round->id)->whereIn('sub_round_id',explode(',',$request->sub_rounds_ids));
        
        $groups = $groups->withCount('students','sessions')->get();
        
        //dd($previousSubRound,$nextSubRound);
        if($request->type == 'next'){
            $nextSubRound = $round->nextSubRound($request->date);
            
            $next_date = ($nextSubRound != null && count($nextSubRound) > 0)?$nextSubRound->max('end_date'):date('Y-m-d');
            $previous_date = ($nextSubRound != null && count($nextSubRound) > 0)?$nextSubRound->min('start_date'):date('Y-m-d');
        }else{
            $previousSubRound = $round->previousSubRound($request->date);
            
            $next_date = ($previousSubRound != null && count($previousSubRound) > 0)?$previousSubRound->max('end_date'):date('Y-m-d');
            $previous_date = ($previousSubRound != null && count($previousSubRound) > 0)?$previousSubRound->min('start_date'):date('Y-m-d');
        }
        
        //dd($next_date,$previous_date,$request->date);
        //$groups = $groups->groupBy('round_id');
        //dd($groups);
        $html = view('instructor.schedule.table',compact('round','groups','next_date','previous_date'))->render();
        return $html;
    }
    
    public function classes(Request $request)
    {
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        $branches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $instructor = auth()->user();
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id')->toArray();
        //$this->rounds = Round::pluck('title', 'id')->toArray();
        $disciplines = DisciplineCategory::pluck('name', 'id')->toArray();
        $courses = [];
        $stageLevels = [];
        $timeframes = [];
        $rounds = [];
        $daysData = [];
        $intervals = [];
        $subRounds = [];
        $rooms = [];
        $groupsQuery = Group::where('instructor_id',$instructor->id)->with('subRound')->withCount('students', 'sessions','studentexam');
        
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $groupsQuery->where('code','like','%'.$request->get('search').'%');
        }
        
        if($request->has('discipline_id') && $request->get('discipline_id') != null && $request->get('discipline_id') != ''){
            $groupsQuery->where('discipline_id',$request->get('discipline_id'));
        }
        
        if($request->has('track_id') && $request->get('track_id') != null && $request->get('track_id') != ''){
            $courses = Track::where('status',1)->where('parent_id',$request->get('track_id'))->pluck('title','id');
            $groupsQuery->where('track_id',$request->get('track_id'));
        }
        
        if($request->has('course_id') && $request->get('course_id') != null && $request->get('course_id') != ''){
            $groupsQuery->where('course_id',$request->get('course_id'));
            $stageLevels = Track::find($request->get('course_id'))->stageLevels->pluck('name', 'id')->toArray();
            $timeframe_ids = DB::table('timeframe_courses')->where('course_id',$request->get('course_id'))->pluck('timeframe_id')->toArray();
            $timeframes = Timeframe::whereIn('id',$timeframe_ids)->where('status',1)->pluck('title','id')->toArray();
        }
        
        if($request->has('level_id') && $request->get('level_id') != null && $request->get('level_id') != ''){
            $groupsQuery->where('level_id',$request->get('level_id'));
        }
        
        if($request->has('timeframe_id') && $request->get('timeframe_id') != null && $request->get('timeframe_id') != ''){
            $groupsQuery->where('timeframe_id',$request->get('timeframe_id'));
            $rounds = Round::where('timeframe_id',$request->get('timeframe_id'))->pluck('title', 'id')->toArray();
        }
        
        if($request->has('round_id') && $request->get('round_id') != null && $request->get('round_id') != ''){
            $groupsQuery->where('round_id',$request->get('round_id'));
            $round = Round::with('timeframe.intervals')->find($request->get('round_id'));

            $daysData = $round->timeframe->days;
            $intervals = $round->timeframe->intervals->pluck('name', 'id')->toArray();
            
        }
        if($request->has('days') && $request->get('days') != null && $request->get('days') != ''){
            $groupsQuery->where('days',$request->get('days'));
            $subRounds = SubRound::where('days', $request->get('days'))
                                -> where('round_id', $request->get('round_id'))
                                -> whereDate('start_date', '>=', now())
                                -> orderBy('start_date')->pluck('start_date', 'id');
        }
        
        if($request->has('interval_id') && $request->get('interval_id') != null && $request->get('interval_id') != ''){
            $groupsQuery->where('interval_id',$request->get('interval_id'));
            $request->instructor_id = '';
        }
        
        if($request->has('sub_round_id') && $request->get('sub_round_id') != null && $request->get('sub_round_id') != ''){
            $groupsQuery->where('sub_round_id',$request->get('sub_round_id'));
        }
        
        if($request->has('branch_id') && $request->get('branch_id') != '' && $request->get('branch_id') != null){
            $groupsQuery->where('branch_id',$request->get('branch_id'));
            $rooms = Room::where('branch_id', $request->get('branch_id'))->pluck('name', 'id');
        }
        
        if($request->has('room_id') && $request->get('room_id') != '' && $request->get('room_id') != null){
            $groupsQuery->where('room_id',$request->get('room_id'));
        }
        
        if($request->has('status') && $request->get('status') != '' && $request->get('status') != null){
            if($request->get('status') == 'complete'){
                $groupsQuery->whereHas('subRound',function($query){
                    $query->where('end_date','<',date('Y-m-d'));
                });
            } 
            if($request->get('status') == 'upcoming'){
                $groupsQuery->whereHas('subRound',function($query){
                    $query->where('start_date','>=',date('Y-m-d'));
                });
            }
            if($request->get('status') == 'running'){
                $groupsQuery->whereHas('subRound',function($query){
                    $query->where('start_date','<',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
                });
            }
        }
        

        $totalgroups = $groupsQuery->count();
        $groupstudents = $groupsQuery->pluck('id');
        $totalstudent =GroupStudent::whereIn('group_id',$groupstudents)->count();
        $totalclient =GroupStudent::whereIn('group_id',$groupstudents)->distinct('lead_id')->count();
       
            
        $groups = $groupsQuery->with('parent', 'round', 'discipline', 'branch', 'room', 'instructor', 'interval')->latest()->paginate($per_page);
        return view('instructor.classes.index',compact('groups','totalstudent','totalclient','totalgroups','branches','tracks','disciplines','courses','stageLevels','timeframes','rounds','daysData','intervals','subRounds','rooms'));
    }

    public function show_student_exam($group_id)
    {
        $examsApplicants = StudentExam::where('group_id' , $group_id)->get();
        // return $examsApplicants;
        if (empty($examsApplicants)) {
            Flash::error('Group  not found');
            return redirect(route('instructor.classes.index'));
        }
        $examsApplicantCount = StudentExam::where('group_id' , $group_id)->count();

        $group = Group::with('students.lead.attendances')->withCount('students', 'sessions')->find($group_id);
        
        //dd($similar_groups);
        $pastSessions = GroupSession::where('group_id',$group->id)->where('status','!=',1)->count();
        
        return view('instructor.classes.show_student_exam', compact('examsApplicants','examsApplicantCount','group' ,'pastSessions'));
       

    }
    
    public function tecnical_tracker($student_id)
    {
    
        $user = Lead::where('id',$student_id)->first();
        // dd($user);
        
        if($user->getPT() != null && $user->getPT() != ''){
            $pt_result = $user->getPT();
            $total_pt = $pt_result->vocabulary_score + $pt_result->grammar_score + $pt_result->reading_score + $pt_result->listening_score + $pt_result->speaking_score + $pt_result->writing_score;
        }elseif($user->getKidsPT() != null && $user->getKidsPT() != ''){
            $pt_result = $user->getKidsPT();
            $total_pt = $pt_result->vocabulary_score + $pt_result->grammar_score + $pt_result->reading_score + $pt_result->listening_score + $pt_result->speaking_score + $pt_result->writing_score;
        }
        else{
            $pt_result = null;
            $total_pt = 0;
        }
        
        $exams_result = StudentExam::where('finish',1)->where('lead_id',$student_id)->get();
        
        return view('instructor.classes.technical_tracker',compact('pt_result','total_pt','exams_result'));
    
        
    }
    public function class_show($class_id)
    {
        $group = Group::find($class_id);
        $current = $group;

        $parentIds = [];
        while ($current->parent_id) {
            $parentIds[] = $current->parent_id;
            $current = $current->parent;
        }
        $parents = Group::whereIn('id', $parentIds)->withCount('students', 'sessions')->latest()->get();
        // dd($parents);

        if (empty($group)) {
            Flash::error('Group not found');

            return redirect(route('instructor.classes.index'));
        }
        

        return view('instructor.classes.show', compact('group', 'parents'));
    }
    
    public function classStudents($class_id)
    {
        $group = Group::with('students.lead.attendances')->withCount('students', 'sessions')->find($class_id);
        
        //dd($similar_groups);
        $pastSessions = GroupSession::where('group_id',$group->id)->where('status','!=',1)->count();
        
        $upgrade_group = null;
        
        //dd($upgrade_group);
        if (empty($group)) {
            Flash::error('Group  not found');
            return redirect(route('instructor.classes.index'));
        }

        return view('instructor.classStudents.show', compact('group','pastSessions'));
    }
    
    public function classSessions($class_id)
    {
        $groupId = request('group');
        $group = Group::with('students.lead.attendances')->withCount('students', 'sessions')->find($class_id);
        $pastSessions = GroupSession::where('group_id', $group->id)->where('status', '!=', 1)->count();
        
        /** @var GroupSession $groupSessions */
        $groupSessions = GroupSession::where('group_id', $class_id) ->with('makeup')->withCount('attendances')->get();

       
        return view('instructor.classSessions.index')
            ->with('groupSessions', $groupSessions)
            
            ->with('group',$group)
            ->with('pastSessions',$pastSessions);
    }
    
    public function classSessionShow($session_id)
    {
        $groupSession = GroupSession::with('group')->find($session_id);
        $group = $groupSession->group;
        if (empty($groupSession)) {
            Flash::error('Group Session not found');

            return redirect(route('instructor.classSessions.index'));
        }
         
        $groupss = GroupSession::with('group','attendances')->find($groupSession->id);
         $groupSessionattendance = $groupss->attendances;
        //  return $groupss;


        return view('instructor.classSessions.show')
        ->with('groupss', $groupss)
         ->with('groupSessionattendance', $groupSessionattendance)
        ->with('groupSession', $groupSession)->with('group' ,$group);
    }
    
    public function classSessionAttendances($session_id)
    {
        $attendances = GroupSessionAttendance::with('makeup')->where('group_session_id', $session_id)->get();
        $presents = $attendances->where('attendance',1)->pluck('id')->toArray();
        return view('instructor.classSessionAttendances.index',compact('attendances','presents','session_id'));
    }
   
    public function classSessionUpdateAttendances($session_id,Request $request)
    {

        $presents = ($request->has('presents') && $request->get('presents') != null && $request->get('presents') != '' && count($request->get('presents')) > 0)?$request->get('presents'):[];
        
        $groupSession = GroupSession::with('makeup')->find($session_id);
        $group = Group::withCount('sessions')->find($groupSession->group_id);
        
            

        $attendances = GroupSessionAttendance::where('group_session_id', $session_id)->get();
        
        
        foreach ($attendances as $attendance) { 
            $attendance->update(['attendance' => in_array($attendance->id, $presents) ? 1 : 0]);

            
            $absentCount = GroupSessionAttendance::where([
                'lead_id' => $attendance->lead_id,
                'group_id' => $attendance->group_id,
                'level_id' => $attendance->level_id,
                'attendance' => 0,
            ])->count();
            //dd($absentCount);
            $student = GroupStudent::where([
                'lead_id' => $attendance->lead_id,
                'group_id' => $attendance->group_id,
            ])->first();           

            if ($absentCount > 1) {
                $student->absence_per = ($absentCount / $group->sessions_count) * 100;

                $attendance->update(['need_makeup' => 1]);
            }
        }
       
        
         
        // $present_two=[];
        // $absent_two=[];
        // $leads_first=[];
        // $absent_first=[];
        // $first_session = GroupSession::where('group_id',$groupSession->group_id)->orderBy('date')->first(); 
        // $present_first = GroupSessionAttendance::where([
        //     'group_session_id'=>$first_session->id,
        //     'attendance'=>1,
            
        // ])->get();
        
        // foreach ($present_first as $key =>$present) {
        //     if($present->attendance == 1)
        //     {
        //         // return $present->lead_id->attendance;
        //        $customer_track = CustomerTrack::where('lead_id',$present->lead_id)->first();
        //        $customer_track->used += 1;
        //        $customer_track->save();
        //     }

        // }
        
        // $absent_first = GroupSessionAttendance::where([
        //     'group_session_id'=>$first_session->id,
        //     'attendance'=>0,
            
        // ])->get();
        
        // $two_session = GroupSession::where('group_id',$groupSession->group_id)->orderBy('date')->get(); 
        
        // $present_two = GroupSessionAttendance::where([
        //     'group_session_id'=>$two_session[1]->id,
        //     'attendance'=>1,
            
        // ])->get();
        
            
        // foreach ($present_two as $key => $per_two) {
        //     // $totalabs = $abs_two->where('attendance',0)->count();
        //     $abs_first = GroupSessionAttendance::where([
        //         'group_session_id'=>$first_session->id,
        //         'attendance'=>0,
        //         'lead_id'=>$per_two->lead_id,
                
        //     ])->first();
        //     // return $totalabs;
        //     if($abs_first != null  ){
        //         if($per_two->attendance==0 )
        //         {
        //             $customer_track = CustomerTrack::where('lead_id',$per_two->lead_id)->first();
        //             $customer_track->used += 1;
        //             $customer_track->save();
        //         }
                 
        //     }
        // }
        //  $absent_two = GroupSessionAttendance::where([
        //         'group_session_id'=>$two_session[1]->id,
        //         'attendance'=>0,
                
        // ])->get();
            
        // foreach ($absent_two as $key => $absent) {
        //     // $totalabs = $abs_two->where('attendance',0)->count();
        //     $abs_first = GroupSessionAttendance::where([
        //         'group_session_id'=>$first_session->id,
        //         'attendance'=>0,
        //         'lead_id'=>$absent->lead_id,
                
        //     ])->first();
        //     // return $totalabs;
        //     if($abs_first != null  ){
        //         if($absent->attendance==0 )
        //         {
        //             $customer_track = CustomerTrack::where('lead_id',$absent->lead_id)->first();
        //             $customer_track->used += 1;
        //             $customer_track->save();
        //         }
                 
        //     }
        // }
        
            
            





        //get first session
        //campare id first session = $id
        //get all present leads in this session
        //increase used level
        
        //get secend session
        //compare id secend session = $id
        //get all absent leads in this session
        // increase used level in case absend in first session
        //get all present leads in this session
        // increase used level in case absent in first session

        

        $groupSession->update(['status' => 2]);

        Flash::success('Attendance saved successfully.');
        
        // return redirect()->back();
        
        return redirect('/instructorPortal/classSessions/'.$group->id);
    }
    
    
    public function makeupSessions()
    {
        $instructor = auth()->user();
        $makeupSessions = MakeupSession::where('instructor_id',$instructor->id)->orderBy('id','desc')->paginate(10);

        return view('instructor..makeup_sessions.index')->with('makeupSessions', $makeupSessions);
    }
    
    public function makeupSession_show($makeup_session_id)
    {
        $instructor = auth()->user();
        $makeupSession = MakeupSession::findOrFail($makeup_session_id);
        
        return view('instructor..makeup_sessions.show')->with('makeupSession', $makeupSession);
    }
    
    public function attendance()
    {
        $instructor = auth()->user();
        $groupSessions = GroupSession::where('instructor_id',$instructor->id)->where('date',date('Y-m-d'))->with('makeup')->withCount('attendances')->get();
        //dd($instructor,$groupSessions);
        return view('instructor.attendance',compact('groupSessions'));
    }
    
    public function examsResults(Request $request)
    {
        $instructor = auth()->user();
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id')->toArray();
        $courses = [];
        $stageLevels = [];
        $groups = Group::orderBy('created_at' , 'desc');
        
        $timeframes = [];
        $rounds = [];
        $daysData = [];
        $intervals = [];
        $subRounds = [];
        
        
        if($request->has('branch_id') && $request->get('branch_id') != null && $request->get('branch_id') != ''){
            $examsApplicantsQuery = StudentExam::whereHas('group',function($query) use ($request,$instructor){
                $query->where('branch_id', $request->get('branch_id'))->where('instructor_id',$instructor->id);
            });
        }else{
            $examsApplicantsQuery = StudentExam::whereHas('group',function($query) use ($employeeBranches,$instructor){
                $query->whereIn('branch_id', array_keys($employeeBranches))->where('instructor_id',$instructor->id);
            });
        }
        if (request()->filled('search')) {
            $examsApplicantsQuery->whereHas('lead',function ($query) {
                $query->where('leads.name', 'like', '%' . $this->search . '%')
                    ->orWhere('leads.mobile_1', 'like', '%' . $this->search . '%')
                    ->orWhere('leads.email', 'like', '%' . $this->search . '%');
            });
        }
        if (request()->filled('status')) {
            $examsApplicantsQuery->where('status', request('status'));
        }
        
        // if($request->has('track_id') && $request->get('track_id') != null && $request->get('track_id') != ''){
        //     $courses = Track::where('status',1)->where('parent_id',$request->get('track_id'))->pluck('title','id');
        //     $examsApplicantsQuery->where('track_id',$request->get('track_id'));
        // }
        
        // if($request->has('course_id') && $request->get('course_id') != null && $request->get('course_id') != ''){
        //     $examsApplicantsQuery->where('course_id',$request->get('course_id'));
        //     $stageLevels = Track::find($request->get('course_id'))->stageLevels->pluck('name', 'id')->toArray();
        // }
        
        // if($request->has('level_id') && $request->get('level_id') != null && $request->get('level_id') != ''){
        //     $examsApplicantsQuery->where('level_id',$request->get('level_id'));
        //     $groups = Group::where('track_id',$request->get('track_id'))->where('course_id',$request->get('course_id'))->where('level_id',$request->get('level_id'))->pluck('code', 'id')->toArray();
        // }
        // if($request->has('timeframe_id') && $request->get('timeframe_id') != null && $request->get('timeframe_id') != ''){
        //     $groupsQuery->where('timeframe_id',$request->get('timeframe_id'));
        //     $rounds = Round::where('timeframe_id',$request->get('timeframe_id'))->pluck('title', 'id')->toArray();
        // }
        
        // if($request->has('round_id') && $request->get('round_id') != null && $request->get('round_id') != ''){
        //     $groupsQuery->where('round_id',$request->get('round_id'));
        //     $round = Round::with('timeframe.intervals')->find($request->get('round_id'));

        //     $daysData = $round->timeframe->days;
        //     $intervals = $round->timeframe->intervals->pluck('name', 'id')->toArray();
            
        // }
        // if($groups != null && count($groups) > 0 && $request->has('branch_id') && $request->get('branch_id') != null && $request->get('branch_id') != ''){
        //     $groups->where('branch_id',$request->get('branch_id'));
        // }
       if($request->has('track_id') && $request->get('track_id') != null && $request->get('track_id') != ''){
            $courses = Track::where('status',1)->where('parent_id',$request->get('track_id'))->pluck('title','id');
            $examsApplicantsQuery->where('track_id',$request->get('track_id'));
        }
        
        if($request->has('course_id') && $request->get('course_id') != null && $request->get('course_id') != ''){
            $examsApplicantsQuery->where('course_id',$request->get('course_id'));
            $stageLevels = Track::find($request->get('course_id'))->stageLevels->pluck('name', 'id')->toArray();

            $timeframe_ids = DB::table('timeframe_courses')->where('course_id',$request->get('course_id'))->pluck('timeframe_id')->toArray();
            $timeframes = Timeframe::whereIn('id',$timeframe_ids)->where('status',1)->pluck('title','id')->toArray();
        }
        
        if($request->has('level_id') && $request->get('level_id') != null && $request->get('level_id') != ''){
            $examsApplicantsQuery->where('level_id',$request->get('level_id'));
            $groups = $groups->where('track_id',$request->get('track_id'))->where('course_id',$request->get('course_id'))->where('level_id',$request->get('level_id'));
        }
        if($request->has('timeframe_id') && $request->get('timeframe_id') != null && $request->get('timeframe_id') != ''){
            $examsApplicantsQuery->whereHas('group' ,function($q) use ($request){
                $q->where('timeframe_id',$request->get('timeframe_id'));
            });
            $groups->where('timeframe_id',$request->get('timeframe_id'));
            $rounds = Round::where('timeframe_id',$request->get('timeframe_id'))->pluck('title', 'id')->toArray();
        }
        
        if($request->has('round_id') && $request->get('round_id') != null && $request->get('round_id') != ''){
            $groups->where('round_id',$request->get('round_id'));
            $round = Round::with('timeframe.intervals')->find($request->get('round_id'));
            $examsApplicantsQuery->whereHas('group' ,function($q)use ($request){
                $q->where('round_id',$request->get('round_id'));
            });
            $daysData = $round->timeframe->days;
            $intervals = $round->timeframe->intervals->pluck('name', 'id')->toArray();
            
        }
        $groups= $groups->get();
        $examsApplicantCount = $examsApplicantsQuery->count();
        $examsApplicants = $examsApplicantsQuery->latest()->paginate(20);
        
        return view('instructor.exams_results.index',compact('employeeBranches','courses','timeframes','rounds','stageLevels','groups','tracks','examsApplicants', 'examsApplicantCount'));
    }
    
    public function examsResultShow($exam_applicant_id)
    {
        $applicant = StudentExam::find($exam_applicant_id);

        if (empty($applicant)) {
            Flash::error('Exam Applicant not found');

            return redirect(route('instructor.examsResults.index'));
        }
        return view('instructor.exams_results.show',compact('applicant'));
    }
    
    public function examsResultEdit($exam_applicant_id)
    {
        $applicant = StudentExam::with('answers')->find($exam_applicant_id);

        if (empty($applicant)) {
            Flash::error('Placement Applicant not found');

            return redirect(route('instructor.examsResults.index'));
        }
        
        return view('instructor.exams_results.edit',compact('applicant'));
    }
    
    public function examsResultUpdate($exam_applicant_id,Request $request)
    {
        $examsApplicant = StudentExam::find($exam_applicant_id);
        
        if (empty($examsApplicant)) {
            Flash::error('Placement Applicant not found');

            return redirect(route('instructor.examsResults.index'));
        }


        $examsApplicant->fill($request->except('_method','_token','exam_per','exam_status'));
        $examsApplicant->save();
        
        $exam_per = ((($examsApplicant->vocabulary_score + $examsApplicant->grammar_score + $examsApplicant->reading_score + $examsApplicant->listening_score + $examsApplicant->speaking_score + $examsApplicant->writing_score+$examsApplicant->evaluation_score) / 100) * 100);
        $updated_data = array();
        $updated_data['exam_status'] = ($exam_per >= 60)?'pass':'fail';
        $updated_data['exam_per'] = number_format($exam_per,2);
        
        $student = $examsApplicant->student;
        $student->update($updated_data);
        
        Flash::success('Placement Applicant updated successfully.');

        return redirect(route('instructor.examsResults.show_student_exam',$examsApplicant->group_id));
    }
    
    public function final_rate()
    {
        $instructor = auth()->user();
        $instructor['plan'] = $instructor->getPlan();
        $instructor['actual_plan'] = $instructor->getActualPlan();
        $instructor['actual_customers'] = $instructor->getActualCustomers();
        
        return view('instructor.final_rate',compact('instructor'));
    }
    

    public function PT_requests()
    {
        return view('instructor.PT_requests');
    }
    
    public function ratio_reporting(Request $request)
    {
        $instructor = auth()->user();
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $timeframes = Timeframe::pluck('title','id');
        
        $groupsQuery = Group::where('instructor_id',$instructor->id);
        // return $groupsQuery=$groupsQuery->get();

        
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $groupsQuery = $groupsQuery->whereIn('branch_id',$request->get('branches'));
        }
        
        if($request->has('timeframe_id') && $request->get('timeframe_id') != '' && $request->get('timeframe_id') != null){
            $groupsQuery = $groupsQuery->where('timeframe_id',$request->get('timeframe_id'));
        }
        
        if($request->has('status') && $request->get('status') != '' && $request->get('status') != null ){
            if($request->get('status') == 'complete'){
                $groupsQuery->whereHas('subRound',function($query){
                    $query->where('end_date','<',date('Y-m-d'));
                })->has('students');
            } 
            if($request->get('status') == 'upcoming'){
                $groupsQuery->whereHas('subRound',function($query){
                    $query->where('start_date','>',date('Y-m-d'));
                })->has('students');
            }
            if($request->get('status') == 'running'){
                // dd($request->all());
                $groupsQuery->whereHas('subRound',function($query){
                    $query->where('start_date','<=',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
                    
                })->has('students');
            }
            
        }
        
        
        $groups = $groupsQuery->select('id','code','timeframe_id','branch_id','room_id','instructor_id','admin_id','discipline_id','sub_round_id')
        ->with('timeframe','branch','room','instructor','admin','discipline','subRound')->withCount('students','studentexam')->get();
        // dd( $groups);
    
    
        return view('instructor.ratio_reporting',compact('employeeBranches','timeframes','groups'));
    }
    
    public function groups_chat()
    {
        return view('instructor.groups_chat');
    }

    public function index()
    {
        // $groups = [];
        $instructor=auth()->user();
        // return $instructor->id;
        $groups = Group::where('instructor_id',$instructor->id)->count();
        // return $groups;

        $groupstudents = Group::where('instructor_id',$instructor->id)->pluck('id');
        
        $client =GroupStudent::whereIn('group_id',$groupstudents)->distinct('lead_id')->count();
       
        $student = GroupStudent::whereIn('group_id',$groupstudents)->count();
      

        return view('instructor.home',compact('client' , 'groups','student'));
    }


    public function getsubtrackI(Request $request)
    {
        // $tracks=[];
        $subtrack=[];
        $subtrack = Track::where('status',1)->where('parent_id' , $request->track_id)->select('title', 'id')->get();
        return json_decode($subtrack);

    }
    public function getlevelsI(Request $request)
    {
        $stageLevels=[];
        // $stageLevels = Track::find($request->course_id)->stageLevels;
        $stageLevels = Track::find($request->course_id)->stageLevels;
        // $levels = Track::where('status',1)->where('levels' , $request->levels)->get();
        return $stageLevels;
    }

    public function gettimeframesI(Request $request){
        $timeframes=[];
        $timeframe_ids=[];
        $timeframe_ids = DB::table('timeframe_courses')->where('course_id',$request->course_id)->pluck('timeframe_id');
        $timeframes = Timeframe::whereIn('id',$timeframe_ids)->where('status',1)->get();
     
        return  $timeframes;
    }

    public function getroundI(Request $request)
    {
        $round=[];
        $round = Round::where('timeframe_id',$request->timeframe_id)->select('title', 'id')->get();

        // $round = Round::find($request->round_id);
       return $round;
    }
    public function getsubroundI(Request $request){
        $round=[];
        
        $round = Round::find($request->round_id);
        $subround=[];
        $subround=SubRound::where('round_id',$round->id)->select('id','start_date')->get();
        return $subround ;

    }

    public function getintervalI(Request $request)
    {
        $round = Round::with('timeframe.intervals')->find($request->round_id);

            // $daysData = $round->timeframe->days;
        $intervals=[];
        $intervals = $round->timeframe->intervals;
            
        return $intervals;
    }

    public function getdayI(Request $request)
    {
        // $daysData=[];
        $round = Round::with('timeframe.intervals')->find($request->round_id);

        $daysData = $round->timeframe->days;
        $html1 ='<option></option>';
        
        // for( $i = 0; $i < $length; $i++) {
        //                     // $html1 +=  data2[i] ;
        //     $html1 += '<option value="' + $daysData[$i] + '" >' + $datasData[$i] + '</option>';
        //  }
        foreach ($daysData as $data) {
            $html1 .= '<option value="' .$data . '" >' .config('system_variables.timeframes.days')[$data] . '</option>';
        }
        // sel2.html(html1);
       


        // return $daysData;
        return $html1;

    } 

    public function getroomI(Request $request)
    {
        $rooms=[];
        $rooms = Room::where('branch_id', $request->branch_id)->select('name', 'id')->get();
        return $rooms;

    }


    
}
