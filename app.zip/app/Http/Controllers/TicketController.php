<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Ticket;
use App\Models\Employee;
use App\Models\Department;
use App\Models\Notification;
use App\Http\Requests\CreateTicketRequest;
use App\Http\Requests\UpdateTicketRequest;
use Flash;
use File;
use DB;
use App\Events\MyEvent;
use App\Traits\StoreImageTrait;


class TicketController extends Controller
{
                         use StoreImageTrait;

    //
    public function index(Request $request)
    {
        $employeedepartment =auth()->user()->department_id;
        $department_manager = DB::table('department_managers')->where('department_id',$employeedepartment)->first();
        $tickets = Ticket::orderBy('created_at','desc');
        
        if($department_manager != null && $department_manager != ' ')
        {
            $tickets = $tickets->with('employee','department','todepartment','actionemployee')
                         ->where('from_depart_id',$department_manager->department_id)
                         ->orwhere('to_depart_id',$department_manager->department_id);  
        }
        else{
            $tickets = $tickets->with('employee','department','fromdepartment','actionemployee' )->where('created_by_id', auth()->user()->id);
        }

                     
        $departments = Department::get();

        // return $tickets;
        
        $from_depart_id = $request->from_depart_id;

        $daterange_from = null;
        $daterange_to = null;
        $reg_to=null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $daterange_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $daterange_to= date_format($reg_to,"Y-m-d");;
            
        }

        if ($daterange_from != null && $daterange_to != '') {
            $tickets->whereBetween('created_at', [$daterange_from, $daterange_to]);
        }
        
        if($request->has('from_depart_id') && count($from_depart_id) != 0 &&  !in_array(0, $from_depart_id)){
            $tickets = $tickets->whereIn('from_depart_id',$from_depart_id);
        }
        if($request->has('status') && $request->get('status') != '' && $request->get('status') != null){
            $tickets = $tickets->where('status',$request->get('status'));
        }
        $tickets=$tickets->get();
        // return $tickets;

        $totalCount = $tickets->count();
        return view('Tickets.index',compact('tickets' , 'totalCount' ,'departments'));
    }
    
    public function indexfrom(Request $request)
    {
        
       $employeedepartment =auth()->user()->id;
        $department_manager = DB::table('department_managers')->where('employee_id',$employeedepartment)->first();
        
        $tickets = Ticket::with('employee','department','fromdepartment','actionemployee' )->
                          where('from_depart_id',auth()->user()->department_id)->where('created_by_id', auth()->user()->id)
        ->orderBy('created_at','desc');
        $departments = Department::get();
        
        $to_depart_id = $request->to_depart_id;
        $daterange_from = null;
        $daterange_to = null;
        $reg_to=null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $daterange_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $daterange_to= date_format($reg_to,"Y-m-d");;
            
        }

        if ($daterange_from != null && $daterange_to != '') {
            $tickets->whereBetween('created_at', [$daterange_from, $daterange_to]);
        }
        
        if($request->has('to_depart_id') && count($to_depart_id) != 0 &&  !in_array(0, $to_depart_id)){
            $tickets = $tickets->whereIn('to_depart_id',$to_depart_id);

        }
        if($request->has('status') && $request->get('status') != '' && $request->get('status') != null){
            $tickets = $tickets->where('status',$request->get('status'));
        }
        $tickets=$tickets->get();
        // return $tickets;
        $totalCount = $tickets->count();
        return view('Tickets.indexfrom',compact('tickets' , 'totalCount' ,'departments'));
    }
    
    public function create(Request $request)
    {
        $departments= Department::get();
        $department_manager = DB::table('department_managers')->where('employee_id',auth()->user()->id)->first();
        $user = auth()->user()->department_id;
        // return $departments;
        return view('Tickets.create',compact('departments','department_manager','user'));
        
    }

    public function show($id)
    {
        $ticket = Ticket::with('employee' ,'department')->find($id);
        // return $tickets;
        return view('Tickets.show',compact('ticket' ));
    }
    
    public function store(CreateTicketRequest $request)
    {
        $data = $request->all();
        $data['created_by_id'] = auth()->user()->id;
        $data['status'] = 'pending';
        $data['from_depart_id'] = auth()->user()->department->id;
        
     
              $data['image'] = $this->verifyAndStoreImageSource($request,'image','uploads/ticket_image');

        if ($request->hasFile('video'))
        {
            $file = $request->file('video');
            
            $file_name = rand(11111,99999).'-'.$file->getClientOriginalName();
            $file->storeAs('/uploads/ticket_video', $file_name);
            $data['video'] = $file_name;
            
            File::move(storage_path('app/uploads/ticket_video/'.$file_name), '/home/harvestc/public_html/uploads/ticket_video/'.$file_name);
        }
        $ticket = Ticket::create($data);
        
        $manager_name = DB::table('department_managers')->where('department_id',$ticket->to_depart_id)->first();
        
        $ticket->save();
        
        $notification = new Notification;
        $notification->username = $manager_name->employee_id;
        $notification->message = $ticket->title;
        $notification->save();
        
        
        
        
        $data=[
            'title'=> $ticket->title,
            'description'=>$ticket->title,
            'user'=>auth()->user()->id,
            ];
        
        event(new MyEvent($data));
        Flash::success('Tickets Added successfully.');
        return redirect(route('admin.Tickets.indexfrom'));


    }

    public function destroy($id)
    {
        $ticket = Ticket::find($id);
        $ticket->delete();
        Flash::success('Tickets deleted successfully.');
        return redirect(route('admin.Tickets.indexfrom'));



    }



    public function edit($id)
    {
       
        $ticket = Ticket::with('employee' , 'department')->find($id);
        $departments= Department::get();
  
        return view('Tickets.edit',compact('ticket','departments'));
        

    }

    public function update($id , Request $request)
    {
        $validator = $request->validate(
            [
                'status' => 'required',
            ]
        );
        $ticket = Ticket::find($id);
        $last_action_employee_id = auth()->user()->id;
        $ticket->last_action_date = date('Y-m-d h:i:sa');
        $ticket->last_action_employee_id= $last_action_employee_id;
        $ticket->status = $request->status;
        $ticket->note = $request->note;
        $ticket->save();
        
        $manager_name = DB::table('department_managers')->where('department_id',$ticket->from_depart_id)->first();
        
       
        
        $notification = new Notification;
        $notification->username = $manager_name->employee_id;
        $notification->message = 'Update Status in Ticket';
        $notification->save();
        
        
        
        
        $data=[
            'title'=> $ticket->title,
            'description'=>$ticket->description,
            'user'=>auth()->user()->id,
            ];
        
        event(new MyEvent($data));
        Flash::success('Tickets Updated successfully.');
        return redirect(route('admin.Tickets.index'));


        
    }
    
    public function showalltickets(Request $request)
    {
        $tickets = Ticket::with('employee','department','todepartment','actionemployee')
        ->orderBy('created_at','desc');
        $departments = Department::get();

        $depart_id = $request->depart_id;
        $daterange_from = null;
        $daterange_to = null;
        $reg_to=null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $daterange_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $daterange_to= date_format($reg_to,"Y-m-d");;
            
        }

        if ($daterange_from != null && $daterange_to != '') {
            $tickets->whereBetween('created_at', [$daterange_from, $daterange_to]);
        }
        
        if($request->has('depart_id') && count($depart_id) != 0 &&  !in_array(0, $depart_id)){
            $tickets = $tickets->whereIn('to_depart_id',$depart_id)->orwhereIn('from_depart_id' ,$depart_id);
        }
        if($request->has('status') && $request->get('status') != '' && $request->get('status') != null){
            $tickets = $tickets->where('status',$request->get('status'));
        }
        $tickets=$tickets->get();
        
        $totalCount = $tickets->count();
        
        return view('Tickets.showallticket',compact('tickets','totalCount','departments'));
    }
}
