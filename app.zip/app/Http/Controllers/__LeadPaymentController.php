<?php

namespace App\Http\Controllers;

use Flash;
use Response;
use DB;
use Mail;
use Exception;
use App\Models\Lead;
use App\Models\LeadPayment;
use App\Models\LeadCase;
use App\Models\LeadLastCase;
use App\Mail\PaymentInvoice;
use App\Models\Timeframe;
use App\Models\Track;
use App\Models\DisciplineCategory;
use App\Models\StageLevel;
use App\Models\LeadSource;
use App\Models\KnowChannel;
use App\Models\Offer;
use App\Models\SafeOperation;
use App\Models\Branch;
use App\Models\TrainingService;
use App\Models\Employee;
use App\Models\GroupSession;
use App\Models\CertificateRequest;
use App\Models\ExtraItem;
use App\Models\SubPayment;
use App\Models\GroupWaitingList;
use App\Models\Group;
use App\Models\Country;
use App\Models\CustomerJob;
use App\Models\University;
use App\Models\PaymentMethod;
use App\Models\ServiceFee;
use App\Models\Interval;
use App\Models\CustomerTrack;
use App\Models\OldCustomerPayment;
use App\Models\Governorate;
use App\Models\City;
use App\Models\PlacementApplicant;
use Illuminate\Http\Request;
use App\Models\Safe;
use App\Http\Requests\UpdateCustomerRequest;
use App\Http\Requests\CreateLeadPaymentRequest;
use App\Http\Requests\UpdateLeadPaymentRequest;
use App\Http\Controllers\AppBaseController;
use Illuminate\Database\Eloquent\Relations\MorphTo;

use App\Models\SMS;
use App\Models\MessageLog;
use App\Models\WhatsApp;
use App\Models\Invoice;
use Auth;
use File;
// use Response;
use Spatie\Activitylog\Contracts\Activity;

class LeadPaymentController extends AppBaseController
{
    /**
     * Display a listing of the LeadPayment.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function oldPaymentCreate($lead)
    {
        $lead = Lead::findOrFail($lead);
        
        if (empty($lead)) {
            Flash::error('Lead not found');

            return redirect(route('admin.leads.index'));
        }
        
        if(! $lead->f_name){
            $lead->f_name = (isset($lead->name['en']))?$lead->name['en']:'';
        }
        
        if(! $lead->name_ar){
            $lead->name_ar = (isset($lead->name['ar']))?$lead->name['ar']:'';
        }
        
        if($lead->pt_level != null && $lead->pt_level != ''){
            $lead->pt_level = Lead::$PT_levels[$lead->pt_level];
        }
        
        $sources = LeadSource::where('status',1)->pluck('name', 'id');
        $channels = KnowChannel::where('status',1)->pluck('name', 'id');
        $offers = Offer::pluck('title', 'id');
        $branches = Branch::pluck('name', 'id');
        $services = TrainingService::pluck('title', 'id');
        $employees = Employee::where('status',1)->where('account_Type','Operations Account')->get()->pluck('name', 'id');
        $timeframes = Timeframe::pluck('title', 'id');
        
        $countries = Country::where('status',1)->pluck('name', 'id')->toArray();
        $jobs = CustomerJob::where('status',1)->pluck('name', 'id')->toArray();
        $univercities = University::where('status',1)->pluck('name', 'id')->toArray();
        $nationalities = Country::where('status',1)->pluck('nationality', 'id')->toArray();
        $governorates = Governorate::select('id','name','country_id')->where('status',1)->get();
        $governorates = $governorates->groupBy('country_id');
        //dd($governorates);
        $cities = City::select('id','name','gov_id')->where('status',1)->get();
        $cities = $cities->groupBy('gov_id');
        
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id')->toArray();
        //$rounds = Round::pluck('title', 'id')->toArray();
        $disciplines = DisciplineCategory::pluck('name', 'id')->toArray();
        $courses = Track::select('parent_id','title','id')->where('status',1)->whereNotNull('parent_id')->get();
        $courses = $courses->groupBy('parent_id');
        
        $stageLevels = StageLevel::join('stages','stages.id','=','stage_levels.stage_id')
                                ->select('stage_levels.id','stage_levels.name','stages.track_id')
                                ->get();
        $stageLevels = $stageLevels->groupBy('track_id');
        
        return view('lead_payments.oldPaymentCreate',compact('employees','countries','jobs','univercities','nationalities','governorates','cities','sources','channels','offers','branches','services','lead','timeframes','tracks','disciplines','courses','stageLevels'));
    }
    
    public function oldPaymentStore($lead,UpdateCustomerRequest $request)
    {
        $lead = Lead::find($lead);
        
        if($request->country == 1) {
            // dd($input);
            $request->validate([
                'mobile_1' => 'required|digits:11|starts_with:0|unique:leads,mobile_1,'.$request->segment(3),
            ]);

        }

        if (empty($lead)) {
            Flash::error('Lead not found');

            return redirect(route('admin.database.index'));
        }
        $pt_applicants = PlacementApplicant::where('mobile',$lead->mobile_1)->get();
        //dd($pt_applicants);
        if($lead->mobile_1 != $request->mobile_1){
            foreach($pt_applicants as $pt_applicant){
                $pt_applicant->mobile = $request->mobile_1;
                $pt_applicant->save();
            }
        }
        if($lead->email != $request->email){
            foreach($pt_applicants as $pt_applicant){
                $pt_applicant->email = $request->email;
                $pt_applicant->save();
            }
        }
        
        $input = $request->except('track_id','sub_track_id','current_level','num_of_levels','discipline_id','timeframe_id','interval','harvest_certificate','cambridge_certificate','books','total_amount','paid');
        $input['name_en'] = $request->f_name.' '.$request->m_name.' '.$request->l_name;
        $input['type'] = 2;
        
        if($lead->trans_customer == null){
         $input['trans_customer']= date('Y-m-d h:i:sa');
        }
        $input['old_customer'] = 1;
        $lead->update($input);
        $level = null;
        
        if(isset($request->current_level) && $request->current_level !== ''){
            $level = StageLevel::find($request->current_level);
            //dd($level);
            if($level != null && $level != ''){
                $lead->update(['pt_level' => $level->value]);
            }
            $checkGroupWaitingList = GroupWaitingList::where('lead_id',$lead->id)->first();
            $intervals_ids = [];
            $interval_timeframe = DB::table('interval_timeframe')->where('timeframe_id',$request->timeframe_id)->pluck('interval_id')->toArray();
            if($request->interval == 'am'){
                $intervals_ids = Interval::whereIn('id',$interval_timeframe)->where('pattern','AM')->pluck('id')->toArray();
            }
            if($request->interval == 'pm'){
                $intervals_ids = Interval::whereIn('id',$interval_timeframe)->where('pattern','PM')->pluck('id')->toArray();
            }
                
            if($checkGroupWaitingList != null && $checkGroupWaitingList != ''){
                $checkGroupWaitingList->update([
                    'level_id' => $level->id,
                    'timeframes' => $request->timeframe_id,
                    'intervals' => implode(',',$intervals_ids),
                    'discipline_id' => $request->discipline_id
                ]);
            }else{
                GroupWaitingList::create([
                    'lead_id' => $lead->id,
                    'level_id' => $level->id,
                    'timeframes' => $request->timeframe_id,
                    'intervals' => implode(',',$intervals_ids),
                    'discipline_id' => $request->discipline_id
                ]);
            }
        }
        
        //dd($request->current_level,$level);
        $customerTrack = CustomerTrack::where('lead_id',$lead->id)->first();
        
        if ($customerTrack){
            if($customerTrack->used == 0){
                $customerTrack->update([
                    'track_id' => $request->track_id,
                    'course_id' => $request->sub_track_id,
                    'level_id' => ($level != null)?$level->id:null,
                    'total' => $request->num_of_levels,
                ]);
            }
        }else{
            $customerTrack = CustomerTrack::create([
                'lead_id' => $lead->id,
                'track_id' => $request->track_id,
                'course_id' => $request->sub_track_id,
                'level_id' => ($level != null)?$level->id:null,
                'total' => $request->num_of_levels,
                'used' => 0,
            ]);
        }
        
        
        $old_customer_payment = OldCustomerPayment::where('customer_id',$lead->id)->first();
        
        if($old_customer_payment != null && $old_customer_payment != ''){
            $old_customer_payment->update([
                'course_id' => $request->sub_track_id,
                'level_id' => ($level != null)?$level->id:null,
                'harvest_certificate' => ($request->harvest_certificate == 'yes')?'1':'0',
                'cambridge_certificate' => ($request->cambridge_certificate == 'yes')?'1':'0',
                'books' => ($request->books == 'yes')?'1':'0'
            ]);
        }else{
            $add = new OldCustomerPayment;
            $add->create([
                'customer_id' => $lead->id,
                'course_id' => $request->sub_track_id,
                'level_id' => ($level != null)?$level->id:null,
                'harvest_certificate' => ($request->harvest_certificate == 'yes')?'1':'0',
                'cambridge_certificate' => ($request->cambridge_certificate == 'yes')?'1':'0',
                'books' => ($request->books == 'yes')?'1':'0'
            ]);
        }
        
        $check_payment = LeadPayment::where('lead_id',$lead->id)->whereNull('paymentable_type')->first();
        if($check_payment != null && $check_payment != ''){
            $payment_data = [
                'lead_id' => $lead->id,
                'employee_id' => auth()->user()->id,
                'amount' => $request->total_amount,
                'include_books' => ($request->books == 'yes')?'1':'0',
            ];
            if($request->total_amount > $request->paid){
                $payment_data['payment_plan_id'] = 3;
                $payment_data['rest'] = ($request->total_amount - $request->paid);
            }else{
                $payment_data['payment_plan_id'] = 2;
                $payment_data['rest'] = 0;
            }
            $payment_data['lead_type'] = $lead->type;
            $check_payment->update($payment_data);
            SubPayment::where('lead_payment_id',$check_payment->id)->delete();
            
            if($request->total_amount > $request->paid){
                $deposit = new SubPayment;
                $deposit->create([
                    'lead_payment_id' => $check_payment->id,
                    'amount' => $request->paid,
                    'employee_id' => auth()->user()->id,
                    'payment_method_id' => 1,
                    'branch_id' => $lead->branch_id,
                    'due_date' => date('Y-m-d'),
                    'paid' => 1,
                ]);
                
                $sub_payment = new SubPayment;
                $sub_payment->create([
                    'lead_payment_id' => $check_payment->id,
                    'amount' => ($request->total_amount - $request->paid),
                    'employee_id' => auth()->user()->id,
                    'branch_id' => $lead->branch_id,
                    'due_date' => date('Y-m-d',strtotime('+ 7 days')),
                    'paid' => 0,
                ]);
            }
        }else{
            $payment = new LeadPayment;
            $payment_data = [
                'lead_id' => $lead->id,
                'amount' => $request->total_amount,
                'employee_id' => auth()->user()->id,
                'include_books' => ($request->books == 'yes')?'1':'0',
            ];
            if($request->total_amount > $request->paid){
                $payment_data['payment_plan_id'] = 3;
                $payment_data['rest'] = ($request->total_amount - $request->paid);
            }else{
                $payment_data['payment_plan_id'] = 2;
                $payment_data['rest'] = 0;
            }
             $payment_data['lead_type'] = $lead->type;
            $payment = $payment->create($payment_data);
            
            if($request->total_amount > $request->paid){
                $deposit = new SubPayment;
                $deposit->create([
                    'lead_payment_id' => $payment->id,
                    'amount' => $request->paid,
                    'employee_id' => auth()->user()->id,
                    'payment_method_id' => 1,
                    'branch_id' => $lead->branch_id,
                    'due_date' => date('Y-m-d'),
                    'paid' => 1,
                ]);
                
                $sub_payment = new SubPayment;
                $sub_payment->create([
                    'lead_payment_id' => $payment->id,
                    'amount' => ($request->total_amount - $request->paid),
                    'employee_id' => auth()->user()->id,
                    'branch_id' => $lead->branch_id,
                    'due_date' => date('Y-m-d',strtotime('+ 7 days')),
                    'paid' => 0,
                ]);
            }
        }
        
        activity('Lead')
        ->causedBy(Auth::user()->id)
        ->performedOn($lead)
        ->log('Old payment create');
        Flash::success('Lead updated successfully.');
        
        $redirect_url = route('admin.database.index').'?type=2';
        return redirect($redirect_url);
    }
     
    public function index(Request $request)
    {
        /** @var LeadPayment $leadPayments */
        $lead = Lead::find(request('customer'));

        $leadPayments = LeadPayment::where('lead_id', $lead->id)->withCount(['subPayments' => function ($query) {
            $query->where('paid', 0);
        }])->with('subPayments')->get();

        return view('lead_payments.index', compact('leadPayments', 'lead'));
    }
    
    public function paymentEmployee()
    {
        
    }

    /**
     * Show the form for creating a new LeadPayment.
     *
     * @return Response
     */
    public function getDetails(Request $request)
    {
        
        $paymentMethods = PaymentMethod::where('status', 1)->where('transfer', 1)->pluck('title', 'id');
        $service = null;
        $suggested_groups = [];
        $extraitem_groups = [];
        $amount = 0;
        $lead = Lead::find($request->customer);
        
        switch ($request->paymentable_type) {
            case 'App\\Models\\ExtraItem':
                $service = ExtraItem::find($request->paymentable_id);
                $amount = $service->price;

                if($lead->pt_level !== null && $lead->pt_level !== ''){
                    if(in_array($request->paymentable_id,[29,31,34,36,37])){
                        $extraitem_groups = $lead->groups;
                    }
                }

                break;

            case 'App\\Models\\Offer':
                $service = Offer::find($request->paymentable_id);

                $amount = $service->fees;

                $intervalsId = $service->intervals->pluck('id')->toArray();
                $disciplinesIds = $service->disciplines->pluck('id')->toArray();
                $timeframesId = $service->timeframes->pluck('id')->toArray();
                $level = StageLevel::where('value',$lead->pt_level)->/*whereIn('stage_id',$service->course->stages->pluck('id'))->*/first();
                //dd($level);
                if($lead->pt_level !== null && $lead->pt_level !== ''){
                    
                    $suggested_groups = Group::where('level_id', $level->id)
                        ->whereIn('discipline_id',$disciplinesIds)
                        ->whereIn('timeframe_id', $timeframesId)
                        ->whereIn('interval_id', $intervalsId)
                        ->whereHas('subRound',function($query){
                            $query->where('start_date','<=',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
                        })->get();
                    // $suggested_groups = [];
                }
                break;

            default:
                $service = ServiceFee::find($request->paymentable_id);

                $amount = $service->fees;

                $suggested_groups = Group::where('level_id', $lead->pt_level)
                    ->whereHas('subRound',function($query){
                        $query->where('start_date','<=',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
                    })->get();

                break;
        }

        $subPayments = [];
        $installment = $service->installment;
        $now = now();
        //dd($installment);
        
        $subPayments[0] = [
            'amount' => $installment ? $installment->deposit : $amount,
            'payment_date' => $now->format('Y-m-d'),
            'due_date' => $now->format('Y-m-d'),
            'paid' => 1,
            'branch_id' => $lead->branch_id,
            'employee_id' => auth()->id(),
        ];
        if ($installment) {
            $first_due_date = $this->calcDueDate($now, $installment->first_due_date);
            $subPayments[1] = [
                'amount' => $installment->first_payment,
                'due_date' => $first_due_date
            ];

            if ($installment->second_payment) {
                $second_due_date = $this->calcDueDate($now, $installment->second_due_date);
                $subPayments[2] = [
                    'amount' => $installment->second_payment,
                    'due_date' => $second_due_date
                ];
            }

            if ($installment->third_payment) {
                $third_due_date = $this->calcDueDate($now, $installment->third_due_date);
                $subPayments[3] = [
                    'amount' => $installment->third_payment,
                    'due_date' => $third_due_date
                ];
            }

            if ($installment->fourth_payment) {
                $fourth_due_date = $this->calcDueDate($now, $installment->fourth_due_date);
                $subPayments[4] = [
                    'amount' => $installment->fourth_payment,
                    'due_date' => $fourth_due_date
                ];
            }
        }
        
        $html = view('lead_payments.payment_details',compact('service','amount','subPayments','paymentMethods','suggested_groups','extraitem_groups'))->render();
        return response()->json(['html' => $html]);
    }
     
    public function create()
    {
        //$testProcess = round(microtime(true) * 1000);
        $paymentMethods = PaymentMethod::where('status', 1)->where('transfer', 1)->pluck('title', 'id');
        $lead = Lead::find(request('customer'));
        if($lead->f_name != null && $lead->f_name != '' &&
            $lead->m_name != null && $lead->m_name != '' &&
            $lead->l_name != null && $lead->l_name != '' &&
            //$lead->nationality != null && $lead->nationality != '' &&
            $lead->country != null && $lead->country != ''){
            //dd(round(microtime(true) * 1000) - $testProcess);
               
            $convertToCustomer = ($lead->type == 1)?1:0;
        
            $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
            $branchesData = $employeeBranches;
            $employee_id = auth()->id();
            $employeeBranches = $employeeBranches;
            $agents = Employee::where('status',1)->where('account_Type', 'Operations Account')->whereHas('branches', function ($query) use ($employeeBranches) {
                $query->whereIn('id', array_keys($employeeBranches));
            })->get()->pluck('name', 'id')->toArray();
            
            $extra_items = ExtraItem::all();
            //dd($extra_items);
            $branchesId = array_keys($employeeBranches);
                //dd($branchesId);
            $no_levels_offers = Offer::whereDate('start_date', '<=', now())->whereDate('end_date', '>=', now())
                ->whereHas('branches', function ($query) use ($branchesId) {
                    $query->whereIn('id', $branchesId);
                })->where('has_levels',0)->get();
                
            $offers = $no_levels_offers;
            if ($lead->pt_level !== null && $lead->pt_level !== '') {
                $levels_offers = Offer::whereDate('start_date', '<=', now())->whereDate('end_date', '>=', now())
                        ->whereHas('branches', function ($query) use ($branchesId) {
                            $query->whereIn('id', $branchesId);
                        })->where('has_levels',1)->whereHas('services.trainingService.levels', function ($query) use($lead){
                            $query->where('value', $lead->pt_level);
                        })->get();
                //dd($levels_offers);
                $offers = $no_levels_offers->merge($levels_offers);
            }
            
            if($lead->pt_level !== '' && $lead->pt_level !== null){
                $serviceQuery = ServiceFee::with('trainingService');
                
                $serviceQuery->whereHas('trainingService.levels', function ($query) use($lead){
                    $query->where('value', $lead->pt_level);
                });
                $services = $serviceQuery->with('trainingService')->get();
            }else{
                $services = collect();
            }
            
            return view('lead_payments.create', compact('paymentMethods','extra_items','offers','services','lead','convertToCustomer','branchesData','employee_id','employeeBranches','agents'));
        }else{
            $url = 'leads/'.$lead->id.'/edit?flag=payment';
            //return redirect(route('admin.leads.edit',$lead->id));
            return redirect($url);
        }
        
    }
    
    public function _store(CreateLeadPaymentRequest $request)
    {
        //dd($request->all());
        $lead = Lead::find($request->lead_id);
        if ($request->payment_method_id == 1) {
            $safe = Safe::where('employee_id', $request->employee_id)->where('payment_method_id',1)
                ->where('is_manager',0)->where('is_hq', 0)->where('status',1)->first();
            if (!$safe) {
                Flash::error('Employee doesn\'t have safe.');
                return redirect()->back();
            }else{
                if($safe->branch_id != $lead->branch_id){
                    Flash::error('customer in another branch, transfer it first.');
                    return redirect()->back();
                }
            }
        } else {
            $safe = Safe::where('payment_method_id',$request->payment_method_id)->where('status',1)->first();
            /*
            $senderSafe = Safe::where('employee_id', $request->employee_id)->where('branch_id', $lead->branch_id)
                ->whereNull('is_manager')->where('is_hq', 0)->first();
            */
            if (!$safe) {
                Flash::error('No safe found for this payment method.');
                return redirect()->back();
            }
            /*
            if (!$senderSafe) {
                Flash::error('Employee doesn\'t have safe.');
                return redirect()->back();
            }*/
        }
        
        $invoice_data = $request->only('lead_id','branch_id','employee_id','total_price','total_discount','payment_method_id','reference_num');
        
        if($request->hasFile('upload_bill') ){
            $file = $request->file('upload_bill');
            
            $file_name = rand(11111,99999).'-'.$file->getClientOriginalName();
            $file->storeAs('/uploads/lead_payments_bills', $file_name);
            $invoice_data['upload_bill'] = $file_name;
            
            File::move(storage_path('app/uploads/lead_payments_bills/'.$file_name), '/home/harvestc/public_html/uploads/lead_payments_bills/'.$file_name);
            
        }
        $invoice = Invoice::create($invoice_data);
        
        if($request->items_ids != null && count($request->items_ids) > 0){
            foreach($request->items_ids as $item_id){
                if($item_id != null && $item_id != ''){
                    $extra_item = ExtraItem::find($item_id);
                    $extra_item_amount = $extra_item->price;
                
                    $lead_payment_data = $request->only('branch_id','lead_id','employee_id');
                    $lead_payment_data['invoice_id'] = $invoice->id;
                    $lead_payment_data['lead_type'] = $lead->type;
                    $lead_payment_data['paymentable_type'] = 'App\Models\ExtraItem';
                    $lead_payment_data['paymentable_id'] = $extra_item->id;
                    //$lead_payment_data['upload_bill'] = $invoice->upload_bill;
                    $lead_payment_data['amount'] = $extra_item_amount;
                    $lead_payment_data['discount'] = 0;
                    $lead_payment_data['payment_plan_id'] = 2;
                    $lead_payment_data['platform'] = 'admin';
                    $lead_payment_data['payment_method_id'] = $request->payment_method_id;
                    $lead_payment_data['reference_num'] = (($request->reference_num != null && $request->reference_num != '')?$request->reference_num:null);
                    $lead_payment_data['upload_bill'] = $invoice->upload_bill;
        
                    $lead_payment = LeadPayment::create($lead_payment_data);
                    
                    $paid = $extra_item_amount;
                    $safe->increment('balance', $paid);
                    // add safe_aoperation 
                    $safe_operation = new SafeOperation;
                    $safe_operation->safe_id = $safe->id;
                    $safe_operation->operation_type = 'income';
                    $safe_operation->amount = $paid;
                    $safe_operation->source = 'new_payment';
                    $safe_operation->save();
                
                    if(in_array($item_id,[2,3]) ){
                        $request_data = [
                            'name' => $lead->getName(),
                            'email' => $lead->email,
                            'phone' => $lead->mobile_1,
                            
                            'certificate_id' => $item_id,
                            'invoice_id' => $lead_payment->id,
                        ];
                        $certificate_request = CertificateRequest::create($request_data);
                    
                        $req_data = [
                            'lead_id' => $lead->id,
                            'branch_id' => $lead->branch_id,
                            'label_type_id' => 39,
                            'customer_notes' => 'cretificate request',
                            'type' => 4,
                            'status' => 0,
                            'follow_up_type' => 3,
                            'serial' => time(),
                        ];
                        //operation inquiry 
                        $leadCase = LeadCase::create($req_data);
                        /*$lastcase = $lead->lastcase;
                        if($lastcase){
                           $lastcase->update($req_data);
                        }else{
                           $lastcase = LeadLastCase::create($req_data);
                        }*/
                    }
                }
            }
        }
        
        if($request->offer_id != null && $request->offer_id != ''){
            
            if ($request->convertToCustomer == 1) {
                if($lead->trans_customer == null){
                    $lead->trans_customer= date('Y-m-d h:i:sa');
                    $lead->save();
                }
                $lead->customer_type = "sales";

                $lead->type = 2;
                $lead->save();
                 
                // PlacementApplicant::where('mobile', $lead->mobile_1)->delete();
            }
            
            $offer = Offer::with('services.trainingService.levels', 'timeframes', 'intervals')->find($request->offer_id);
            $offer_amount = $offer->fees;
            
            $lead_payment_data = $request->only('branch_id','lead_id','employee_id');
            $lead_payment_data['invoice_id'] = $invoice->id;
            $lead_payment_data['lead_type'] = $lead->type;
            $lead_payment_data['paymentable_type'] = 'App\Models\Offer';
            $lead_payment_data['paymentable_id'] = $offer->id;
            //$lead_payment_data['upload_bill'] = $invoice->upload_bill;
            $lead_payment_data['amount'] = $request->offer_amount;
            $lead_payment_data['discount'] = $request->offer_discount;
            $lead_payment_data['payment_plan_id'] = $offer->payment_plan_id;
            $lead_payment_data['platform'] = 'admin';
            
            $lead_payment = LeadPayment::create($lead_payment_data);
            if($offer->payment_plan_id == 1 || $offer->payment_plan_id == 3){
                $offer_subPayments = $request->offer_subPayments;
                //dd($subPayments);
                $paid = 0;
                $discount = $lead_payment->discount ?? 0;
                foreach ($offer_subPayments as $key => $subPayment) {
                    if ($key === 0) {
                        $paid = ($request->offer_discount)?($subPayment['amount'] - $request->offer_discount):$subPayment['amount'];
                        $subPayment['paid'] = 1;
                        $subPayment['payment_method_id'] = $request->payment_method_id;
                        $subPayment['reference_num'] = (($request->reference_num != null && $request->reference_num != '')?$request->reference_num:null);
                        $subPayment['upload_bill'] = $invoice->upload_bill;
                        $subPayment['payment_date'] = date('Y-m-d');
                        $subPayment['branch_id'] = $lead_payment->branch_id;
                        $subPayment['employee_id'] = Auth::user()->id;
                    }
                    if ($key === 1 && $offer->payment_plan_id == 3){
                        $subPayment['amount'] = $lead_payment->amount - $discount - $paid;
                    }
                    if($subPayment['amount'] > 0){
                        $lead_payment->subPayments()->create($subPayment);
                    }
                }
                
                $rest = $lead_payment->amount - $discount - $paid;
                $rest = $rest < 0 ? 0 : $rest;
                $lead_payment->update(['rest' => $rest]);
            }else{
                $paid = $lead_payment->amount;
                
                $lead_payment->update([
                    'payment_method_id' => $request->payment_method_id,
                    'reference_num' => (($request->reference_num != null && $request->reference_num != '')?$request->reference_num:null),
                    'upload_bill' => $invoice->upload_bill
                ]);
                
            }
            
            $safe->increment('balance', $paid);
            // add safe_aoperation 
            $safe_operation = new SafeOperation;
            $safe_operation->safe_id = $safe->id;
            $safe_operation->operation_type = 'income';
            $safe_operation->amount = $paid;
            $safe_operation->source = 'new_payment';
            $safe_operation->save();
            
            $servicesFee = $offer->services;
            //dd($offer);
            if($offer->has_levels == 1 && $servicesFee != null && count($servicesFee) > 0){
                foreach ($servicesFee as $service){
                    $trainingService = $service->trainingService;
                    $trackId = $trainingService->track_id;
                    $courseId = $trainingService->course_id;
                    $levelId = $trainingService->levels[0]->id;
                    $levelsCount = $trainingService->levels->count();
                    $groupLevel = $trainingService->levels[0];
    
                    $customerTrack = CustomerTrack::where('lead_id',$lead->id)->where('course_id', $courseId)->first();
    
                    if ($customerTrack) {
                        $customerTrack->increment('total', $levelsCount);
                    } else {
                        $customerTrack = CustomerTrack::create([
                            'lead_id' => $lead->id,
                            'track_id' => $trackId,
                            'course_id' => $courseId,
                            'level_id' => $levelId,
                            'total' => $levelsCount,
                            'used' => 0,
                        ]);
                    }
                }
                
                $timeframesString = implode(',', $offer->timeframes->pluck('id')->toArray());
                $intervalsString = implode(',', $offer->intervals->pluck('id')->toArray());
                $disciplinesIds = DB::table('offer_disciplines')->where('offer_id',$offer->id)->pluck('discipline_id')->toArray();
                GroupWaitingList::create([
                    'lead_id' => $lead->id,
                    'level_id' => $groupLevel->id,
                    'timeframes' => $timeframesString,
                    //'intervals' => $intervalsString,
                    'lead_payment_id' => $lead_payment->id,
                    'discipline_id' => ($disciplinesIds != null && count($disciplinesIds) > 0)?$disciplinesIds[0]:null
                ]);
    
            }elseif($offer->has_levels == 0 && $offer->num_levels > 0 && $lead->pt_level !== '' && $lead->pt_level !== null){
                $course = $offer->course;
                if($lead->groups != null && count($lead->groups) > 0){
                    $last_level = $lead->groups->sortByDesc('level_id')->first();
                    
                    $stage_levels = StageLevel::leftJoin('stages','stages.id','=','stage_levels.stage_id')->where('stages.track_id',$offer->course_id)->where('stage_levels.value','>=',$last_level->level->value)->take($offer->num_levels)->pluck('stage_levels.id')->toArray();
                }else{
                    $stage_levels = StageLevel::leftJoin('stages','stages.id','=','stage_levels.stage_id')->where('stages.track_id',$offer->course_id)->where('stage_levels.value','>=',$lead->pt_level)->take($offer->num_levels)->pluck('stage_levels.id')->toArray();
                }
                $customerTrack = CustomerTrack::where('lead_id',$lead->id)->where('track_id',$offer->track_id)->where('course_id',$offer->course_id)->first();
                $groupLevel = StageLevel::find($stage_levels[0]);
                //dd($stage_levels);
                if ($customerTrack){
                    $customerTrack->increment('total', $offer->num_levels); 
                }else{
                    $customerTrack = CustomerTrack::create([
                        'lead_id' => $lead->id,
                        'track_id' => $offer->track_id,
                        'course_id' => $offer->course_id,
                        'level_id' => $stage_levels[0],
                        'total' => $offer->num_levels,
                        'used' => 0,
                    ]);
                }
                
                $timeframesString = implode(',', $offer->timeframes->pluck('id')->toArray());
                $intervalsString = implode(',', $offer->intervals->pluck('id')->toArray());
                $disciplinesIds = DB::table('offer_disciplines')->where('offer_id',$offer->id)->pluck('discipline_id')->toArray();
                GroupWaitingList::create([
                    'lead_id' => $lead->id,
                    'level_id' => $stage_levels[0],
                    'timeframes' => $timeframesString,
                    //'intervals' => $intervalsString,
                    'lead_payment_id' => $lead_payment->id,
                    'discipline_id' => ($disciplinesIds != null && count($disciplinesIds) > 0)?$disciplinesIds[0]:null
                ]);
            }else{
                
            }
            
            
        }
        
        if($request->service_id != null && $request->service_id != ''){
            
            if ($request->convertToCustomer == 1) {
                if($lead->trans_customer == null){
                    $lead->trans_customer= date('Y-m-d h:i:sa');
                    $lead->save();
                }
                $lead->customer_type = "sales";

                $lead->type = 2;
                $lead->save();
                 
                // PlacementApplicant::where('mobile', $lead->mobile_1)->delete();
            }
            
            $service = ServiceFee::find($request->service_id);
            $service_amount = $service->fees;
            
            $lead_payment_data = $request->only('branch_id','lead_id','employee_id');
            $lead_payment_data['invoice_id'] = $invoice->id;
            $lead_payment_data['lead_type'] = $lead->type;
            $lead_payment_data['paymentable_type'] = 'App\Models\ServiceFee';
            $lead_payment_data['paymentable_id'] = $service->id;
            //$lead_payment_data['upload_bill'] = $invoice->upload_bill;
            $lead_payment_data['amount'] = $request->service_amount;
            $lead_payment_data['discount'] = $request->service_discount;
            $lead_payment_data['payment_plan_id'] = $service->payment_plan_id;
            $lead_payment_data['platform'] = 'admin';
            
            $lead_payment = LeadPayment::create($lead_payment_data);
            if($service->payment_plan_id == 1 || $service->payment_plan_id == 3){
                $service_subPayments = $request->service_subPayments;
                //dd($subPayments);
                $paid = 0;
                $discount = $lead_payment->discount ?? 0;
                foreach ($service_subPayments as $key => $subPayment) {
                    if ($key === 0) {
                        $paid = ($request->service_discount)?($subPayment['amount'] - $request->service_discount):$subPayment['amount'];
                        $subPayment['paid'] = 1;
                        $subPayment['payment_method_id'] = $request->payment_method_id;
                        $subPayment['reference_num'] = (($request->reference_num != null && $request->reference_num != '')?$request->reference_num:null);
                        $subPayment['upload_bill'] = $invoice->upload_bill;
                        $subPayment['payment_date'] = date('Y-m-d');
                        $subPayment['branch_id'] = $lead_payment->branch_id;
                        $subPayment['employee_id'] = Auth::user()->id;
                    }
                    if ($key === 1 && $service->payment_plan_id == 3){
                        $subPayment['amount'] = $lead_payment->amount - $discount - $paid;
                    }
                    if($subPayment['amount'] > 0){
                        $lead_payment->subPayments()->create($subPayment);
                    }
                }
                
                $rest = $lead_payment->amount - $discount - $paid;
                $rest = $rest < 0 ? 0 : $rest;
                $lead_payment->update(['rest' => $rest]);
            }else{
                $paid = $lead_payment->amount;
                
                $lead_payment->update([
                    'payment_method_id' => $request->payment_method_id,
                    'reference_num' => (($request->reference_num != null && $request->reference_num != '')?$request->reference_num:null),
                    'upload_bill' => $invoice->upload_bill
                ]);
                
            }
            
            $safe->increment('balance', $paid);
            // add safe_aoperation 
            $safe_operation = new SafeOperation;
            $safe_operation->safe_id = $safe->id;
            $safe_operation->operation_type = 'income';
            $safe_operation->amount = $paid;
            $safe_operation->source = 'new_payment';
            $safe_operation->save();
            
            $trainingService = $service->trainingService;
            $trackId = $trainingService->track_id;
            $courseId = $trainingService->course_id;
            $levelId = $trainingService->levels[0]->id;
            $levelsCount = $trainingService->levels->count();
            $groupLevel = $trainingService->levels[0];

            $customerTrack = CustomerTrack::where('lead_id',$lead->id)->where('course_id', $courseId)->first();

            if ($customerTrack){
                $customerTrack->increment('total', $levelsCount);
            }else{
                $customerTrack = CustomerTrack::create([
                    'lead_id' => $lead->id,
                    'track_id' => $trackId,
                    'course_id' => $courseId,
                    'level_id' => $levelId,
                    'total' => $levelsCount,
                    'used' => 0,
                ]);
            }
            
            if($lead->type == 2){
                GroupWaitingList::where('lead_id',$lead->id)->delete();
                
                GroupWaitingList::create([
                    'lead_id' => $lead->id,
                    'level_id' => $groupLevel->id,
                    'lead_payment_id' => $lead_payment->id,
                    'discipline_id' => 1
                ]);
            }
        }
        
        Flash::success('Lead Payment saved successfully.');
        
        //dd($request->all());
        //return redirect(route('admin.leadPayments.show', $payment->id));
    }
    
    public function store(CreateLeadPaymentRequest $request)
    {
        $data = $request->all();
        $lead = Lead::find($request->lead_id);
        $service = null;
        switch ($request->paymentable_type) {
            case 'App\\Models\\ExtraItem':
                $service = ExtraItem::find($request->paymentable_id);
                $amount = $service->price;

                break;

            case 'App\\Models\\Offer':
                $service = Offer::find($request->paymentable_id);
                $amount = $service->fees;

                break;

            default:
                $service = ServiceFee::find($request->paymentable_id);
                $amount = $service->fees;

                break;
        }

        if ($data['subPayments'][0]['payment_method_id'] == 1) {
            $safe = Safe::where('employee_id', $request->employee_id)->where('payment_method_id',1)
                ->where('is_manager',0)->where('is_hq', 0)->where('status',1)->first();
            if (!$safe) {
                Flash::error('Employee doesn\'t have safe.');
                return redirect()->back();
            }else{
                if($safe->branch_id != $lead->branch_id){
                    Flash::error('customer in another branch, transfer it first.');
                    return redirect()->back();
                }
            }
        } else {
            $safe = Safe::where('payment_method_id',$data['subPayments'][0]['payment_method_id'])->where('status',1)->first();
            /*
            $senderSafe = Safe::where('employee_id', $request->employee_id)->where('branch_id', $lead->branch_id)
                ->whereNull('is_manager')->where('is_hq', 0)->first();
            */
            if (!$safe) {
                Flash::error('No safe found for this payment method.');
                return redirect()->back();
            }
            /*
            if (!$senderSafe) {
                Flash::error('Employee doesn\'t have safe.');
                return redirect()->back();
            }*/
        }
        if($service->duration != null)
        {
            //$data['branch_id'] = $lead->branch_id;
            $data['expire_date'] = date('Y-m-d', strtotime(' + '.$service->duration.' months'));
        }
 
        $data['payment_plan_id'] = $service->payment_plan_id;
        if($data['paymentable_type'] == 'App\\Models\\Offer'){
            //dd($service);
            $data['include_books'] = $service->include_books;
        }
        $payment = LeadPayment::create($data);
        
        if($service->payment_plan_id == 1 || $service->payment_plan_id == 3){
            $subPayments = $data['subPayments'];
            //dd($subPayments);
            $paid = 0;
            $discount = $payment->discount ?? 0;
            foreach ($subPayments as $key => $subPayment) {
                if ($key === 0) {
                    $paid = ($request->discount)?$subPayment['amount'] - $request->discount:$subPayment['amount'];
                    $subPayment['paid'] = 1;
                    $subPayment['payment_date'] = date('Y-m-d');
                    $subPayment['branch_id'] = $payment->branch_id;
                    $subPayment['employee_id'] = Auth::user()->id;
                }
                if ($key === 1 && $service->payment_plan_id == 3){
                    $subPayment['amount'] = $payment->amount - $discount - $paid;
                }
                if($subPayment['amount'] > 0){
                    if(isset($subPayments[$key]['upload_bill']) && $subPayments[$key]['upload_bill'] != null && $subPayments[$key]['upload_bill'] != ''){
                        $file = $subPayments[$key]['upload_bill']->store('/');
                        $subPayment['upload_bill'] = $file;
                        if (env('APP_ENV') == 'production') {
                            rename(storage_path('app/' . $file), '/home/harvestc/public_html/uploads/lead_payments_bills/' . $file);
                        } else {
                            rename(storage_path('app/' . $file), public_path('uploads/' . $file));
                        }
                    }
                    
                    $payment->subPayments()->create($subPayment);
                }
            }
            
            $rest = $payment->amount - $discount - $paid;
            $rest = $rest < 0 ? 0 : $rest;
            $payment->update(['rest' => $rest]);
        }else{
            $paid = $payment->amount;
            $file_name = null;
            if(isset($data['subPayments'][0]['upload_bill']) && $data['subPayments'][0]['upload_bill'] != null && $data['subPayments'][0]['upload_bill'] != ''){
                $file = $request->subPayments[0]['upload_bill']->store('/');
                $file_name = $file;
                if (env('APP_ENV') == 'production') {
                    rename(storage_path('app/' . $file), '/home/harvestc/public_html/uploads/lead_payments_bills/' . $file);
                } else {
                    rename(storage_path('app/' . $file), public_path('uploads/' . $file));
                }
            }
            $payment->update([
                'payment_method_id' => $data['subPayments'][0]['payment_method_id'],
                'reference_num' => ((isset($data['subPayments'][0]['reference_num']))?$data['subPayments'][0]['reference_num']:''),
                'upload_bill' => $file_name
            ]);
            
        }
        // add to safe
        $safe->increment('balance', $paid);
        // add safe_aoperation 
        $safe_operation = new SafeOperation;
        $safe_operation->safe_id = $safe->id;
        $safe_operation->operation_type = 'income';
        $safe_operation->amount = $paid;
        $safe_operation->source = 'new_payment';
        $safe_operation->save();
        
        /*
        if ($safe->is_hq){
            
            SafeTrancation::create([
                'sender' => auth()->id(),
                'receiver' => $safe->employee_id,
                'safe_sender' => $senderSafe->id,
                'safe_receiver' => $safe->id,
                'amount' => $paid,
                //'description' => ,
                'payment_methods_id' => $data['subPayments'][0]['payment_method_id'],
                'status' => 'approve',
            ]);
        }
        */
        $msg = "Your purchase was successful. Invoice Number:" . $payment->id;
        
        $groupLevel = null;
        if ($payment->paymentable_type == 'App\\Models\\ServiceFee') {
            if ($request->convertToCustomer == 1) {
                $lead->update(['type' => 2 , 'customer_type'=>'sales']);
                // PlacementApplicant::where('mobile', $lead->mobile_1)->delete();
            }

            $trainingService = ServiceFee::with('trainingService.levels')->find($payment->paymentable_id)->trainingService;
            $trackId = $trainingService->track_id;
            $courseId = $trainingService->course_id;
            $levelId = $trainingService->levels[0]->id;
            $levelsCount = $trainingService->levels->count();
            $groupLevel = $trainingService->levels[0];

            $customerTrack = CustomerTrack::where('lead_id',$lead->id)->where('course_id', $courseId)->first();

            if ($customerTrack){
                $customerTrack->increment('total', $levelsCount);
            }else{
                $customerTrack = CustomerTrack::create([
                    'lead_id' => $lead->id,
                    'track_id' => $trackId,
                    'course_id' => $courseId,
                    'level_id' => $levelId,
                    'total' => $levelsCount,
                    'used' => $request->group_id ? 1 : 0,
                ]);
            }

            if (!$request->group_id) {
                GroupWaitingList::create([
                    'lead_id' => $lead->id,
                    'level_id' => $groupLevel->id,
                    'lead_payment_id' => $payment->id,
                    'discipline_id' => 1
                ]);
            }
        } elseif ($payment->paymentable_type == 'App\\Models\\Offer') {
            if ($request->convertToCustomer) {
                $lead->update(['type' => 2 , 'customer_type'=>'sales']);
                // PlacementApplicant::where('mobile', $lead->mobile_1)->delete();
            }
            
            $offer = Offer::with('services.trainingService.levels', 'timeframes', 'intervals')->find($payment->paymentable_id);
            $servicesFee = $offer->services;
            //dd($offer);
            if($offer->has_levels == 1 && $servicesFee != null && count($servicesFee) > 0){
                foreach ($servicesFee as $service){
                    $trainingService = $service->trainingService;
                    $trackId = $trainingService->track_id;
                    $courseId = $trainingService->course_id;
                    $levelId = $trainingService->levels[0]->id;
                    $levelsCount = $trainingService->levels->count();
                    $groupLevel = $trainingService->levels[0];
    
                    $customerTrack = CustomerTrack::where('lead_id',$lead->id)->where('course_id', $courseId)->first();
    
                    if ($customerTrack) {
                        $customerTrack->increment('total', $levelsCount);
                    } else {
                        $customerTrack = CustomerTrack::create([
                            'lead_id' => $lead->id,
                            'track_id' => $trackId,
                            'course_id' => $courseId,
                            'level_id' => $levelId,
                            'total' => $levelsCount,
                            'used' => $request->group_id ? 1 : 0,
                        ]);
                    }
                }
    
                if(!$request->group_id){
                    $timeframesString = implode(',', $offer->timeframes->pluck('id')->toArray());
                    $intervalsString = implode(',', $offer->intervals->pluck('id')->toArray());
                    $disciplinesIds = DB::table('offer_disciplines')->where('offer_id',$offer->id)->pluck('discipline_id')->toArray();
                    GroupWaitingList::create([
                        'lead_id' => $lead->id,
                        'level_id' => $groupLevel->id,
                        'timeframes' => $timeframesString,
                        'intervals' => $intervalsString,
                        'lead_payment_id' => $payment->id,
                        'discipline_id' => ($disciplinesIds != null && count($disciplinesIds) > 0)?$disciplinesIds[0]:null
                    ]);
                }
            }elseif($offer->has_levels == 0 && $offer->num_levels > 0 && $lead->pt_level !== '' && $lead->pt_level !== null){
                $course = $offer->course;
                if($lead->groups != null && count($lead->groups) > 0){
                    $last_level = $lead->groups->sortByDesc('level_id')->first();
                    
                    $stage_levels = StageLevel::leftJoin('stages','stages.id','=','stage_levels.stage_id')->where('stages.track_id',$offer->course_id)->where('stage_levels.value','>=',$last_level->level->value)->take($offer->num_levels)->pluck('stage_levels.id')->toArray();
                }else{
                    $stage_levels = StageLevel::leftJoin('stages','stages.id','=','stage_levels.stage_id')->where('stages.track_id',$offer->course_id)->where('stage_levels.value','>=',$lead->pt_level)->take($offer->num_levels)->pluck('stage_levels.id')->toArray();
                }
                $customerTrack = CustomerTrack::where('lead_id',$lead->id)->where('track_id',$offer->track_id)->where('course_id',$offer->course_id)->first();
                $groupLevel = StageLevel::find($stage_levels[0]);
                //dd($stage_levels);
                if ($customerTrack){
                    $customerTrack->increment('total', $offer->num_levels); 
                }else{
                    $customerTrack = CustomerTrack::create([
                        'lead_id' => $lead->id,
                        'track_id' => $offer->track_id,
                        'course_id' => $offer->course_id,
                        'level_id' => $stage_levels[0],
                        'total' => $offer->num_levels,
                        'used' => 0,
                    ]);
                }
                
                if(!$request->group_id){
                    //dd($stage_levels,$training_service_levels,$total,$training_services->pluck('id'));
                    $timeframesString = implode(',', $offer->timeframes->pluck('id')->toArray());
                    $intervalsString = implode(',', $offer->intervals->pluck('id')->toArray());
                    $disciplinesIds = DB::table('offer_disciplines')->where('offer_id',$offer->id)->pluck('discipline_id')->toArray();
                    GroupWaitingList::create([
                        'lead_id' => $lead->id,
                        'level_id' => $stage_levels[0],
                        'timeframes' => $timeframesString,
                        'intervals' => $intervalsString,
                        'lead_payment_id' => $payment->id,
                        'discipline_id' => ($disciplinesIds != null && count($disciplinesIds) > 0)?$disciplinesIds[0]:null
                    ]);
                }
            }else{
                
            }
        }
         elseif ($payment->paymentable_type == 'App\\Models\\ExtraItem') {
           if(in_array($payment->paymentable_id,[2,3]) ){
                $request_data = [
                    'name' => $lead->getName(),
                    'email' => $lead->email,
                    'phone' => $lead->mobile_1,
                    
                    'certificate_id' => $payment->paymentable_id,
                    'invoice_id' => $payment->id,
                ];
                $certificate_request = CertificateRequest::create($request_data);
            
               $req_data = [
                'lead_id' => $lead->id,
                'branch_id' => $lead->branch_id,
                'label_type_id' => 39,
                'customer_notes' => 'cretificate request',
                'type' => 4,
                'status' => 0,
                'follow_up_type' => 3,
                'serial' => time(),
               ];
               //operation inquiry 
               $leadCase = LeadCase::create($req_data);
               $lastcase = $lead->lastcase;
               if($lastcase){
                   $lastcase->update($req_data);
               }else{
                   $lastcase = LeadLastCase::create($req_data);
               }
           }
        }

        if ($request->group_id) {
            //dd($groupLevel);
            $group = Group::find($request->group_id);
            $lead->groups()->attach($request->group_id, [
                'level_id' => $group->level_id,
                'payment' => $payment->payment_plan_id == 1 ? 0 : 1,
                'lead_payment_id' => $payment->id
            ]);

            $lead->update(['type' => 3]);

            $sessions = GroupSession::with('level')->where('group_id', $request->group_id)->get();
            foreach ($sessions as $session){
                $session->attendances()->create([
                    'lead_id' => $lead->id,
                    'group_id' => $session->group_id,
                    'level_id' => $session->level_id,
                ]);
            }
            $msg .= ". You had been assigned to new group. Group Number:" . $request->group_id;
        }

        if ($lead->email) {
            $payment->load('lead', 'paymentPlan', 'subPayments', 'paymentable');
            try{
                Mail::to($lead->email)->send(new PaymentInvoice($payment));
            }catch(Exception $e){
                
            }
        }

        // $sms = new SMS;
        // $mobile = $lead->mobile_1;
        // $sms->send($mobile, $msg);

        // $log = MessageLog::create([
        //     'type' => 1,
        //     'content' => $msg
        // ]);
        // $log->leads()->sync($lead->id);

        Flash::success('Lead Payment saved successfully.');

        return redirect(route('admin.leadPayments.show', $payment->id));
        
    }
    
    public function calcDueDate($date, $after)
    {
        if ($after > 12) {
            return $date->addWeeks($after == 13 ? 1 : 2)->format('Y-m-d');
        } else {
            return $date->addMonths($after)->format('Y-m-d');
        }
    }


    /**
     * Display the specified LeadPayment.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var LeadPayment $leadPayment */
        $leadPayment = LeadPayment::with(['lead', 'paymentPlan', 'subPayments', 'paymentable' => function (MorphTo $morphTo) {
            $morphTo->morphWith([
                'App\\Models\\Offer' => ['services.trainingService', 'items'],
                'App\\Models\\ExtraItem' => ['itemCategory'],
            ]);
        }])->find($id);

        if (empty($leadPayment)) {
            Flash::error('Lead Payment not found');

            return redirect(route('admin.leadPayments.index'));
        }

        $leadPayment->increment('print_count');

        return view('lead_payments.show')->with('leadPayment', $leadPayment);
    }

    /**
     * Show the form for editing the specified LeadPayment.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var LeadPayment $leadPayment */
        $leadPayment = LeadPayment::find($id);
        if (empty($leadPayment)) {
            Flash::error('Lead Payment not found');

            return redirect(route('admin.leadPayments.index'));
        }
        $lead = Lead::find($leadPayment->lead_id);
        
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $employee_id = auth()->id();

        $paymentable_type = ($leadPayment->paymentable_type)?$leadPayment->paymentable_type:null;
        $service = ($leadPayment->paymentable_type && $leadPayment->paymentable_id)?$leadPayment->paymentable:null;
        $installments = $leadPayment->subPayments()->with('payment_method')->get();
        $paymentMethods = PaymentMethod::where('status', 1)->where('transfer', 1)->pluck('title', 'id');
        //dd($paymentMethods);
        $subPayments = [];
        $employee_id = auth()->id();
        if($leadPayment->payment_plan_id == 3 || $leadPayment->payment_plan_id == 1){
            
            $subPayments = $leadPayment->subPayments()->select('id','amount','payment_method_id','reference_num','upload_bill','payment_status','merchantRefNumber')->where('paid',0)->get();
            $array = [];
            foreach($subPayments as $subPayment){
                if($subPayment->merchantRefNumber != null && $subPayment->merchantRefNumber != ''){
                    $array[$subPayment->id] = [
                        'payment_status' => $subPayment->payment_status,
                        'amount' => $subPayment->amount,
                        'payment_method_id' => $subPayment->payment_method_id,
                        'reference_num' => $subPayment->reference_num,
                        'upload_bill' => $subPayment->upload_bill.'',
                    ];
                }else{
                    $array[$subPayment->id] = ['amount' => $subPayment->amount];
                }
                break;
            }
            $subPayments = $array;
        }
        
        return view('lead_payments.edit', compact('leadPayment', 'lead','paymentable_type','employeeBranches','service','installments','paymentMethods','employee_id','subPayments'));
    }
    
    public function update($id,UpdateLeadPaymentRequest $request)
    {
        $leadPayment = LeadPayment::find($id);
        $employee_id = auth()->id();
        $data = $request->all();
        $lead = Lead::find($leadPayment->lead_id);
        $subPayments = $data['subPayments'];
        //dd($subPayments);
        foreach ($subPayments as $sub_id => $subPayment) {

            if ($subPayment['payment_method_id'] == 1) {
                $safe = Safe::where('employee_id', $employee_id)->where('payment_method_id',1)
                    ->where('is_manager',0)->where('is_hq', 0)->where('status',1)->first();
                if (!$safe) {
                    Flash::error('Employee doesn\'t have safe.');
                    return redirect()->back();
                }else{
                    if($safe->branch_id != $lead->branch_id){
                        Flash::error('customer in another branch, transfer it first.');
                        return redirect()->back();
                    }
                }
            } else {
                $safe = Safe::where('payment_method_id',$subPayment['payment_method_id'])->where('status',1)->first();
                if (!$safe) {
                    Flash::error('No safe found for this payment method.');
                    return redirect()->back();
                }
            }
            if(isset($subPayment['payment_status']) && $subPayment['payment_status'] != null && $subPayment['payment_status'] != ''){
                if($subPayment['payment_status'] == 'ACCEPTED'){
                    $subPayment['paid'] = 1;
                }else{
                    $subPayment['paid'] = 0;
                }
            }else{
                $subPayment['paid'] = 1;
            }
            
            //$subPayment['branch_id'] = $lead->branch_id;
            $subPayment['employee_id'] = auth()->id();
            $subPayment['payment_date'] = date('Y-m-d');
            $subPayment['due_date'] = date('Y-m-d');
            $sub = SubPayment::find($sub_id);
            if($sub->amount > $subPayment['amount']){
                
                $new_amount = $sub->amount - $subPayment['amount'];
                //dd($new_amount);
                $new_subPayment = [
                    'lead_payment_id' => $sub->lead_payment_id,
                    'amount' => $new_amount,
                    'due_date' => date('Y-m-d',strtotime('+ 7 days')),
                    'paid' => 0
                ];
                
                SubPayment::create($new_subPayment);
            }
            
            if(isset($subPayments[$sub_id]['upload_bill']) && $subPayments[$sub_id]['upload_bill'] != null && $subPayments[$sub_id]['upload_bill'] != ''){
                $file = $subPayments[$sub_id]['upload_bill']->store('/');
                $subPayment['upload_bill'] = $file;
                if (env('APP_ENV') == 'production') {
                    rename(storage_path('app/' . $file), '/home/harvestc/public_html/uploads/lead_payments_bills/' . $file);
                } else {
                    rename(storage_path('app/' . $file), public_path('uploads/' . $file));
                }
            }
            
            $sub->update($subPayment);
            
            // add to safe
            $safe->increment('balance', $sub->amount);

            // add safe operation
            $safe_operation = new SafeOperation;
            $safe_operation->safe_id = $safe->id;
            $safe_operation->operation_type = 'income';
            $safe_operation->amount = $sub->amount;
            $safe_operation->source = 'old_payment';
            $safe_operation->save();

            /*
            if($safe->is_hq){
                $senderSafe = Safe::where('employee_id', auth()->id())->where('branch_id', $lead->branch_id)
                    ->whereNull('is_manager')->where('is_hq', 0)->first();
                SafeTrancation::create([
                    'sender' => auth()->id(),
                    'receiver' => $safe->employee_id,
                    'safe_sender' => $senderSafe->id,
                    'safe_receiver' => $safe->id,
                    'amount' => $sub->amount,
                    // 'description' => ,
                    'payment_methods_id' => $subPayment['payment_method_id'],
                    'status' => 'approve',
                ]);
            }
            */
        }

        $leadPayment = $leadPayment;
        $paid = $leadPayment->subPayments()->where('paid', 1)->sum('amount');
        $discount = $leadPayment->discount ?? 0;
        $rest = $leadPayment->amount - $discount - $paid;
        $rest = $rest < 0 ? 0 : $rest;
        $leadPayment->update(['rest' => $rest]);

        Flash::success('Lead Payment saved successfully.');

        return redirect(route('admin.leadPayments.index', ['customer' => $lead->id]));
    }

    /**
     * Remove the specified LeadPayment from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var LeadPayment $leadPayment */
        $leadPayment = LeadPayment::find($id);
        //dd($id);
        if (empty($leadPayment)) {
            Flash::error('Lead Payment not found');

            return redirect()->back();
        }
        
        if($leadPayment->subPayments != null && count($leadPayment->subPayments) > 0){
            foreach($leadPayment->subPayments as $sub_payment){
                if($sub_payment->payment_method_id != null && $sub_payment->payment_method_id != '' && $sub_payment->employee_id != '' && $sub_payment->employee_id != null){
                    if ($sub_payment->payment_method_id == 1) {
                        $safe = Safe::where('employee_id', $sub_payment->employee_id)->where('payment_method_id',1)
                            ->where('is_manager',0)->where('is_hq', 0)->where('status',1)->first();
                        
                    } else {
                        $safe = Safe::where('payment_method_id',$sub_payment->payment_method_id)->where('status',1)->first();
                    }
                    
                    if($safe != null && $safe != ''){
                        $safe->decrement('balance',$sub_payment->amount);
                        
                        $safe_operation = SafeOperation::where('safe_id',$safe->id)->where('operation_type','income')->where('amount',$sub_payment->amount)->first();
                        if($safe_operation != null && $safe_operation != ''){
                            $safe_operation->delete();
                        }
                    }
                }
                $sub_payment->delete();
            }
            
        }else{
            if($leadPayment->payment_method_id != null && $leadPayment->payment_method_id != '' && $leadPayment->employee_id != '' && $leadPayment->employee_id != null){
                if ($leadPayment->payment_method_id == 1){
                    $safe = Safe::where('employee_id', $leadPayment->employee_id)->where('payment_method_id',1)
                        ->where('is_manager',0)->where('is_hq', 0)->where('status',1)->first();
                    
                }else{
                    $safe = Safe::where('payment_method_id',$leadPayment->payment_method_id)->where('status',1)->first();
                }
                
                if($safe != null && $safe != ''){
                    $safe->decrement('balance',($leadPayment->amount - $leadPayment->discount));
                    
                    $safe_operation = SafeOperation::where('safe_id',$safe->id)->where('operation_type','income')->where('amount',$leadPayment->amount)->first()->delete();
                }
            }
        }
        $lead_id = $leadPayment->lead_id;
        
        activity('LeadPayment')
           ->causedBy(Auth::user()->id)
           ->performedOn($leadPayment)
      //   ->withProperties(['group_id' =>$group->id ])
           ->log('delete payment');
           
        $leadPayment->delete();
        $lead = Lead::find($lead_id);
        if($lead != null && $lead != '' && $lead->type == 2 && count($lead->payments) == 0){
            $lead->type = 1;
            $lead->save();
        }
        
        
        Flash::success('Lead Payment deleted successfully.');

        return redirect()->back();
    }

    public function paymentDiscount()
    {
        return redirect()->back();
    }
}
