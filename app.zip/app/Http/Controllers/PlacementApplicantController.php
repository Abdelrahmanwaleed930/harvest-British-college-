<?php

namespace App\Http\Controllers;

use Flash;
use Response;
use DB;
use App\Models\SMS;
use App\Models\MessageLog;
use Illuminate\Http\Request;
use App\Mail\PlacementTestResult;
use App\Models\PlacementApplicant;
use Illuminate\Support\Facades\Mail;
use App\Http\Controllers\AppBaseController;
use App\Http\Requests\CreatePlacementApplicantRequest;
use App\Http\Requests\UpdatePlacementApplicantRequest;
use App\Models\Lead;
use App\Models\LeadPayment;
use App\Models\Branch;
use App\Models\Track;
use App\Models\Employee;
use App\Models\LeadSource;
use App\Models\Offer;
use App\Models\TrainingService;
use App\Models\CustomerTrack;
use App\Models\LabelType;
use App\Models\StageLevel;
use App\Models\GroupWaitingList;
use Carbon\Carbon;

use App\Models\WhatsApp;
class PlacementApplicantController extends AppBaseController
{
    /**
     * Display a listing of the PlacementApplicant.
     *
     * @param Request $request
     *
     * @return Response
     */

     public function index(Request $request)
    {

        /** @var PlacementApplicant $placementApplicants */
        //$testProcess = round(microtime(true) * 1000);
               

        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        
        $employeeBranches = auth()->user()->branches->pluck('name','id')->toArray();
        $track = Track::findOrFail($request->get('track_id'));
        $courses = Track::where('parent_id',$track->id)->pluck('id');
        $instructors = Employee::where('account_Type','ESL Account Profile')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->get()->pluck('name','id')->toArray();
        $levels = StageLevel::whereHas('stage',function($query) use ($courses){
            $query->whereIn('track_id',$courses);
        })->orderBy('value')->pluck('name','value')->toArray();
        $registration_from = null;
        $registration_to = null;
        if ($request->has('registration_daterange') && $request->get('registration_daterange') != null && $request->get('registration_daterange') != '') {
            $daterange = explode(' - ',$request->get('registration_daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            // $registration_to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
        }
        
        $placementApplicantsQuery = PlacementApplicant::whereIn('branch_id', array_keys($employeeBranches));
        
        if ($request->has('search') && $request->get('search') != null && $request->get('search') != '') {
            //dd($request->get('search'));
            $placementApplicantsQuery->whereHas('lead',function($query) use ($request){
                $query->where('name', 'like', '%' . request('search') . '%')
                    ->orWhere('mobile_1', 'like', '%' . request('search') . '%')
                    ->orWhere('email', 'like', '%' . request('search') . '%');
            });
                
        }
        
        if ($request->has('status') && $request->get('status') != null && $request->get('status') != '') {
            //dd($request->get('status'));
            $placementApplicantsQuery->where('status', request('status'));
        }
       
        
        if ($request->has('finish') && $request->get('finish') !== null && $request->get('status') !== '') {
            
            $placementApplicantsQuery->where('finish', request('finish'));
        }
        if($request->has('type') && $request->get('type') != null && $request->get('type') != ''){
            $placementApplicantsQuery->whereHas('lead',function($query) use ($request){
                $query->where('type', $request->get('type'));
            });
        }
        if ($request->has('level') && $request->get('level') !== null && $request->get('level') !== '') {
            
            $placementApplicantsQuery->where('level', request('level'));
        }
        if ($request->has('has_level') && $request->get('has_level') !== null && $request->get('has_level') !== '') {
            if(request('has_level') == '1'){
              $placementApplicantsQuery->whereNotNull('level');
            }
            else{
                $placementApplicantsQuery->whereNull('level');
            }
             
        }
         $sources = LeadSource::whereNotIn('id', [1, 6, 12])->pluck('name', 'id')->toArray();

        if ($request->has('sources') && is_array($request->get('sources')) && count($request->get('sources')) > 0) {
            $placementApplicantsQuery->whereHas('lead', function ($query) use ($request) {
                $query->whereIn('lead_source_id', $request->get('sources'));
            });
        }

        if($request->has('instructor') && $request->get('instructor') != null && $request->get('instructor') != ''){
            //dd($request->get('instructor'));
            $placementApplicantsQuery->where('instructor_id', $request->get('instructor'));
        }
        if($request->has('track_id') && $request->get('track_id') != null && $request->get('track_id') != ''){
            
            $placementApplicantsQuery->where('track_id', $request->get('track_id'));
        }else{
            $placementApplicantsQuery->where('track_id', 1);
        }
        if($request->has('select_assigned') && $request->get('select_assigned') != null && $request->get('select_assigned') != ''){
            //dd($request->get('select_assigned'));
            if($request->get('select_assigned') === '0'){
                $placementApplicantsQuery->whereNull('instructor_id');
            }elseif($request->get('select_assigned') === '1'){
                $placementApplicantsQuery->whereNotNull('instructor_id');
            }
        }
        if ($request->has('branches') && $request->get('branches') != null && $request->get('branches') != '') {
            //dd($request->get('branches'));
            $placementApplicantsQuery->whereIn('branch_id', $request->get('branches'));
        }
        
        if ($registration_from != null && $registration_to != '') {
            //dd($registration_from,$registration_to);
            $placementApplicantsQuery->whereBetween('created_at', [$registration_from, $registration_to]);
        }
        
        if($request->has('has_followup') && $request->get('has_followup') != null && $request->get('has_followup') != ''){
            if ($request->get('has_followup') === '0') {
                $placementApplicantsQuery->doesntHave('cases');
            } elseif ($request->get('has_followup') === '1') {
                $placementApplicantsQuery->has('cases');
            }
        }

        //$mobiles = $placementApplicantsQuery->pluck('mobile')->toArray();
        $ptApplicantCount = $placementApplicantsQuery->count();
        $placementApplicants = $placementApplicantsQuery->withCount('cases')->with('lastcase','lead','track','branch','instructor')->latest()->paginate($per_page);
        // dd($placementApplicants);
        $branch = Branch::pluck('id')->toArray();
        /*$leadpendingmobiles= PlacementApplicant::whereIn('branch_id', array_keys($employeeBranches))->whereNull('level')->pluck('mobile')->toArray();
        
        $leadfakemobiles= PlacementApplicant::whereIn('branch_id', array_keys($employeeBranches))->whereNotNull('level')->where('vocabulary_score','0.0')
        ->where('grammar_score','0.0')->pluck('mobile')->toArray();
        */
        // $totalleadpending=Lead::whereIn('mobile_1',$leadpendingmobiles)->where('type',1)->get()->count();
        // $totalleadfake=Lead::whereIn('mobile_1',$leadfakemobiles)->where('type',1)->get()->count();
        // $totalclient=Lead::whereIn('mobile_1',$mobiles)->where('type',3)->get()->count();
        // $totalcustomer = Lead::whereIn('mobile_1',$mobiles)->where('type',2)->get()->count();
        $labelTypes = LabelType::where('status', 1)->where('category', 6)->pluck('name', 'id')->toArray();
        
        
    //   return  $last6month = PlacementApplicant::select('*')->where("created_at",">", Carbon::now()->subMonths(6))->delete();
        //dd(round(microtime(true) * 1000) - $testProcess);
        // 'totalleadpending','totalleadfake','totalclient','totalcustomer',
        return view('placement_applicants.index',compact('placementApplicants','levels','ptApplicantCount','track','instructors','employeeBranches','labelTypes','sources'));
    }
    /**
     * Show the form for creating a new PlacementApplicant.
     *
     * @return Response
     */
    public function create()
    {
        return view('placement_applicants.create');
    }

    /**
     * Store a newly created PlacementApplicant in storage.
     *
     * @param CreatePlacementApplicantRequest $request
     *
     * @return Response
     */
    public function store(CreatePlacementApplicantRequest $request)
    {
        
    }

    /**
     * Display the specified PlacementApplicant.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var PlacementApplicant $placementApplicant */
        //$testProcess = round(microtime(true) * 1000);
        $placementApplicant = PlacementApplicant::with('lead')->find($id);

        if (empty($placementApplicant)) {
            Flash::error('Placement Applicant not found');

            return redirect(route('admin.placementApplicants.index'));
        }
        //dd(round(microtime(true) * 1000) - $testProcess);
        
        return view('placement_applicants.show')->with('placementApplicant', $placementApplicant);
    }

    /**
     * Show the form for editing the specified PlacementApplicant.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var PlacementApplicant $placementApplicant */
        //$testProcess = round(microtime(true) * 1000);
        $placementApplicant = PlacementApplicant::with('answers')->find($id);
        $levels = StageLevel::get();

        if (empty($placementApplicant)) {
            Flash::error('Placement Applicant not found');

            return redirect(route('admin.placementApplicants.index'));
        }
        //dd(round(microtime(true) * 1000) - $testProcess);
        return view('placement_applicants.edit')->with('placementApplicant', $placementApplicant)->with('levels', $levels);
    }

    /**
     * Update the specified PlacementApplicant in storage.
     *
     * @param int $id
     * @param UpdatePlacementApplicantRequest $request
     *
     * @return Response
     */
    public function update($id, UpdatePlacementApplicantRequest $request)
    {
        /** @var PlacementApplicant $placementApplicant */
        $placementApplicant = PlacementApplicant::find($id);
        
        if (empty($placementApplicant)) {
            Flash::error('Placement Applicant not found');

            return redirect(route('admin.placementApplicants.index'));
        }
        
        $data = $request->all();
        if($placementApplicant->track_id ==1)
        {
            $total_degree = $placementApplicant->vocabulary_score + $placementApplicant->grammar_score + $placementApplicant->reading_score+
                        $placementApplicant->listening_score + $request->writing_score + $request->speaking_score;
            $level = StageLevel::where('min_degree','<',$total_degree)->where('max_degree','>=',$total_degree)->first();
            $data['level'] = $level->value;
        }elseif($placementApplicant->track_id ==14){
            $data['level'] = $request->level;
        }else{
            
        }
        $placementApplicant->fill($data);
        $placementApplicant->save();

        $lead = Lead::where('id', $placementApplicant->lead_id)->first();
        
        if($lead != null && $lead != ''){
            $customerTrack = CustomerTrack::where('lead_id',$lead->id)->where('track_id',$placementApplicant->track_id)->first();
            $payments = LeadPayment::where('track_id',$placementApplicant->track_id)->where('lead_id',$lead->id)->where('paymentable_type','App\\Models\\Offer')->whereNull('group_id')->get();
            if($payments != null && count($payments) > 0 && ! $customerTrack){
                foreach($payments as $payment){
                    $offer = Offer::where('track_id',$placementApplicant->track_id)->with('timeframes', 'intervals')->find($payment->paymentable_id);
                    if($offer->has_levels == 0){
                        $course = $offer->course;
                        $stage_levels = DB::table('stage_levels')->leftJoin('stages','stages.id','=','stage_levels.stage_id')
                                                ->where('stages.track_id',$offer->course_id)
                                                ->where('stage_levels.value','>=',$placementApplicant->level)->take($offer->num_levels)->pluck('stage_levels.id')->toArray();
                        //dd($stage_levels,$check_cusTrack);
                        if($stage_levels != null && count($stage_levels) > 0){
                            
                            $customerTrack = CustomerTrack::create([
                                'lead_id' => $lead->id,
                                'track_id' => $offer->track_id,
                                'course_id' => $offer->course_id,
                                'level_id' => $stage_levels[0],
                                'total' => $offer->num_levels,
                                'used' => 0,
                            ]);
                            
                            //dd($stage_levels,$training_service_levels,$total,$training_services->pluck('id'));
                            $timeframesString = implode(',', $offer->timeframes->pluck('id')->toArray());
                            $intervalsString = implode(',', $offer->intervals->pluck('id')->toArray());
                            $disciplinesIds = DB::table('offer_disciplines')->where('offer_id',$offer->id)->pluck('discipline_id')->toArray();
                            GroupWaitingList::where('lead_id',$lead->id)->where('track_id',$placementApplicant->track_id)->delete();
                            GroupWaitingList::create([
                                'lead_id' => $lead->id,
                                'level_id' => $stage_levels[0],
                                'track_id' => $offer->track_id,
                                'course_id' => $offer->course_id,
                                'timeframes' => $timeframesString,
                                'intervals' => $intervalsString,
                                'lead_payment_id' => $payment->id,
                                'discipline_id' => ($disciplinesIds != null && count($disciplinesIds) > 0)?$disciplinesIds[0]:null
                            ]);
                            
                            
                        }
                    }
                }
            }
        }
        
        
        $whatsApp = new WhatsApp;
        // $buttons = [
            
        //     'templateButtons' => [
        //         ['index' => 1, 'urlButton' => ['displayText' => 'Visit your profile', 'url' => 'https://harvestcollege.co.uk/customerPortal']],
        //     ],
             
        // ];

        $msg = 
        'Dear Harvest Customer'.' 
        Please Find Your Placement Test Results as Follows :'.'
        vocabulary_score : '.$placementApplicant->vocabulary_score.' / 10 '.'
        Grammer_score : '.$placementApplicant->grammar_score.' / 10 '.'
        reading_score : '.$placementApplicant->reading_score.' / 20 '.'
        listening_score : '.$placementApplicant->listening_score.' / 20 '.'
        writing_score : '.$placementApplicant->writing_score.' / 20 '.'
        speaking_score : '.$placementApplicant->speaking_score.' / 20 '.'
        Placement Test Level : '.$placementApplicant->level.'
        Looking Forward Meeting You Soon 😊';
        $whatsApp->send($placementApplicant->mobile, $msg); 
        $log = MessageLog::create([
            'type' => 2,
            'content' => $msg,
            'employee_id' => auth()->id()
        ]);
        $log->leads()->sync($placementApplicant->mobile);
        
        
        $url = route('admin.placementApplicants.index').'?track_id='.$placementApplicant->track_id;
        Flash::success('Placement Applicant updated successfully.');

        return redirect($url);
    }

    /**
     * Remove the specified PlacementApplicant from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var PlacementApplicant $placementApplicant */
        $placementApplicant = PlacementApplicant::find($id);

        if (empty($placementApplicant)) {
            Flash::error('Placement Applicant not found');

            return redirect(route('admin.placementApplicants.index'));
        }

        $placementApplicant->delete();

        Flash::success('Placement Applicant deleted successfully.');

        return redirect(route('admin.placementApplicants.index'));
    }

    public function instructorsAssign(Request $request)
    {
        if(! $request->instructor_id) {
            Flash::error('Assigned Instructor is required.');
        }elseif ($request->ids != null && count($request->ids) > 0) {
            PlacementApplicant::whereIn('id', $request->ids)->update(['instructor_id' => $request->instructor_id]);
            Flash::success('Assigned Successfully.');
        }else {
            Flash::error('Selected PT is required.');
        }
        return 0;
    }
    /**
     * Display the specified PlacementApplicant.
     *
     * @param int $id
     *
     * @return Response
     */
    public function sendMail($id)
    {
        /** @var PlacementApplicant $placementApplicant */
        $placementApplicant = PlacementApplicant::find($id);

        if (empty($placementApplicant)) {
            Flash::error('Placement Applicant not found');

            return redirect(route('admin.placementApplicants.index'));
        }

        Mail::to($placementApplicant)->send(new PlacementTestResult($placementApplicant));

        Flash::success('Mail sent successfully.');

        return redirect(route('admin.placementApplicants.index'));
    }


    public function PTSendmsg(Request $request)
    {
        //dd($request->all());
        if (!$request->message) {
            Flash::error('Message is required.');
        } elseif ($request->ids != null && count($request->ids) > 0) {
            if($request->type == 'sms'){
                $sms = new SMS;
    
                $mobiles = PlacementApplicant::whereIn('id', $request->ids)->pluck('mobile', 'id')->toArray();
                $msg = $request->message;
    
                $sms->send($mobiles, $msg);
    
                $log = MessageLog::create([
                    'type' => 1,
                    'content' => $msg,
                    'employee_id' => auth()->id(),
                ]);

                $log->PTsApplications()->sync(array_keys($mobiles));
            }else{
                $whatsApp = new WhatsApp;

                $mobiles = PlacementApplicant::whereIn('id', $request->ids)->pluck('mobile', 'id')->toArray();
                $msg = $request->message;
    
                $whatsApp->send($mobiles, $msg);
    
                $log = MessageLog::create([
                    'type' => 2,
                    'content' => $msg,
                    'employee_id' => auth()->id()
                ]);
                $log->PTsApplications()->sync(array_keys($mobiles));

            }
            Flash::success('Sent Successfully.');

        } else {
            Flash::error('Selected Employees is required.');
        }
        return 0;
    }
    
    public function pt6month(){
        return PlacementApplicant::select('*')->where("created_at","<", Carbon::now()->subMonths(6))->delete();
    }
    
}
