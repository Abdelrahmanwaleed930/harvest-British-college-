<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TODoList;
use App\Models\Department;
use App\Models\TODoListRandom;
use App\Models\Job;
use App\Models\ToDoListJobs;
use App\Models\Notification;
use App\Models\Employee;
use App\Events\MyToDoList;
use Flash;
use DB;
use App\Http\Requests\UpdateToDoListRandomRequest;
use App\Http\Requests\CreateToDoListRandomRequest;

class TODoListRandomController extends Controller
{
    public function index(Request $request){}
    public function show(Request $request , $id){}
    public function create(Request $request){
        $departments = Department::pluck('title','id');
        $jobs =[];
        $employee=[];
         return view('TODoListRandom.create',compact('departments','jobs','employee'));
    }
    public function store(Request $request){
       
       
        $data = $request->validate(
            [
                
                'type'=>'required',
                'start_date'=>'nullable',
                'start_date1'=>'nullable',
                'end_date'=>'nullable',
                'end_date2'=>'nullable',
                
            ]
        );
        
        $employee = TODoList::find($request->todolist);
        $names = $request->name;
        foreach($names as $key=>$name)
        {
            $ToDoListRandom = new TODoListRandom;
            $ToDoListRandom->name = $request->name[$key];
            $ToDoListRandom->type = $request->type[$key];
            $ToDoListRandom->start_date = $request->start_date1[$key];
            $ToDoListRandom->end_date = $request->end_date1[$key];
            $ToDoListRandom->to_do_list_id = $request->todolist;
            $ToDoListRandom->employee_id = $employee->employee_id;
            $ToDoListRandom->save();
            
        }
        Flash::success(' TODoListRandom Created successfully.');
        return redirect(route('admin.ToDoList.index'));
    }
    public function edit(Request $request,$id){
         $TODoListRandom = TODoListRandom::find($id);
         $employee = Employee::where('id',$TODoListRandom->employee_id)->get()->pluck('name','id');
        return view('TODoListRandom.edit',compact('TODoListRandom','employee'));
    }
    public function update(UpdateToDoListRandomRequest $request,$id){
         $TODoListRandom = TODoListRandom::find($id);
         $data = $request->all();
        $TODoListRandom->update($data);
        
        Flash::success(' TODoListRandom Updated successfully.');
        return redirect(route('admin.ToDoList.index'));
        
    }
    public function destroy($id){}
    
}
