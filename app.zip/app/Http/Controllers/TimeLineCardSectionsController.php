<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TimeLineCardSections;
use Flash;

class TimeLineCardSectionsController extends Controller
{
     public function index(){
        $TimeLineCardSections = TimeLineCardSections::get();
        
        return view('TimeLineCardSections.index',compact('TimeLineCardSections')); 
    }
    public function create(){
        $TimeLineCardSections = TimeLineCardSections::get();
        
        return view('TimeLineCardSections.create',compact('TimeLineCardSections')); 
    }
    public function store(Request $request ){
        
          $credentials = $request->validate([
            'title' => 'required',
            'description' => 'required',
            'max_score' => 'required',
        ]);
        $TimeLineCardSections = new TimeLineCardSections;
        $TimeLineCardSections->title = $request->title;
        $TimeLineCardSections->description = $request->description;
        $TimeLineCardSections->max_score = $request->max_score;
        $TimeLineCardSections->save();
        
        Flash::success('TimeLineCardSections created successfully.');
        return redirect()->back(); 
    }
    public function edit($id){
        $TimeLineCardSections = TimeLineCardSections::find($id);
        
        return view('TimeLineCardSections.edit',compact('TimeLineCardSections')); 
    }
    public function update($id , Request $request){
        $TimeLineCardSections = TimeLineCardSections::find($id);
        $credentials = $request->validate([
            'title' => 'required',
            'description' => 'required',
            'max_score' => 'required',
        ]);
         $TimeLineCardSections->title = $request->title;
        $TimeLineCardSections->description = $request->description;
      
        $TimeLineCardSections->max_score = $request->max_score;
        $TimeLineCardSections->save();
        
        
        Flash::success('TimeLineCardSections updated successfully.');
        return redirect()->back(); 
    }
    
    public function destroy($id){
        $TimeLineCardSections = TimeLineCardSections::find($id);
        $TimeLineCardSections->delete();
        Flash::success('TimeLineCardSections deleted successfully.');
        return redirect()->back(); 
        
    }
}
