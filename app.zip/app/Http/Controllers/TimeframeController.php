<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateTimeframeRequest;
use App\Http\Requests\UpdateTimeframeRequest;
use App\Http\Controllers\AppBaseController;
use App\Models\Timeframe;
use App\Models\Interval;
use App\Models\Track;
use Illuminate\Http\Request;
use Flash;
use DB;
use Response;

class TimeframeController extends AppBaseController
{
    /**
     * Display a listing of the Timeframe.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var Timeframe $timeframes */
        $timeframes = Timeframe::all();

        return view('timeframes.index')
            ->with('timeframes', $timeframes);
    }

    /**
     * Show the form for creating a new Timeframe.
     *
     * @return Response
     */
    public function create()
    {
        
        $intervals_data = Interval::where('status', 1)->pluck('name', 'id');
        $courses_data = Track::where('status', 1)->whereNotNull('parent_id')->pluck('title', 'id');
        // $total_hours = $this->total_hours;
        // $session_hours = $this->session_hours;
        // $week_session = $this->week_session;
        // if ($total_hours && $session_hours && $week_session) {
        //     $weeks = round((($total_hours / $session_hours) / $week_session), 1);
        //     $months = round((($total_hours / $session_hours) / $week_session / 4), 1);
        //     $preview = "$weeks weeks or $months months";
        // }
        return view('timeframes.create',compact('intervals_data' ,'courses_data'));
    }

    /**
     * Store a newly created Timeframe in storage.
     *
     * @param CreateTimeframeRequest $request
     *
     * @return Response
     */
    public function storee(Request $request)
    {
        

        /** @var Timeframe $timeframe */
        $timeframe = new Timeframe;
        $timeframe->title = $request-> title;
        $timeframe->total_hours = $request-> total_hours;
        $timeframe->week_session = $request-> week_session;
        $timeframe->session_hours = $request-> session_hours;
        $timeframe->status = $request-> status;
        $days = $request->days;
        // return $days; 
        $days_id_list='';

        foreach($days as $day)
        {
            $days_id_list .=$day.',';
        }
    
        $data_days_id=rtrim($days_id_list,',');   
    
        
         $timeframe->days=$data_days_id;
        
        $timeframe->save ();
        
        $timeframe->courses()->sync($request->courses);
        $timeframe->intervals()->sync($request->intervals);

        Flash::success('Timeframe saved successfully.');

        return redirect(route('admin.timeframes.index'));
    }

    /**
     * Display the specified Timeframe.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var Timeframe $timeframe */
        $timeframe = Timeframe::find($id);

        if (empty($timeframe)) {
            Flash::error('Timeframe not found');

            return redirect(route('admin.timeframes.index'));
        }

        return view('timeframes.show')->with('timeframe', $timeframe);
    }

    /**
     * Show the form for editing the specified Timeframe.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var Timeframe $timeframe */
        $timeframe = Timeframe::find($id);
        $intervals_data = Interval::where('status', 1)->pluck('name', 'id');
        $courses_data = Track::where('status', 1)->whereNotNull('parent_id')->pluck('title', 'id');
        $tracks = Track::whereNull('parent_id')->pluck('title', 'id');
        $course_ids = DB::table('timeframe_courses')->where('timeframe_id',$timeframe->id)
        ->pluck('course_id')->toArray();
        $intervals_ids = DB::table('interval_timeframe')->where('timeframe_id',$timeframe->id)
        ->pluck('interval_id')->toArray();
        if (empty($timeframe)) {
            Flash::error('Timeframe not found');

            return redirect(route('admin.timeframes.index'));
        }

        return view('timeframes.edit',compact('course_ids','intervals_ids','intervals_data','courses_data'))->with('timeframe', $timeframe);
    }

    /**
     * Update the specified Timeframe in storage.
     *
     * @param int $id
     * @param UpdateTimeframeRequest $request
     *
     * @return Response
     */
    public function updatee($id, Request $request)
    {
        /** @var Timeframe $timeframe */
        $timeframe = Timeframe::find($id);

        if (empty($timeframe)) {
            Flash::error('Timeframe not found');

            return redirect(route('admin.timeframes.index'));
        }
        $timeframe->title = $request-> title;
        $timeframe->total_hours = $request-> total_hours;
        $timeframe->week_session = $request-> week_session;
        $timeframe->session_hours = $request-> session_hours;
        $timeframe->status = $request-> status;
        $days = $request->days;
        // return $days; 
        $days_id_list='';

        foreach($days as $day)
        {
            $days_id_list .=$day.',';
        }
    
        $data_days_id=rtrim($days_id_list,',');   
    
        
         $timeframe->days=$data_days_id;
        
        $timeframe->save ();
        
        $timeframe->courses()->sync($request->courses);
        $timeframe->intervals()->sync($request->intervals);
/*
        $timeframe->fill($request->all());
        $timeframe->save();*/

        Flash::success('Timeframe updated successfully.');

        return redirect(route('admin.timeframes.index'));
    }

    /**
     * Remove the specified Timeframe from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var Timeframe $timeframe */
        $timeframe = Timeframe::find($id);

        if (empty($timeframe)) {
            Flash::error('Timeframe not found');

            return redirect(route('admin.timeframes.index'));
        }

        $timeframe->delete();

        Flash::success('Timeframe deleted successfully.');

        return redirect(route('admin.timeframes.index'));
    }
}
