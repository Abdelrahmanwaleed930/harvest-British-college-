<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\HrGroups;

class HrGroupSessionController extends Controller
{
    public function index(Request $request){
         $group = request('group');
         $groups = HrGroups::with('hr_group_session')->find($group);
         return view('hr_group_session.index',compact('groups'));
    }
}
