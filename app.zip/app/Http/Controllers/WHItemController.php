<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateWHItemRequest;
use App\Http\Requests\UpdateWHItemRequest;
use App\Http\Controllers\AppBaseController;
use App\Models\WHItem;
use App\Models\WHItemCategory;
use Illuminate\Http\Request;
use Flash;
use Response;

class WHItemController extends AppBaseController
{
    /**
     * Display a listing of the WHItem.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var WHItem $items */
        $items = WHItem::latest()->paginate(10);
        $countitems = $items->count();

        return view('wh_items.index')->with('items', $items)->with('countitems', $countitems);
    }

    /**
     * Show the form for creating a new WHItem.
     *
     * @return Response
     */
    public function create()
    {
        $categories = WHItemCategory::all()->pluck('name','id');
        
        return view('wh_items.create',compact('categories'));
    }

    /**
     * Store a newly created WHItem in storage.
     *
     * @param CreateWHItemRequest $request
     *
     * @return Response
     */
    public function store(CreateWHItemRequest $request)
    {
        $input = $request->all();

        /** @var WHItem $item */
        $item = WHItem::create($input);

        Flash::success('Warehouse Item saved successfully.');

        return redirect(route('admin.whItems.index'));
    }

    /**
     * Display the specified WHItem.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var WHItem $item */
        $categories = WHItemCategory::all()->pluck('name','id');
        
        $item = WHItem::find($id);

        if (empty($item)) {
            Flash::error('Warehouse Item not found');

            return redirect(route('admin.whItems.index'));
        }

        return view('wh_items.show')->with('item', $item)->with('categories',$categories);
    }

    /**
     * Show the form for editing the specified WHItem.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var WHItem $item */
        $categories = WHItemCategory::all()->pluck('name','id');
        
        $item = WHItem::find($id);

        if (empty($item)) {
            Flash::error('Warehouse Item not found');

            return redirect(route('admin.whItems.index'));
        }

        return view('wh_items.edit')->with('item', $item)->with('categories',$categories);
    }

    /**
     * Update the specified WHItem in storage.
     *
     * @param int $id
     * @param UpdateWHItemRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateWHItemRequest $request)
    {
        /** @var WHItem $item */
        $item = WHItem::find($id);

        if (empty($item)) {
            Flash::error('Warehouse Item not found');

            return redirect(route('admin.whItems.index'));
        }

        $item->fill($request->all());
        $item->save();

        Flash::success('Warehouse Item updated successfully.');

        return redirect(route('admin.whItems.index'));
    }

    /**
     * Remove the specified WHItem from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var WHItem $item */
        $item = WHItem::find($id);

        if (empty($item)) {
            Flash::error('Warehouse Item not found');

            return redirect(route('admin.whItems.index'));
        }

        $item->delete();

        Flash::success('Warehouse Item deleted successfully.');

        return redirect(route('admin.whItems.index'));
    }
}
