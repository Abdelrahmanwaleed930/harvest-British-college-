<?php

namespace App\Http\Controllers;

use App\Http\Controllers\AppBaseController;
use App\Models\GroupSessionAttendance;
use App\Models\GroupSession;
use App\Models\GroupStudent;
use App\Models\Group;
use Illuminate\Http\Request;
use Response;
use Auth;
// use Response;
use Spatie\Activitylog\Contracts\Activity;

use Laracasts\Flash\Flash;

class GroupSessionAttendanceController extends AppBaseController
{
    /**
     * Display a listing of the GroupSessionAttendance.
     *
     * @param Request $request
     *
     * @return Response
     */
    
    
    public function index(Request $request)
    {
        $session_id = $request->get('session');
        $attendances = GroupSessionAttendance::with('makeup')->where('group_session_id', $session_id)->get();
        $presents = $attendances->where('attendance',1)->pluck('id')->toArray();
        
        return view('group_session_attendances.index',compact('attendances','presents','session_id'));
    }
    
    public function addToMakeup(Request $request)
    {
        $groupSession = GroupSession::with('makeup')->find($request->session_id);
        
        if(!$groupSession->makeup){
            
            $url = route('admin.makeupSessions.create', ['session' => $groupSession->id]);
            
            // activity('Group student')
            //   ->causedBy(Auth::user()->id)
            //   ->performedOn($attendance->lead_id)
            //   ->withProperties(['group_id' =>$attendance->group_id ])
            //   ->log('Create Makeup session');
            return response()->json(['status' => 'redirect','url' => $url]);
        }else{
            $groupSession->makeup->attendances()->attach($request->attendance_id);

            $attendance = GroupSessionAttendance::find($request->attendance_id);
            $attendance->update(['attendance' => 1]);
            
            // activity('Group student')
            //   ->causedBy(Auth::user()->id)
            //   ->performedOn($attendance->lead_id)
            //   ->withProperties(['group_id' =>$attendance->group_id ])
            //   ->log('Makeup session');
            Flash::success('Added to makeup session successfully.');
            return response()->json(['status' => 'reload']);
        }
        
    }
    
    public function update($id,Request $request)
    {
        //dd($request->all());
        $presents = ($request->has('presents') && $request->get('presents') != null && $request->get('presents') != '' && count($request->get('presents')) > 0)?$request->get('presents'):[];
        
        $groupSession = GroupSession::with('makeup')->find($id);
        $group = Group::withCount('sessions')->find($groupSession->group_id);
        $group_students_ids = GroupStudent::where('group_id',$groupSession->group_id)->pluck('lead_id');
        $attendances = GroupSessionAttendance::where('group_session_id', $id)->whereIn('lead_id',$group_students_ids)->get();
        
        foreach ($attendances as $attendance) {
            $attendance->update(['attendance' => in_array($attendance->id, $presents) ? 1 : 0]);

            $absentCount = GroupSessionAttendance::where([
                'lead_id' => $attendance->lead_id,
                'group_id' => $attendance->group_id,
                'level_id' => $attendance->level_id,
                'attendance' => 0,
            ])->count();
            //dd($absentCount);
            $student = GroupStudent::where([
                'lead_id' => $attendance->lead_id,
                'group_id' => $attendance->group_id,
            ])->first();
            //dd($student);
            if ($absentCount > 1) {
                //dd($student,$attendance->lead_id,$absentCount,$group);
                $student->absence_per = ($absentCount / $group->sessions_count) * 100;

                $attendance->update(['need_makeup' => 1]);
            }
            
        //  activity('Group student')
        //   ->causedBy(Auth::user()->id)
        //   ->performedOn($attendance->lead)
        //   ->withProperties(['group_id' =>$attendance->group_id ])
        //   ->log('update attendance Student');
        }

        $groupSession->update(['status' => 2]);
        
        //get first session
        //campare id first session = $id
        //get all present leads in this session
        //increase used level
        
        //get secend session
        //compare id secend session = $id
        //get all absent leads in this session
        // increase used level in case absend in first session
        //get all present leads in this session
        // increase used level in case absent in first session
        

        
        Flash::success('Attendance saved successfully.');
        
        //return redirect('/groupSessions?group='.$group->id);
        // return view();
    }
}
