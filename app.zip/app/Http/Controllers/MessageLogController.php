<?php

namespace App\Http\Controllers;

use App\Http\Controllers\AppBaseController;
use App\Models\MessageLog;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Builder;
use Flash;
use Response;

class MessageLogController extends AppBaseController
{
    /**
     * Display a listing of the MessageLog.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var MessageLog $messageLogs */
        // $messageLogs = MessageLog::orderBy('created_at' , 'DESC')->paginate(10);
        

        $messageLogs = MessageLog::with(['leads'=>function($q){
            $q->select('mobile_1' ,'name_en','name_ar' ,'type','id');
        } ,'employee'=>function($q){
            $q->select('first_name','last_name','middle_name' , 'mobile' , 'id');
        },'jobsApplications'])->orderBy('created_at' , 'DESC');
        // $message = MessageLog::with('leads' , 'employee' ,'jobsApplications');
        
        $totalmessagelog = $messageLogs->count();

        $daterange_from = null;
        $daterange_to = null;
        $reg_to=null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $daterange_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $daterange_to= date_format($reg_to,"Y-m-d");;
            
        }

        if ($daterange_from != null && $daterange_to != '') {
            $messageLogs->whereBetween('created_at', [$daterange_from, $daterange_to]);
        }
        if($request->has('type') && $request->get('type') != '' && $request->get('type') != null){
            $messageLogs = $messageLogs->where('type',$request->get('type'));
        }
        if($request->has('mobile_1') && $request->get('mobile_1') != '' && $request->get('mobile_1') != null){
            $mobile_1 = $request->mobile_1;
            
            $messageLogs = MessageLog::with(['leads'=>function( $q){
                $q->select('mobile_1' ,'name_en','name_ar' ,'type','id')
                ->where('mobile_1' ,'=', 01115215514);
            } ,'employee'=>function($q){
                $q->select('first_name','last_name','middle_name' , 'mobile' , 'id');
            },'jobsApplications'])->orderBy('created_at' , 'DESC');
        }
            
            // $messageLogs = $messageLogs->where('mobile_1',$request->get('mobile_1'));

        
        $messagecount = $messageLogs->count();
        $messageLogs= $messageLogs->paginate(10);

        // return $messageLogs;
        



        

         
        return view('message_logs.index',compact('totalmessagelog' ,'messagecount'))
            ->with('messageLogs', $messageLogs);
    }

    /**
     * Display the specified MessageLog.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var MessageLog $messageLog */
        $messageLog = MessageLog::with(['leads'=>function($q){
            $q->select('mobile_1' ,'name_en','name_ar' ,'type','id');
        } ,'employee'=>function($q){
            $q->select('first_name','last_name' , 'mobile' , 'id');
        },'jobsApplications'])->find($id);

        
        

        if (empty($messageLog)) {
            Flash::error('Message Log not found');

            return redirect(route('admin.messageLogs.index'));
        }
        // return  $messageLog ;
        

        return view('message_logs.show')->with('messageLog', $messageLog);
    }
}
