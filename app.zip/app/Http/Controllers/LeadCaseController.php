<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateLeadCaseRequest;
use App\Http\Requests\UpdateLeadCaseRequest;
use App\Repositories\LeadCaseRepository;
use App\Http\Controllers\AppBaseController;
use App\Models\Action;
use App\Models\Branch;
use App\Models\SMS;
use App\Models\WhatsApp;
use App\Models\Feedback;
use App\Models\Label;
use App\Models\LabelType;
use App\Models\LeadLastCase;
use App\Models\Lead;
use App\Models\LeadCase;
use App\Models\LeadPayment;
use App\Models\Group;
use App\Models\PlacementApplicant;
use App\Models\Employee;
use App\Models\LeadSource;
use App\Models\KnowChannel;
use App\Models\TrainingService;
use App\Models\Offer;
use App\Models\MessageLog;
use App\Models\GroupWaitingList;
use App\Models\GroupSession;
use App\Models\CertificateRequest;
use Illuminate\Http\Request;
use Flash;

use Auth;
// use Response;
use Spatie\Activitylog\Contracts\Activity;
use Response;
use DB;
use Carbon\Carbon;

class LeadCaseController extends AppBaseController
{
    /** @var  LeadCaseRepository */
    
    public function followUpDelete(Request $request)
    {
        if ($request->ids != null && count($request->ids) > 0) {
            $lead = LeadCase::whereIn('id', $request->ids);
            $lead->delete();

            Flash::success('Deleted Successfully.');

            $this->show_delete = false;
            $this->selected = [];
            
            
            activity('Leads')
              ->causedBy(Auth::user()->id)
              ->performedOn($lead)
             ->log('delete followup');


        } else {
            Flash::error('Selected Leads is required.');
        }
        return 0;
    }
    
    public function followUpSendmsg(Request $request)
    {
        if (!$request->message) {
            Flash::error('Message is required.');
        } elseif ($request->ids != null && count($request->ids) > 0) {
            if($request->type == 'sms'){
                $sms = new SMS;

                $leadsMobile = LeadCase::whereIn('id', $request->ids)->with('lead')->get()->pluck('lead.mobile_1', 'lead_id')->toArray();
                $mobiles = array_unique($leadsMobile);
    
                $msg = $request->message;

                $sms->send($mobiles, $msg);

                $log = MessageLog::create([
                    'type' => 1,
                    'content' => $msg,
                    'employee_id' => auth()->id()
                ]);
                $log->leads()->sync(array_keys($mobiles));

            }else{
                $whatsApp = new WhatsApp;

                $leadsMobile = LeadCase::whereIn('id', $request->ids)->with('lead')->get()->pluck('lead.mobile_1', 'lead_id')->toArray();
                $mobiles = array_unique($leadsMobile);
    
                $msg = $request->message;

                $whatsApp->send($mobiles, $msg);

                $log = MessageLog::create([
                    'type' => 2,
                    'content' => $msg,
                    'employee_id' => auth()->id()
                ]);
                $log->leads()->sync(array_keys($mobiles));

            }
            Flash::success('Sent Successfully.');

        } else {
            Flash::error('Selected Employees is required.');
        }
        return 0;
    }
    
    /**
     * Display a listing of the LeadCase.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    { 
        //dd($request->all());
        //$testsec = round(microtime(true)*1000);
        $lead = Lead::find(request('lead'));
        // return $lead;
        $type = $request->input('type');
          $trackId = $request->input('track');
       
        $leadCasesQuery = LeadCase::where('lead_id', $lead->id);
        // return $leadCasesQuery->get();

        if (request()->filled('student')) {
            $leadCasesQuery->where('student_id', request('student'));
        } else {
            $leadCasesQuery->whereNull('student_id');
        }

        $leadCases = $leadCasesQuery->orderBy('id','desc')->get();
        
        $invoices = LeadPayment::where('lead_id', $lead->id)->withCount(['subPayments' => function ($query) {
            $query->where('paid', 0);
        }])->with('subPayments')->get();
        
        $pt = PlacementApplicant::where('lead_id',$lead->id)->get()->last();
        //dd($pt);
        $groups_ids = DB::table('group_students')->where('lead_id',$lead->id)->pluck('group_id');
        $groups = Group::whereIn('id',$groups_ids)->orderBy('id','desc')->get();
        $msgs_ids = DB::table('lead_message_log')->where('lead_id',$lead->id)->pluck('message_log_id');
        $msgs = MessageLog::whereIn('id',$msgs_ids)->orderBy('id','desc')->get();
        
        $labelTypes = LabelType::where('status', 1)->where('category', $request->type)->get();
        $feedbacks = Feedback::where('status', 1)->whereIn('label_type_id', $labelTypes->pluck('id'))->get();
        $actions = Action::where('status', 1)->whereIn('label_type_id', $labelTypes->pluck('id'))->get();
        $feedbacks = $feedbacks->groupBy('label_type_id');
        $actions = $actions->groupBy('label_type_id');
        
        return view('lead_cases.index', compact('leadCases','lead','invoices','pt','groups','msgs','labelTypes','feedbacks','actions','type','trackId'));
    }
    
    public function get_feedbacks(Request $request)
    {
        
        $feedbacks = Feedback::where('status', 1)->whereIn('label_type_id', $request->label_type_id)->pluck('name', 'id');
        // return $feedbacks;
        return json_decode($feedbacks);
        
    }
    public function get_actions(Request $request)
    {
        $actions = Action::where('status', 1)->whereIn('label_type_id', $request->label_type_id)->pluck('name', 'id');
        return json_decode($actions);
    }
    
    
    public function store(Request $request){
        
        //dd($request->all());
        $data = $request->validate([
            'lead_id' => 'required',
            'student_id' => 'nullable',
            'branch_id' => 'required',
            'label_type_id' => 'required',
            'type' => 'required',
            'follow_up_type' => 'required',
            'call_type' => 'nullable',
            'feedback_id' => 'nullable',
            'feedback_date' => 'nullable',
            'action_id' => 'nullable',
            'notes' => 'required',
            'date' => 'nullable',
        ]); 
        $lead= Lead::find($request->lead_id);
        $data['employee_id'] = Auth::user()->id;
        $data['action_employee_id'] = Auth::user()->id;
        $data['serial'] = time();
        
        if(isset($data['action_id']) && $data['action_id'] != null && $data['action_id'] != ''){
            $action = Action::findOrFail($data['action_id']);
            //dd($action);
            if(strtolower($action->name) == 'open'){
                $data['status'] = 0;
            }
            if(strtolower($action->name) == 'close' || strtolower($action->name) == 'closed'){
                $data['status'] = 1;
            }
        }
        
        $leadCase = LeadCase::create($data);
        
        activity('Lead Case')
            ->causedBy(Auth::user()->id)
            ->performedOn($leadCase)
            ->log('Create Lead Case');
            
        if($request->has('old') && $request->get('old') != '' && $request->get('old') != null) {
            $followup = LeadCase::find($request->get('old'));
            $followup->update(['status' => 1]);
        }
       
        $lastcase = $lead->lastcase;
        $last_case_date = array_merge(['lead_case_id' => $leadCase->id ],$data);
        if($lastcase){
            $lastcase->update($last_case_date);
        }else{
            $lastcase = LeadLastCase::create($last_case_date);
        }
        $query = ['lead' => $leadCase->lead_id,'type' => $leadCase->type];
    
        if ($leadCase->student_id) {
            $query['student'] = $leadCase->student_id;
        }
        
        if($request->label_type_id == 42 && $request->type == 2 && $request->group_id != '' && $request->group_id != null)
        {
            $group = Group::withCount('students')->find($request->group_id);
            if($group != null && $group != ''){
                $maxStudent = $group->discipline->max_student;
                //dd($maxStudent);
                $students_ids = $request->students;
                if (count($students_ids) == 0) {
                    Flash::error("The students field is required.");
                    return redirect()->back();
                }
                $total_students_count = count($students_ids) + $group->students_count;
                if ($total_students_count > $maxStudent) {
                    Flash::error("The students may not have more than $maxStudent items.");
                    return redirect()->back();
                }
               
                $lists = GroupWaitingList::with('lead', 'level')->where('track_id',$group->track_id)->whereIn('id', $students_ids)->get();
                $track = CustomerTrack::where('track_id',$group->track_id)->where('lead_id', $leadCase->lead_id)->first();
            
                $track->last_group_id = $group->id;
                $track->last_level_id = $group->level_id;
                $track->save();
                $mobiles = [];
                foreach ($lists as $list) {
                    $lead = $list->lead;
                    $payment = $list->payment;
                    $lead->groups()->attach($group->id, [
                        'level_id' => $group->level_id,
                        'payment' => (($payment != null && $payment != '') && ($payment->payment_plan_id == 1 || $payment->rest == 0))?1:0,
                        'lead_payment_id' => ($payment != null && $payment != '')?$payment->lead_payment_id:null,
                    ]);
       
                    $lead->type = 3;
                    /*$lead->last_group_id = $group->id;
                    $lead->last_level_id = $group->level_id;*/
                    $lead->save();
       
                    $sessions = GroupSession::with('level')->where('group_id', $group->id)->get();
                    foreach ($sessions as $session) {
                        $session->attendances()->create([
                            'lead_id' => $lead->id,
                            'group_id' => $session->group_id,
                            'level_id' => $session->level_id,
                        ]);
                    }
       
                    $mobiles[$lead->id] = $lead->mobile_1;
                    $list->delete();
                }
            }
        }
        
        if($request->label_type_id == 90 ||$request->label_type_id == 91 ){
            if($request->label_type_id == 90){
                $item_id = 2;
            }else{
                $item_id = 3;
            }
            $request_data = [
                            'name' => $lead->getName(),
                            'email' => $lead->email,
                            'phone' => $lead->mobile_1,
                            'certificate_id' => $item_id,
                        ];
             $certificate_request = CertificateRequest::create($request_data);
                    
        }

        return redirect(route('admin.leadCases.index', $query));
    }

    /**
     * Show the form for creating a new LeadCase.
     *
     * @return Response
     */
    public function create()
    {
        //dd(request('lead'));
        $lead = Lead::find(request('lead'));

        return view('lead_cases.create', compact('lead'));
    }

    /**
     * Store a newly created LeadCase in storage.
     *
     * @param CreateLeadCaseRequest $request
     *
     * @return Response
     */
    public function __store(CreateLeadCaseRequest $request)
    {
        $input = $request->all();

        $input['employee_id'] = auth()->id();
        $input['serial'] = time();
        $leadCase = LeadCase::create($input);

        if (request()->filled('old')) {
            $followup = LeadCase::find(request('old'));
            $followup->update(['status' => 1]);
        }

        Flash::success('Lead Case saved successfully.');

        $query = ['lead' => request('lead_id')];

        if ($leadCase->student_id) {
            $query['student'] = $leadCase->student_id;
        }

        return redirect(route('admin.leadCases.index', $query));
    }

    /**
     * Display the specified LeadCase.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $leadCase = LeadCase::find($id);

        if (empty($leadCase)) {
            Flash::error('Lead Case not found');

            return redirect(route('admin.leadCases.index'));
        }

        return view('lead_cases.show')->with('leadCase', $leadCase);
    }

    /**
     * Show the form for editing the specified LeadCase.
     *
     * @param int $id
     *
     * @return Response
     */
   public function edit($id)
{
    $leadCase = LeadCase::find($id);
    if (empty($leadCase)) {
        Flash::error('Lead Case not found');
        return redirect(route('admin.leadCases.index'));
    }

    // Get track_id from the request
    

    // From related Lead model
    $labelTypes = LabelType::where('status', 1)->where('category', $leadCase->type)->get();
    $feedbacks = Feedback::where('status', 1)->whereIn('label_type_id', $labelTypes->pluck('id'))->get();
    $actions = Action::where('status', 1)->whereIn('label_type_id', $labelTypes->pluck('id'))->get();
    $feedbacks = $feedbacks->groupBy('label_type_id');
    $actions = $actions->groupBy('label_type_id');

    $lead = Lead::find($leadCase->lead_id);

    // Pass track_id to the view
    return view('lead_cases.edit', compact('leadCase', 'lead', 'labelTypes', 'feedbacks', 'actions'));
}

    /**
     * Update the specified LeadCase in storage.
     *
     * @param int $id
     * @param UpdateLeadCaseRequest $request
     *
     * @return Response
     */
    public function update($id, Request $request)
    {
        $data =$request->all();
        $employee = auth()->user();
        $leadCase = LeadCase::find($id);
  
         if(isset($data['action_id']) && $data['action_id'] != null && $data['action_id'] != ''){
            $action = Action::findOrFail($data['action_id']);
            //dd($action);
            if(strtolower($action->name) == 'open'){
                $data['status'] = 0;
            }
            if(strtolower($action->name) == 'close' || strtolower($action->name) == 'closed'){
                $data['status'] = 1;
            }
        }
        
        if(isset($data['label_type_id']) && $data['label_type_id'] != null && $data['label_type_id'] != ''){
            $label_type = LabelType::findOrFail($data['label_type_id']);
            //dd($action);
            if(strtolower($label_type->name) == 'reserved'){
                $data['status'] = 1;
            }
        }
        //dd($leadCase);
        if (empty($leadCase)) {
            Flash::error('Lead Case not found');

            return redirect(route('admin.leadCases.index'));
        }
        $leadCase->employee_id = $employee->id;
        $leadCase->date = date('Y-m-d h:i:sa');
        $leadCase->update($data);
        
            activity('Lead Case')
            ->causedBy(Auth::user()->id)
            ->performedOn($leadCase)
            ->log('update Lead Case');
            

        Flash::success('Lead Case updated successfully.');

        return redirect()->back();
    }

    /**
     * Remove the specified LeadCase from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        $leadCase = LeadCase::find($id);

        if (empty($leadCase)) {
            Flash::error('Lead Case not found');

            return redirect(route('admin.leadCases.index'));
        }

        $lead = $leadCase->lead_id;
            activity('Leads')
              ->causedBy(Auth::user()->id)
              ->performedOn($lead)
             ->log('delete leadcase');
        $leadCase->delete($id);
        
           

        Flash::success('Lead Case deleted successfully.');

        return redirect(route('admin.leadCases.index', ['lead' => $lead]));
    }

    /**
     * Get label types depending on label id.
     *
     * @return void
     */
    public function getLabelTypes()
    {
        if (request()->filled('label_id')) {
            $types = LabelType::where('label_id', request('label_id'))->get();

            return $types;
        }
    }

    /**
     * Show the follow up page.
     *
     * @return Response
     */
    public function followup(Request $request)
    {
        //dd('dddd');
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $agents = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            /*->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })*/->where('current_branch',$request->get('branches'))->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        
        $leadSources = LeadSource::where('id', '!=', 6)->where('status',1)->pluck('name', 'id')->toArray();
        $knowChannels = KnowChannel::pluck('name', 'id')->toArray();
        $services = TrainingService::pluck('title', 'id')->toArray();
        $offers = Offer::pluck('title', 'id')->toArray();
        $types = ($request->has('types'))?$request->types:[1];
        $labelTypes = LabelType::where('status', 1)->whereIn('category',$types)->pluck('name', 'id')->toArray();
        
        
        $labelTypes_without_not_interested = $labelTypes;
        unset($labelTypes_without_not_interested[12]);
        
        // return $types;
      $followupsQuery = LeadCase::leftJoin('leads', 'leads.id', '=', 'lead_cases.lead_id')
    ->where('lead_cases.status', 0)
    ->whereIn('lead_cases.label_type_id', array_keys($labelTypes_without_not_interested))
    ->whereNotNull('lead_cases.date')
    ->whereIn('lead_cases.type', $types)
    ->where('lead_cases.date', '<=', now());

// Add the track_id filter if present in the request
if ($request->has('track_id') && $request->get('track_id') != '') {
    $followupsQuery->where('leads.prefered_track_id', $request->get('track_id')); // No extra space
}

        
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $followupsQuery->where(function ($query) use ($request){
                $query->where('leads.name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.mobile_1', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.email', 'like', '%' . $request->get('search') . '%');
            });
        }
        $registration_from = null;
        $registration_to = null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));

            // return $request->daterange ;
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            // $registration_to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
        }
         if ($registration_from != null && $registration_to != '') {
            $followupsQuery = $followupsQuery->whereBetween('leads.created_at', [$registration_from, $registration_to]);
        }
        $registration_action_from = null;
        $registration_action_to = null;
        if ($request->has('actiondaterange') && $request->get('actiondaterange') != null && $request->get('actiondaterange') != '') {
            $actiondaterange = explode(' - ',$request->get('actiondaterange'));

            // return $request->daterange ;
            $registration_action_from = date_format(date_create($actiondaterange[0]),'Y-m-d');
            // $registration_to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($actiondaterange[1]);
            //date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_action_to= date_format($reg_to,"Y-m-d");
        }
         if ($registration_action_from != null && $registration_action_to != '') {
            $followupsQuery = $followupsQuery->whereBetween('lead_cases.date', [$registration_action_from, $registration_action_to]);
        }
        if($request->has('lead_source') && $request->get('lead_source') != null && $request->has('lead_source') != ''){
            $followupsQuery->where('leads.lead_source_id', $request->get('lead_source'));
        }
        if($request->has('know_channel') && $request->get('know_channel') != null && $request->get('know_channel') != ''){
            $followupsQuery->where('leads.know_channel_id', $request->get('know_channel'));
        }
        if ($request->has('time') && $request->get('time') != null && $request->get('time') != '') {
            $followupsQuery->where('leads.preferred_time', $request->get('time'));
        }
        if ($request->has('service') && $request->get('service') != null && $request->get('service') != '') {
            $followupsQuery->where('leads.training_service_id', $request->get('service'));
        }
        if ($request->has('offer') && $request->get('offer') != null && $request->get('offer') != '') {
            $followupsQuery->where('leads.offer_id', $request->get('offer'));
        }
        if ($request->has('branches') && $request->get('branches') != null && $request->get('branches') != '') {
            $followupsQuery->whereIn('leads.branch_id', $request->get('branches'));
        }else {
            $followupsQuery->whereIn('leads.branch_id', array_keys($employeeBranches));
        }
        if($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
            $followupsQuery->where('lead_cases.action_employee_id', $request->get('agent'));
        }
        if(!auth()->user()->can('followup manager')){
            //dd('ddd');
            $followupsQuery->where('lead_cases.action_employee_id', auth()->id());
        }
        if($request->has('label_type_id') && $request->get('label_type_id') != null && $request->get('label_type_id') != ''){
            $followupsQuery->where('lead_cases.label_type_id', $request->get('label_type_id'));
        }
        
        $followups = $followupsQuery->select('lead_cases.id','lead_cases.created_at','lead_cases.branch_id','lead_cases.label_type_id','lead_cases.employee_id','lead_cases.lead_id','lead_cases.feedback_id','lead_cases.action_id','lead_cases.date','lead_cases.type')
        ->with('lead','employee','branch','feedback','action','labelType')->orderBy('lead_cases.date','desc')->paginate($per_page);
          
        return view('lead_cases.followup',compact('types','followups','leadSources','knowChannels','services','offers','labelTypes','agents','employeeBranches'));
    }
}
