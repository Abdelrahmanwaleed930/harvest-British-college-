<?php

namespace App\Http\Controllers;


use App\Http\Requests\CreateJobApplicationRequest;
use App\Http\Requests\UpdateJobApplicationRequest;
use App\Http\Controllers\AppBaseController;
use App\Models\Branch;
use App\Models\Employee;
use App\Models\JobApplication;
use App\Models\SMS;
use App\Models\MessageLog;
use App\Models\JobApplicationCase;
use App\Models\WhatsApp;
use App\Models\Department;
use App\Models\KnowChannel;
use App\Models\Job;
use App\Models\LabelType;
use App\Imports\JobsApplicationsImport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Http\Request;
use Flash;
use Response;
use File;

class JobApplicationController extends AppBaseController
{
    public function jobsApplicationsSendmsg(Request $request)
    {
        if (!$request->message) {
            Flash::error('Message is required.');
        } elseif ($request->ids != null && count($request->ids) > 0) {
            if($request->type == 'sms'){
                $sms = new SMS;
    
                $mobiles = JobApplication::whereIn('id', $request->ids)->pluck('phone', 'id')->toArray();
                $msg = $request->message;
    
                $sms->send($mobiles, $msg);
    
                $log = MessageLog::create([
                    'type' => 1,
                    'content' => $msg,
                    'employee_id' => auth()->id(),
                ]);
                $log->jobsApplications()->sync(array_keys($mobiles));
            }else{
                $whatsApp = new WhatsApp;

                $mobiles = JobApplication::whereIn('id', $request->ids)->pluck('phone', 'id')->toArray();
                $msg = $request->message;
    
                $whatsApp->send($mobiles, $msg);
    
                $log = MessageLog::create([
                    'type' => 2,
                    'content' => $msg,
                    'employee_id' => auth()->id()
                ]);
                $log->jobsApplications()->sync(array_keys($mobiles));

            }
            Flash::success('Sent Successfully.');

        } else {
            Flash::error('Selected Applications is required.');
        }
        return 0;
    }
    
    public function jobsApplicationsDelete(Request $request)
    {
        if ($request->ids != null && count($request->ids) > 0) {
            $jobs_applications = JobApplication::whereIn('id', $request->ids)->get();
            //LeadCase::whereIn('lead_id', $assignLeads)->where('status', 0)->update(['employee_id' => $this->assigned_employee]);
            foreach($jobs_applications as $job_application){
                if($job_application->upload_cv != null && $job_application->upload_cv != ''){
                    $file_path = '/home/harvestc/public_html/uploads/jobs_applications_cv/';
                    unlink(sprintf($file_path . '%s', $job_application->upload_cv));
                }
            }
            JobApplication::whereIn('id', $request->ids)->delete();
            
            Flash::success('Deleted Successfully.');
        }else{
            Flash::error('Selected Leads is required.');
        }
        return 0;
        
    }
    
    public function jobsApplicationsUploadExcel(Request $request)
    {
        //dd($request->all());
        if($request->hasFile('excel')){
            $file = $request->file('excel')->store('/');
            Excel::import(new JobsApplicationsImport, storage_path('app/' . $file));
            Flash::success('Jobs Applications Imported Successfully.');
        }else{
            Flash::success('excel file is required.');
        }
        return redirect()->back();
    }

    
    public function index(Request $request)
    {
        
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        
        $branches = Branch::pluck('name', 'id');
        
        $agents = Employee::where('account_Type', 'H.Q Account')->where('status',1)
                            ->whereIn('job_id',[32,33,34])->get()->pluck('name', 'id')->toArray();
        
        $case_from = null;
        $case_to = null;
        if ($request->has('case_daterange') && $request->get('case_daterange') != null && $request->get('case_daterange') != '') {
            $daterange = explode(' - ',$request->get('case_daterange'));
            $case_from = date_format(date_create($daterange[0]),'Y-m-d');
            // $case_to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $case_to= date_format($reg_to,"Y-m-d");
        }
        
        $registration_from = null;
        $registration_to = null;
        if ($request->has('registration_daterange') && $request->get('registration_daterange') != null && $request->get('registration_daterange') != '') {
            $daterange = explode(' - ',$request->get('registration_daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            // $registration_to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
        }
        $labelTypes = LabelType::where('status', 1)->where('category', 5)->pluck('name', 'id')->toArray();
        $jobs = Job::pluck('title', 'id')->toArray();
        
        $applicationsQuery = JobApplication::with('lastcase')
        ->leftJoin('jobs_applications_last_case','jobs_applications.id','=','jobs_applications_last_case.job_application_id')
                            /*->whereRaw('COALESCE(jobs_applications_last_case.label_type_id,0) in (6,7,8,9,0)')*/;
                            
        
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $applicationsQuery->where(function ($query) use ($request){
                $query->where('full_name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('phone', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('email', 'like', '%' . $request->get('search') . '%');
            });
        }elseif($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
            $applicationsQuery->whereIn('jobs_applications.assigned_employee_id', $request->get('agent'));
        } elseif (auth()->user()->can('jobsApplications applicationAssign')) {
            // show all
            //$applicationsQuery->whereIn('jobs_applications.branch_id', array_keys($employeeBranches));
        } else {
            $applicationsQuery->where('jobs_applications.assigned_employee_id', auth()->id());
        }
        
        if($request->has('select_assigned') && $request->get('select_assigned') != null && $request->get('select_assigned') != ''){
            if ($request->get('select_assigned') === '0') {
                $applicationsQuery->whereNull('jobs_applications.assigned_employee_id');
            } elseif ($request->get('select_assigned') === '1') {
                $applicationsQuery->whereNotNull('jobs_applications.assigned_employee_id');
            }
        }
        if (($request->has('label_type_id') && $request->get('label_type_id') != '' && $request->get('label_type_id') != null) || ($case_from != null && $case_to != null)) {
            if ($case_from && $case_to) {
                $applicationsQuery->whereBetween('jobs_applications_last_case.date', [$case_from, $case_to]);
            }
            if ($request->get('label_type_id') != '' && $request->get('label_type_id') != null) {
                $applicationsQuery->where('jobs_applications_last_case.label_type_id', $request->get('label_type_id'));
            }
            
        }
        if (($request->has('status') && $request->get('status') != '' && $request->get('status') != null) || ($case_from != null && $case_to != null)) {
            $applicationsQuery->where('jobs_applications.status', $request->get('status'));
        
            
        }
        if($request->has('has_followup') && $request->get('has_followup') != null && $request->get('has_followup') != ''){
            if ($request->get('has_followup') === '0') {
                $applicationsQuery->doesntHave('cases');
            } elseif ($request->get('has_followup') === '1') {
                $applicationsQuery->has('cases');
            }
        }
        

        if ($registration_from != null && $registration_to != '') {
            $applicationsQuery->whereBetween('jobs_applications.created_at', [$registration_from, $registration_to]);
        }
        
        if($request->has('job_id') && $request->get('job_id') != '' && $request->get('job_id') != null){
            $applicationsQuery->whereIn('jobs_applications.job_id', $request->job_id);
        }
        
        if ($request->has('branches') && $request->get('branches') != null && $request->get('branches') != '') {
            $applicationsQuery->whereIn('jobs_applications.branch_id', $request->get('branches'));
        }
        
        $applicationsCount = $applicationsQuery->distinct('jobs_applications.id')->count();
        $applications = $applicationsQuery->select('jobs_applications.full_name','jobs_applications.age',
        'jobs_applications.english_level','jobs_applications.status',
        'jobs_applications.email','jobs_applications.created_at','jobs_applications.phone',
        'jobs_applications.job_id','jobs_applications.branch_id','jobs_applications.assigned_employee_id',
        'jobs_applications.id')->groupBy('jobs_applications.id')->withCount('cases')
        ->with('lastcase')->distinct('jobs_applications.id')->orderBy('jobs_applications.id','desc')
        ->paginate($per_page);
        // return $applications;
        //dd(round(microtime(true)*1000)-$testsec);
        return view('jobs_applications.index',compact('applications','applicationsCount','agents','jobs','labelTypes','branches'));
        
    }
    
    public function create()
    {
        $branches = Branch::where('status',1)->pluck('name','id');
        $jobs = Job::pluck('title','id');
        $channels = KnowChannel::where('status',1)->pluck('name', 'id');
        
        return view('jobs_applications.create',compact('branches','jobs','channels'));
    }
    
    public function store(CreateJobApplicationRequest $request)
    {
        $data = $request->except('_token','upload_cv');
        $data['register_from'] = 'create_form';
        
        if($request->hasFile('upload_cv') ){
            $file = $request->file('upload_cv');
            
            $file_name = rand(11111,99999).'-'.$file->getClientOriginalName();
            $file->storeAs('/uploads/jobs_applications_cv', $file_name);
            $data['upload_cv'] = $file_name;
            
            File::move(storage_path('app/uploads/jobs_applications_cv/'.$file_name), '/home/harvestc/public_html/uploads/jobs_applications_cv/'.$file_name);
        }
        
        $application = new JobApplication;
        $application = $application->create($data);
        
        Flash::success('job application request sent successfully.');
        
        return redirect()->route('admin.jobs_applications.index');
    }
    
    public function show($id)
    {
        $job_application = JobApplication::find($id);
        if (empty($job_application)) {
            Flash::error('Job Application not found');
            return redirect(route('admin.jobs_applications.index'));
        }
        return view('jobs_applications.show')->with('job_application', $job_application);
    }
    
    public function edit($id)
    {
        $job_application = JobApplication::find($id);
        if (empty($job_application)) {
            Flash::error('Job Application not found');
            return redirect(route('admin.jobs_applications.index'));
        }
        $branches = Branch::where('status',1)->pluck('name','id');
        $jobs = Job::pluck('title','id');
        
        return view('jobs_applications.edit')->with('job_application', $job_application)->with('branches',$branches)->with('jobs',$jobs);
    }
    
    public function update($id,UpdateJobApplicationRequest $request)
    {
        //dd('ddd');
        $job_application = JobApplication::find($id);
        if(empty($job_application)){
            Flash::error('Job Application not found');
            return redirect(route('admin.jobs_applications.index'));
        }
        $input = $request->all();
        
        if($request->hasFile('upload_cv') ){
            $file = $request->file('upload_cv');
            
            $file_name = rand(11111,99999).'-'.$file->getClientOriginalName();
            $file->storeAs('/uploads/jobs_applications_cv', $file_name);
            $input['upload_cv'] = $file_name;
            
            if($job_application->upload_cv != null && $job_application->upload_cv != ''){
                $file_path = '/home/harvestc/public_html/uploads/jobs_applications_cv/';
                unlink(sprintf($file_path . '%s', $job_application->upload_cv));
            }
            
            File::move(storage_path('app/uploads/jobs_applications_cv/'.$file_name), '/home/harvestc/public_html/uploads/jobs_applications_cv/'.$file_name);
        }
        
        $job_application->update($input);
        
        Flash::success('Job Application updated successfully.');
        return redirect(route('admin.jobs_applications.index'));
    }
    
    public function destroy($id)
    {
        $job_application = JobApplication::find($id);

        if (empty($job_application)) {
            Flash::error('Job Application not found');

            return redirect(route('admin.leads.index'));
        }

        if($job_application->upload_cv != null && $job_application->upload_cv != ''){
            $file_path = '/home/harvestc/public_html/uploads/jobs_applications_cv/';
            unlink(sprintf($file_path . '%s', $job_application->upload_cv));
        }
        
        $job_application->delete();

        Flash::success('Job Application deleted successfully.');

        return redirect(route('admin.jobs_applications.index'));
    }
    
    public function jobsApplicationsAssign(Request $request)
    {
        if (!$request->employee_id) {
            Flash::error('Assigned Employee is required.');
        } elseif ($request->ids != null && count($request->ids) > 0) {
            JobApplication::whereIn('id', $request->ids)->update(['assigned_employee_id' => $request->employee_id]);
            JobApplicationCase::whereIn('job_application_id', $request->ids)->where('status', 0)->update(['employee_id' => $request->employee_id]);

            Flash::success('Assigned Successfully.');
        } else {
            Flash::error('Selected Employees is required.');
        }
        return 0;
    }
    public function head_count(Request $request)
    {
        $branches = Branch::where('status',1)->get();
        return view('hr_reports.head_count',compact('branches'));
    }
    public function database(Request $request)
    {
         $branches = Branch::where('status',1)->pluck('name','id');
        // $employees = Employee::where('status',1)->orderBy('created_at' ,'desc');
        $employees = Employee::where('status',1)->orderBy('created_at' ,'desc');

        $departments = Department::pluck('title','id')->toArray();
        $jobs = Job::pluck('title','id')->toArray();

        // $avg = Employee::where('academic_certificate_image',null);
        
        if($request->has('department_id') && $request->get('department_id') != null && $request->get('department_id') != ''){
            $employees->where('department_id' , $request->get('department_id'));

        }
        if($request->has('current_branch') && $request->get('current_branch') != null && $request->get('current_branch') != ''){
            $employees->where('current_branch' , $request->get('current_branch'));

        }
        if($request->has('job_id') && $request->get('job_id') != null && $request->get('job_id') != ''){
            $employees->where('job_id' , $request->get('job_id'));
        }
        $registration_from=null;
        $reg_to=null;

        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
            
        }
        if ($registration_from != null && $registration_to != '') {
            $employees->whereBetween('created_at', [$registration_from, $registration_to]);
   
        }
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $employees->where(function ($query) use ($request){
                $query->where('first_name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('mobile', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('email', 'like', '%' . $request->get('search') . '%');
            });
        }
        else{
        
            // $employees->whereIn('branch_id', array_keys($employeeBranches));
        }
        
        $employees=$employees->paginate(20);
        // dd($employees);

        // $employees->get();

        
        
        return view('hr_reports.database',compact('employees','departments','jobs','branches'));  
    }

    public function operations_reports(Request $request){
        $labelTypes = LabelType::where('status',1)->where('category',5)->pluck('name','id');
        $labelTypes1 = LabelType::where('status',1)->where('category',5)->pluck('id');

        $registration_from=null;
        $reg_to=null;

        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
            
        }
        if ($registration_from != null && $registration_to != '') {
            $employees = Employee::where('status',1)->where('account_Type', 'H.Q Account')
            ->whereHas('job_application_cases',function($quary)use ($registration_from , $registration_to){
                        $quary->whereBetween('created_at', [$registration_from, $registration_to]);
                    })->with('job_application_cases')->where('status',1);
   
        }else{
            
            $employees = Employee::where('status',1)->where('account_Type', 'H.Q Account')
            ->whereHas('job_application_cases',function($quary){
                        $quary->where('created_at','like','%'.date('Y-m-d').'%');
                    })->with('job_application_cases')->where('status',1);
        }
        $employees = $employees->get();
        
        // return $employees;

        return view('hr_reports.operations_report',compact('labelTypes','employees','labelTypes1'));

    }
    
}