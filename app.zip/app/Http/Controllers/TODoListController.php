<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TODoList;
use App\Models\Department;
use App\Models\TODoListRandom;
use App\Models\Job;
use App\Models\ToDoListJobs;
use App\Models\Notification;
use App\Models\Employee;
use App\Events\MyToDoList;
use Flash;
use DB;
class TODoListController extends Controller
{
     public function getDayInRange($dateFromString, $dateToString,$day)
    {
        $dateFrom = new \DateTime($dateFromString);
        $dateTo = new \DateTime($dateToString);
        $dates = [];
        $dayNum = date_format(date_create($day),'N');
        if ($dateFrom > $dateTo) {
            return $dates;
        }
        
        if ($dayNum != $dateFrom->format('N')) {
            $dateFrom->modify(('next '.$day));
        }
    
        while ($dateFrom <= $dateTo) {
            $dates[] = $dateFrom->format('Y-m-d');
            $dateFrom->modify('+1 week');
        }
    
        return $dates;
    }

    public function index(Request $request) { 
    $todolists = TODoList::with('employee', 'job', 'department', 'created_by')->get();
    $todolists = $todolists->groupBy('dept_id');
    $departmentss = Department::all(); 
    $departments = Department::pluck('title', 'id'); 
    $jobs = [];
    $employees = [];
    $static_tasks = ToDoListJobs::orderBy('type', 'ASC'); // Simplified order by

    $eloquentEvents = TODoListRandom::orderBy('id'); // EventModel implements LaravelFullcalendar\Event
    
    // Check request parameters and add conditions
    if ($request->has('dept_id') && $request->get('dept_id') !== null && $request->get('dept_id') !== '') {
        $static_tasks->where('dept_id', $request->get('dept_id'));
    }
    if ($request->has('job_id') && $request->get('job_id') !== null && $request->get('job_id') !== '') {
        $static_tasks->where('job_id', $request->get('job_id'));
    }
    if ($request->has('employee_id') && $request->get('employee_id') !== null && $request->get('employee_id') !== '') {
        $eloquentEvents->where('employee_id', $request->get('employee_id'));
    }

    // Execute the queries
    $static_tasks = $static_tasks->get(); 
    $eloquentEvents = $eloquentEvents->get();
    
    $events = [];
    $dateFromString = date('Y-m-01');
    $dateToString = date('Y-m-t');
    
    // Process static tasks
    foreach ($static_tasks as $task) {
        if ($task->type == 'Weekly') {
            $tks = $this->getDayInRange($dateFromString, $dateToString, $task->day);
            foreach ($tks as $tk) {
                $events[] = [
                    'title' => $task->text . ' (' . $task->type . ')',
                    'start' => $tk,
                    'end' => $tk,
                ];
            }
        }
        if ($task->type == 'Monthly') {
            $events[] = [
                'title' => $task->text . ' (' . $task->type . ')',
                'start' => $dateToString,
                'end' => $dateToString,
            ];
        }
    }

    // Process eloquent events
    foreach ($eloquentEvents as $event) {
        $events[] = [
            'title' => $event->name . ' (' . $event->type . ')',
            'start' => $event->start_date,
            'end' => $event->end_date,
        ];
    }

    return view('to_do_list.index', compact('todolists', 'events', 'jobs', 'employees', 'departments', 'departmentss', 'jobs', 'employees'));
}

    public function show(Request $request , $id){
        $todolist = TODoList::with('job','TODoListRandom','employee','created_by','department')->find($id);
        $static_tasks = ToDoListJobs::where('job_id',$todolist->job_id)->select('type','text','time','day')
        ->orderByRaw('LENGTH(type)', 'asc')->orderBy('type', 'ASC')->get();
        // return $static_tasks;
        
        return view('to_do_list.show',compact('todolist','static_tasks'));
    }
    public function create(Request $request){
        $departments = Department::pluck('title','id');
        $jobs =[];
        $employee=[];
        
        return view('to_do_list.create',compact('departments','jobs','employee'));
    }
    public function store(Request $request){
        
        $data = $request->validate(
            [
                'department_id' => 'required',
                'job_id'=>'required',
                'employee_id'=>'required',
                'start_date'=>'nullable',
                'start_date1'=>'nullable',
                'end_date'=>'nullable',
                'end_date2'=>'nullable',
                
            ]
        );
        
        $ToDoList = new TODoList;
        $ToDoList->dept_id = $request->department_id;
        $ToDoList->job_id = $request->job_id;
        $ToDoList->employee_id = $request->employee_id;
        $ToDoList->start_date = $request->start_date;
        $ToDoList->end_date = $request->end_date;
        $ToDoList->created_by_id = auth()->user()->id;
        $ToDoList->save();
        $names = $request->name;
        foreach($names as $key=>$name)
        {
            $ToDoListRandom = new TODoListRandom;
            $ToDoListRandom->name = $request->name[$key];
            $ToDoListRandom->type = $request->type[$key];
            $ToDoListRandom->start_date = $request->start_date1[$key];
            $ToDoListRandom->end_date = $request->end_date1[$key];
            $ToDoListRandom->to_do_list_id = $ToDoList->id;
            $ToDoListRandom->employee_id = $request->employee_id;
            $ToDoListRandom->save();
            
        }
        $notification = new Notification;
        $notification->username = $ToDoList->employee_id;
        $notification->message = 'New To Do List ';
        $notification->save();
        
        
        
        
        $data=[
            'start_date'=> $ToDoList->start_date,
            'end_date'=>$ToDoList->end_date,
            'user'=>$ToDoList->employee_id,
            ];
        
        event(new MyToDoList($data));
        Flash::success(' ToDoList Create successfully.');
        return redirect(route('admin.ToDoList.index'));
    }
    public function edit(Request $request,$id){
         $ToDoList = TODoList::with('job','TODoListRandom','employee','created_by','department')->withCount('TODoListRandom')->find($id);
        
        $departments = Department::pluck('title','id');
        $jobs = Job::where('id',$ToDoList->job_id)->pluck('title','id');
        $employee = Employee::where('status',1)->where('job_id',$ToDoList->job_id)->select('first_name', 'last_name','middle_name','id')->get()->pluck('name','id');
        return view('to_do_list.edit',compact('ToDoList','departments','jobs','employee'));
    }
    public function update(Request $request,$id){
         $data = $request->validate(
            [
                'department_id' => 'required',
                'job_id'=>'required',
                'employee_id'=>'required',
                'start_date'=>'nullable',
                'start_date1'=>'nullable',
                'end_date'=>'nullable',
                'end_date2'=>'nullable',
                
            ]
        );
        
        $ToDoList = TODoList::with('TODoListRandom')->withCount('TODoListRandom')->find($id);
        $ToDoList->dept_id = $request->department_id;
        $ToDoList->job_id = $request->job_id;
        $ToDoList->employee_id = $request->employee_id;
        $ToDoList->start_date = $request->start_date;
        $ToDoList->end_date = $request->end_date;
        $ToDoList->save();
        
        $names = $request->name;
        $name_count = count($names);
        if($name_count >= 1){
            TODoListRandom::where('to_do_list_id',$ToDoList->id)->delete();
            foreach($names as $key=>$name)
            {
                $ToDoListRandom = new TODoListRandom;
                $ToDoListRandom->name = $request->name[$key];
                $ToDoListRandom->start_date = $request->start_date1[$key];
                $ToDoListRandom->end_date = $request->end_date1[$key];
                $ToDoListRandom->to_do_list_id = $ToDoList->id;
                $ToDoListRandom->employee_id = $request->employee_id;
                $ToDoListRandom->save();
                
            }
        }
        
        Flash::success(' ToDoList Updated successfully.');
        return redirect(route('admin.ToDoList.index'));
        
    }
    public function destroy($id){
        $ToDoList = TODoList::find($id);
        $ToDoList->delete();
        
        Flash::success(' ToDoList Deleted successfully.');
        
        return redirect(route('admin.ToDoList.index'));
        
    }
    
    public function getemp(Request $request){
        return $employee = Employee::where('status',1)->where('job_id',$request->job_id)->select('first_name', 'last_name','id')->get();
    }
    
   
    public function edittodolist($id,Request $request){
        $TODoListRandom = TODoListRandom::find($id);
        
        return view('to_do_list.updatestatus',compact('TODoListRandom'));
    }
    
    public function updateStatus($id,Request $request){
        $TODoListRandom = TODoListRandom::find($id);
        $TODoListRandom->status = $request->status;
        $TODoListRandom->note = $request->note;
        $TODoListRandom->save();
        
        $employee = $TODoListRandom->TODoList->created_by_id;
     
        
        $notification = new Notification;
        $notification->username = $employee;
        $notification->message = 'Edit To Do List ';
        $notification->save();
        
        
        
        
        $data=[
            'start_date'=> $TODoListRandom->start_date,
            'end_date'=>$TODoListRandom->end_date,
            'user'=>$employee,
            ];
        
        event(new MyToDoList($data));
        

        return redirect(route('admin.employee.getProfile'));
    }
    
    
}
