<?php

namespace App\Http\Controllers;

use Flash;
use Response;
use DB;
use Illuminate\Http\Request;
use App\Models\CertificateRequest;
use App\Models\Lead;
use App\Models\ExtraItem;
use App\Models\GroupStudent;
use Illuminate\Support\Facades\Mail;
use App\Http\Controllers\AppBaseController;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\FromArray;

class CertificateRequestController extends AppBaseController
{
    /**
     * Display a listing of the CertificateRequest.
     *
     * @param Request $request
     *
     * @return Response
     */
 public function index(Request $request)
{
    // Initialize the query
    $requests = CertificateRequest::query();

    // Get certificates for the dropdown
    $certificates = ExtraItem::pluck('name', 'id');

    // Search by name, mobile, or email if the search term is provided
    if ($request->has('search') && $request->get('search') != '') {
        $requests->whereHas('Lead', function ($query) use ($request) {
            $query->where('name', 'like', '%' . $request->get('search') . '%')
                  ->orWhere('mobile_1', 'like', '%' . $request->get('search') . '%')
                  ->orWhere('email', 'like', '%' . $request->get('search') . '%');
        });
    }

    // Filter by date range if provided
    if ($request->has('daterange') && $request->get('daterange') != '') {
        $daterange = explode(' - ', $request->get('daterange'));
        $daterange_from = date_format(date_create($daterange[0]), 'Y-m-d');
        $reg_to = date_create($daterange[1]);
        date_add($reg_to, date_interval_create_from_date_string("1 days"));
        $daterange_to = date_format($reg_to, "Y-m-d");

        // Apply date filter
        $requests->whereBetween('created_at', [$daterange_from, $daterange_to]);
    }

    // Filter by certificate if provided
    if ($request->has('certificate_id') && $request->get('certificate_id') != '') {
        $requests->where('certificate_id', $request->get('certificate_id'));
    }

    // Filter by status if provided
    if ($request->has('status') && $request->get('status') != '') {
        $requests->where('status', $request->get('status'));
    }

    // Get the total count of the requests (for display or pagination purposes)
    $requestCount = $requests->count();

    // Paginate the results
    $requests = $requests->with('Lead')->latest()->paginate($request->get('per_page', 20));

    // Return the view with the necessary data
    return view('certificates_requests.index', compact('requests', 'requestCount', 'certificates'));
}
     
    /**
     * Show the request for creating a new CertificateRequest.
     *
     * @return Response
     */
    public function create()
    {
       
    }
  public function export()
{
    $fileName = 'certificate_requests.xlsx';

    // Fetch the data
    $data = \App\Models\CertificateRequest::with(['Certificate', 'Lead'])
        ->get()
        ->map(function ($request) {
            return [
                'Created At' => $request->created_at,
                'Name' => $request->Lead->getName() ?? '',
                'Mobile' => $request->Lead->mobile_1 ?? '',
                'Display Name' => $request->display_name,
                'Certificate' => $request->Certificate->name ?? '',
                'Invoice ID' => $request->invoice_id,
                'Status' => $request->status,
            ];
        })
        ->toArray();

    // Add the header row
    $header = [
        'Created At',
        'Name',
        'Mobile',
        'Display Name',
        'Certificate',
        'Invoice ID',
        'Status'
    ];

    // Merge the header with the data
    $data = array_merge([$header], $data);

    // Define the export class inline
    $export = new class($data) implements FromArray {
        private $data;

        public function __construct(array $data)
        {
            $this->data = $data;
        }

        public function array(): array
        {
            return $this->data;
        }
    };

    // Return the Excel download
    return Excel::download($export, $fileName);
}
    public function change_status($id , Request $request)
    {
      $certificate = CertificateRequest::with('certificate')->find($id);
      $certificate->status = $request->status;
      $certificate->save();
      Flash::success('Status updated successfully.');
      return redirect(route('admin.certificatesRequests.index'));
     
   
    }

    /**
     * Store a newly created CertificateRequest in storage.
     *
     * @param CreateCertificateRequestRequest $request
     *
     * @return Response
     */
    public function store()
    {
        
    }

    /**
     * Display the specified CertificateRequest.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $request = CertificateRequest::with('certificate','Lead')->find($id);

        if (empty($request)) {
            Flash::error('Certificate request not found');

            return redirect(route('admin.certificatesRequests.index'));
        }
        
        //$lead = Lead::where('mobile_1',$request->phone)->with('branch','payments','assignedEmployee','getLastGroup')->first();
        
        return view('certificates_requests.show',compact('request'));
    }

    /**
     * Show the request for editing the specified CertificateRequest.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
         $certificate = CertificateRequest::with('certificate')->find($id);
         
        return view('certificates_requests.edit',compact('certificate'));
        
        
    }

    /**
     * Update the specified CertificateRequest in storage.
     *
     * @param int $id
     * @param Request $request
     *
     * @return Response
     */
    public function update($id, Request $request)
    {
        $certificate = CertificateRequest::with('certificate')->find($id);
       $certificate->status = $request->status;
       $certificate->save();
       Flash::success('Status updated successfully.');
       return redirect(route('admin.certificatesRequests.index'));
     
    }

    /**
     * Remove the specified CertificateRequest from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        $request = CertificateRequest::find($id);

        if (empty($request)) {
            Flash::error('Certificate Request not found');

            return redirect(route('admin.certificatesRequests.index'));
        }

        $request->delete();

        Flash::success('Contact request deleted successfully.');

        return redirect(route('admin.certificatesRequests.index'));
    }

    /**
     * Display the specified CertificateRequest.
     *
     * @param int $id
     *
     * @return Response
     */
    
}
