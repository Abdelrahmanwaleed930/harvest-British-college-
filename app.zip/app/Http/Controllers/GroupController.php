<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateGroupRequest;
use App\Http\Requests\UpdateGroupRequest;
use App\Http\Controllers\AppBaseController;
use App\Models\Group;
use App\Models\Employee;
use App\Models\Track;
use App\Models\Timeframe;
use App\Models\Round;
use App\Models\Lead;
use App\Models\Room;
use App\Models\Branch;
use App\Models\Stage;
use App\Models\StageLevel;
use App\Models\SubRound;
use App\Models\GroupWaitingList;
use App\Models\GroupSession;
use App\Models\GroupStudent;
use App\Models\StudentExam;

use App\Models\CustomerTrack;
use App\Models\DisciplineCategory;
use App\Models\SubRoundSession;
use App\Models\Interval;
use App\Models\GroupSessionAttendance;
use Illuminate\Http\Request;
use Flash;
use Response;
use DB;
use Auth;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\GroupExport;

use Spatie\Activitylog\Contracts\Activity;
use Carbon\Carbon;
use App\Models\SMS;
use App\Models\WhatsApp;
use App\Models\MessageLog;

class GroupController extends AppBaseController
{
    /**
     * Display a listing of the Group.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        //dd($request->all());
        
        // sat & tues
       /* $sub_rounds = SubRound::where('round_id',8)->where('days',2)->where('end_date','>',date('Y-m-d'))->orderBy('end_date')->get();
        dd($sub_rounds);
        if($sub_rounds != null && count($sub_rounds) > 0){
            for($i = 1;$i < count($sub_rounds);$i++){
                $sub_rounds[$i]->update(['start_date' => $sub_rounds[($i - 1)]->end_date]);
            }
            for($i = 1;$i < count($sub_rounds);$i++){
                $end_date = $sub_rounds[$i]->end_date;
                $day_name = date_format(date_create($end_date),'D');
                if($day_name == 'Sat'){
                    $new_end_date = date('Y-m-d',strtotime($end_date.'-4 days'));
                }else{
                    $new_end_date = date('Y-m-d',strtotime($end_date.'-3 days'));
                }
                $sub_rounds[$i]->update(['end_date' => $new_end_date]);
            }
            $sub_round_sessions = SubRoundSession::whereIn('sub_round_id',$sub_rounds->pluck('id'))->where('id','>=',14447)->orderBy('id','desc')->get();
            
            if($sub_round_sessions != null && count($sub_round_sessions) > 0){
                for($i = 0;$i < (count($sub_round_sessions) - 1);$i++){
                    $sub_round_sessions[$i]->update(['date' => $sub_round_sessions[($i + 1)]->date]);
                }
            }
        }
        
        //sun & wens
        $sub_rounds = SubRound::where('round_id',8)->where('days',3)->where('end_date','>',date('Y-m-d'))->orderBy('end_date')->get();
        if($sub_rounds != null && count($sub_rounds) > 0){
            //dd($sub_rounds);
            for($i = 1;$i < count($sub_rounds);$i++){
                $sub_rounds[$i]->update(['start_date' => $sub_rounds[($i - 1)]->end_date]);
            }
            for($i = 1;$i < count($sub_rounds);$i++){
                $end_date = $sub_rounds[$i]->end_date;
                $day_name = date_format(date_create($end_date),'D');
                //dd($day_name);
                if($day_name == 'Sun'){
                    $new_end_date = date('Y-m-d',strtotime($end_date.'-4 days'));
                }else{
                    $new_end_date = date('Y-m-d',strtotime($end_date.'-3 days'));
                }
                $sub_rounds[$i]->update(['end_date' => $new_end_date]);
            }
            $sub_round_sessions = SubRoundSession::whereIn('sub_round_id',$sub_rounds->pluck('id'))->where('id','>=',14721)->orderBy('id','desc')->get();
            
            if($sub_round_sessions != null && count($sub_round_sessions) > 0){
                for($i = 0;$i < (count($sub_round_sessions) - 1);$i++){
                    $sub_round_sessions[$i]->update(['date' => $sub_round_sessions[($i + 1)]->date]);
                }
            }
        }
        
        //mon & thur
        $sub_rounds = SubRound::where('round_id',8)->where('days',4)->where('end_date','>',date('Y-m-d'))->orderBy('end_date')->get();
        if($sub_rounds != null && count($sub_rounds) > 0){
            //dd($sub_rounds);
            for($i = 1;$i < count($sub_rounds);$i++){
                $sub_rounds[$i]->update(['start_date' => $sub_rounds[($i - 1)]->end_date]);
            }
            for($i = 1;$i < count($sub_rounds);$i++){
                $end_date = $sub_rounds[$i]->end_date;
                $day_name = date_format(date_create($end_date),'D');
                //dd($day_name);
                if($day_name == 'Mon'){
                    $new_end_date = date('Y-m-d',strtotime($end_date.'-4 days'));
                }else{
                    $new_end_date = date('Y-m-d',strtotime($end_date.'-3 days'));
                }
                $sub_rounds[$i]->update(['end_date' => $new_end_date]);
            }
            $sub_round_sessions = SubRoundSession::whereIn('sub_round_id',$sub_rounds->pluck('id'))->where('id','>=',14961)->orderBy('id','desc')->get();
            
            if($sub_round_sessions != null && count($sub_round_sessions) > 0){
                for($i = 0;$i < (count($sub_round_sessions) - 1);$i++){
                    $sub_round_sessions[$i]->update(['date' => $sub_round_sessions[($i + 1)]->date]);
                }
            }
        }
        dd('ddd');
        /*
        $groups = Group::where('round_id',8)->get();
        foreach($groups as $group){
            $group_sessions = $group->sessions;
            if($group_sessions != null && count($group_sessions) > 0){
                $round_sessions = SubRoundSession::where('sub_round_id',$group->sub_round_id)->get();
                if($round_sessions != null && count($round_sessions) > 0){
                    foreach($group_sessions as $key => $group_session){
                        $group_session->date = $round_sessions[$key]->date;
                        $group_session->save();
                    }
                }
            }
        }
        */
        $per_page = 20;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        $branches = Branch::pluck('name', 'id')->toArray();
        $admins = [];
        $instructors = [];
        if($request->has('branch_id') && $request->get('branch_id') != '' && $request->get('branch_id') != null){
            $admins = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->where('id', $request->get('branch_id'));
                            })->get()->pluck('name', 'id')->toArray();
                            
            $instructors = Employee::where('account_Type', 'ESL Account Profile')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->where('id', $request->get('branch_id'));
                            })->get()->pluck('name', 'id')->toArray();
                            // dd($request);

        }
        else{
            $admins = Employee::where('account_Type', 'Operations Account')->where('status',1)
                         ->whereHas('branches', function ($query) use ($branches) {
                             $query->whereIn('id', array_keys($branches));
                         })->get()->pluck('name', 'id')->toArray();
                            
            $instructors = Employee::where('account_Type', 'ESL Account Profile')->where('status',1)
                         ->whereHas('branches', function ($query) use ($branches) {
                             $query->whereIn('id', array_keys($branches));
                         })->get()->pluck('name', 'id')->toArray();
        }
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id');
        //$this->rounds = Round::pluck('title', 'id')->toArray();
        $disciplines = DisciplineCategory::pluck('name', 'id')->toArray();
        $courses = [];
        $stageLevels = [];
        $timeframes = [];
        $rounds = [];
        $daysData = [];
        $intervals = [];
        $subRounds = [];
        $rooms = [];
        
        $groupsQuery = Group::with('subRound')->withCount('students', 'sessions');
        
        
        if($request->has('discipline_id') && $request->get('discipline_id') != null && $request->get('discipline_id') != ''){
            $groupsQuery->whereIn('discipline_id',$request->get('discipline_id'));
        }
        
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $groupsQuery->where('code','like','%'.$request->get('search').'%');
        }
        
        if($request->has('track_id') && $request->get('track_id') != null && $request->get('track_id') != ''){
            $courses = Track::where('status',1)->where('parent_id',$request->get('track_id'))->pluck('title','id');
            $groupsQuery->where('track_id',$request->get('track_id'));
        }
        
        if($request->has('course_id') && $request->get('course_id') != null && $request->get('course_id') != ''){
            $groupsQuery->where('course_id',$request->get('course_id'));
            $stageLevels = Track::find($request->get('course_id'))->stageLevels->pluck('name', 'id')->toArray();
            $timeframe_ids = DB::table('timeframe_courses')->where('course_id',$request->get('course_id'))->pluck('timeframe_id')->toArray();
            $timeframes = Timeframe::whereIn('id',$timeframe_ids)->where('status',1)->pluck('title','id')->toArray();
        }
        
        if($request->has('level_id') && $request->get('level_id') != null && $request->get('level_id') != ''){
            $groupsQuery->where('level_id',$request->get('level_id'));
        }
        
        if($request->has('timeframe_id') && $request->get('timeframe_id') != null && $request->get('timeframe_id') != ''){
            $groupsQuery->where('timeframe_id',$request->get('timeframe_id'));
            $rounds = Round::where('timeframe_id',$request->get('timeframe_id'))->pluck('title', 'id')->toArray();
        }
        
        if($request->has('round_id') && $request->get('round_id') != null && $request->get('round_id') != ''){
            $groupsQuery->where('round_id',$request->get('round_id'));
            $round = Round::with('timeframe.intervals')->find($request->get('round_id'));

            $daysData = $round->timeframe->days;
            $intervals = $round->timeframe->intervals->pluck('name', 'id')->toArray();
            
        }
        if($request->has('days') && $request->get('days') != null && $request->get('days') != ''){
            $groupsQuery->where('days',$request->get('days'));
            $subRounds = SubRound::where('days', $request->get('days'))
                                -> where('round_id', $request->get('round_id'))
                                // -> whereDate('start_date', '>=', now())
                                -> orderBy('start_date')->pluck('start_date', 'id');
        }
        
        if($request->has('interval_id') && $request->get('interval_id') != null && $request->get('interval_id') != ''){
            $groupsQuery->where('interval_id',$request->get('interval_id'));
            $request->instructor_id = '';
        }
        
        if($request->has('sub_round_id') && $request->get('sub_round_id') != null && $request->get('sub_round_id') != ''){
            $groupsQuery->where('sub_round_id',$request->get('sub_round_id'));
        }
        
        if($request->has('branch_id') && $request->get('branch_id') != '' && $request->get('branch_id') != null){
            $groupsQuery->where('branch_id',$request->get('branch_id'));
            $rooms = Room::where('branch_id', $request->get('branch_id'))->pluck('name', 'id');
        }else{
            $branches_ids = auth()->user()->branches->pluck('id')->toArray();

            $groupsQuery->whereIn('branch_id',$branches_ids);
            // return $groupsQuery->orderBy('created_at' )->get();
        }
        
        if($request->has('instructor_id') && $request->get('instructor_id') != '' && $request->get('instructor_id') != null){
            $groupsQuery->where('instructor_id',$request->get('instructor_id'));
        }
        
        if($request->has('room_id') && $request->get('room_id') != '' && $request->get('room_id') != null){
            $groupsQuery->where('room_id',$request->get('room_id'));
        }
        
        if($request->has('admin_id') && $request->get('admin_id') != '' && $request->get('admin_id') != null){
            $groupsQuery->where('admin_id',$request->get('admin_id'));
        }
        
        if($request->has('status') && $request->get('status') != '' && $request->get('status') != null){
            if($request->get('status') == 'complete'){
                $groupsQuery->whereHas('subRound',function($query){
                    $query->where('end_date','<',date('Y-m-d'));
                });
            } 
            if($request->get('status') == 'upcoming'){
                $groupsQuery->whereHas('subRound',function($query){
                    $query->where('start_date','>',date('Y-m-d'));
                });
            }
            if($request->get('status') == 'running'){
                $groupsQuery->whereHas('subRound',function($query){
                    $query->where('start_date','<=',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
                });
            }
        }
        
        if(count($request->all()) == 0){
            $groupsQuery->whereHas('subRound',function($query){
                $query->where('start_date','<=',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
            });
        }
        $groupsCount = $groupsQuery->count();
        $groups = $groupsQuery->with('parent', 'round', 'discipline', 'branch', 'room', 'instructor', 'interval')
            ->orderBy('round_id')
            ->orderBy('sub_round_id')
            ->orderBy('days')
            ->orderBy('interval_id')
            ->paginate($per_page);
        
        // $groups = $groups->groupBy('round_id');
        
        
        // return $groups;
        return view('groups.index',compact('groups','admins','groupsCount','branches','tracks','disciplines','courses','stageLevels','timeframes','rounds','daysData','intervals','subRounds','instructors','rooms'));
    }
    
    // start filter group

    public function gettrack(Request $request)
    {
        $tracks=[];
        $subtracks=[];
        $tracks = Track::where('status',1)->whereNull('parent_id')->select('title', 'id')->get();

        $subtracks = $tracks->groupBy('parent_id');
        return json_decode($subtracks);
       

    }
    public function getsubtrackgroup(Request $request)
    {
        // $tracks=[];
        $subtrack=[];
        $subtrack = Track::where('status',1)->where('parent_id' , $request->track_id)->select('title', 'id')->get();

        return json_decode($subtrack);

    }
    public function getlevels(Request $request)
    {
        $stageLevels=[];
        // $stageLevels = Track::find($request->course_id)->stageLevels;
        $stageLevels = Track::find($request->course_id)->stageLevels;
        // $levels = Track::where('status',1)->where('levels' , $request->levels)->get();
        return $stageLevels;
    }

    public function gettimeframes(Request $request)
    {
        $timeframes=[];
        $timeframe_ids=[];
        $timeframe_ids = DB::table('timeframe_courses')->where('course_id',$request->course_id)->pluck('timeframe_id');
        $timeframes = Timeframe::whereIn('id',$timeframe_ids)->where('status',1)->get();
     
        return  $timeframes;
    }

    public function getround(Request $request)
    {
        $round=[];
        $round = Round::where('timeframe_id',$request->timeframe_id)->select('title', 'id')->get();

        // $round = Round::find($request->round_id);
       return $round;
    }
    public function getsubround(Request $request)
    {
        $round=[];
        
        $round = Round::find($request->round_id);
        $subround=[];
        $subround=SubRound::where('round_id',$round->id)->select('id','start_date')->get();
        return $subround ;

    }

    public function getinterval(Request $request)
    {
        $round = Round::with('timeframe.intervals')->find($request->round_id);

            // $daysData = $round->timeframe->days;
        $intervals=[];
        $intervals = $round->timeframe->intervals;
            
        return $intervals;
    }

    public function getday(Request $request)
    {
        // $daysData=[];
        $round = Round::with('timeframe.intervals')->find($request->round_id);

        $daysData = $round->timeframe->days;
        $html1 ='<option></option>';
        
        // for( $i = 0; $i < $length; $i++) {
        //                     // $html1 +=  data2[i] ;
        //     $html1 += '<option value="' + $daysData[$i] + '" >' + $datasData[$i] + '</option>';
        //  }
        foreach ($daysData as $data) {
            $html1 .= '<option value="' .$data . '" >' .config('system_variables.timeframes.days')[$data] . '</option>';
        }
        // sel2.html(html1);
       


        // return $daysData;
        return $html1;

    }
    
    public function getemployee(Request $request)
    {
        $branches=[];
        $admins=[];
        $branches = Branch::pluck('name', 'id');
        $admins = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->where('id', $request->branch_id);
                            })->select('first_name', 'last_name','id')->get();
        return $admins ;

    }
    public function getallemployee(Request $request)
    {
        $branches=[];
        $admins=[];
        $branches = Branch::pluck('name', 'id');
        $admins = Employee::where('status',1)->where('department_id',$request->department_id)
        ->select('first_name', 'last_name','id')->get();
        return $admins ;

    }
    
    public function getRoomsInstructors(Request $request)
    {
        $rooms = Room::where('branch_id', $request->branch_id)->pluck('name', 'id');
            
        $busy_rooms = [];
    
        if ($request->days && $request->sub_round_id && $request->interval_id) {
            $busy_rooms = Group::where(['branch_id' => $request->branch_id,'days' => $request->days,'sub_round_id' => $request->sub_round_id, 'interval_id' => $request->interval_id])
                ->pluck('room_id')->toArray();
        }
        
        $rooms_html = '<option value="">Select Option...</option>';
        foreach($rooms as $key => $room){
            $rooms_html .= '<option value="'.$key.'"'. ((in_array($key,$busy_rooms))?'disabled':'').'>'.$room.((in_array($key,$busy_rooms))?'(Busy)':'').'</option>';
        }
        
        $instructorsQuery = Employee::where('status',1)->where('account_Type', 'ESL Account Profile')->whereHas('attendances',function($query) use ($request){
            $query->where('day',$request->days)->where('interval_id',$request->interval_id);
        });

        if ($request->branch_id) {
            $instructorsQuery->whereHas('branches', function ($query) use ($request){
                $query->where('id', $request->branch_id);
            });
        }else{
            $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
            $instructorsQuery->whereHas('branches', function ($query) use ($employeeBranches){
                $query->whereIn('id', array_keys($employeeBranches));
            });
        }
        
        $instructors = $instructorsQuery->get()->pluck('name', 'id')->toArray();
        $busy_instructors = [];
        
        if ($request->days && $request->sub_round_id && $request->interval_id) {
            $busy_instructors = Group::where(['days' => $request->days,'sub_round_id' => $request->sub_round_id, 'interval_id' => $request->interval_id])
                ->pluck('instructor_id')->toArray();

        }
        $instructors_html = '<option value="">Select Option...</option>';
        foreach($instructors as $key => $instructor){
            $instructors_html .= '<option value="'.$key.'"'. ((in_array($key,$busy_instructors))?'disabled':'').'>'.$instructor.((in_array($key,$busy_instructors))?'(Busy)':'').'</option>';
        }
        
        return response()->json(['rooms_html' => $rooms_html,'instructors_html' => $instructors_html]);
    }
    
    public function getinstructor(Request $request)
    {
        
        $branches=[];
        $instructors=[];
        $branches = Branch::pluck('name', 'id');                            
        $instructors = Employee::where('account_Type', 'ESL Account Profile')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->where('id', $request->branch_id);
                            })->select('first_name','last_name', 'id')->get();

        return $instructors;


    }

    public function getroom(Request $request)
    {
        $rooms=[];
        $rooms = Room::where('branch_id', $request->branch_id)->select('name', 'id')->get();
        return $rooms;

    }

    // end filter group
    public function groupsSendmsg(Request $request)
    {
        //dd($request->all());
        if (!$request->message) {
            Flash::error('Message is required.');
        } elseif ($request->ids != null && count($request->ids) > 0) {
            if($request->type == 'sms'){
                $sms = new SMS;
    
                $groupStudentsMobile = GroupStudent::whereIn('group_id', $request->ids)->with('lead')->get()->pluck('lead.mobile_1', 'lead_id')->toArray();
                $mobiles = array_unique($groupStudentsMobile);

                $msg = $request->message;
    
                $sms->send($mobiles, $msg);
    
                $log = MessageLog::create([
                    'type' => 1,
                    'content' => $msg,
                    'employee_id' => auth()->id(),
                ]);
                $log->leads()->sync(array_keys($mobiles));
            }else{
                $whatsApp = new WhatsApp;

                $groupStudentsMobile = GroupStudent::whereIn('group_id', $request->ids)->with('lead')->get()->pluck('lead.mobile_1', 'lead_id')->toArray();
                $mobiles = array_unique($groupStudentsMobile);

                $msg = $request->message;
    
                $whatsApp->send($mobiles, $msg);
    
                $log = MessageLog::create([
                    'type' => 2,
                    'content' => $msg,
                    'employee_id' => auth()->id()
                ]);
                $log->leads()->sync(array_keys($mobiles));

            }
            Flash::success('Sent Successfully.');

        } else {
            Flash::error('Selected Employees is required.');
        }
        return 0;
    }
    
    public function getWaitingList(Request $request)
    {
         $group = Group::with('level', 'students', 'discipline','branch','timeframe','track' ,'round','subRound','interval')->find($request->group_id);
        
        //$branch_leads_ids = Lead::where('branch_id',$group->branch_id)->where('type',2)->pluck('id')->toArray();
        
        $level_id = $group->level->id;
        $oldStudents = $group->students->pluck('lead_id')->toArray();

        $waitingLists = GroupWaitingList::join('leads','leads.id','=','group_waiting_lists.lead_id')
            ->where('group_waiting_lists.level_id', $level_id)
            // ->where('group_waiting_lists.track_id', $group->track->id)
            ->where('leads.branch_id',$group->branch_id)
            ->whereNotIn('group_waiting_lists.lead_id', $oldStudents)
            //->where('timeframes',$group->timeframe_id)
            ->where('group_waiting_lists.discipline_id',$group->discipline_id)
            ->select('group_waiting_lists.*')
            ->with('lead')
            ->get();

            // return $waitingLists;
        $html = '<option></option>';
        $check=[];
        foreach($waitingLists as $waitingList){
            $check = CustomerTrack::where('lead_id',$waitingList->lead_id)->first();
      
            if($check !=null && $check != ''){
                if($check->total > $check->used && $waitingList->lead){
                    $html .= '<option value="'.$waitingList->id.'">'.$waitingList->lead->getName().' / '.$waitingList->lead->mobile_1.' / '.$waitingList->lead->mobile_2.' / '.$waitingList->lead->email.'</option>';
                }   
            }else{
                $html.='';
            }
        }
          
        //dd($waitingLists);
        return response()->json(['html' => $html]);
    }
    
    public function addStudents(Request $request)
    {
        
        $group = Group::withCount('students')->find($request->group_id);
        
        $maxStudent = $group->discipline->max_student;
        //dd($maxStudent);
        $students_ids = $request->students;
        if (count($students_ids) == 0) {
            Flash::error("The students field is required.");
            return redirect()->back();
        }
        $total_students_count = count($students_ids) + $group->students_count;
        if ($total_students_count > $maxStudent) {
            Flash::error("The students may not have more than $maxStudent items.");
            return redirect()->back();
        }
        
        $lists = GroupWaitingList::with('lead', 'level')->where('track_id',$group->track_id)->whereIn('id', $students_ids)->get();
        
        $mobiles = [];
        //dd($lists,$students_ids,$group);
        foreach ($lists as $list) {
            $lead = $list->lead;
            $payment = $list->payment;
            $lead->groups()->attach($group->id, [
                'level_id' => $group->level_id,
                'payment' => (($payment != null && $payment != '') && ($payment->payment_plan_id == 1 || $payment->rest == 0))?1:0,
                'lead_payment_id' => ($payment != null && $payment != '')?$payment->lead_payment_id:null,
            ]);
            if($lead->customer_to_client == null){
                
              $group_count = GroupStudent::where('lead_id',$lead->id)->count();    
             $lead->customer_to_client= date('Y-m-d h:i:sa');
             if($group_count >= 1)
             {
                if($lead->customer_type == null)
                {
                   $lead->customer_type = "missing"; 
                }
             }else{
                $lead->customer_type = "sales"; 
             }
             
            

             $lead->save();
            }
            $track = CustomerTrack::where('track_id',$group->track_id)->where('lead_id', $lead->id)->first();
            
            $track->last_group_id = $group->id;
            $track->last_level_id = $group->level_id;
            $track->save();

            // $lead->update(['type' => 3]);
             $lead->type = 3;
             
             $lead->save();

            $sessions = GroupSession::with('level')->where('group_id', $group->id)->get();
            foreach ($sessions as $session) {
                $session->attendances()->create([
                    'lead_id' => $lead->id,
                    'group_id' => $session->group_id,
                    'level_id' => $session->level_id,
                ]);
            }
            if($group->course_id == 13)
            {
                // create student exam
                // $group_student = GroupStudent::where('group_id',$group->id)->where('lead_id',$lead->id)->where('level_id',$group->level_id)->first();
                //  $group_student->Confirmation = 1;
                // $group_student->save();
                
                $student_exam = StudentExam::updateOrCreate([
                    'group_id' => $group->id,
                    'lead_id' => $lead->id,
                    'track_id' => $group->track_id,
                    'course_id' => $group->course_id,
                    'level_id' => $group->level_id,
                    'student_id' => $group_student->id,
                    'finish'=>1,
                ]);
                
            }

            $mobiles[$lead->id] = $lead->mobile_1;
            $list->delete();
            
            
         activity('Groups')
           ->causedBy(Auth::user()->id)
           ->performedOn($lead)
           ->withProperties(['group_id' =>$group->id ])
           ->log('Add Student');

        }


        // $whatsApp = new WhatsApp;
        // $buttons = [
            
        //     'templateButtons' => [
        //         ['index' => 1, 'urlButton' => ['displayText' => 'Visit your profile', 'url' => 'https://harvestcollege.co.uk/customerPortal/courses']],
        //     ],
             
        // ];
         
        // $msg = 'جاهزين نبدأ رحلتنا؟😎
        // معاك Harvest  هنكون بنتابع معاك دايما من 11صباحا ل9 مساءا ماعدا الجمعة
        // حابين حابين نأكد مع حضرتك ان بداية موعدك الدراسى يوم'. config('system_variables.timeframes.days')[$group->days]  .  
        // 'من الساعة '. $group->interval->name .'
        // فى دبلومة '. $group->course->title .' 
        // فى الفترة '. $group->subRound->start_date  .'-'.  $group->subRound->end_date .'
        // فى فرع '. $group->branch->name  .'
        
        // بنتمنالك يوم سعيد و وقت مميز تقضيه معانا🌸
        // Have a nice day🌸
        // لتأكيد الحجز
        // ';

        // // $whatsApp->send($mobiles, $msg ,$buttons);

        // $log = MessageLog::create([
        //     'type' => 2,
        //     'content' => $msg
        // ]);
        // $log->leads()->sync(array_keys($mobiles));

        // $sms = new SMS;
        // $msg = "You had been assigned to new group. Group Number:" . $group->id;
        // $sms->send($mobiles, $msg);

        // $log = MessageLog::create([
        //     'type' => 1,
        //     'content' => $msg
        // ]);
        // $log->leads()->sync(array_keys($mobiles));
        
        Flash::success('Students Added Successfully.');
        return redirect()->back();

    }
    
    public function HoldStudents(Request $request)
    {

        $confirmation =  GroupStudent::where('lead_id' , $request->lead_id)->where('group_id',$request->group_id)->first();
        //    return $confirmation;
        $group = Group::find($request->group_id);
        $track = CustomerTrack::where('lead_id',$request->lead_id)->where('track_id',$group->track_id)->first();
        if($confirmation->Confirmation == 1 && ! ($confirmation->exam_per != null && $confirmation->exam_per != ''))
        {
            $customer_track = CustomerTrack::where('lead_id',$request->lead_id)->where('track_id',$group->track_id)->first();
            if($customer_track->used > 0 )
            {
                $customer_track->used -= 1;
                $customer_track->save();
            }else{
                
            }
            
        }
        GroupStudent::where('id',$request->student_id)->delete();
        GroupSessionAttendance::where('lead_id',$request->lead_id)->where('group_id',$request->group_id)->delete();
        
        GroupWaitingList::where('lead_id',$request->lead_id)->where('track_id',$group->track_id)->delete();
        $waiting_list = new GroupWaitingList;
        $waiting_list->create([
            'lead_id' => $request->lead_id,
            'level_id' => $request->level_id,
            'track_id' => $group->track_id,
            'course_id' => $group->course_id,
            'timeframes' => $group->timeframe_id,
            'discipline_id' => $group->discipline_id,
        ]);
        $lead = Lead::find($request->lead_id);
        $lead->type = 2;
        $lead->customer_type = "missing";
        $lead->save();
        
        
        $track->last_group_id = null;
        $track->last_level_id = $request->level_id;
        $track->save();

        
         activity('Group Student')
           ->causedBy(Auth::user()->id)
           ->performedOn($lead)
           ->withProperties(['group_id' =>$group->id ])
           ->log('Hold Student ');
        
        return redirect()->back();
    }
    
    public function FreezeStudents(Request $request)
    {
        $confirmation =  GroupStudent::where('lead_id' , $request->lead_id)->where('group_id',$request->group_id)->first();
        $group = Group::find($request->group_id);
        $customer_track = CustomerTrack::where('lead_id',$request->lead_id)->where('track_id',$group->track_id)->first();
        if($confirmation->Confirmation == 1)
        {
            // $customer_track = CustomerTrack::where('lead_id',$request->lead_id)->first();
            $customer_track->used -= 1;
            $customer_track->save();
        }
        GroupStudent::where('id',$request->student_id)->delete();
        GroupSessionAttendance::where('lead_id',$request->lead_id)->where('group_id',$request->group_id)->delete();
        
        GroupWaitingList::where('lead_id',$request->lead_id)->delete();
        $waiting_list = new GroupWaitingList;
        $waiting_list->create([
            'lead_id' => $request->lead_id,
            'level_id' => $request->level_id,
            'track_id' => $group->track_id,
            'course_id' => $group->course_id,
            'timeframes' => $group->timeframe_id,
            'discipline_id' => $group->discipline_id,
        ]);
        $lead = Lead::find($request->lead_id);
        $lead->type = 2;
        $lead->customer_type = "freeze";
        $lead->save();
        
    
        $customer_track->last_group_id = null;
        $customer_track->last_level_id = $request->level_id ;
        $customer_track->save();
        
         activity('Group Student')
           ->causedBy(Auth::user()->id)
           ->performedOn($lead)
           ->withProperties(['group_id' =>$group->id ])
           ->log('Freeze Student ');
        
        return redirect()->back();
    }
    
    /*public function TransferStudents(Request $request)
    {
        $student = GroupStudent::findOrFail($request->student_id);
        $confirmation =  GroupStudent::where('lead_id' , $student->lead_id)->where('group_id',$student->group_id)->first();
        
        GroupSessionAttendance::where('lead_id',$student->lead_id)->where('group_id',$student->group_id)->delete();
        
        
        //    return $confirmation;
      if($confirmation->Confirmation == 1)
        {
            $student->Confirmation = 1;
        }
        else{
            $student->Confirmation = 0;

        }
        
        
        $student->group_id = $request->group_id;

        $student->save();
        
        $sessions = GroupSession::with('level' ,'group')->where('group_id', $request->group_id)->get();
        
        foreach ($sessions as $session) {
            $session->attendances()->create([
                'lead_id' => $student->lead_id,
                'group_id' => $session->group_id,
                'level_id' => $session->level_id,

            ]);
            
        }
        
        activity('Group Student')
         ->causedBy(Auth::user()->id)
         ->performedOn($student->lead)
         ->withProperties(['group_id' =>$request->group_id ])
         ->log('Transfer Student ');
            
        $group_id = $request->group_id;
        $group = Group::find($group_id);
        
        $mobiles=[];
        $lead = Lead::find($student->lead_id);
        $mobiles[] = $lead->mobile_1;
        // dd($mobiles);
        // dd($group);
        
        // $whatsApp = new WhatsApp;
               
        // $buttons = [
            
        //     'templateButtons' => [
        //         ['index' => 1, 'urlButton' => ['displayText' => 'Visit your profile', 'url' => 'https://harvestcollege.co.uk/customerPortal/courses']],
        //     ],
             
        // ];
              $msg = 'جاهزين نبدأ رحلتنا؟😎
              معاك Harvest  هنكون بنتابع معاك دايما من 11صباحا ل9 مساءا ماعدا الجمعة
              حابين حابين نأكد مع حضرتك ان بداية موعدك الدراسى يوم'. config('system_variables.timeframes.days')[$group->days]  .  
              'من الساعة '. $group->interval->name .'
              فى دبلومة '. $group->course->title .' 
              فى الفترة '. $group->subRound->start_date  .'-'.  $group->subRound->end_date .'
              فى فرع '. $group->branch->name  .'
              
              بنتمنالك يوم سعيد و وقت مميز تقضيه معانا🌸
              Have a nice day🌸
              لتأكد الحجز
              ';
            //   $whatsApp->send($mobiles, $msg ,$buttons);
      
              $log = MessageLog::create([
                  'type' => 2,
                  'content' => $msg
              ]);
              $log->leads()->sync(array_keys($mobiles));
      
        return redirect()->back();
    }*/
    public function TransferStudents(Request $request)
    {
        
        if (!$request->group_id) {
            Flash::error('Group is required.');
        } elseif ($request->ids != null && count($request->ids) > 0) {
            $leads = Lead::whereIn('id', $request->ids)->get();
            $student = GroupStudent::whereIn('id', $request->ids)->get();
            // $confirmation =  GroupStudent::where('lead_id' , $student->lead_id)->where('group_id',$student->group_id)->first();
            
            $sessions = GroupSession::with('level' ,'group')->where('group_id', $request->group_id)->get();
            foreach($student as $stu)
            {
                $confirmation =  GroupStudent::where('lead_id' , $stu->lead_id)->where('group_id',$stu->group_id)->first();
                
                
                if($confirmation->Confirmation == 1)
                {
                    $stu->Confirmation = 1;
                }
                else{
                    $stu->Confirmation = 0;
                }
                GroupSessionAttendance::where('lead_id',$stu->lead_id)->where('group_id',$stu->group_id)->delete();
                $group = Group::where('id',$request->group_id)->first();
                $customer_track = CustomerTrack::where('lead_id',$stu->lead_id)->where('track_id',$group->track_id)->first();
                // $lead = Lead::where('id',$stu->lead_id)->first();
                $customer_track->last_group_id = $request->group_id;
                $customer_track->last_level_id = $group->level_id;
                $customer_track->save();
                
                foreach ($sessions as $session) {
                $session->attendances()->create([
                    'lead_id' => $stu->lead_id,
                    'group_id' => $session->group_id,
                    'level_id' => $session->level_id,
    
                ]);
                $stu->group_id = $request->group_id;
                $stu->absence_per = null;
                $stu->exam_per = null;
                $stu->exam_status = null;
                $stu->save();
                
                

        
            }
            
            
            
        }
            
      
        return redirect()->back();
    }
    }
    /**
     * Show the form for creating a new Group.
     *
     * @return Response
     */
    public function create()
    {
        $tracks = Track::whereNull('parent_id')->pluck('title', 'id')->toArray();
        $sub_tracks = Track::whereNotNull('parent_id')->get();
        $sub_tracks = $sub_tracks->groupBy('parent_id');
        
        $levels = StageLevel::join('stages','stages.id','=','stage_levels.stage_id')
            ->select('stages.track_id','stage_levels.id','stage_levels.name','stage_levels.value')->get();
        $levels = $levels->groupBy('track_id');    
        
        $timeframes = Timeframe::join('timeframe_courses','timeframe_courses.timeframe_id','=','timeframes.id')
            ->where('timeframes.status',1)->select('timeframe_courses.course_id','timeframes.id','timeframes.title','timeframes.days')->get();
        $daysData = $timeframes->pluck('days','id');
        $timeframes = $timeframes->groupBy('course_id'); 
        //dd($daysData);
        
        $rounds = Round::all();
        $rounds = $rounds->groupBy('timeframe_id');
        
        $sub_rounds = SubRound::whereDate('end_date', '>', now())->orderBy('start_date')->take(36)->get();
        $sub_rounds = $sub_rounds->groupBy('round_id');
        //dd($sub_rounds[15]);
        $intervals = Interval::join('interval_timeframe','intervals.id','=','interval_timeframe.interval_id')
            ->select('interval_timeframe.timeframe_id','intervals.name','intervals.id')->where('intervals.status',1)->orderBy('intervals.sort')->get();
        $intervals = $intervals->groupBy('timeframe_id');
        
        //$this->rounds = Round::pluck('title', 'id')->toArray();
        $disciplines = DisciplineCategory::pluck('name', 'id')->toArray();
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $employeeBranches = $employeeBranches;
        $branches = $employeeBranches;
        $admins = Employee::join('branches_employees','branches_employees.employee_id','=','employees.id')
            ->where('employees.status',1)->where('employees.account_Type', 'Operations Account')
            ->select('employees.id','employees.first_name','employees.middle_name','employees.last_name','branches_employees.branch_id')->get();
        $admins = $admins->groupBy('branch_id');
        
        return view('groups.create',compact('tracks','sub_tracks','levels','timeframes','sub_rounds','rounds','daysData','intervals','disciplines','branches','admins'));
    }

    /**
     * Store a newly created Group in storage.
     *
     * @param CreateGroupRequest $request
     *
     * @return Response
     */
    public function store(CreateGroupRequest $request)
    {
        $data = $request->all();
        
        foreach($data as $key => $value){
            if($value == ''){
                $data[$key] = null;
            }
        }
        //dd($data);

        $subRound = SubRound::with('round.timeframe')->find($data['sub_round_id']);
        $interval = Interval::find($data['interval_id']);
        $data['title'] = "group " . $subRound->round->timeframe->title . " | " . $interval->name;
        
        $last_group = Group::orderBy('id','desc')->first();
        $data['code'] = ($last_group)?sprintf("%07d",($last_group->id + 1)):sprintf("%07d",1);
        
        $group = Group::create($data);

        $dates = SubRoundSession::where('sub_round_id', $group->sub_round_id)->pluck('date')->toArray();

        //$levels = $data['levels'];
        //$levelsCount = count($levels);
        $perSession = count($dates) - 1;
        $end = end($dates);

        //$key = 0;
        //$i = 1;
        foreach ($dates as $date) {
            $sessionData = [
                'group_id' => $group->id,
                'date' => $date,
                'room_id' => $group->room_id,
                'instructor_id' => $group->instructor_id,
                'interval_id' => $group->interval_id,
                'level_id' => $group->level_id,
            ];
            GroupSession::create($sessionData);
        }
        activity('Groups')
           ->causedBy(Auth::user()->id)
           ->performedOn($group)
      //   ->withProperties(['group_id' =>$group->id ])
           ->log('create group');
           
        
        if($request->is_upgraded == 1 ){
            //$level = StageLevel::find($group->level_id);
            $count=0;
            $stages_ids = Stage::where('track_id',$group->course_id)->pluck('id');
            $next_levels = StageLevel::whereIn('stage_id',$stages_ids)->where('id','>',$group->level_id)->orderBy('value')->take(3)->get();
            $next_sub_rounds = SubRound::where('round_id',$group->round_id)->where('days',$group->days)->where('id','>',$group->sub_round_id)->orderBy('id')->take(3)->get();
            if($next_levels != null && count($next_levels) > 0){
                foreach($next_levels as $key => $next_level){
                    
                    if(isset($next_sub_rounds[$key])){
                        $next_sub_round = $next_sub_rounds[$key];
                    }else{
                          
                          if($next_sub_rounds != null && count($next_sub_rounds) > 0){
                              $last_sub_round = $next_sub_rounds->last();
                          }else{
                              $last_sub_round = SubRound::find($group->sub_round_id);
                          }
                          $timeframe = Round::with('timeframe')->find($group->round_id)->timeframe;
                          $total_hours = $timeframe->total_hours;
                          $session_hours = $timeframe->session_hours;
                          $session_count = ($total_hours / $session_hours) + 1;
                          
                          $last_session_date = Carbon::parse($last_sub_round->subRoundSessions->last()->date);
                          $days = explode('/', config('system_variables.timeframes.days')[$last_sub_round->days]);
                          $startDate = $last_session_date->next($days[0]);
                          $n = 1;
                          while ($n <= 30) {
                              $new_subRound = SubRound::create([
                                  'round_id' => $group->round_id,
                                  'days' => $group->days,
                                  'start_date' => $startDate,
                              ]);
  
                              $days = explode('/', config('system_variables.timeframes.days')[$last_sub_round->days]);
                              $daysObj = new ArrayObject($days);
                              $daysIt = $daysObj->getIterator();
                              $date = $startDate;
                              for ($i = 0; $i < $session_count; $i++) {
                                  if ($i) {
                                      if (!$daysIt->valid()) {
                                          $daysIt->rewind();
                                      }
                                      $date = $date->next($daysIt->current());
                                  }
                                  $session = SubRoundSession::create([
                                      'sub_round_id' => $new_subRound->id,
                                      'date' => $date,
                                  ]);
                                  $daysIt->next();
                              }
                              $new_subRound->update(['end_date' => $session->date]);
                              $startDate = $date->next($days[0]);
                              $n++;
                          }
                          
                          $next_sub_rounds = SubRound::where('round_id',$group->round_id)->where('days',$group->days)->where('id','>',$group->sub_round_id)->orderBy('id')->get();
                          $next_sub_round = $next_sub_rounds[$key];
                          
                      }
                      $next_group_data = [
                          'track_id' => $group->track_id,
                          'level_id' => $next_level->id,
                          'course_id' => $group->course_id,
                          'timeframe_id' => $group->timeframe_id,
                          'round_id' => $group->round_id,
                          'sub_round_id' => $next_sub_round->id,
                          'days' => $group->days,
                          'discipline_id' => $group->discipline_id,
                          'branch_id' => $group->branch_id,
                          'room_id' => $group->room_id,
                          'instructor_id' => $group->instructor_id,
                          'admin_id' => $group->admin_id,
                          'is_upgraded' => 1,
                          'interval_id' => $group->interval_id,
                      ];
                      $last_group = Group::orderBy('id','desc')->first();
                      $next_group_data['code'] = ($last_group)?sprintf("%07d",($last_group->id + 1)):sprintf("%07d",1);
                      $next_group_data['title'] = "group " . $next_sub_round->round->timeframe->title . " | " . $interval->name;
                      $next_group_data['parent_id'] = $group->id;
                      
                      $next_group = Group::create($next_group_data);
                      
                      $dates = SubRoundSession::where('sub_round_id', $next_sub_round->id)->pluck('date')->toArray();
                      $perSession = count($dates) - 1;
                      $end = end($dates);
          
                       foreach ($dates as $date) {
                           $sessionData = [
                               'group_id' => $next_group->id,
                               'date' => $date,
                               'room_id' => $next_group->room_id,
                               'instructor_id' => $next_group->instructor_id,
                               'interval_id' => $next_group->interval_id,
                               'level_id' => $next_group->level_id,
                           ];
                           
                           GroupSession::create($sessionData);
                           
                       }
                       activity('Groups')
                        ->causedBy(Auth::user()->id)
                        ->performedOn($next_group)
          //            ->withProperties(['group_id' =>$group->id ])
                        ->log('create group');
                    
                }
            }
            
            $group->is_upgraded = 1;
            $group->save();
            
        }
        
        //$group->levels()->sync($data['levels']);

        Flash::success('Group saved successfully.');

        return redirect(route('admin.groups.index'));
    }

    /**
     * Display the specified Group.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var Group $group */
        $group = Group::find($id);
        $current = $group;

        $parentIds = [];
        while ($current->parent_id) {
            $parentIds[] = $current->parent_id;
            $current = $current->parent;
        }
        $parents = Group::whereIn('id', $parentIds)->withCount('students', 'sessions')->latest()->get();
        // dd($parents);

        if (empty($group)) {
            Flash::error('Group not found');

            return redirect(route('admin.groups.index'));
        }

        return view('groups.show', compact('group', 'parents'));
    }

    /**
     * Show the form for editing the specified Group.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var Group $group */
        $group = Group::find($id);
        
        if (empty($group)) {
            Flash::error('Group not found');

            return redirect(route('admin.groups.index'));
        }
        $tracks = Track::whereNull('parent_id')->pluck('title', 'id')->toArray();
        $sub_tracks = Track::whereNotNull('parent_id')->get();
        $sub_tracks = $sub_tracks->groupBy('parent_id');
        
        $levels = StageLevel::join('stages','stages.id','=','stage_levels.stage_id')
            ->select('stages.track_id','stage_levels.id','stage_levels.name','stage_levels.value')->get();
        $levels = $levels->groupBy('track_id');    
        
        $timeframes = Timeframe::join('timeframe_courses','timeframe_courses.timeframe_id','=','timeframes.id')
            ->where('timeframes.status',1)->select('timeframe_courses.course_id','timeframes.id','timeframes.title','timeframes.days')->get();
        $daysData = $timeframes->pluck('days','id');
        $timeframes = $timeframes->groupBy('course_id'); 
        //dd($daysData);
        
        $rounds = Round::all();
        $rounds = $rounds->groupBy('timeframe_id');
        
        $sub_rounds = SubRound::whereDate('end_date', '>', now())->orderBy('start_date')->take(36)->get();
        $sub_rounds = $sub_rounds->groupBy('round_id');
        
        $intervals = Interval::join('interval_timeframe','intervals.id','=','interval_timeframe.interval_id')
            ->select('interval_timeframe.timeframe_id','intervals.name','intervals.id')->where('intervals.status',1)->orderBy('intervals.sort')->get();
        $intervals = $intervals->groupBy('timeframe_id');
        
        //$this->rounds = Round::pluck('title', 'id')->toArray();
        $disciplines = DisciplineCategory::pluck('name', 'id')->toArray();
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $employeeBranches = $employeeBranches;
        $branches = $employeeBranches;
        $admins = Employee::join('branches_employees','branches_employees.employee_id','=','employees.id')
            ->where('employees.status',1)->where('employees.account_Type', 'Operations Account')
            ->select('employees.id','employees.first_name','employees.middle_name','employees.last_name','branches_employees.branch_id')->get();
        $admins = $admins->groupBy('branch_id');
        
        $rooms = Room::where('branch_id', $group->branch_id)->pluck('name', 'id');
            
        $busy_rooms = [];
    
        if ($group->days && $group->sub_round_id && $group->interval_id) {
            $busy_rooms = Group::where('id','!=',$group->id)->where(['branch_id' => $group->branch_id,'days' => $group->days,'sub_round_id' => $group->sub_round_id, 'interval_id' => $group->interval_id])
                ->pluck('room_id')->toArray();
        }
        

        $instructorsQuery = Employee::where('status',1)->where('account_Type', 'ESL Account Profile')->whereHas('attendances',function($query) use ($group){
            $query->where('day',$group->days)->where('interval_id',$group->interval_id);
        });

        if ($group->branch_id) {
            $instructorsQuery->whereHas('branches', function ($query) use ($group){
                $query->where('id', $group->branch_id);
            });
        }else{
            $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
            $instructorsQuery->whereHas('branches', function ($query) use ($employeeBranches){
                $query->whereIn('id', array_keys($employeeBranches));
            });
        }
        
        $instructors = $instructorsQuery->get()->pluck('name', 'id')->toArray();
        $busy_instructors = [];
        
        if ($group->days && $group->sub_round_id && $group->interval_id) {
            $busy_instructors = Group::where('id','!=',$group->id)->where(['days' => $group->days,'sub_round_id' => $group->sub_round_id, 'interval_id' => $group->interval_id])
                ->pluck('instructor_id')->toArray();

        }
        
        /*
        $interval = Interval::find($group->interval_id);
        if(! $group->is_upgraded){
            //$level = StageLevel::find($group->level_id);
            $count=0;
            $stages_ids = Stage::where('track_id',$group->course_id)->pluck('id');
            $next_levels = StageLevel::whereIn('stage_id',$stages_ids)->where('id','>',$group->level_id)->orderBy('value')->take(3)->get();
            $next_sub_rounds = SubRound::where('round_id',$group->round_id)->where('days',$group->days)->where('id','>',$group->sub_round_id)->orderBy('id')->take(3)->get();
            //dd($stages_ids,$next_levels,$next_sub_rounds);
            if($next_levels != null && count($next_levels) > 0){
                foreach($next_levels as $key => $next_level){
                    
                    if(isset($next_sub_rounds[$key])){
                        $next_sub_round = $next_sub_rounds[$key];
                    }else{
                          
                          if($next_sub_rounds != null && count($next_sub_rounds) > 0){
                              $last_sub_round = $next_sub_rounds->last();
                          }else{
                              $last_sub_round = SubRound::find($group->sub_round_id);
                          }
                          $timeframe = Round::with('timeframe')->find($group->round_id)->timeframe;
                          $total_hours = $timeframe->total_hours;
                          $session_hours = $timeframe->session_hours;
                          $session_count = ($total_hours / $session_hours) + 1;
                          
                          $last_session_date = Carbon::parse($last_sub_round->subRoundSessions->last()->date);
                          $days = explode('/', config('system_variables.timeframes.days')[$last_sub_round->days]);
                          $startDate = $last_session_date->next($days[0]);
                          $n = 1;
                          while ($n <= 30) {
                              $new_subRound = SubRound::create([
                                  'round_id' => $group->round_id,
                                  'days' => $group->days,
                                  'start_date' => $startDate,
                              ]);
  
                              $days = explode('/', config('system_variables.timeframes.days')[$last_sub_round->days]);
                              $daysObj = new ArrayObject($days);
                              $daysIt = $daysObj->getIterator();
                              $date = $startDate;
                              for ($i = 0; $i < $session_count; $i++) {
                                  if ($i) {
                                      if (!$daysIt->valid()) {
                                          $daysIt->rewind();
                                      }
                                      $date = $date->next($daysIt->current());
                                  }
                                  $session = SubRoundSession::create([
                                      'sub_round_id' => $new_subRound->id,
                                      'date' => $date,
                                  ]);
                                  $daysIt->next();
                              }
                              $new_subRound->update(['end_date' => $session->date]);
                              $startDate = $date->next($days[0]);
                              $n++;
                          }
                          
                          $next_sub_rounds = SubRound::where('round_id',$group->round_id)->where('days',$group->days)->where('id','>',$group->sub_round_id)->orderBy('id')->get();
                          $next_sub_round = $next_sub_rounds[$key];
                          
                      }
                      $next_group_data = [
                          'track_id' => $group->track_id,
                          'level_id' => $next_level->id,
                          'course_id' => $group->course_id,
                          'timeframe_id' => $group->timeframe_id,
                          'round_id' => $group->round_id,
                          'sub_round_id' => $next_sub_round->id,
                          'days' => $group->days,
                          'discipline_id' => $group->discipline_id,
                          'branch_id' => $group->branch_id,
                          'room_id' => $group->room_id,
                          'instructor_id' => $group->instructor_id,
                          'admin_id' => $group->admin_id,
                          'is_upgraded' => 1,
                          'interval_id' => $group->interval_id,
                      ];
                      $last_group = Group::orderBy('id','desc')->first();
                      $next_group_data['code'] = ($last_group)?sprintf("%07d",($last_group->id + 1)):sprintf("%07d",1);
                      $next_group_data['title'] = "group " . $next_sub_round->round->timeframe->title . " | " . $interval->name;
                      $next_group_data['parent_id'] = $group->id;
                      
                      $next_group = Group::create($next_group_data);
                      
                      $dates = SubRoundSession::where('sub_round_id', $next_sub_round->id)->pluck('date')->toArray();
                      $perSession = count($dates) - 1;
                      $end = end($dates);
          
                       foreach ($dates as $date) {
                           $sessionData = [
                               'group_id' => $next_group->id,
                               'date' => $date,
                               'room_id' => $next_group->room_id,
                               'instructor_id' => $next_group->instructor_id,
                               'interval_id' => $next_group->interval_id,
                               'level_id' => $next_group->level_id,
                           ];
                           
                           GroupSession::create($sessionData);
                           
                       }
                       activity('Groups')
                        ->causedBy(Auth::user()->id)
                        ->performedOn($next_group)
          //            ->withProperties(['group_id' =>$group->id ])
                        ->log('create group');
                    
                }
            }
            
            $group->is_upgraded = 1;
            $group->save();
            
        }
        */
        
        return view('groups.edit',compact('busy_instructors','instructors','rooms','busy_rooms','group','tracks','sub_tracks','levels','timeframes','sub_rounds','rounds','daysData','intervals','disciplines','branches','admins'));
    }

    /**
     * Update the specified Group in storage.
     *
     * @param int $id
     * @param UpdateGroupRequest $request
     *
     * @return Response
     */
    public function update($id, Request $request)
    {
        /** @var Group $group */
        $group = Group::find($id);

        if (empty($group)) {
            Flash::error('Group not found');

            return redirect(route('admin.groups.index'));
        }
        
        foreach($group->sessions as $session)
        {
            if($session->date  >=  date('Y-m-d')){
                $session->instructor_id = $request->instructor_id;
                $session->save();
            }
        }
        
        $interval = Interval::find($group->interval_id);
        $group->fill($request->all());
        $group->save();
        //dd('dddd');
        if($request->has('is_upgraded') && $request->is_upgraded == 1 ){
            //$level = StageLevel::find($group->level_id);
            $count=0;
            $stages_ids = Stage::where('track_id',$group->course_id)->pluck('id');
            $next_levels = StageLevel::whereIn('stage_id',$stages_ids)->where('id','>',$group->level_id)->orderBy('value')->take(3)->get();
            $next_sub_rounds = SubRound::where('round_id',$group->round_id)->where('days',$group->days)->where('id','>',$group->sub_round_id)->orderBy('id')->take(3)->get();
            //dd($stages_ids,$next_levels,$next_sub_rounds);
            if($next_levels != null && count($next_levels) > 0){
                foreach($next_levels as $key => $next_level){
                    
                    if(isset($next_sub_rounds[$key])){
                        $next_sub_round = $next_sub_rounds[$key];
                    }else{
                          
                          if($next_sub_rounds != null && count($next_sub_rounds) > 0){
                              $last_sub_round = $next_sub_rounds->last();
                          }else{
                              $last_sub_round = SubRound::find($group->sub_round_id);
                          }
                          $timeframe = Round::with('timeframe')->find($group->round_id)->timeframe;
                          $total_hours = $timeframe->total_hours;
                          $session_hours = $timeframe->session_hours;
                          $session_count = ($total_hours / $session_hours) + 1;
                          
                          $last_session_date = Carbon::parse($last_sub_round->subRoundSessions->last()->date);
                          $days = explode('/', config('system_variables.timeframes.days')[$last_sub_round->days]);
                          $startDate = $last_session_date->next($days[0]);
                          $n = 1;
                          while ($n <= 30) {
                              $new_subRound = SubRound::create([
                                  'round_id' => $group->round_id,
                                  'days' => $group->days,
                                  'start_date' => $startDate,
                              ]);
  
                              $days = explode('/', config('system_variables.timeframes.days')[$last_sub_round->days]);
                              $daysObj = new ArrayObject($days);
                              $daysIt = $daysObj->getIterator();
                              $date = $startDate;
                              for ($i = 0; $i < $session_count; $i++) {
                                  if ($i) {
                                      if (!$daysIt->valid()) {
                                          $daysIt->rewind();
                                      }
                                      $date = $date->next($daysIt->current());
                                  }
                                  $session = SubRoundSession::create([
                                      'sub_round_id' => $new_subRound->id,
                                      'date' => $date,
                                  ]);
                                  $daysIt->next();
                              }
                              $new_subRound->update(['end_date' => $session->date]);
                              $startDate = $date->next($days[0]);
                              $n++;
                          }
                          
                          $next_sub_rounds = SubRound::where('round_id',$group->round_id)->where('days',$group->days)->where('id','>',$group->sub_round_id)->orderBy('id')->get();
                          $next_sub_round = $next_sub_rounds[$key];
                          
                      }
                      $next_group_data = [
                          'track_id' => $group->track_id,
                          'level_id' => $next_level->id,
                          'course_id' => $group->course_id,
                          'timeframe_id' => $group->timeframe_id,
                          'round_id' => $group->round_id,
                          'sub_round_id' => $next_sub_round->id,
                          'days' => $group->days,
                          'discipline_id' => $group->discipline_id,
                          'branch_id' => $group->branch_id,
                          'room_id' => $group->room_id,
                          'instructor_id' => $group->instructor_id,
                          'admin_id' => $group->admin_id,
                          'is_upgraded' => 1,
                          'interval_id' => $group->interval_id,
                      ];
                      $last_group = Group::orderBy('id','desc')->first();
                      $next_group_data['code'] = ($last_group)?sprintf("%07d",($last_group->id + 1)):sprintf("%07d",1);
                      $next_group_data['title'] = "group " . $next_sub_round->round->timeframe->title . " | " . $interval->name;
                      $next_group_data['parent_id'] = $group->id;
                      
                      $next_group = Group::create($next_group_data);
                      
                      $dates = SubRoundSession::where('sub_round_id', $next_sub_round->id)->pluck('date')->toArray();
                      $perSession = count($dates) - 1;
                      $end = end($dates);
          
                       foreach ($dates as $date) {
                           $sessionData = [
                               'group_id' => $next_group->id,
                               'date' => $date,
                               'room_id' => $next_group->room_id,
                               'instructor_id' => $next_group->instructor_id,
                               'interval_id' => $next_group->interval_id,
                               'level_id' => $next_group->level_id,
                           ];
                           
                           GroupSession::create($sessionData);
                           
                       }
                       activity('Groups')
                        ->causedBy(Auth::user()->id)
                        ->performedOn($next_group)
          //            ->withProperties(['group_id' =>$group->id ])
                        ->log('update group');
                    
                }
            }
            
            $group->is_upgraded = 1;
            $group->save();
            
        }
        
        Flash::success('Group updated successfully.');

        return redirect(route('admin.groups.index'));
    }
    /**
     * Remove the specified Group from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var Group $group */
        $group = Group::find($id);

        if (empty($group)) {
            Flash::error('Group not found');

            return redirect(route('admin.groups.index'));
        }

        $group->delete();
        
        
         activity('Group')
           ->causedBy(Auth::user()->id)
           ->performedOn($group)
        //   ->withProperties(['group_id' =>$group ])
           ->log('Delete Group ');
        

        Flash::success('Group deleted successfully.');

        return redirect(route('admin.groups.index'));
    }
    public function exportdata(Request $request){
        
        return Excel::download(new GroupExport( $request ), 'groups_'.date('Y-m-d H:i').'.xlsx'); 
    }
    
    public function missing(Request $request){
        //   Carbon::now()->subDays(1)->format('Y-m-d');
        $subround = SubRound::where('end_date' , Carbon::now()->subDays(4)->format('Y-m-d'))->pluck('id');
        
       $groups = Group::whereIn('sub_round_id' , $subround)->with('students')->get();
         
        // $clients = GroupStudent::whereIn('group_id',$groups)->pluck('lead_id');
        $students=[];
        foreach($groups as $group){
            foreach($group->students as $student){
               
                $student_attend_count = GroupSessionAttendance::where('attendance',1)->where('lead_id',$student->lead_id)->where('group_id',$student->group_id)->count();
                if($student_attend_count <= 1)
                {
                   //make a hold functions and change the customer_type to missing
                    GroupSessionAttendance::where('lead_id',$student->lead_id)->where('group_id',$student->group_id)->delete();
                    $currentgroup = Group::find($student->group_id);
                    GroupWaitingList::where('lead_id',$student->lead_id)->delete();
                    $waiting_list = new GroupWaitingList;
                    $waiting_list->create([
                        'lead_id' => $student->lead_id,
                        'level_id' => $student->level_id,
                        'timeframes' => $currentgroup->timeframe_id,
                        'discipline_id' => $currentgroup->discipline_id,
                    ]);
                    $lead = Lead::find($student->lead_id);
                    $lead->type = 2;
                    $lead->customer_type = "missing";
                    $lead->save();
                    
                    
                   return "missing";
                }
            }
            
        }
            
         
        
        
    }
    

}
