<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Penalties;
use App\Models\Department;
use App\Models\Employee;
use Flash;
class PenaltiesController extends Controller
{
    public function index(){
        $Penalties = Penalties::get();
        
        return view('Penalties.index',compact('Penalties')); 
    }
    public function create(){
        $departments = Department::pluck('title','id');
        $employees =[];
        $Penalties = Penalties::get();
        
        return view('Penalties.create',compact('Penalties','departments','employees')); 
    }
    public function store(Request $request){
        $credentials = $request->validate([
            'employee_id' => 'required',
            'department_id' => 'required',
            'action' => 'required',
        ]);
        $Penalties = new Penalties;
        $Penalties->employee_id = $request->employee_id;
        $Penalties->department_id = $request->department_id;
        $Penalties->action = $request->action;
        $Penalties->save();
        
        Flash::success('Penalties created successfully.');
        return redirect()->back(); 
    }
    public function show($id){}
    public function edit($id){
        $departments = Department::pluck('title','id');
        $Penalties = Penalties::find($id);
        $employees =Employee::where('status',1)->where('department_id',$Penalties->department_id)->get()->pluck('name','id')->toArray();  
        
        return view('Penalties.edit',compact('Penalties','departments','employees')); 
    }
    public function update($id ,Request $request){
        $Penalties = Penalties::find($id);
         $credentials = $request->validate([
            'employee_id' => 'required',
            'department_id' => 'required',
            'action' => 'required',
        ]);
        $Penalties->employee_id = $request->employee_id;
        $Penalties->department_id = $request->department_id;
        $Penalties->action = $request->action;
        $Penalties->save();
        
        Flash::success('Penalties updated successfully.');
        return redirect()->back(); 
    }
    public function destroy($id){
        
        $Penalties = Penalties::find($id);
        $Penalties->delete();
        Flash::success('Penalties deleted successfully.');
        return redirect()->back(); 
        
        
    }
}
