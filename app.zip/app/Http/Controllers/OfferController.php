<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateOfferRequest;
use App\Http\Requests\UpdateOfferRequest;
use App\Repositories\OfferRepository;
use App\Http\Controllers\AppBaseController;
use Illuminate\Http\Request;
use App\Models\Offer;
use App\Models\Track;
use App\Models\StageLevel;
use App\Models\Timeframe;
use App\Models\Interval;
use App\Models\DisciplineCategory;
use App\Models\Branch;
use App\Models\PaymentPlan;
use App\Models\Installment;
use App\Models\ExtraItem;
use App\Models\ServiceFee;
use Flash;
use File;
use Response;
use App\Traits\StoreImageTrait;


class OfferController extends AppBaseController
{
             use StoreImageTrait;

    /** @var  OfferRepository */
    private $offerRepository;

    public function offers_editWeb($id)
    {
        $offer = $this->offerRepository->find($id);

        if (empty($offer)) {
            Flash::error('Offer not found');

            return redirect(route('admin.offers.index'));
        }

        return view('offers.editWeb')->with('offer', $offer);
    }
    
    public function offers_calcAmount(Request $request)
    {
        //dd($request->all());
        $items = $request->items;
        $services = $request->services;
        $course_id = $request->course_id;
        $services_data = ServiceFee::whereHas('trainingService', function ($query) use ($course_id) {
            $query->where('course_id', $course_id);
        })->with('trainingService')->get()->pluck('trainingService.title', 'id');
        //dd($items,$services);
        $total_amount = 0;
        if($items){
            $total_amount += ExtraItem::whereIn('id', $items)->sum('price');
        }
        if($request->has_levels == 1){
            if($services){
                $total_amount += ServiceFee::whereIn('id', $services)->sum('fees');
            }
        }else{
            if($services_data != null && count($services_data) > 0){
                //dd(array_key_first($services_data->toArray()));
                $service = ServiceFee::find(array_key_first($services_data->toArray()));
                $book = ExtraItem::where('item_category_id',1)->first();
                //dd($book);
                if($request->include_books == 1){
                    $total_amount += $request->num_levels * ($service->fees + $book->price);
                }else{
                    //dd($request->num_levels,$service);
                    $total_amount += $request->num_levels * $service->fees;
                }
                
            }
        }
        
        return $total_amount;
    }
    
    public function offers_updateWeb($id,Request $request)
    {
        $offer = $this->offerRepository->find($id);

        if (empty($offer)) {
            Flash::error('Offer not found');

            return redirect(route('admin.offers.index'));
        }
        $data = $request->except('image','_token');
        
        
                 $data['image'] = $this->verifyAndUpdateImageSource($offer->image,$request,'image','uploads/offers');

        $offer = $this->offerRepository->update($data, $id);

        Flash::success('Offer updated successfully.');

        return redirect(route('admin.offers.index'));
    }
    
    public function __construct(OfferRepository $offerRepo)
    {
        $this->offerRepository = $offerRepo;
    }

    /**
     * Display a listing of the Offer.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        
        
        $registration_from = null;
        $registration_to = null;
        if ($request->has('registration_daterange') && $request->get('registration_daterange') != null && $request->get('registration_daterange') != '') {
            $daterange = explode(' - ',$request->get('registration_daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $registration_to = date_format(date_create($daterange[1]),'Y-m-d');
        }

        if($request->has('expired') && $request->get('expired') !== null && $request->get('expired') !== ''){
            if ($request->get('expired') === '0') {
                $offersQuery = Offer::where('end_date','>=',date('Y-m-d'));
            } elseif ($request->get('expired') === '1') {
                $offersQuery = Offer::where('end_date','<',date('Y-m-d'));
            }
        }else{
            $offersQuery = Offer::where('end_date','>=',date('Y-m-d'));
        }
        
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $offersQuery->where('title','like','%'.$request->get('search').'%');
        }
         if ($request->has('offer_type')) {
        $offerType = $request->input('offer_type');
        $offersQuery->where('offer_type', $offerType);
    }
        if ($request->has('offer_status') && $request->get('offer_status') != '') {
        $offerStatus = $request->input('offer_status');
        $offersQuery->where('offer_status', $offerStatus);
    }  
        if ($registration_from != null && $registration_to != '') {
            $offersQuery->whereBetween('created_at', [$registration_from, $registration_to]);
        }
        $offers = $offersQuery->orderBy('order_by')->paginate($per_page);
        //dd($offers);
        return view('offers.index')->with('offers', $offers);
    }

    /**
     * Show the form for creating a new Offer.
     *
     * @return Response
     */
    public function create()
    {
        $tracks = Track::whereNull('parent_id')->pluck('title', 'id')->toArray();
        $sub_tracks = Track::whereNotNull('parent_id')->get();
        $sub_tracks = $sub_tracks->groupBy('parent_id');
        
        $timeframes = Timeframe::join('timeframe_courses','timeframe_courses.timeframe_id','=','timeframes.id')
            ->where('timeframes.status',1)->select('timeframe_courses.course_id','timeframes.id','timeframes.title','timeframes.days')->get();
        
        $timeframes = $timeframes->groupBy('course_id'); 
        
         $intervals = Interval::join('interval_timeframe','intervals.id','=','interval_timeframe.interval_id')
            ->select('interval_timeframe.timeframe_id','intervals.name','intervals.id')->where('intervals.status',1)->orderBy('intervals.sort')->get();
        $intervals = $intervals->groupBy('timeframe_id');
        
        
        $disciplines = DisciplineCategory::pluck('name', 'id')->toArray();
        $branches = Branch::pluck('name', 'id');
        $paymentPlans = PaymentPlan::where('status', 1)->pluck('title', 'id');
         $extra_items = ExtraItem::pluck('name', 'id');
        $services = ServiceFee::join('training_services','training_services.id','=','service_fees.training_service_id')
            ->select('service_fees.*','training_services.title','training_services.course_id')->get();
         $services = $services->groupBy('course_id');
        
        return view('offers.create',compact('services','tracks','sub_tracks','timeframes','intervals','disciplines','branches','paymentPlans','extra_items'));
    }

    /**
     * Store a newly created Offer in storage.
     *
     * @param CreateOfferRequest $request
     *
     * @return Response
     */
    public function store(CreateOfferRequest $request)
    {
        $data = $request->all();
        $data['title_ar'] = $request->title;
        $offer = Offer::create($data);
        if ($request->payment_plan_id == 1) {
            $data['installment']['installmentable_type'] = 'App\\Models\\Offer';
            $data['installment']['installmentable_id'] = $offer->id;
            Installment::create($data['installment']);
        }elseif($request->payment_plan_id == 3){
            $data['installment']['installmentable_type'] = 'App\\Models\\Offer';
            $data['installment']['installmentable_id'] = $offer->id;
            $data['installment']['first_payment'] = $offer->fees - $data['installment']['deposit'];
            $data['installment']['first_due_date'] = 13;
            Installment::create($data['installment']);
        }
        
        $offer->timeframes()->sync($data['timeframes']);
        $offer->intervals()->sync($data['intervals']);
        $offer->branches()->sync($data['branches']);
        $offer->disciplines()->sync($data['disciplines']);
        $offer->items()->sync($data['items']);
        if($offer->has_levels == 1){
            $offer->services()->sync($data['services']);
        }

        Flash::success('Offer saved successfully.');

        return redirect(route('admin.offers.index'));
    }

    /**
     * Display the specified Offer.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $offer = $this->offerRepository->find($id);

        if (empty($offer)) {
            Flash::error('Offer not found');

            return redirect(route('admin.offers.index'));
        }

        return view('offers.show')->with('offer', $offer);
    }

    /**
     * Show the form for editing the specified Offer.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $offer = $this->offerRepository->find($id);
        
        if (empty($offer)) {
            Flash::error('Offer not found');

            return redirect(route('admin.offers.index'));
        }
        $tracks = Track::whereNull('parent_id')->pluck('title', 'id')->toArray();
        $sub_tracks = Track::whereNotNull('parent_id')->get();
        $sub_tracks = $sub_tracks->groupBy('parent_id');
        
        $timeframes = Timeframe::join('timeframe_courses','timeframe_courses.timeframe_id','=','timeframes.id')
            ->where('timeframes.status',1)->select('timeframe_courses.course_id','timeframes.id','timeframes.title','timeframes.days')->get();
        
        $timeframes = $timeframes->groupBy('course_id'); 
        
        $intervals = Interval::join('interval_timeframe','intervals.id','=','interval_timeframe.interval_id')
            ->select('interval_timeframe.timeframe_id','intervals.name','intervals.id')->where('intervals.status',1)->orderBy('intervals.sort')->get();
        $intervals = $intervals->groupBy('timeframe_id');
        
        $disciplines = DisciplineCategory::pluck('name', 'id')->toArray();
        $branches = Branch::pluck('name', 'id');
        $paymentPlans = PaymentPlan::where('status', 1)->pluck('title', 'id');
        $extra_items = ExtraItem::pluck('name', 'id');
        $services = ServiceFee::join('training_services','training_services.id','=','service_fees.training_service_id')
            ->select('service_fees.*','training_services.title','training_services.course_id')->get();
        $services = $services->groupBy('course_id');
        
        $total = 0;
        $offer_items = $offer->items->pluck('id');
        $offer_services = $offer->services->pluck('id');
        $services_data = ServiceFee::whereHas('trainingService', function ($query) use ($offer) {
                                        $query->where('course_id', $offer->course_id);
                                    })->with('trainingService')->get()->pluck('trainingService.title', 'id');
        
        if ($offer_items) {
            $total += ExtraItem::whereIn('id', $offer_items)->sum('price');
        }
        if($offer->has_levels == 1){
            if ($offer_services) {
                $total += ServiceFee::whereIn('id', $offer_services)->sum('fees');
            }
        }else{
            if($services_data != null && count($services_data) > 0){
                $service = ServiceFee::find(array_key_first($services_data->toArray()));
                $total += $offer->num_levels * $service->fees;
            }
        }
        
        $offer_timeframes = $offer->timeframes->pluck('id')->toArray();
        $offer_intervals = $offer->intervals->pluck('id')->toArray();
        $offer_branches = $offer->branches->pluck('id');
        $offer_disciplines = $offer->disciplines->pluck('id');
        $offer_installment = $offer->installment;
        
        return view('offers.edit',compact('services_data','offer','offer_timeframes','offer_intervals','offer_branches','offer_disciplines','offer_installment','total','offer_items','offer_services','services','tracks','sub_tracks','timeframes','intervals','disciplines','branches','paymentPlans','extra_items'));
    }

    /**
     * Update the specified Offer in storage.
     *
     * @param int $id
     * @param UpdateOfferRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateOfferRequest $request)
    {
        $data = $request->all();
        
        $offer = $this->offerRepository->find($id);

        if (empty($offer)) {
            Flash::error('Offer not found');

            return redirect(route('admin.offers.index'));
        }

        $offer->update($data);
        if($offer->installment() != null && $offer->installment() != ''){
            $offer->installment()->delete();
        }
        if ($request->payment_plan_id == 1) {
            $data['installment']['installmentable_type'] = 'App\\Models\\Offer';
            $data['installment']['installmentable_id'] = $offer->id;
            Installment::create($data['installment']);
        }elseif($request->payment_plan_id == 3){
            $data['installment']['installmentable_type'] = 'App\\Models\\Offer';
            $data['installment']['installmentable_id'] = $offer->id;
            $data['installment']['first_payment'] = $offer->fees - $data['installment']['deposit'];
            $data['installment']['first_due_date'] = 13;
            Installment::create($data['installment']);
        }
        
        $offer->timeframes()->sync($data['timeframes']);
        $offer->intervals()->sync($data['intervals']);
        $offer->branches()->sync($data['branches']);
        $offer->disciplines()->sync($data['disciplines']);
        $offer->items()->sync($data['items']);
        if($offer->has_levels == 1){
            $offer->services()->sync($data['services']);
        }
        
        Flash::success('Offer updated successfully.');

        return redirect(route('admin.offers.index'));
    }

    /**
     * Remove the specified Offer from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        $offer = $this->offerRepository->find($id);

        if (empty($offer)) {
            Flash::error('Offer not found');

            return redirect(route('admin.offers.index'));
        }

        $this->offerRepository->delete($id);

        Flash::success('Offer deleted successfully.');

        return redirect(route('admin.offers.index'));
    }
}
