<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\Employee;
use App\Models\Expense;
use App\Models\Lead;
use App\Models\LeadPayment;
use App\Models\PlacementApplicant;
use App\Models\PlacementKidsApplicant;
use App\Models\Offer;
use App\Models\CustomerTrack;
use App\Models\ExtraItem;
use App\Models\StageLevel;
use App\Models\Safe;
use App\Models\GroupSessionAttendance;
use App\Models\GroupSession;
use App\Models\Group;
use App\Models\GroupStudent;
use App\Models\LeadSource;
use App\Models\LabelType;
use App\Models\LeadCase;
use App\Models\SubPayment;
use App\Models\Timeframe;
use App\Models\Round;
use App\Models\StudentExam;
use App\Models\SubRound;
use App\Models\Track;
use App\Models\TODoListRandom;
use App\Models\GroupWaitingList;
use App\Models\LeadsDutch;
use App\Events\MyEvent;
use Illuminate\Http\Request;
use Auth;
use DB;
use Illuminate\Database\Eloquent\Model;
use App\Traits\TargetCashTrait;

class HomeController extends Controller
{
     use TargetCashTrait;
    
    public function dutch_index(Request $request){
        $leads_dutch = LeadsDutch::all();
        return view('leads_dutch',compact('leads_dutch'));
    }
    
    public function transfertoinstallment(Request $request){
        $allpayments = LeadPayment::where('payment_plan_id' , 3)->where('rest','>',0)
                                    ->whereHas('subPayments',function($query){
                                        $query->where('due_date','<',date('Y-m-d'))->where('paid',0);
                                    })->with('subPayments',function($query){
                                        $query->where('due_date','<',date('Y-m-d'))->where('paid',0);
                                    })->get();
        //dd($allpayments);
        foreach($allpayments as $allpayment){
            // dd($allpayment);
            
            $lopcount = 0;
            if($allpayment->rest < 1000){
                $lopcount = 1;
            }elseif($allpayment->rest >= 1000 && $allpayment->rest <= 2000){
                $lopcount = 2;
                //dd(2,$allpayment);
            }else{
                $lopcount = 3;
                //dd(3,$allpayment);
            }
            
            $due_date = date('Y-m-d');
            SubPayment::where('lead_payment_id',$allpayment->id)->where('paid',0)->delete();
            $allpayment->payment_plan_id = 1;
            $allpayment->save();
            
            for($i = 1 ; $i <= $lopcount ; $i ++ )
            {
                $amount = round($allpayment->rest / $lopcount);
                $day = (($i * 7)." days");
                $d_date = date('Y-m-d',strtotime($due_date.' '.$day));
                //dd($d_date,$due_date);
                $subPayment = [
                    'lead_payment'=>$allpayment->id,
                    'amount'=>$amount,
                    'paid'=>0, 
                    'due_date'=>$d_date,
                    'branch_id'=>$allpayment->branch_id,
                    'employee_id'=>$allpayment->employee_id,
                    'type' => 2,
                ];
                $allpayment->subPayments()->create($subPayment);
            }
            
        }                            
        
    }
    public function branchReport(Request $request)
    {
        $branches = Branch::where('id' ,'!=' , 19)->pluck('id')->toArray();
        $allbranches = Branch::where('status',1)->pluck('name','id');
       
        // $paymentQuery1 = LeadPayment::whereNotNull('paymentable_type')->whereNotNull('paymentable_id')->where('rest',0)->whereNotNull('branch_id')->whereIn('branch_id',array_keys($branches));
        $paymentQuery1 =LeadPayment::leftjoin('branches','branches.id','lead_payments.branch_id')
            ->where('lead_payments.payment_plan_id',2)
            ->where('lead_payments.rest',0)
            ->whereNotNull('lead_payments.paymentable_type')
            ->whereNotNull('lead_payments.paymentable_id');
            
            
        $paymentQuery2 = SubPayment::join('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
            ->leftjoin('branches','branches.id','sub_payments.branch_id')
            ->whereIn('lead_payments.payment_plan_id',[1,3])
            ->whereNotNull('lead_payments.paymentable_type')
            ->whereNotNull('lead_payments.paymentable_id')
            ->where('sub_payments.paid',1);
           
        // dd($employees_payment1,$employees_payment2);
        
        $oldPaymentQuery = SubPayment::join('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
            ->leftjoin('branches','branches.id','sub_payments.branch_id')
            ->whereIn('lead_payments.payment_plan_id',[1,3])
            ->whereNull('lead_payments.paymentable_type')
            ->where('sub_payments.paid',1)
            //->whereRaw('sub_payments.created_at != DATE_FORMAT(lead_payments.created_at, "%Y-%m-%d")');
            ->whereRaw('sub_payments.updated_at != sub_payments.created_at');      
            
        $registration_from=null;
        $reg_to=null;
        if (request()->has('operation_daterange') && request()->get('operation_daterange') != null && request()->get('operation_daterange') != '') {
            $daterange = explode(' - ',request()->get('operation_daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $registration_to  = date_create($daterange[1]);
            date_add($registration_to,date_interval_create_from_date_string("1 days"));
            $reg_to= date_format($registration_to,"Y-m-d");
            
        }
        
        if(!$registration_from && !$reg_to){
            $paymentQuery1->where('lead_payments.created_at' ,'like','%'.date('Y-m-d').'%' );
            $paymentQuery2->where('sub_payments.due_date','like','%'.date('Y-m-d').'%' );
            $oldPaymentQuery->where('sub_payments.due_date','like','%'.date('Y-m-d').'%' );
        }
        
        if($registration_from){
            
            $paymentQuery1->where('lead_payments.created_at', '>=',$registration_from);
            $paymentQuery2->where('sub_payments.due_date', '>=', $registration_from);
            $oldPaymentQuery->where('sub_payments.due_date', '>=', $registration_from);
        }
        if($reg_to){
            $paymentQuery1->where('lead_payments.created_at', '<', $reg_to);
            $paymentQuery2->where('sub_payments.due_date', '<', $reg_to);
            $oldPaymentQuery->where('sub_payments.due_date', '<', $reg_to);
        }  
            
        $employees_payment1 = $paymentQuery1->orderBy('branch_id')->select('lead_payments.branch_id','lead_payments.paymentable_type','lead_payments.paymentable_id','lead_payments.amount')->get()->groupBy('branch_id');
        $employees_payment2 = $paymentQuery2->select('sub_payments.branch_id','sub_payments.amount','sub_payments.payment_date','sub_payments.created_at','sub_payments.updated_at','lead_payments.lead_id','lead_payments.paymentable_type')->orderBy('sub_payments.branch_id')->with('leadPayment')->get()->groupBy('branch_id');
        $employees_old_payment = $oldPaymentQuery->select('sub_payments.branch_id','sub_payments.amount','sub_payments.payment_date','sub_payments.due_date','sub_payments.updated_at','sub_payments.created_at')->orderBy('sub_payments.branch_id')->with('leadPayment')->get()->groupBy('branch_id');
        
        //dd($employees_payment1[1],$employees_payment2[1],$employees_old_payment[1]);
        $employees_payment = [];
        if($employees_payment1 != null && count($employees_payment1) > 0){
            foreach($employees_payment1 as $branch_id => $employee_payment1){
                $format_payment = new LeadPayment; 
                $format_payment->branch_id = $branch_id;
                $offers_amount = $employee_payment1->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->sum('amount');
                if(isset($employees_payment2[$branch_id]) && count($employees_payment2[$branch_id]) > 0){
                    $offers_amount += $employees_payment2[$branch_id]->filter(function ($value, $key) { return ($value->updated_at == $value->created_at ); })->sum('amount');
                }
                
                $format_payment->offers_amount = $offers_amount;
                $format_payment->items_amount = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->sum('amount');
                $completting_payment = 0;
                if(isset($employees_payment2[$branch_id]) && count($employees_payment2[$branch_id]) > 0){
                    // $completting_payment += $employees_payment2[$branch_id]->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->updated_at),'Y-m-d'); })->sum('amount');
                    $completting_payment += $employees_payment2[$branch_id]->filter(function ($value, $key) { return ($value->updated_at != $value->created_at ); })->sum('amount');
                }
                if(isset($employees_old_payment[$branch_id]) && count($employees_old_payment[$branch_id]) > 0){
                    $completting_payment += $employees_old_payment[$branch_id]->sum('amount');
                }
                $format_payment->completting_payment = $completting_payment;
                $employees_payment[$branch_id] = $format_payment;
                
                if(isset($employees_payment2[$branch_id]) && count($employees_payment2[$branch_id]) > 0){
                    unset($employees_payment2[$branch_id]);
                }
                
                if(isset($employees_old_payment[$branch_id]) && count($employees_old_payment[$branch_id]) > 0){
                    unset($employees_old_payment[$branch_id]);
                }

            }
        }
        if($employees_payment2 != null && count($employees_payment2) > 0){
            foreach($employees_payment2 as $branch_id => $employee_payment2){
                $format_payment = new LeadPayment;
                $format_payment->branch_id = $branch_id;
                
                $offers_amount = $employee_payment2->filter(function ($value, $key) { return $value->created_at == $value->updated_at; })->sum('amount');
                $format_payment->offers_amount =$offers_amount;
                $format_payment->items_amount = 0;
                // $completting_payment = $employee_payment2->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->updated_at),'Y-m-d'); })->sum('amount');
                $completting_payment = $employee_payment2->filter(function ($value, $key) { return ($value->updated_at != $value->created_at ); })->sum('amount');
                if(isset($employees_old_payment[$branch_id]) && count($employees_old_payment[$branch_id]) > 0){
                    $completting_payment += $employees_old_payment[$branch_id]->sum('amount');
                }
                $format_payment->completting_payment = $completting_payment;
               
                
                if(isset($employees_old_payment[$branch_id]) && count($employees_old_payment[$branch_id]) > 0){
                    unset($employees_old_payment[$branch_id]);
                }
                
                $employees_payment[$branch_id] = $format_payment;
            }
        }
        if($employees_old_payment != null && count($employees_old_payment) > 0){
            foreach($employees_old_payment as $branch_id => $employee_old_payment){
                $format_payment = new LeadPayment;
                $format_payment->branch_id = $branch_id;
                $format_payment->offers_amount = 0;
                $format_payment->items_amount = 0;
                $format_payment->completting_payment = $employee_old_payment->sum('amount');
                $format_payment->completting_payment_count = $employee_old_payment->count();
                $employees_payment[$branch_id] = $format_payment;
            }
        }
        // return $employees_payment;
        $Branch_Expenses = Expense::where('branch_id', '!=' ,19);
        $HQ_Expenses = Expense::where('branch_id' ,19);
            
        if($registration_from && $reg_to){
            
            $HQ_Expenses->whereBetween('created_at', [$registration_from, $reg_to]);
            $Branch_Expenses->whereBetween('created_at', [$registration_from, $reg_to]);
        }else{
            $HQ_Expenses->where('created_at' ,'like','%'.date('Y-m-d').'%' );
            $Branch_Expenses->where('created_at','like','%'.date('Y-m-d').'%' );
            
        }  
        $Branch_Expenses = $Branch_Expenses->select(DB::raw( 'sum(amount) as branch_amount') , 'branch_id')->groupBy('branch_id')->get();
        $Branch_Expenses = $Branch_Expenses->groupBy('branch_id');
        $HQ_Expenses= $HQ_Expenses->select(DB::raw( 'sum(amount) as Hq_amount') )->get();
        // return $Branch_Expenses;
        // dd($Branch_Expenses,$employees_payment);
        return view('branch_report',compact('branches','allbranches','employees_payment','Branch_Expenses' ,'HQ_Expenses') );
    
    }
    
    public function missingbook(Request $request)
    {
        $branches = Branch::where('status',1)->pluck('name','id');  
         $registration_from=null;
        $reg_to=null;
        $reg_from=null;
        $registration_to = null;
         if (request()->has('daterange') && request()->get('daterange') != null && request()->get('daterange') != '') {
            $daterange = explode(' - ',request()->get('daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
            
        }
        
        $instructors_showBook_query = GroupSession::join('groups','groups.id','=','group_sessions.group_id')
                                                    ->join('stage_levels','stage_levels.id','=','group_sessions.level_id')
                                                    ->whereNotNull('stage_levels.digital_material')->has('attendances');
                                                    
        
        if ($registration_from != null && $registration_to != ''){
            $instructors_showBook_query->whereBetween('group_sessions.date',[$registration_from, $registration_to]);
        }
        if (request()->has('sub_round_id') && request()->get('sub_round_id') != null && request()->get('sub_round_id') != ''){
            $instructors_showBook_query->where('groups.sub_round_id',request()->get('sub_round_id'));
        }
        if($request->branch_id != null && $request->branch_id != ' ' && $request->branch_id !=''){
            $instructors_showBook_query->where('groups.branch_id',$request->branch_id);
        }
        if(count($request->all()) == 0){
            $instructors_showBook_query->where('group_sessions.date',date('Y-m-d'));
        }
        
         $instructors_showBook = $instructors_showBook_query->select('group_sessions.instructor_id',DB::raw('COUNT(DISTINCT(group_sessions.group_id)) as groups_count, count(*) as sessions_count, COUNT(IF(group_sessions.show_book = 1,1,NULL)) as showBooks_count'))
                                                           ->groupBy('group_sessions.instructor_id')->with('instructor')->get();
        //dd($instructors_showBook);
        /*$GroupId = Group::withCount('sessions');
                                
        if ($registration_from != null && $registration_to != ''){
            
            $GroupId->whereHas('sessions', function ($query) use ($registration_from ,$registration_to) {
               $query->whereBetween('date', [$registration_from, $registration_to]); 
            });
            
        }
        if (request()->has('sub_round_id') && request()->get('sub_round_id') != null && request()->get('sub_round_id') != ''){
            
            
            $GroupId->where('sub_round_id', request()->get('sub_round_id') );
        }
         if(count($request->all()) == 0){
           $GroupId->whereHas('sessions', function ($query)  {
                $query->where('date',date('Y-m-d'));
            });
        }
        
        $GroupId = $GroupId->pluck('id')->ToArray();
        
        $instructor_group = Group::whereIn('id',$GroupId)->WhereNotNull('instructor_id')->distinct()
        ->pluck('instructor_id')->toArray();
        
        $instructors = Employee::where('status',1)->whereIn('id',$instructor_group);
        if($request->branch_id != null && $request->branch_id != ' ' && $request->branch_id !=''){
            $instructors->where('current_branch' ,$request->branch_id );
        }
        $instructors= $instructors->get();
        */
        $subRounds = SubRound::join('rounds','rounds.id','=','sub_rounds.round_id')->where('sub_rounds.start_date','<=',date('Y-m-d'))->orderBy('sub_rounds.start_date','desc')->take(20)->select(DB::raw('concat(rounds.title,", ",sub_rounds.start_date) as sub_round_name'),'sub_rounds.id')->get()->pluck('sub_round_name', 'id');
        
        return view('missing_book',compact('branches','subRounds','instructors_showBook') );
        
    }
    
    public function totalattendance(Request $request)
    {
        $reg_to=null;
        $reg_from=null;
        $branches = Branch::where('status',1)->pluck('name','id');
        
        
        $registration_from = null;
        $registration_to = null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
        }
        $empty_sessions_query = GroupSessionAttendance::join('groups','groups.id','=','group_session_attendances.group_id')
                                                    ->join('group_sessions','group_sessions.id','=','group_session_attendances.group_session_id');
        
        $instructors_attendance_query = GroupSessionAttendance::join('groups','groups.id','=','group_session_attendances.group_id')
                                                              ->join('group_sessions','group_sessions.id','=','group_session_attendances.group_session_id');
        /*   
        if ($registration_from != null && $registration_to != ''){
            $instructors_attendance_query->whereBetween('group_sessions.date',[$registration_from, $registration_to]);
            $empty_sessions_query->whereBetween('group_sessions.date',[$registration_from, $registration_to]);
        }*/
        if (request()->has('sub_rounds_ids') && request()->get('sub_rounds_ids') != null && request()->get('sub_rounds_ids') != ''){
            $instructors_attendance_query->whereIn('groups.sub_round_id',request()->get('sub_rounds_ids'));
            $empty_sessions_query->whereIn('groups.sub_round_id',request()->get('sub_rounds_ids'));
        }
        if($request->branch_id != null && $request->branch_id != ' ' && $request->branch_id !=''){
            $instructors_attendance_query->where('groups.branch_id',$request->branch_id);
            $empty_sessions_query->where('groups.branch_id',$request->branch_id);
        }
        if(count($request->all()) == 0){
            $instructors_attendance_query->where('group_sessions.date',date('Y-m-d'));
            $empty_sessions_query->where('group_sessions.date',date('Y-m-d'));
        }  
        
        
        $empty_sessions = $empty_sessions_query->whereNull('group_session_attendances.attendance')
                                               ->select(DB::raw('COUNT(DISTINCT(group_session_attendances.group_session_id)) as empty_sessions'),'group_sessions.instructor_id')
                                               ->groupBy('group_sessions.instructor_id')->pluck('empty_sessions','group_sessions.instructor_id');  
        
        // dd($empty_sessions);
             
             
        $instructors_attendance = $instructors_attendance_query->select('group_sessions.instructor_id',
        DB::raw('COUNT(DISTINCT(group_session_attendances.group_id)) as groups_count,COUNT(DISTINCT(group_session_attendances.group_session_id)) as sessions_count, COUNT(IF(group_session_attendances.attendance = 1,1,NULL)) as attendance_count ,COUNT(IF(group_session_attendances.attendance = 0,1,NULL)) as absent_count ,COUNT(*) as student_count ,COUNT(IF(group_session_attendances.attendance IS NULL,1,NULL)) as emp'))
                                                               ->groupBy('group_sessions.instructor_id')->get();
        
        //  dd($instructors_attendance);   
        
        /*if ($registration_from != null && $registration_to != ''){
            
            $GroupId = GroupSession::whereBetween('date', [$registration_from, $registration_to])
            ->withCount('attendances')->pluck('group_id')->ToArray();
            
        }
         if(count($request->all()) == 0){
           $GroupId = GroupSession::where('date',date('Y-m-d'))->withCount('attendances')->pluck('group_id')->ToArray();
        }
        
       
         
        $instructor_group = Group::whereIn('id',$GroupId)->WhereNotNull('instructor_id')->distinct()
        ->pluck('instructor_id')->toArray();
        
        $instructors = Employee::where('status',1)->whereIn('id',$instructor_group);
        if($request->branch_id != null && $request->branch_id != ' ' && $request->branch_id !=''){
            $instructors->where('current_branch' ,$request->branch_id );
        }
        $instructors= $instructors->get();
        */
        $subRounds = SubRound::join('rounds','rounds.id','=','sub_rounds.round_id')->where('sub_rounds.start_date','<=',date('Y-m-d'))->orderBy('sub_rounds.start_date','desc')->take(25)->select(DB::raw('concat(rounds.title,", ",sub_rounds.start_date) as sub_round_name'),'sub_rounds.id')->get()->pluck('sub_round_name', 'id');

        return view('total_attendance',compact('empty_sessions','instructors_attendance','branches','subRounds') );
                                    
    }
    
    public function totalcall(Request $request)
    {
        $view_type = 'branches';
        if($request->has('view_type')){
            $view_type = $request->get('view_type');
        }
        $reachable_labelTypes = LabelType::where('type', 'Reachable')->pluck('id');

        $registration_from=null;
        $reg_to=null;

        if (request()->has('daterange') && request()->get('daterange') != null && request()->get('daterange') != '') {
            $daterange = explode(' - ',request()->get('daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
            
        }
        $leadCases = [];
        if($view_type == 'branches'){
            $branches = Branch::where('status',1)->get();
            $employees =[];
            $leadcas = LeadCase::select('branch_id','type','label_type_id',DB::raw('count(*) as total_calls'));
            if ($registration_from != null && $registration_to != ''){
                $leadcas->whereBetween('created_at', [$registration_from, $registration_to]);
            }else{
                $leadcas->where('created_at','like','%'.date('Y-m-d').'%');
            }
            $leadcase = $leadcas->groupBy('branch_id','type','label_type_id')->get();
            
            foreach($branches as $branch){
                $leadCases[$branch->id]['total_sales'] = $leadcase->where('branch_id',$branch->id)->where('type',1)->sum('total_calls');
                $leadCases[$branch->id]['total_sales_reachable'] = $leadcase->where('branch_id',$branch->id)->where('type',1)->whereIn('label_type_id',$reachable_labelTypes)->sum('total_calls');
                $leadCases[$branch->id]['total_sales_coming'] = $leadcase->where('branch_id',$branch->id)->where('label_type_id',7)->where('type',1)->sum('total_calls');
                $leadCases[$branch->id]['total_customer'] = $leadcase->where('branch_id',$branch->id)->where('type',2)->sum('total_calls');
                $leadCases[$branch->id]['total_customer_reachable'] = $leadcase->where('branch_id',$branch->id)->where('type',2)->whereIn('label_type_id',$reachable_labelTypes)->sum('total_calls');
                $leadCases[$branch->id]['total_customer_confirmed'] = $leadcase->where('branch_id',$branch->id)->where('label_type_id',42)->where('type',2)->sum('total_calls');
                $leadCases[$branch->id]['total_client'] = $leadcase->where('branch_id',$branch->id)->where('type',3)->sum('total_calls');
                $leadCases[$branch->id]['total_client_reachable'] = $leadcase->where('branch_id',$branch->id)->where('type',3)->whereIn('label_type_id',$reachable_labelTypes)->sum('total_calls');
                $leadCases[$branch->id]['total_client_confirmed'] = $leadcase->where('branch_id',$branch->id)->whereIn('label_type_id',[88,80])->where('type',3)->sum('total_calls');
                $leadCases[$branch->id]['total_operation_inquiry'] = $leadcase->where('branch_id',$branch->id)->where('type',4)->sum('total_calls');
            }
            
            //dd($leadCases);
        }
        elseif($view_type == 'employees'){
            $branches = Branch:: where('status',1)->pluck('id');
         
            $employees = Employee::where('account_Type', 'Operations Account')
                 ->where('status',1)->whereIn('current_branch' ,$branches)->get();
            $leadcas = LeadCase::select('employee_id','type','label_type_id',DB::raw('count(*) as total_calls')); 
            if ($registration_from != null && $registration_to != ''){
                $leadcas->whereBetween('created_at', [$registration_from, $registration_to]);
            }else{
                $leadcas->where('created_at','like','%'.date('Y-m-d').'%');
            }
            $leadcase = $leadcas->groupBy('employee_id','type','label_type_id')->get();
            
            foreach($employees as $employee){
                $leadCases[$employee->id]['total_sales'] = $leadcase->where('employee_id',$employee->id)->where('type',1)->sum('total_calls');
                $leadCases[$employee->id]['total_sales_reachable'] = $leadcase->where('employee_id',$employee->id)->where('type',1)->whereIn('label_type_id',$reachable_labelTypes)->sum('total_calls');
                $leadCases[$employee->id]['total_sales_coming'] = $leadcase->where('employee_id',$employee->id)->where('label_type_id',7)->where('type',1)->sum('total_calls');
                $leadCases[$employee->id]['total_customer'] = $leadcase->where('employee_id',$employee->id)->where('type',2)->sum('total_calls');
                $leadCases[$employee->id]['total_customer_reachable'] = $leadcase->where('employee_id',$employee->id)->where('type',2)->whereIn('label_type_id',$reachable_labelTypes)->sum('total_calls');
                $leadCases[$employee->id]['total_customer_confirmed'] = $leadcase->where('employee_id',$employee->id)->where('label_type_id',42)->where('type',2)->sum('total_calls');
                $leadCases[$employee->id]['total_client'] = $leadcase->where('employee_id',$employee->id)->where('type',3)->sum('total_calls');
                $leadCases[$employee->id]['total_client_reachable'] = $leadcase->where('employee_id',$employee->id)->where('type',3)->whereIn('label_type_id',$reachable_labelTypes)->sum('total_calls');
                $leadCases[$employee->id]['total_client_confirmed'] = $leadcase->where('employee_id',$employee->id)->whereIn('label_type_id',[88,80])->where('type',3)->sum('total_calls');
                $leadCases[$employee->id]['total_operation_inquiry'] = $leadcase->where('employee_id',$employee->id)->where('type',4)->sum('total_calls');
            }
        }
        //dd($leadCases);
        
        return view('sales_reports.total_call',compact('branches','view_type','employees','leadCases'));
    }
    
    public function showAllData()
    {
        return null;
    }
    
    public function placement_test()
    {
        return view('customers_portal.placement_test');
    }
    
    public function placement_test_result()
    {
        return view('customers_portal.placement_test_result');
    }
    
    public function website_view()
    {
        
    }
    
    public function home_searchBar(Request $request)
    {
        $html = '';
        if($request->search_text != null && $request->search_text != ''){
            $leads = Lead::where('mobile_1', 'like', '%' . $request->search_text . '%')->orwhere('mobile_2', 'like', '%' . $request->search_text . '%')->orWhere('email', 'like', '%' . $request->search_text . '%')->get();
            // return $leads;
            foreach($leads as $lead){
                $html .= '<p>';
                
                    // $html .= '<a target="_blank" href="'. route('admin.leadCases.index') .'?lead='.$lead->id.'&type='.$lead->type.'">';
                    if($lead->type == 1)
                    {
                        $html .= '<a target="_blank" href="'. route('admin.leads.show',$lead->id) .'">';
                        
                    }else{
                        $html .= '<a target="_blank" href="'. route('admin.database.show',$lead->id).'">';
                    
                    }
               
			    $html .=  $lead->getName().' , '.$lead->mobile_1.', './*$lead->email.' , '.*/Lead::$lead_type[$lead->type].' , '.$lead->lead_source->name.' , '.$lead->branch->name;
			    $html .= '</a>';
			    $html .= '</p>';
            }
        }
        return $html;
    }
    
    public function books_demo($level_id)
    {
        $level = StageLevel::find($level_id);
        return view('customers_portal.books_demo',compact('level'));
    }
    
    public function showPaymentReport(Request $request)
    {
        $view_type = 'employees';
        if($request->has('view_type')){
            $view_type = $request->get('view_type');
        }
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $agents = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $agents = Employee::/*where('account_Type', 'Operations Account')->*/where('status',1)
                            ->whereIn('current_branch' , $request->get('branches'))
                            ->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::/*where('account_Type', 'Operations Account')->*/where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        $from = null;
        $to = null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $from = date_format(date_create($daterange[0]),'Y-m-d');
            // $to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $to= date_format($reg_to,"Y-m-d");
        }
        $register_from = null;
        $register_to = null;
        if ($request->has('register_daterange') && $request->get('register_daterange') != null && $request->get('register_daterange') != '') {
            $register_daterange = explode(' - ',$request->get('register_daterange'));
            $register_from = date_format(date_create($register_daterange[0]),'Y-m-d');
            // $register_to = date_format(date_create($register_daterange[1]),'Y-m-d');
            $reg_to  = date_create($register_daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $register_to= date_format($reg_to,"Y-m-d");
        }
        $timeframes = Timeframe::where('status',1)->pluck('title','id')->toArray();
        $rounds = [];
        $daysData = [];
        $subRounds = [];
        
        if($request->has('timeframe_id') && $request->get('timeframe_id') != null && $request->get('timeframe_id') != ''){
            $rounds = Round::where('timeframe_id',$request->get('timeframe_id'))->pluck('title', 'id')->toArray();
        }
        
        if($request->has('round_id') && $request->get('round_id') != null && $request->get('round_id') != ''){
            $round = Round::with('timeframe.intervals')->find($request->get('round_id'));
            $daysData = $round->timeframe->days;
        }
        if($request->has('days') && $request->get('days') != null && $request->get('days') != ''){
            $subRounds = SubRound::where('days', $request->get('days'))
                                -> where('round_id', $request->get('round_id'))
                                //-> whereDate('start_date', '>=', now())
                                -> orderBy('start_date')
                                ->select('id','start_date','end_date',DB::raw('concat(start_date," / ",end_date) as start_end_date'))->get()->pluck('start_end_date', 'id');
        }
        $first_total_payments = LeadPayment::select('lead_id',DB::raw('count(*) as total_payment'))->whereIn('paymentable_type',['App\Models\ServiceFee','App\Models\Offer'])->groupBy('lead_id')->having('total_payment','>=',1)->pluck('lead_id')->toArray();
        
        if($view_type == 'employees'){
            
            $paymentQuery1 = LeadPayment::whereNotNull('paymentable_type')->whereNotNull('paymentable_id')->whereNotNull('employee_id')->where('payment_plan_id',2)->where('rest',0);
            
            if (count($agents) > 0){
                $paymentQuery1->whereIn('employee_id', array_keys($agents));
            }
            if(! auth()->user()->can('reports show_all_data')){
                $paymentQuery1->where('employee_id', auth()->user()->id);
            }
            
            if($register_from && $register_to){
                $paymentQuery1->whereHas('lead',function($quary) use($register_from,$register_to){
                    $quary->whereBetween('created_at',[$register_from,$register_to]);
                });
            }
            
            if ($from && $to) {
                $paymentQuery1->whereBetween('created_at',[$from,$to]);
            }elseif($register_from && $register_to){
                $paymentQuery1->whereBetween('created_at',[$register_from,$register_to]);
            }elseif($request->has('sub_round_id') && $request->get('sub_round_id') != null && $request->get('sub_round_id') != ''){
                $subRound = SubRound::find($request->get('sub_round_id'));
                $paymentQuery1->whereBetween('created_at',[$subRound->start_date,$subRound->end_date]);
            }
            else{
                $paymentQuery1->where('created_at','like','%'.date('Y-m-d').'%');
            }
            
            $employees_payment1 = $paymentQuery1->orderBy('employee_id')->select('employee_id','paymentable_type','paymentable_id','amount','lead_id')->get()->groupBy('employee_id');
            
            $paymentQuery2 = SubPayment::leftjoin('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
                ->leftjoin('leads','leads.id','lead_payments.lead_id')
                ->whereIn('lead_payments.payment_plan_id',[1,3])
                ->where('sub_payments.paid',1)
                ->whereNotNull('lead_payments.paymentable_type')
                ->whereNotNull('lead_payments.paymentable_id')
                ->whereNotNull('sub_payments.employee_id');
                //->whereRaw('sub_payments.due_date != DATE_FORMAT(lead_payments.created_at, "%Y-%m-%d")');
            
            if (count($agents) > 0){
                $paymentQuery2->whereIn('sub_payments.employee_id', array_keys($agents));
            }
            if(! auth()->user()->can('reports show_all_data')){
                $paymentQuery2->where('sub_payments.employee_id', auth()->user()->id);
            }
            
            if($register_from && $register_to){
                $paymentQuery2->whereBetween('leads.created_at',[$register_from,$register_to]);
            }
            
            if ($from && $to) {
                if($from == $to){
                    $paymentQuery2->where('sub_payments.due_date',$from);
                }else{
                    $paymentQuery2->where('sub_payments.due_date','>=',$from)->where('sub_payments.due_date','<',$to);
                }
            }elseif($register_from && $register_to){
                if($register_from == $register_to){
                    $paymentQuery2->where('sub_payments.due_date',$register_from);
                }else{
                    $paymentQuery2->where('sub_payments.due_date','>=',$register_from)->where('sub_payments.due_date','<',$register_to);
                }
            }elseif($request->has('sub_round_id') && $request->get('sub_round_id') != null && $request->get('sub_round_id') != ''){
                $subRound = SubRound::find($request->get('sub_round_id'));
                $paymentQuery2->where('sub_payments.due_date','>=',$subRound->start_date)->where('sub_payments.due_date','<',$subRound->end_date);
            }
            else{
                $paymentQuery2->where('sub_payments.due_date','like','%'.date('Y-m-d').'%');
            }
            
            $employees_payment2 = $paymentQuery2->select('sub_payments.employee_id','sub_payments.amount','sub_payments.payment_date','sub_payments.created_at')->orderBy('sub_payments.employee_id')->with('leadPayment')->get()->groupBy('employee_id');
            //dd($employees_payment2[536]);
            
            $oldPaymentQuery = SubPayment::leftjoin('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
                ->leftjoin('leads','leads.id','lead_payments.lead_id')
                ->whereIn('lead_payments.payment_plan_id',[1,3])
                ->where('sub_payments.paid',1)
                ->whereNull('lead_payments.paymentable_type')
                ->whereNotNull('sub_payments.employee_id')
                ->whereRaw('sub_payments.due_date != DATE_FORMAT(lead_payments.created_at, "%Y-%m-%d")');
            
            if (count($agents) > 0){
                $oldPaymentQuery->whereIn('sub_payments.employee_id', array_keys($agents));
            }
            if(! auth()->user()->can('reports show_all_data')){
                $oldPaymentQuery->where('sub_payments.employee_id', auth()->user()->id);
            }
            
            if($register_from && $register_to){
                $oldPaymentQuery->whereBetween('leads.created_at',[$register_from,$register_to]);
            }
            
            if ($from && $to) {
                if($from == $to){
                    $oldPaymentQuery->where('sub_payments.due_date',$from);
                }else{
                    $oldPaymentQuery->where('sub_payments.due_date','>=',$from)->where('sub_payments.due_date','<',$to);
                }
            }elseif($register_from && $register_to){
                if($register_from == $register_to){
                    $oldPaymentQuery->where('sub_payments.due_date',$register_from);
                }else{
                    $oldPaymentQuery->where('sub_payments.due_date','>=',$register_from)->where('sub_payments.due_date','<',$register_to);
                }
            }elseif($request->has('sub_round_id') && $request->get('sub_round_id') != null && $request->get('sub_round_id') != ''){
                $subRound = SubRound::find($request->get('sub_round_id'));
                $oldPaymentQuery->where('sub_payments.due_date','>=',$subRound->start_date)->where('sub_payments.due_date','<',$subRound->end_date);
            }
            else{
                $oldPaymentQuery->where('sub_payments.due_date','like','%'.date('Y-m-d').'%');
            }
            
            $employees_old_payment = $oldPaymentQuery->select('sub_payments.employee_id','sub_payments.amount','sub_payments.payment_date','sub_payments.created_at')->orderBy('sub_payments.employee_id')->with('leadPayment')->get()->groupBy('employee_id');
            
            $employees_payment = collect();
            if($employees_payment1 != null && count($employees_payment1) > 0){
                foreach($employees_payment1 as $employee_id => $employee_payment1){
                    
                    $format_payment = new LeadPayment;
                    $format_payment->employee_id = $employee_id;
                    
                    $offers_amount = $employee_payment1->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->whereNotIn('lead_id',$first_total_payments)->sum('amount');
                    $offers_count = $employee_payment1->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->whereNotIn('lead_id',$first_total_payments)->count();
                    
                    if(isset($employees_payment2[$employee_id]) && count($employees_payment2[$employee_id]) > 0){
                        $offers_amount += $employees_payment2[$employee_id]->whereNotIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                        $offers_count += $employees_payment2[$employee_id]->whereNotIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    }
                    
                    $format_payment->offers_amount = $offers_amount;
                    $format_payment->offers_count = $offers_count;
                    
                    $activations_amount = $employee_payment1->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->whereIn('lead_id',$first_total_payments)->sum('amount');
                    $activations_count = $employee_payment1->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->whereIn('lead_id',$first_total_payments)->count();
                    if(isset($employees_payment2[$employee_id]) && count($employees_payment2[$employee_id]) > 0){
                        $activations_amount += $employees_payment2[$employee_id]->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                        $activations_count += $employees_payment2[$employee_id]->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    }
                    $format_payment->activations_amount = $activations_amount;
                    $format_payment->activations_count = $activations_count;
                    
                    $format_payment->books_amount = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',[4,5,6,7,8,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25])->sum('amount');
                    $format_payment->books_count = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',[4,5,6,7,8,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25])->count();
                    $format_payment->certificates_amount = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',[2,3])->sum('amount');
                    $format_payment->certificates_count = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',[2,3])->count();
                    $format_payment->pt_amount = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->where('paymentable_id',28)->sum('amount');
                    $format_payment->pt_count = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->where('paymentable_id',28)->count();
                    
                    $format_payment->MUSessions_amount = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->where('paymentable_id',31)->sum('amount');
                    $format_payment->MUSessions_count = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->where('paymentable_id',31)->count();
                    
                    $format_payment->transfer_freeze_amount = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',[29,30,33,34,35,36,37,39,40])->sum('amount');
                    $format_payment->transfer_freeze_count = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',[29,30,33,34,35,36,37,39,40])->count();
                    
                    
                    $completting_payment = 0;
                    if(isset($employees_payment2[$employee_id]) && count($employees_payment2[$employee_id]) > 0){
                        $completting_payment += $employees_payment2[$employee_id]->filter(function ($value, $key) { return $value->payment_date != date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                    }
                    if(isset($employees_old_payment[$employee_id]) && count($employees_old_payment[$employee_id]) > 0){
                        $completting_payment += $employees_old_payment[$employee_id]->sum('amount');
                    }
                    
                    $format_payment->completting_payment = $completting_payment;
                    $employees_payment[$employee_id] = $format_payment;
                    
                    if(isset($employees_payment2[$employee_id]) && count($employees_payment2[$employee_id]) > 0){
                        unset($employees_payment2[$employee_id]);
                    }
                    
                    if(isset($employees_old_payment[$employee_id]) && count($employees_old_payment[$employee_id]) > 0){
                        unset($employees_old_payment[$employee_id]);
                    }
                    
                }
            }
            
            if($employees_payment2 != null && count($employees_payment2) > 0){
                foreach($employees_payment2 as $employee_id => $employee_payment2){
                    //dd($employee_payment2);
                    
                    $format_payment = new LeadPayment;
                    $format_payment->employee_id = $employee_id;
                    $format_payment->offers_amount = $employee_payment2->whereNotIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                    $format_payment->offers_count = $employee_payment2->whereNotIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    
                    $format_payment->activations_amount = $employee_payment2->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                    $format_payment->activations_count = $employee_payment2->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    
                    $format_payment->books_amount = 0;
                    $format_payment->books_count = 0;
                    $format_payment->certificates_amount = 0;
                    $format_payment->certificates_count = 0;
                    $format_payment->pt_amount = 0;
                    $format_payment->pt_count = 0;
                    
                    $format_payment->MUSessions_amount = 0;
                    $format_payment->MUSessions_count = 0;
                    
                    $format_payment->transfer_freeze_amount = 0;
                    $format_payment->transfer_freeze_count = 0;
                    
                    $completting_payment = $employee_payment2->filter(function ($value, $key) { return $value->payment_date != date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                    if(isset($employees_old_payment[$employee_id]) && count($employees_old_payment[$employee_id]) > 0){
                        $completting_payment += $employees_old_payment[$employee_id]->sum('amount');
                    }
                    $format_payment->completting_payment = $completting_payment;
                    
                    if(isset($employees_old_payment[$employee_id]) && count($employees_old_payment[$employee_id]) > 0){
                        unset($employees_old_payment[$employee_id]);
                    }
                    
                    $employees_payment->push($format_payment);
                }
            }
            
            if($employees_old_payment != null && count($employees_old_payment) > 0){
                foreach($employees_old_payment as $employee_id => $employee_old_payment){
                    $format_payment = new LeadPayment;
                    $format_payment->employee_id = $employee_id;
                    $format_payment->offers_amount = 0;
                    $format_payment->offers_count = 0;
                    
                    $format_payment->activations_amount = 0;
                    $format_payment->activations_count = 0;
                    
                    $format_payment->books_amount = 0;
                    $format_payment->books_count = 0;
                    $format_payment->certificates_amount = 0;
                    $format_payment->certificates_count = 0;
                    $format_payment->pt_amount = 0;
                    $format_payment->pt_count = 0;
                    
                    $format_payment->MUSessions_amount = 0;
                    $format_payment->MUSessions_count = 0;
                    
                    $format_payment->transfer_freeze_amount = 0;
                    $format_payment->transfer_freeze_count = 0;
                    
                    $format_payment->completting_payment = $employee_old_payment->sum('amount');
                    $employees_payment->push($format_payment);
                }
            }
            
        }else{
            
            $paymentQuery1 = LeadPayment::whereNotNull('paymentable_type')->whereNotNull('paymentable_id')->whereNotNull('branch_id')->where('payment_plan_id',2)->where('rest',0)->whereIn('branch_id',array_keys($employeeBranches));
            
            if($register_from && $register_to){
                $paymentQuery1->whereHas('lead',function($quary) use($register_from,$register_to){
                    $quary->whereBetween('created_at',[$register_from,$register_to]);
                });
            }
            
            if ($from && $to) {
                $paymentQuery1->whereBetween('created_at',[$from,$to]);
            }elseif($register_from && $register_to){
                $paymentQuery1->whereBetween('created_at',[$register_from,$register_to]);
            }elseif($request->has('sub_round_id') && $request->get('sub_round_id') != null && $request->get('sub_round_id') != ''){
                $subRound = SubRound::find($request->get('sub_round_id'));
                $paymentQuery1->whereBetween('created_at',[$subRound->start_date,$subRound->end_date]);
            }
            else{
                $paymentQuery1->where('created_at','like','%'.date('Y-m-d').'%');
            }
            
            $employees_payment1 = $paymentQuery1->orderBy('branch_id')->select('branch_id','paymentable_type','paymentable_id','amount','lead_id')->get()->groupBy('branch_id');
            
            $paymentQuery2 = SubPayment::leftjoin('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
                ->leftjoin('leads','leads.id','lead_payments.lead_id')
                ->whereNotNull('lead_payments.paymentable_type')
                ->whereIn('lead_payments.payment_plan_id',[1,3])
                ->where('sub_payments.paid',1)
                ->whereNotNull('sub_payments.branch_id')
                ->whereIn('sub_payments.branch_id',array_keys($employeeBranches));
                //->whereRaw('sub_payments.due_date != DATE_FORMAT(lead_payments.created_at, "%Y-%m-%d")');
                
            if($register_from && $register_to){
                $paymentQuery2->whereBetween('leadscreated_at',[$register_from,$register_to]);
            }
            
            if ($from && $to) {
                if($from == $to){
                    $paymentQuery2->where('sub_payments.due_date',$from);
                }else{
                    $paymentQuery2->where('sub_payments.due_date','>=',$from)->where('sub_payments.due_date','<',$to);
                }
            }elseif($register_from && $register_to){
                if($register_from == $register_to){
                    $paymentQuery2->where('sub_payments.due_date',$register_from);
                }else{
                    $paymentQuery2->whereBetween('sub_payments.due_date','>=',$register_from)->where('sub_payments.due_date','<',$register_to);
                }
            }elseif($request->has('sub_round_id') && $request->get('sub_round_id') != null && $request->get('sub_round_id') != ''){
                $subRound = SubRound::find($request->get('sub_round_id'));
                $paymentQuery2->where('sub_payments.due_date','>=',$subRound->start_date)->where('sub_payments.due_date','<',$subRound->end_date);
            }
            else{
                $paymentQuery2->where('sub_payments.due_date','like','%'.date('Y-m-d').'%');
            }
            
            $employees_payment2 = $paymentQuery2->select('sub_payments.branch_id','sub_payments.amount','sub_payments.payment_date','sub_payments.created_at')->orderBy('sub_payments.branch_id')->with('leadPayment')->get()->groupBy('branch_id');
            
            $oldPaymentQuery = SubPayment::leftjoin('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
                ->leftjoin('leads','leads.id','lead_payments.lead_id')
                ->whereNull('lead_payments.paymentable_type')
                ->whereIn('lead_payments.payment_plan_id',[1,3])
                ->where('sub_payments.paid',1)
                ->whereNotNull('sub_payments.branch_id')
                ->whereIn('sub_payments.branch_id',array_keys($employeeBranches))
                ->whereRaw('sub_payments.due_date != DATE_FORMAT(lead_payments.created_at, "%Y-%m-%d")');
                
            if($register_from && $register_to){
                $oldPaymentQuery->whereBetween('leadscreated_at',[$register_from,$register_to]);
            }
            
            if ($from && $to) {
                if($from == $to){
                    $oldPaymentQuery->where('sub_payments.due_date',$from);
                }else{
                    $oldPaymentQuery->where('sub_payments.due_date','>=',$from)->where('sub_payments.due_date','<',$to);
                }
            }elseif($register_from && $register_to){
                if($register_from == $register_to){
                    $oldPaymentQuery->where('sub_payments.due_date',$register_from);
                }else{
                    $oldPaymentQuery->whereBetween('sub_payments.due_date','>=',$register_from)->where('sub_payments.due_date','<',$register_to);
                }
            }elseif($request->has('sub_round_id') && $request->get('sub_round_id') != null && $request->get('sub_round_id') != ''){
                $subRound = SubRound::find($request->get('sub_round_id'));
                $oldPaymentQuery->where('sub_payments.due_date','>=',$subRound->start_date)->where('sub_payments.due_date','<',$subRound->end_date);
            }
            else{
                $oldPaymentQuery->where('sub_payments.due_date','like','%'.date('Y-m-d').'%');
            }
            
            $employees_old_payment = $oldPaymentQuery->select('sub_payments.branch_id','sub_payments.amount','sub_payments.payment_date','sub_payments.created_at')->orderBy('sub_payments.branch_id')->with('leadPayment')->get()->groupBy('branch_id');
            
            //dd($employees_payment1,$employees_payment2);
            $employees_payment = collect();
            if($employees_payment1 != null && count($employees_payment1) > 0){
                foreach($employees_payment1 as $branch_id => $employee_payment1){
                    $format_payment = new LeadPayment;
                    $format_payment->branch_id = $branch_id;
                    
                    $offers_amount = $employee_payment1->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->whereNotIn('lead_id',$first_total_payments)->sum('amount');
                    $offers_count = $employee_payment1->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->whereNotIn('lead_id',$first_total_payments)->count();
                    
                    if(isset($employees_payment2[$branch_id]) && count($employees_payment2[$branch_id]) > 0){
                        $offers_amount += $employees_payment2[$branch_id]->whereNotIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                        $offers_count += $employees_payment2[$branch_id]->whereNotIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    }
                    
                    $format_payment->offers_amount = $offers_amount;
                    $format_payment->offers_count = $offers_count;
                    
                    $activations_amount = $employee_payment1->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->whereIn('lead_id',$first_total_payments)->sum('amount');
                    $activations_count = $employee_payment1->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->whereIn('lead_id',$first_total_payments)->count();
                    if(isset($employees_payment2[$branch_id]) && count($employees_payment2[$branch_id]) > 0){
                        $activations_amount += $employees_payment2[$branch_id]->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                        $activations_count += $employees_payment2[$branch_id]->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    }
                    $format_payment->activations_amount = $activations_amount;
                    $format_payment->activations_count = $activations_count;
                    
                    $format_payment->books_amount = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',[4,5,6,7,8,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25])->sum('amount');
                    $format_payment->books_count = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',[4,5,6,7,8,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25])->count();
                    $format_payment->certificates_amount = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',[2,3])->sum('amount');
                    $format_payment->certificates_count = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',[2,3])->count();
                    $format_payment->pt_amount = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->where('paymentable_id',28)->sum('amount');
                    $format_payment->pt_count = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->where('paymentable_id',28)->count();
                    
                    $format_payment->MUSessions_amount = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->where('paymentable_id',31)->sum('amount');
                    $format_payment->MUSessions_count = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->where('paymentable_id',31)->count();
                    
                    $format_payment->transfer_freeze_amount = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',[29,30,33,34,35,36,37,39,40])->sum('amount');
                    $format_payment->transfer_freeze_count = $employee_payment1->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',[29,30,33,34,35,36,37,39,40])->count();
                    
                    
                    $completting_payment = 0;
                    if(isset($employees_payment2[$branch_id]) && count($employees_payment2[$branch_id]) > 0){
                        $completting_payment += $employees_payment2[$branch_id]->filter(function ($value, $key) { return $value->payment_date != date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                    }
                    if(isset($employees_old_payment[$branch_id]) && count($employees_old_payment[$branch_id]) > 0){
                        $completting_payment += $employees_old_payment[$branch_id]->sum('amount');
                    }
                    
                    $format_payment->completting_payment = $completting_payment;
                    $employees_payment[$branch_id] = $format_payment;
                    
                    if(isset($employees_payment2[$branch_id]) && count($employees_payment2[$branch_id]) > 0){
                        unset($employees_payment2[$branch_id]);
                    }
                    
                    if(isset($employees_old_payment[$branch_id]) && count($employees_old_payment[$branch_id]) > 0){
                        unset($employees_old_payment[$branch_id]);
                    }
                    
                    //dd($format_payment);
                }
            }
            
            if($employees_payment2 != null && count($employees_payment2) > 0){
                foreach($employees_payment2 as $branch_id => $employee_payment2){
                    $format_payment = new LeadPayment;
                    $format_payment->branch_id = $branch_id;
                    $format_payment->offers_amount = $employee_payment2->whereNotIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                    $format_payment->offers_count = $employee_payment2->whereNotIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    
                    $format_payment->activations_amount = $employee_payment2->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                    $format_payment->activations_count = $employee_payment2->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    
                    $format_payment->books_amount = 0;
                    $format_payment->books_count = 0;
                    $format_payment->certificates_amount = 0;
                    $format_payment->certificates_count = 0;
                    $format_payment->pt_amount = 0;
                    $format_payment->pt_count = 0;
                    
                    $format_payment->MUSessions_amount = 0;
                    $format_payment->MUSessions_count = 0;
                    
                    $format_payment->transfer_freeze_amount = 0;
                    $format_payment->transfer_freeze_count = 0;
                    
                    $completting_payment = $employee_payment2->filter(function ($value, $key) { return $value->payment_date != date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                    if(isset($employees_old_payment[$branch_id]) && count($employees_old_payment[$branch_id]) > 0){
                        $completting_payment += $employees_old_payment[$branch_id]->sum('amount');
                    }
                    $format_payment->completting_payment = $completting_payment;
                    
                    if(isset($employees_old_payment[$branch_id]) && count($employees_old_payment[$branch_id]) > 0){
                        unset($employees_old_payment[$branch_id]);
                    }
                    
                    $employees_payment->push($format_payment);
                }
            }
            
            if($employees_old_payment != null && count($employees_old_payment) > 0){
                foreach($employees_old_payment as $branch_id => $employee_old_payment){
                    $format_payment = new LeadPayment;
                    $format_payment->employee_id = $branch_id;
                    $format_payment->offers_amount = 0;
                    $format_payment->offers_count = 0;
                    
                    $format_payment->activations_amount = 0;
                    $format_payment->activations_count = 0;
                    
                    $format_payment->books_amount = 0;
                    $format_payment->books_count = 0;
                    $format_payment->certificates_amount = 0;
                    $format_payment->certificates_count = 0;
                    $format_payment->pt_amount = 0;
                    $format_payment->pt_count = 0;
                    
                    $format_payment->MUSessions_amount = 0;
                    $format_payment->MUSessions_count = 0;
                    
                    $format_payment->transfer_freeze_amount = 0;
                    $format_payment->transfer_freeze_count = 0;
                    
                    $format_payment->completting_payment = $employee_old_payment->sum('amount');
                    $employees_payment->push($format_payment);
                }
            }
            
        }
        
        return view('operations_reports.payment_report',compact('view_type','employeeBranches','agents','employees_payment','timeframes','rounds','daysData','subRounds'));
    }
    
    public function showSourcesFollowupReport(Request $request)
    {
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        
        $leadSources = LeadSource::where('status',1)->get();
        $labelTypes = LabelType::where('status',1)->where('category',1)->orderBy('type')->get();
        $agents = [];
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id')->toArray();
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })
                            //->whereIn('current_branch' , $request->get('branches'))
                            ->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        $from = null;
        $to = null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $from = date_format(date_create($daterange[0]),'Y-m-d');
            // $to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $to= date_format($reg_to,"Y-m-d");
        }
        /*
        $leadCasesQuary = LeadCase::leftJoin('leads','leads.id','=','lead_cases.lead_id')
                                ->whereRaw('lead_cases.id in (select max(id) as last_follow_up_id from lead_cases group by lead_id)');
        */
        $leadsQuary = Lead::leftJoin('lead_last_cases','leads.id','=','lead_last_cases.lead_id')
        ->whereIn('lead_last_cases.label_type_id',$labelTypes->pluck('id')->toArray())
        ->where('leads.type',1)
        ->whereNotNull('leads.lead_source_id');
        /*
        if(count($agents) > 0){
            $leadsQuary->whereIn('leads.assigned_employee_id', array_keys($agents));
        }
        */
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $leadsQuary->whereIn('leads.branch_id', $request->get('branches'));
            //$leadsQuary->whereIn('leads.assigned_employee_id', array_keys($agents));
        }
        if($request->has('track_id') && $request->get('track_id') != '' && $request->get('track_id') != null){
                $leadsQuary->whereIn('leads.prefered_track_id', $request->get('track_id'));
        }
       
        
        if ($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
            $leadsQuary->where('leads.assigned_employee_id', $request->get('agent'));
        }
        
        if($from != null && $from != '' && $to != null && $to != ''){
            $leadsQuary->whereBetween('leads.created_at',[$from,$to]);
        }
        //dd(array_keys($labelTypes),$leadsQuary->select('lead_last_cases.label_type_id','leads.lead_source_id',DB::raw('count(*) as leads_count'))->groupBy('lead_last_cases.label_type_id')->groupBy('leads.lead_source_id')->toSql());
        $leads = $leadsQuary->select('lead_last_cases.label_type_id','leads.lead_source_id',DB::raw('count(*) as leads_count'))->groupBy('lead_last_cases.label_type_id')->groupBy('leads.lead_source_id')->get();
        
        $leads = $leads->groupBy('label_type_id');
        foreach($leads as $key => $lead){
            $leads[$key] = $lead->pluck('leads_count','lead_source_id')->toArray();
        }
        $leads = $leads->toArray();
        //dd($leads);
        return view('sales_reports.sources_followup',compact('labelTypes','employeeBranches','agents','tracks','leadSources','leads'));   
    }

    public function showSourcesCountReport(Request $request)
    {
        $view_type = 'branches';
        if($request->has('view_type')){
            $view_type = $request->get('view_type');
        }
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $agents = [];
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id')->toArray();
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })
                            //->whereIn('current_branch' , $request->get('branches'))
                            ->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        $from = null;
        $to = null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $from = date_format(date_create($daterange[0]),'Y-m-d');
            // $to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $to= date_format($reg_to,"Y-m-d");
        }
        
        $leadSources = LeadSource::where('status',1)->get();
        
        $lead= Lead::select('lead_source_id',DB::raw('count(*) as total_leads'))->groupBy('lead_source_id')->get()->pluck('total_leads','lead_source_id')->toArray();
        //dd($lead);
    //   return $lead[0]->pt;
        
        if($view_type == 'employees'){
            $leadsQuary = Lead::whereNotNull('lead_source_id')->whereNotNull('assigned_employee_id')
            ->whereHas('assignedEmployee',function($quary){
                $quary->where('account_Type', 'Operations Account')->where('status',1);
            });
            if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
                $leadsQuary->whereIn('branch_id', $request->get('branches'));
            }
            elseif (count($agents) > 0){
                $leadsQuary->whereIn('assigned_employee_id', array_keys($agents));
            }
            
            if ($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
                $leadsQuary->where('assigned_employee_id', $request->get('agent'));
            }
            if($request->has('track_id') && $request->get('track_id') != '' && $request->get('track_id') != null){
                $leadsQuary->whereIn('leads.prefered_track_id', $request->get('track_id'));
                //$leadsQuary->whereIn('leads.assigned_employee_id', array_keys($agents));
            }
        
            if ($request->has('type') && $request->get('type') != null && $request->get('type') != ''){
                $leadsQuary->where('type', $request->get('type'));
            }else{
                $leadsQuary->where('type', 1);
            }
        
            if($from != null && $from != '' && $to != null && $to != ''){
                $leadsQuary->whereBetween('created_at',[$from,$to]);
            }else{
                $leadsQuary->where('created_at','like','%'.date('Y-m-d').'%');
            }
            //dd($request->get('branches'),$from,$to,$leadsQuary->select('assigned_employee_id','lead_source_id',DB::raw('count(*) as source_count'))->groupBy('assigned_employee_id')->groupBy('lead_source_id')->orderBy('assigned_employee_id')->toSql());
            $leads = $leadsQuary->select('assigned_employee_id','lead_source_id',DB::raw('count(*) as source_count'))->groupBy('assigned_employee_id')->groupBy('lead_source_id')->orderBy('assigned_employee_id')->get();
            $leads = $leads->groupBy('assigned_employee_id');
            $employees_ids = array_keys($leads->toArray());
            
            $loops = Employee::where('status',1)->select('id','first_name','middle_name','last_name')->whereIn('id',$employees_ids)->get();
        }else{
            $leadsQuary = Lead::whereNotNull('lead_source_id');
        
            if ($request->has('type') && $request->get('type') != null && $request->get('type') != ''){
                $leadsQuary->where('type', $request->get('type'));
            }else{
                $leadsQuary->where('type', 1);
            }
        
            if($from != null && $from != '' && $to != null && $to != ''){
                $leadsQuary->whereBetween('created_at',[$from,$to]);
            }else{
                $leadsQuary->where('created_at','like','%'.date('Y-m-d').'%');
            }
            if($request->has('track_id') && $request->get('track_id') != '' && $request->get('track_id') != null){
                  $leadsQuary->whereIn('leads.prefered_track_id', $request->get('track_id'));
                  //$leadsQuary->whereIn('leads.assigned_employee_id', array_keys($agents));
              }
            
            
            $leads = $leadsQuary->select('branch_id','lead_source_id',DB::raw('count(*) as source_count'))->groupBy('branch_id')->groupBy('lead_source_id')->orderBy('branch_id')->get();
            $leads = $leads->groupBy('branch_id');
            $branches_ids = array_keys($leads->toArray());
            
            $loops = Branch::where('status',1)->whereIn('id',$branches_ids)->pluck('name','id');
        }
        return view('sales_reports.sources_count_report',compact('view_type','tracks','lead','employeeBranches','agents','leadSources','leads','loops'));
    }
    
    public function showRecentFollowupReport(Request $request)
    {
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $agents = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            /*->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })*/->whereIn('current_branch' , $request->get('branches'))
                            ->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        $from = null;
        $to = null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $from = date_format(date_create($daterange[0]),'Y-m-d');
            // $to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $to= date_format($reg_to,"Y-m-d");
        }
        
        $register_from = null;
        $register_to = null;
        if ($request->has('register_daterange') && $request->get('register_daterange') != null && $request->get('register_daterange') != '') {
            $register_daterange = explode(' - ',$request->get('register_daterange'));
            $register_from = date_format(date_create($register_daterange[0]),'Y-m-d');
            // $register_to = date_format(date_create($register_daterange[1]),'Y-m-d');
            $reg_to  = date_create($register_daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $register_to= date_format($reg_to,"Y-m-d");
        }
         $types = ($request->has('types'))?$request->types:[1];
        $labelTypes = LabelType::where('status',1)->whereIn('category',$types)->pluck('name','id')->toArray();
        
        $leadCasesQuary = LeadCase::whereIn('label_type_id',array_keys($labelTypes))->with('lead')->whereHas('employee',function($quary){
            $quary->where('account_Type', 'Operations Account')->where('status',1);
        });
        
        if($register_from && $register_to){
            $leadCasesQuary->whereHas('lead',function($query) use ($register_from,$register_to){
                $query->whereBetween('created_at',[$register_from,$register_to]);
            });
        }
        
        if($from && $to){
            $leadCasesQuary->whereBetween('created_at', [$from, $to]);
        }elseif($register_from && $register_to){
            $leadCasesQuary->whereBetween('created_at', [$register_from,$register_to]);
        }
        else{
            $leadCasesQuary->where('created_at','like','%'.date('Y-m-d').'%');
        }
        
        if(count($agents) > 0){
            $leadCasesQuary->whereIn('employee_id', array_keys($agents));
        }
        
        if($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
            $leadCasesQuary->where('employee_id', $request->get('agent'));
        }
        
        if(! auth()->user()->can('reports show_all_data')){
            $leadCasesQuary->where('employee_id', auth()->user()->id);
        }
        
        $followupsCount = $leadCasesQuary->count();
        $leadCases = $leadCasesQuary->orderBy('id','desc')->paginate($per_page);
        
        return view('sales_reports.recent_followup_report',compact('types','per_page','agents','employeeBranches','leadCases','followupsCount'));
    }
    
    public function showTotalFollowupReport(Request $request)
    {
        $view_type = 'employees';
        if($request->has('view_type')){
            $view_type = $request->get('view_type');
        }
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $agents = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            /*->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })*/
                            ->whereIn('current_branch' , $request->get('branches'))->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        $labelTypes = LabelType::select('id','name')->where('category',1)->where('status',1)->get();
        $from = null;
        $to = null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $from = date_format(date_create($daterange[0]),'Y-m-d');
            // $to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $to= date_format($reg_to,"Y-m-d");
        }
        
        if($view_type == 'employees'){
            if (count($agents) > 0){
                $leadCasesQuary = LeadLastCase::whereIn('employee_id', array_keys($agents));
            }else{
                $leadCasesQuary = LeadLastCase::whereHas('employee',function($quary){
                    $quary->where('account_Type', 'Operations Account')->where('status',1);
                });
            }
            $leadCasesQuary->whereIn('label_type_id',$labelTypes->pluck('id'));
            
            if ($from && $to) {
                $leadCasesQuary->whereHas('lead',function($quary) use ($from,$to){
                    $quary->whereBetween('created_at', [$from, $to]);
                });
            }
            /*
            if ($this->case_from && $this->case_to) {
                $leadCasesQuary->whereBetween('created_at', [$this->case_from, $this->case_to]);
            }
            */
            if ($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
                $leadCasesQuary->where('employee_id', $request->get('agent'));
            }
            
            if(! auth()->user()->can('reports show_all_data')){
                $leadCasesQuary->where('employee_id', auth()->user()->id);
            }
            $quary = '';
            foreach($labelTypes as $key => $labelType){
                $quary .= 'count(case when label_type_id = '.$labelType->id.' then label_type_id end) as labelTypeCount'.$labelType->id;
                if($key < (count($labelTypes) - 1)){
                    $quary .= ' , ';
                }
            }
            $leadCases = $leadCasesQuary->select('employee_id',DB::raw($quary))->groupBy('employee_id')->orderBy('employee_id')->get();
        }else{
            $leadCasesQuary = LeadLastCase::leftJoin('leads','leads.id','=','lead_last_cases.lead_id')->whereIn('leads.branch_id',array_keys($employeeBranches))
                    ->where('leads.type', 1)
                    
                    /*->whereHas('employee',function($quary){
                        $quary->where('account_Type', 'Operations Account');
                    })*/;
                    //->select('branch_id','employee_id','lead_id',DB::raw('max(id) as last_follow_up_id'))->groupBy('employee_id')->groupBy('lead_id')->orderBy('branch_id')->get();
        
            //$leadCasesQuary2 = LeadCase::whereIn('id',$leadCasesQuary1->pluck('last_follow_up_id'));
            
            if ($from && $to) {
                //dd($from);
                $leadCasesQuary->whereBetween('leads.created_at', [$from, $to]);
            }
            
            $quary = '';
            foreach($labelTypes as $key => $labelType){
                $quary .= 'count(case when lead_last_cases.label_type_id = '.$labelType->id.' then label_type_id end) as labelTypeCount'.$labelType->id;
                if($key < (count($labelTypes) - 1)){
                    $quary .= ' , ';
                }
            }
            $leadCases = $leadCasesQuary->select('leads.branch_id',DB::raw($quary))->groupBy('leads.branch_id')->orderBy('leads.branch_id')->get();
            
        }
        return view('sales_reports.total_followup_report',compact('view_type','agents','employeeBranches','labelTypes','leadCases'));
    }
    
    public function showNotdoneFollowupReport(Request $request)
    {
        $view_type = 'employees';
        if($request->has('view_type')){
            $view_type = $request->get('view_type');
        }
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $agents = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            /*->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })*/
                            ->whereIn('current_branch' , $request->get('branches'))->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        $from = null;
        $to = null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $from = date_format(date_create($daterange[0]),'Y-m-d');
            // $to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $to= date_format($reg_to,"Y-m-d");
        }
        
        $register_from = null;
        $register_to = null;
        if ($request->has('register_daterange') && $request->get('register_daterange') != null && $request->get('register_daterange') != '') {
            $register_daterange = explode(' - ',$request->get('register_daterange'));
            $register_from = date_format(date_create($register_daterange[0]),'Y-m-d');
            // $register_to = date_format(date_create($register_daterange[1]),'Y-m-d');
            $reg_to  = date_create($register_daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $register_to= date_format($reg_to,"Y-m-d");
        }
        
        if($view_type == 'employees'){
            $leadsQuery = Lead::whereNotNull('assigned_employee_id')->whereHas('assignedEmployee',function($quary){
                $quary->where('account_Type', 'Operations Account')->where('status',1);
            });
            
            if($register_from && $register_to){
                $leadsQuery->whereBetween('created_at',[$register_from,$register_to]);
            }
            if (count($agents) > 0){
                $leadsQuery->whereIn('assigned_employee_id', array_keys($agents));
            }
            
            if ($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
                $leadsQuery->where('assigned_employee_id', $request->get('agent'));
            }
            if(! auth()->user()->can('reports show_all_data')){
                $leadsQuery->where('assigned_employee_id', auth()->user()->id);
            }
            $leadsQuery = $leadsQuery->select('id','assigned_employee_id')->get();
            $leadsQuery = $leadsQuery->groupBy('assigned_employee_id');
            $leads = array();
            //dd($leadsQuery);
            foreach($leadsQuery as $key => $lead){
                $leads_ids = $lead->pluck('id')->toArray();
                
                $new_lead_case = new Lead;
                $new_lead_case['assigned_employee_id'] = $key;
                $leadCasesQuary = LeadCase::whereIn('lead_id', $leads_ids);
                if (count($agents) > 0){
                    $leadCasesQuary->whereIn('employee_id', array_keys($agents));
                }
                if ($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
                    $leadCasesQuary->where('employee_id', $request->get('agent'));
                }
                $overdueQuary = LeadCase::whereIn('lead_id', $leads_ids);
                if (count($agents) > 0){
                    $overdueQuary->whereIn('employee_id', array_keys($agents));
                }
                if ($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
                    $overdueQuary->where('employee_id', $request->get('agent'));
                }
                $new_lead_case['leads_no_followup'] = count(array_diff($leads_ids,array_unique($leadCasesQuary->pluck('lead_id')->toArray())));
                $new_lead_case['overdue_followup'] = $overdueQuary->where('status',0)->where('date','<',date('Y-m-d'))->count();
                //dd($leadCasesQuary);
                if($from && $to){
                    $leadCasesQuary->whereBetween('date', [$from, $to]);
                }elseif($register_from && $register_to){
                    $leadCasesQuary->whereBetween('date', [$register_from, $register_to]);
                }
                else{
                    $leadCasesQuary->where('date','like','%'.date('Y-m-d').'%');
                }
                $leadCasesQuary = $leadCasesQuary->get();
                $followup_count = $leadCasesQuary->count();
                
                $done_followup_count = $leadCasesQuary->where('status',1)->count();
                $notdone_followup_count = $leadCasesQuary->where('status',0)->count();
                $not_interested = $leadCasesQuary->where('label_type_id',12)->count();
                
                $new_lead_case['followup_count'] = $followup_count;
                $new_lead_case['done_followup_count'] = $done_followup_count;
                $new_lead_case['notdone_followup_count'] = $notdone_followup_count;
                $new_lead_case['not_interested'] = $not_interested;
                
                $leads[] = $new_lead_case;
            }
        }else{
            $leadsQuery = Lead::whereNotNull('branch_id')->whereIn('branch_id',array_keys($employeeBranches));/*->whereHas('assignedEmployee',function($quary){
                $quary->where('account_Type', 'Operations Account')->where('status',1);
            });*/
            
            if($register_from && $register_to){
                $leadsQuery->whereBetween('created_at',[$register_from,$register_to]);
            }
            $leadsQuery = $leadsQuery->select('id','branch_id')->get();
            $leadsQuery = $leadsQuery->groupBy('branch_id');
            $leads = array();
            foreach($leadsQuery as $key => $lead){
                $leads_ids = $lead->pluck('id')->toArray();
                
                $new_lead_case = new Lead;
                $new_lead_case->branch_id = $key;
                $leadCasesQuary = LeadCase::whereIn('lead_id', $leads_ids)->whereHas('employee',function($quary){
                    $quary->where('account_Type', 'Operations Account')->where('status',1);
                });
                $overdueQuary = LeadCase::where('lead_id', $leads_ids)->whereHas('employee',function($quary){
                    $quary->where('account_Type', 'Operations Account')->where('status',1);
                });
                //dd($leads_ids,array_unique($leadCasesQuary->pluck('lead_id')->toArray()));
                $new_lead_case['leads_no_followup'] = count(array_diff($leads_ids,array_unique($leadCasesQuary->pluck('lead_id')->toArray())));
                $new_lead_case['overdue_followup'] = $overdueQuary->where('status',0)->where('date','<',date('Y-m-d'))->count();;
                
                if($from && $to){
                    $leadCasesQuary->whereBetween('date', [$from, $to]);
                }
                elseif($register_from && $register_to){
                    $leadCasesQuary->whereBetween('date', [$register_from, $register_to]);
                }
                else{
                    $leadCasesQuary->where('date','like','%'.date('Y-m-d').'%');
                }
                $leadCasesQuary = $leadCasesQuary->get();
                $followup_count = $leadCasesQuary->count();
                //dd($followup_count,$leadCasesQuary->where('status',1)->count(),$leadCasesQuary->where('status',0)->count());
                $done_followup_count = $leadCasesQuary->where('status',1)->count();
                $notdone_followup_count = $leadCasesQuary->where('status',0)->count();
                $not_interested = $leadCasesQuary->where('label_type_id',12)->count();
                //dd($followup_count,$leadCasesQuary->where('status',1)->count(),$leadCasesQuary->where('status',0)->count(),$done_followup_count,$notdone_followup_count);
                $new_lead_case['followup_count'] = $followup_count;
                $new_lead_case['done_followup_count'] = $done_followup_count;
                $new_lead_case['notdone_followup_count'] = $notdone_followup_count;
                $new_lead_case['not_interested'] = $not_interested;
                
                $leads[] = $new_lead_case;
            }
        }
        //dd($leads);
        return view('sales_reports.notdone_followup_report',compact('view_type','employeeBranches','agents','leads'));
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function index(Request $request)
    {
        
        /*$group_students = GroupStudent::where('finance_status',2)->get();
        foreach($group_students as $group_student){
            
            $group = Group::find($group_student->group_id);
            GroupWaitingList::where('track_id',$group->track_id)->where('lead_id',$group_student->lead_id)->delete();
            $waiting_list = new GroupWaitingList;
            $waiting_list->create([
                'lead_id' => $group_student->lead_id,
                'level_id' => $group->level_id,
                'track_id' => $group->track_id,
                'course_id' => $group->course_id,
                'timeframes' => $group->timeframe_id,
                'discipline_id' => $group->discipline_id,
            ]);
            $lead = Lead::find($group_student->lead_id);
            $lead->type = 2;
            $lead->customer_type = "reject";
            $lead->save();
            
            $customer_track = CustomerTrack::where('track_id',$group->track_id)->where('lead_id',$group_student->lead_id)->first();
            $customer_track->used = $customer_track->total;
            $customer_track->save();
            
            GroupStudent::where('lead_id',$group_student->lead_id)->where('group_id' , $group_student->group_id)->delete();
            GroupSessionAttendance::where('lead_id',$group_student->lead_id)->where('group_id',$group_student->group_id)->delete();
            
        }*/
        // event(new MyEvent('hello world',auth()->user()->id));
        //dd($leads_not_in_group_session_attendances);
        //$testProcess = round(microtime(true) * 1000);
        $branches = Branch::where('status',1)->pluck('name', 'id');
        $employeeBranchesId = auth()->user()->branches->pluck('id')->toArray();
        
        $registration_from=null;
        $reg_to=null;  
 
        if (request()->has('operation_daterange') && request()->get('operation_daterange') != null && request()->get('operation_daterange') != '') {
            $daterange = explode(' - ',request()->get('operation_daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $registration_to  = date_create($daterange[1]);
            date_add($registration_to,date_interval_create_from_date_string("1 days"));
            $reg_to= date_format($registration_to,"Y-m-d");
            
        }
        //dd($registration_from,$reg_to);
        $leadsQuery= Lead::select('type',DB::raw('count(*) as total'));                   
        if (request()->filled('branches')) {
            $leadsQuery->whereIn('branch_id', request('branches'));
        } else {
            $leadsQuery->whereIn('branch_id', $employeeBranchesId);
        }
        /*if (request()->filled('daterange')) {
            
            //dd($daterange,$from,$to);
            $leadsQuery->whereBetween('created_at', [$from, $to]);
        }*/
        $leadsCount = $leadsQuery->groupBy('type')->orderBy('type')->get()->pluck('total','type')->toArray();
      
        if (request()->filled('branches')) {
            $applicantsQuery = PlacementApplicant::whereIn('branch_id', request('branches'));
        } else {
            $applicantsQuery = PlacementApplicant::whereIn('branch_id', $employeeBranchesId);
            // $applicantsQuery->whereIn('branch_id', $employeeBranchesId);
        }
        if($registration_from && $reg_to){
            
            $applicantsQuery->whereBetween('created_at', [$registration_from, $reg_to]);
        }else{
            $applicantsQuery->where('created_at','like','%'.date('Y-m-d').'%' );
        }
        $applicantsCount = $applicantsQuery->count();
        
        
        if (request()->filled('branches')) {
            $kidsApplicantsQuery = PlacementKidsApplicant::whereIn('branch_id', request('branches'));
        } else {
            $kidsApplicantsQuery = PlacementKidsApplicant::whereIn('branch_id', $employeeBranchesId);
            // $applicantsQuery->whereIn('branch_id', $employeeBranchesId);
        }
        if($registration_from && $reg_to){
            
            $kidsApplicantsQuery->whereBetween('created_at', [$registration_from, $reg_to]);
        }else{
            $kidsApplicantsQuery->where('created_at','like','%'.date('Y-m-d').'%' );
        }
        $kidsApplicantsCount = $kidsApplicantsQuery->count();

        $expenseQuery=Expense::orderBy('id', 'DESC');
        if (request()->filled('branches')) {
            $expenseQuery->whereIn('branch_id', request('branches'));
        } else {
            $expenseQuery->whereIn('branch_id', $employeeBranchesId);
        }
        if($registration_from && $reg_to){
            $expenseQuery->whereBetween('created_at', [$registration_from, $reg_to]);
        }else{
            $expenseQuery->where('created_at', 'like','%'.date('Y-m-d').'%');
        }
        
        $expenseQuery=$expenseQuery->sum('amount');

        if (request()->filled('branches')) {
            $safeQuery =Safe::where('is_hq',0)->whereIn('branch_id', request('branches'));
            // $safeQuery->whereIn('branch_id', request('branches'));
        } else {
            // $safeQuery->whereIn('branch_id', $employeeBranchesId);
            $safeQuery =Safe::where('is_hq',0)->whereIn('branch_id', $employeeBranchesId);
        }
        /*
        if (request()->filled('daterange')) {
            $safeQuery->whereBetween('created_at', [$from, $to]);
        }
        */
        $safeQueryCount = $safeQuery->sum('balance');

        
        $view_type = 'branches';
        if($request->has('view_type')){
            $view_type = $request->get('view_type');
        }
        $employeeBranches = auth()->user()->branches->whereNotIn('id',[16,18,19,22,23])->pluck('name', 'id')->toArray();
        $agents = [];
        
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereIn('current_branch' , $request->get('branches'))->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
           $agents = Employee::where('account_Type', 'Operations Account')->where('status', 1)->whereHas('branches', function ($query) use ($employeeBranches) {
                                   $query->whereIn('id', array_keys($employeeBranches));
                               })->groupBy('id')->get()->pluck('name', 'id')->toArray();

        if ($request->filled('created_by') || $request->filled('owner_by')) {
            $filteredAgents = [];
            if ($request->filled('created_by')) {
                $filteredAgents[$request->created_by] = $agents[$request->created_by];
            }
            if ($request->filled('owner_by')) {
                $filteredAgents[$request->owner_by] = $agents[$request->owner_by];
            }
            $agents = $filteredAgents;
        }
        }
        $agentss = Employee::where('account_Type', 'Operations Account')->where('status', 1)->groupBy('id')->get()->pluck('name', 'id')->toArray();
        
        $loop_through = '';
        $leadCases = [];
        
        $extra_items_ids = ExtraItem::pluck('id')->toArray();
        //dd($extra_items_ids);
        $first_total_payments = LeadPayment::select('lead_id',DB::raw('count(*) as total_payment'))->whereIn('paymentable_type',['App\Models\ServiceFee','App\Models\Offer'])->groupBy('lead_id')->having('total_payment','>=',1)->pluck('lead_id')->toArray();
        $reachable_labelTypes = LabelType::where('type', 'Reachable')->pluck('id');
        
        if($view_type == 'branches'){
            $loop_through = $employeeBranches;
            if ($registration_from != null && $reg_to != ''){
                 $leadCases = LeadCase::select('branch_id','type',DB::raw('count(*) as total_calls'))
                    ->whereBetween('created_at',[$registration_from,$reg_to])
                    ->whereIn('branch_id',array_keys($employeeBranches))
                    ->whereIn('label_type_id',$reachable_labelTypes)
                    ->groupBy('branch_id','type')->get();
                  
            }else{
                
                $leadCases = LeadCase::select('branch_id','type',DB::raw('count(*) as total_calls'))
                    ->where('created_at','like','%'.date('Y-m-d').'%')
                    ->whereIn('branch_id',array_keys($employeeBranches))
                    ->whereIn('label_type_id',$reachable_labelTypes)
                    ->groupBy('branch_id','type')->get();
                
                    
            }
            
            $leadCases = $leadCases->groupBy('branch_id');
            
            if($registration_from && $reg_to){
                $attendance_count = GroupSessionAttendance::leftjoin('group_sessions','group_sessions.id','group_session_attendances.group_session_id')
                            ->leftjoin('groups','groups.id','group_session_attendances.group_id')
                            ->select('groups.branch_id',DB::raw('count(*) as total_attendance'))
                            ->whereBetween('group_sessions.date',[$registration_from,$reg_to])
                            ->where('attendance',1)
                            ->groupBy('branch_id')
                            ->get()->pluck('total_attendance','branch_id');
            }else{
                $attendance_count = GroupSessionAttendance::leftjoin('group_sessions','group_sessions.id','group_session_attendances.group_session_id')
                            ->leftjoin('groups','groups.id','group_session_attendances.group_id')
                            ->select('groups.branch_id',DB::raw('count(*) as total_attendance'))
                            ->where('group_sessions.date','like','%'.date('Y-m-d').'%')
                            ->where('attendance',1)
                            ->groupBy('branch_id')
                            ->get()->pluck('total_attendance','branch_id');
            }
             
            

            if($registration_from && $reg_to){
                $leads = Lead::select('branch_id','type','created_at','trans_customer','customer_to_client')
                    ->whereBetween('created_at',[$registration_from, $reg_to])
                    ->orwhereBetween('trans_customer',[$registration_from, $reg_to])
                    ->orwhereBetween('customer_to_client',[$registration_from, $reg_to])
                    ->get()->groupBy('branch_id');
            }else{
                $leads = Lead::select('branch_id','type','created_at','trans_customer','customer_to_client')
                    ->where('created_at','like','%'.date('Y-m-d').'%')
                    ->orWhere('trans_customer','like','%'.date('Y-m-d').'%')
                    ->orWhere('customer_to_client','like','%'.date('Y-m-d').'%')
                    ->get()->groupBy('branch_id');
            }
            $lead_count = [];
            
          
            if($leads != null && count($leads) > 0){
                foreach($leads as $branch_id => $lead){
                    // return $lead->where('type',1)->where('created_at','like','%'.date('Y-m-d').'%')->count();
                    //dd($lead->where('type',1)->/*where('created_at','like','%'.date('Y-m-d').'%')->*/count());
                    $format_lead = new Lead;
                    $format_lead->branch_id = $branch_id;
                    if($registration_from && $reg_to){
                        $format_lead->lead_count = $lead->where('type',1)->whereBetween('created_at',[$registration_from,$reg_to])->count();
                        $format_lead->customer_count= $lead->where('type',2)->whereBetween('trans_customer',[$registration_from,$reg_to])->count();
                        $format_lead->client_count= $lead->where('type',3)->whereBetween('customer_to_client',[$registration_from,$reg_to])->count();
                    }else{
                        $format_lead->lead_count = $lead->where('type',1)->where('created_at','like','%'.date('Y-m-d').'%')->count();
                        $format_lead->customer_count = $lead->where('type',2)->where('trans_customer','like','%'.date('Y-m-d').'%')->count();
                        $format_lead->client_count = $lead->where('type',3)->where('customer_to_client','like','%'.date('Y-m-d').'%')->count();
                    }
                    
                    $lead_count[$branch_id] = $format_lead;
                }
            }
            //dd($lead_count);
            
            $paymentQuery1 = LeadPayment::whereNotNull('paymentable_type')->whereNotNull('paymentable_id')->where('payment_plan_id',2)->where('rest',0)->whereNotNull('branch_id')->whereIn('branch_id',array_keys($employeeBranches));
            
            if($registration_from && $reg_to){
                $paymentQuery1->where('created_at','>=',$registration_from)->where('created_at','<',$reg_to);
            }
            else{
                $paymentQuery1->where('created_at','like','%'.date('Y-m-d').'%');
            }
            
            $employees_payment1 = $paymentQuery1->orderBy('branch_id')->select('id','lead_type','type','branch_id','paymentable_type','paymentable_id','amount','lead_id')->get()->groupBy('branch_id');
            //dd($employees_payment1[1]);
            $paymentQuery2 = SubPayment::leftjoin('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
                ->leftjoin('leads','leads.id','lead_payments.lead_id')
                ->whereNotNull('lead_payments.paymentable_type')
                ->whereIn('lead_payments.payment_plan_id',[1,3])
                ->where('sub_payments.paid',1)
                ->whereNotNull('sub_payments.branch_id')
                ->whereIn('sub_payments.branch_id',array_keys($employeeBranches));
                //->whereRaw('sub_payments.due_date != DATE_FORMAT(lead_payments.created_at, "%Y-%m-%d")');
                //->whereRaw('sub_payments.due_date != DATE_FORMAT(lead_payments.created_at, "%Y-%m-%d")');
            
            if($registration_from && $reg_to){
                if($registration_from == $reg_to){
                    $paymentQuery2->where('sub_payments.due_date',$registration_from);
                }else{
                    $paymentQuery2->where('sub_payments.due_date','>=',$registration_from)->where('sub_payments.due_date','<',$reg_to);
                }
            }
            else{
                $paymentQuery2->where('sub_payments.due_date','like','%'.date('Y-m-d').'%');
            }
            //dd($paymentQuery2->select('sub_payments.branch_id','sub_payments.amount','sub_payments.payment_date','sub_payments.created_at')->orderBy('sub_payments.branch_id')->with('leadPayment')->toSql());
            $employees_payment2 = $paymentQuery2->select('sub_payments.type','sub_payments.branch_id','sub_payments.amount','sub_payments.payment_date','sub_payments.created_at','lead_payments.lead_id','lead_payments.lead_type')->orderBy('sub_payments.branch_id')->with('leadPayment')->get()->groupBy('branch_id');
            //dd($registration_from,$reg_to,$employees_payment1[1]->sortBy('id'),$employees_payment2[1]);
            //dd($employees_payment2[1]);
            $oldPaymentQuery = SubPayment::leftjoin('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
                ->leftjoin('leads','leads.id','lead_payments.lead_id')
                ->whereNull('lead_payments.paymentable_type')
                ->whereIn('lead_payments.payment_plan_id',[1,3])
                ->where('sub_payments.paid',1)
                ->whereNotNull('sub_payments.branch_id')->whereIn('sub_payments.branch_id',array_keys($employeeBranches))
                //->whereRaw('sub_payments.due_date != DATE_FORMAT(lead_payments.created_at, "%Y-%m-%d")');
                ->whereRaw('sub_payments.updated_at != sub_payments.created_at');
            
            if($registration_from && $reg_to){
                if($registration_from == $reg_to){
                    $oldPaymentQuery->where('sub_payments.due_date',$registration_from);
                }else{
                    $oldPaymentQuery->where('sub_payments.due_date','>=',$registration_from)->where('sub_payments.due_date','<',$reg_to);
                }
            }
            else{
                $oldPaymentQuery->where('sub_payments.due_date','like','%'.date('Y-m-d').'%');
            }
            $employees_old_payment = $oldPaymentQuery->select('sub_payments.type','sub_payments.branch_id','sub_payments.amount','sub_payments.payment_date','sub_payments.due_date','sub_payments.created_at','lead_payments.lead_type','lead_payments.id')->orderBy('sub_payments.branch_id')->get()->groupBy('branch_id');
            
            //dd($employees_old_payment);
            $employees_payment = [];
            foreach($employeeBranches as $branch_id => $name){
                $format_payment = new LeadPayment;
                $format_payment->branch_id = $branch_id;
                
                $sales = 0;
                $coordinator = 0;
                $cs = 0;
                
                $sales += (isset($employees_payment1[$branch_id]))?$employees_payment1[$branch_id]->where('type',1)->sum('amount'):0;
                $coordinator += (isset($employees_payment1[$branch_id]))?$employees_payment1[$branch_id]->where('type',2)->whereIn('lead_type',[1,2])->sum('amount'):0; 
                $cs += (isset($employees_payment1[$branch_id]))?$employees_payment1[$branch_id]->where('type',2)->where('lead_type',3)->sum('amount'):0;    
                //dd($sales,$coordinator,$cs);
                $sales += (isset($employees_payment2[$branch_id]))?$employees_payment2[$branch_id]->where('type',1)->sum('amount'):0;
                $coordinator += (isset($employees_payment2[$branch_id]))?$employees_payment2[$branch_id]->where('type',2)->whereIn('lead_type',[1,2])->sum('amount'):0; 
                $cs += (isset($employees_payment2[$branch_id]))?$employees_payment2[$branch_id]->where('type',2)->where('lead_type',3)->sum('amount'):0;    
                
                $sales += (isset($employees_old_payment[$branch_id]))?$employees_old_payment[$branch_id]->where('type',1)->sum('amount'):0;
                $coordinator += (isset($employees_old_payment[$branch_id]))?$employees_old_payment[$branch_id]->where('type',2)->whereIn('lead_type',[1,2])->sum('amount'):0; 
                $cs += (isset($employees_old_payment[$branch_id]))?$employees_old_payment[$branch_id]->where('type',2)->where('lead_type',3)->sum('amount'):0;    
                
                $format_payment->sales = $sales;
                $format_payment->coordinator = $coordinator;
                $format_payment->cs = $cs;
                //dd(((isset($employees_payment1[$branch_id]))?$employees_payment1[$branch_id]:0),((isset($employees_payment2[$branch_id]))?$employees_payment2[$branch_id]:0),((isset($employees_old_payment[$branch_id]))?$employees_old_payment[$branch_id]:0));
                $employees_payment[$branch_id] = $format_payment;
                    
            }
            /*
            if($employees_payment1 != null && count($employees_payment1) > 0){
                foreach($employees_payment1 as $branch_id => $employee_payment1){
                    
                    $format_payment->sales = $employee_payment1->where('type',1)->sum('amount');
                    $format_payment->coordinator = $employee_payment1->where('type',2)->where('lead_type',3)->sum('amount');
                    $format_payment->cs = $employee_payment1->where('type',2)->where('lead_type',2)->sum('amount');
                    
                    $offers_amount = $employee_payment1->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->whereNotIn('lead_id',$first_total_payments)->sum('amount');
                    $offers_count = $employee_payment1->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->whereNotIn('lead_id',$first_total_payments)->count();
                    
                    if(isset($employees_payment2[$branch_id]) && count($employees_payment2[$branch_id]) > 0){
                        $offers_amount += $employees_payment2[$branch_id]->whereNotIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                        $offers_count += $employees_payment2[$branch_id]->whereNotIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    }
                    
                    $format_payment->offers_amount = $offers_amount;
                    $format_payment->offers_count = $offers_count;
                    
                    $activations_amount = $employee_payment1->where('lead_type',2)->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->whereIn('lead_id',$first_total_payments)->sum('amount');
                    $activations_count = $employee_payment1->where('lead_type',2)->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->whereIn('lead_id',$first_total_payments)->count();
                    if(isset($employees_payment2[$branch_id]) && count($employees_payment2[$branch_id]) > 0){
                        $activations_amount += $employees_payment2[$branch_id]->where('lead_type',2)->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                        $activations_count += $employees_payment2[$branch_id]->where('lead_type',2)->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    }
                    $format_payment->activations_amount = $activations_amount;
                    $format_payment->activations_count = $activations_count;
                    
                    $activations_amount_clients = $employee_payment1->where('lead_type',3)->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->whereIn('lead_id',$first_total_payments)->sum('amount');
                    $activations_count_clients = $employee_payment1->where('lead_type',3)->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->whereIn('lead_id',$first_total_payments)->count();
                    if(isset($employees_payment2[$branch_id]) && count($employees_payment2[$branch_id]) > 0){
                        $activations_amount_clients += $employees_payment2[$branch_id]->where('lead_type',3)->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                        $activations_count_clients += $employees_payment2[$branch_id]->where('lead_type',3)->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    }
                    $format_payment->activations_amount_clients = $activations_amount_clients;
                    $format_payment->activations_count_clients = $activations_count_clients;
                    
                    $format_payment->items_amount = $employee_payment1->where('lead_type',2)->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',$extra_items_ids)->sum('amount');
                    $format_payment->items_count = $employee_payment1->where('lead_type',2)->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',$extra_items_ids)->count();
                    
                    $format_payment->items_amount_clients = $employee_payment1->where('lead_type',3)->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',$extra_items_ids)->sum('amount');
                    $format_payment->items_count_clients = $employee_payment1->where('lead_type',3)->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',$extra_items_ids)->count();
                    
                    
                    $format_payment->items_amount_leads = $employee_payment1->where('lead_type',1)->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',$extra_items_ids)->sum('amount');
                    $format_payment->items_count_leads = $employee_payment1->where('lead_type',1)->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',$extra_items_ids)->count();
                    
                    
                    
                    $completting_payment = 0;
                    $completting_payment_count = 0;
                    if(isset($employees_payment2[$branch_id]) && count($employees_payment2[$branch_id]) > 0){
                        $completting_payment += $employees_payment2[$branch_id]->filter(function ($value, $key) { return $value->payment_date != date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                        $completting_payment_count += $employees_payment2[$branch_id]->filter(function ($value, $key) { return $value->payment_date != date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    }
                    if(isset($employees_old_payment[$branch_id]) && count($employees_old_payment[$branch_id]) > 0){
                        $completting_payment += $employees_old_payment[$branch_id]->sum('amount');
                        $completting_payment_count += $employees_old_payment[$branch_id]->count();
                    }
                    $format_payment->completting_payment = $completting_payment;
                    $format_payment->completting_payment_count = $completting_payment_count;
                    $employees_payment[$branch_id] = $format_payment;
                    
                    if(isset($employees_payment2[$branch_id]) && count($employees_payment2[$branch_id]) > 0){
                        unset($employees_payment2[$branch_id]);
                    }
                    
                    if(isset($employees_old_payment[$branch_id]) && count($employees_old_payment[$branch_id]) > 0){
                        unset($employees_old_payment[$branch_id]);
                    }
                
                    //dd($format_payment);
                }
            }
            if($employees_payment2 != null && count($employees_payment2) > 0){
                foreach($employees_payment2 as $branch_id => $employee_payment2){
                    $format_payment = new LeadPayment;
                    $format_payment->branch_id = $branch_id;
                    
                    $format_payment->offers_amount = $employee_payment2->whereNotIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                    $format_payment->offers_count = $employee_payment2->whereNotIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    
                    $format_payment->activations_amount = $employee_payment2->where('lead_type',2)->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                    $format_payment->activations_count = $employee_payment2->where('lead_type',2)->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    
                    $format_payment->activations_amount_clients = $employee_payment2->where('lead_type',3)->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                    $format_payment->activations_count_clients = $employee_payment2->where('lead_type',3)->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    
                    
                    $format_payment->items_amount = 0;
                    $format_payment->items_count = 0;
                    $format_payment->items_amount_clients = 0;
                    $format_payment->items_count_clients = 0;
                    $format_payment->items_amount_leads = 0;
                    $format_payment->items_count_leads = 0;
                    
                    $completting_payment = $employee_payment2->filter(function ($value, $key) { return $value->payment_date != date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                    $completting_payment_count = $employee_payment2->filter(function ($value, $key) { return $value->payment_date != date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    if(isset($employees_old_payment[$branch_id]) && count($employees_old_payment[$branch_id]) > 0){
                        $completting_payment += $employees_old_payment[$branch_id]->sum('amount');
                        $completting_payment_count += $employees_old_payment[$branch_id]->count();
                    }
                    $format_payment->completting_payment = $completting_payment;
                    $format_payment->completting_payment_count = $completting_payment_count;
                    
                    if(isset($employees_old_payment[$branch_id]) && count($employees_old_payment[$branch_id]) > 0){
                        unset($employees_old_payment[$branch_id]);
                    }
                    
                    $employees_payment[$branch_id] = $format_payment;
                }
            }
            if($employees_old_payment != null && count($employees_old_payment) > 0){
                foreach($employees_old_payment as $branch_id => $employee_old_payment){
                    $format_payment = new LeadPayment;
                    $format_payment->branch_id = $branch_id;
                    $format_payment->offers_amount = 0;
                    $format_payment->offers_count = 0;
                    $format_payment->activations_amount = 0;
                    $format_payment->activations_count = 0;
                    $format_payment->activations_amount_clients = 0;
                    $format_payment->activations_count_clients = 0;
                    $format_payment->items_amount = 0;
                    $format_payment->items_count = 0;
                    $format_payment->items_amount_clients = 0;
                    $format_payment->items_count_clients = 0;
                    $format_payment->items_amount_leads = 0;
                    $format_payment->items_count_leads = 0;
                    $format_payment->completting_payment = $employee_old_payment->sum('amount');
                    $format_payment->completting_payment_count = $employee_old_payment->count();
                    
                    $employees_payment[$branch_id] = $format_payment;
                }
            }
            */
        }
        else{
            $loop_through = $agents;
            if ($registration_from != null && $reg_to != ''){
                $leadCases = LeadCase::select('employee_id','type',DB::raw('count(*) as total_calls'))
                    ->whereBetween('created_at',[$registration_from,$reg_to])
                    ->whereIn('label_type_id',$reachable_labelTypes)
                    ->groupBy('employee_id','type')->get();
                
            }else{
                $leadCases = LeadCase::select('employee_id','type',DB::raw('count(*) as total_calls'))
                    ->where('created_at','like','%'.date('Y-m-d').'%')
                    ->whereIn('label_type_id',$reachable_labelTypes)
                    ->groupBy('employee_id','type')->get();
            }
            if(! auth()->user()->can('reports show_all_data')){
                $leadCases = $leadCases->where('employee_id', auth()->user()->id);
            }
            $leads = Lead::select('assigned_employee_id','type','created_at','trans_customer','customer_to_client')
            ->where('created_at','like','%'.date('Y-m-d').'%')->orWhere('trans_customer','like','%'.date('Y-m-d').'%')
            ->orWhere('customer_to_client','like','%'.date('Y-m-d').'%')->get()->groupBy('assigned_employee_id');
            $lead_count = [];
            $attendance_count = []; 
            if($leads != null && count($leads) > 0){
                foreach($leads as $assigned_employee_id => $lead){
                    //dd($lead->where('type',1)->/*where('created_at','like','%'.date('Y-m-d').'%')->*/count());
                    $format_lead = new Lead;
                    $format_lead->employee_id = $assigned_employee_id;
                    if($registration_from && $reg_to){
                        $format_lead->lead_count = $lead->where('type',1)->whereBetween('created_at',[$registration_from,$reg_to])->count();
                        $format_lead->customer_count= $lead->where('type',2)->whereBetween('trans_customer',[$registration_from,$reg_to])->count();
                        $format_lead->client_count= $lead->where('type',3)->whereBetween('customer_to_client',[$registration_from,$reg_to])->count();
                    }else{
                        $format_lead->lead_count = $lead->where('type',1)->where('created_at','like','%'.date('Y-m-d').'%')->count();
                        $format_lead->customer_count = $lead->where('type',2)->where('trans_customer','like','%'.date('Y-m-d').'%')->count();
                        $format_lead->client_count = $lead->where('type',3)->where('customer_to_client','like','%'.date('Y-m-d').'%')->count();
                    }
                    
                    $lead_count[$assigned_employee_id] = $format_lead;
                }
            }
            $attendance_count=[];
            
            $leadCases = $leadCases->groupBy('employee_id');
  
  
            // Query 1 - LeadPayment
            $paymentQuery1 = LeadPayment::whereNotNull('paymentable_type')
                ->whereNotNull('paymentable_id')
                ->whereNotNull('employee_id')
                ->where('payment_plan_id', 2)
                ->where('rest', 0);
            
            $paymentQuery2 = SubPayment::leftjoin('lead_payments', 'lead_payments.id', '=', 'sub_payments.lead_payment_id')
                ->leftjoin('leads', 'leads.id', '=', 'lead_payments.lead_id')
                ->whereIn('lead_payments.payment_plan_id', [1, 3])
                ->where('sub_payments.paid', 1)
                ->whereNotNull('lead_payments.paymentable_type')
                ->whereNotNull('lead_payments.paymentable_id')
                ->whereNotNull('sub_payments.employee_id');
            
            $oldPaymentQuery = SubPayment::leftjoin('lead_payments', 'lead_payments.id', '=', 'sub_payments.lead_payment_id')
                ->leftjoin('leads', 'leads.id', '=', 'lead_payments.lead_id')
                ->whereIn('lead_payments.payment_plan_id', [1, 3])
                ->where('sub_payments.paid', 1)
                ->whereNull('lead_payments.paymentable_type')
                ->whereNotNull('sub_payments.employee_id')
                ->whereRaw('sub_payments.due_date != DATE_FORMAT(lead_payments.created_at, "%Y-%m-%d")');
            
            // Apply filters based on the request
            if ($request->has('owner_by') && $request->input('owner_by') !== null) {
                $ownerId = $request->input('owner_by');
                $paymentQuery1->where('lead_payments.owner_id', $ownerId);
                $paymentQuery2->where('sub_payments.owner_id', $ownerId);
                $oldPaymentQuery->where('sub_payments.owner_id', $ownerId);
            }
            
            if ($request->has('created_by') && $request->input('created_by') !== null) {
                $createdBy = $request->input('created_by');
                $paymentQuery1->where('lead_payments.employee_id', $createdBy);
                $paymentQuery2->where('sub_payments.employee_id', $createdBy);
                $oldPaymentQuery->where('sub_payments.employee_id', $createdBy);
            }
            
            if (count($agents) > 0) {
                $paymentQuery1->whereIn('employee_id', array_keys($agents));
                $paymentQuery2->whereIn('sub_payments.employee_id', array_keys($agents));
                $oldPaymentQuery->whereIn('sub_payments.employee_id', array_keys($agents));
            }
            
            if (!auth()->user()->can('reports show_all_data')) {
                $paymentQuery1->where('employee_id', auth()->user()->id);
                $paymentQuery2->where('sub_payments.employee_id', auth()->user()->id);
                $oldPaymentQuery->where('sub_payments.employee_id', auth()->user()->id);
            }
            
            if ($registration_from && $reg_to) {
                if ($registration_from == $reg_to) {
                    $paymentQuery1->where('created_at', $registration_from);
                    $paymentQuery2->where('sub_payments.due_date', $registration_from);
                    $oldPaymentQuery->where('sub_payments.due_date', $registration_from);
                } else {
                    $paymentQuery1->whereBetween('created_at', [$registration_from, $reg_to]);
                    $paymentQuery2->whereBetween('sub_payments.due_date', [$registration_from, $reg_to]);
                    $oldPaymentQuery->whereBetween('sub_payments.due_date', [$registration_from, $reg_to]);
                }
            } else {
                $paymentQuery1->where('created_at', 'like', '%' . date('Y-m-d') . '%');
                $paymentQuery2->where('sub_payments.due_date', 'like', '%' . date('Y-m-d') . '%');
                $oldPaymentQuery->where('sub_payments.due_date', 'like', '%' . date('Y-m-d') . '%');
            }
            
            // Fetch data
            $employees_payment1 = $paymentQuery1->orderBy('employee_id')->select('type', 'lead_type', 'employee_id', 'owner_id', 'paymentable_type', 'paymentable_id', 'amount', 'lead_id')->get()->groupBy('employee_id');
            $employees_payment2 = $paymentQuery2->select('sub_payments.type', 'sub_payments.employee_id', 'sub_payments.amount', 'sub_payments.payment_date', 'sub_payments.created_at', 'lead_payments.lead_type')->orderBy('sub_payments.employee_id')->with('leadPayment')->get()->groupBy('employee_id');
            $employees_old_payment = $oldPaymentQuery->select('sub_payments.type', 'lead_payments.lead_type', 'sub_payments.employee_id', 'sub_payments.amount', 'sub_payments.payment_date', 'sub_payments.created_at')->orderBy('sub_payments.employee_id')->with('leadPayment')->get()->groupBy('employee_id');
            
            // Combine payments for employees
            $employees_payment = [];
            if (count($agents) > 0) {
                foreach ($agents as $employee_id => $name) {
                    $format_payment = new LeadPayment;
                    $format_payment->employee_id = $employee_id;
            
                    $sales = 0;
                    $coordinator = 0;
                    $cs = 0;
            
                    // Aggregate payments per employee
                    $sales += (isset($employees_payment1[$employee_id])) ? $employees_payment1[$employee_id]->where('type', 1)->sum('amount') : 0;
                    $coordinator += (isset($employees_payment1[$employee_id])) ? $employees_payment1[$employee_id]->where('type', 2)->whereIn('lead_type', [1, 2])->sum('amount') : 0;
                    $cs += (isset($employees_payment1[$employee_id])) ? $employees_payment1[$employee_id]->where('type', 2)->where('lead_type', 3)->sum('amount') : 0;
            
                    $sales += (isset($employees_payment2[$employee_id])) ? $employees_payment2[$employee_id]->where('type', 1)->sum('amount') : 0;
                    $coordinator += (isset($employees_payment2[$employee_id])) ? $employees_payment2[$employee_id]->where('type', 2)->whereIn('lead_type', [1, 2])->sum('amount') : 0;
                    $cs += (isset($employees_payment2[$employee_id])) ? $employees_payment2[$employee_id]->where('type', 2)->where('lead_type', 3)->sum('amount') : 0;
            
                    $sales += (isset($employees_old_payment[$employee_id])) ? $employees_old_payment[$employee_id]->where('type', 1)->sum('amount') : 0;
                    $coordinator += (isset($employees_old_payment[$employee_id])) ? $employees_old_payment[$employee_id]->where('type', 2)->whereIn('lead_type', [1, 2])->sum('amount') : 0;
                    $cs += (isset($employees_old_payment[$employee_id])) ? $employees_old_payment[$employee_id]->where('type', 2)->where('lead_type', 3)->sum('amount') : 0;
            
                    // Assign to the format payment
                    $format_payment->sales = $sales;
                    $format_payment->coordinator = $coordinator;
                    $format_payment->cs = $cs;
            
                    $employees_payment[$employee_id] = $format_payment;
                }
            }
            
            // For the current user, if not showing all data
            if (!auth()->user()->can('reports show_all_data')) {
                $employee_id = auth()->user()->id;
                $format_payment = new LeadPayment;
                $format_payment->employee_id = $employee_id;
            
                $sales = 0;
                $coordinator = 0;
                $cs = 0;
            
                // Aggregate payments for current user
                $sales += (isset($employees_payment1[$employee_id])) ? $employees_payment1[$employee_id]->where('type', 1)->sum('amount') : 0;
                $coordinator += (isset($employees_payment1[$employee_id])) ? $employees_payment1[$employee_id]->where('type', 2)->whereIn('lead_type', [1, 2])->sum('amount') : 0;
                $cs += (isset($employees_payment1[$employee_id])) ? $employees_payment1[$employee_id]->where('type', 2)->where('lead_type', 3)->sum('amount') : 0;
            
                $sales += (isset($employees_payment2[$employee_id])) ? $employees_payment2[$employee_id]->where('type', 1)->sum('amount') : 0;
                $coordinator += (isset($employees_payment2[$employee_id])) ? $employees_payment2[$employee_id]->where('type', 2)->whereIn('lead_type', [1, 2])->sum('amount') : 0;
                $cs += (isset($employees_payment2[$employee_id])) ? $employees_payment2[$employee_id]->where('type', 2)->where('lead_type', 3)->sum('amount') : 0;
            
                $sales += (isset($employees_old_payment[$employee_id])) ? $employees_old_payment[$employee_id]->where('type', 1)->sum('amount') : 0;
                $coordinator += (isset($employees_old_payment[$employee_id])) ? $employees_old_payment[$employee_id]->where('type', 2)->whereIn('lead_type', [1, 2])->sum('amount') : 0;
                $cs += (isset($employees_old_payment[$employee_id])) ? $employees_old_payment[$employee_id]->where('type', 2)->where('lead_type', 3)->sum('amount') : 0;
            
                $format_payment->sales = $sales;
                $format_payment->coordinator = $coordinator;
                $format_payment->cs = $cs;
            
                $employees_payment[$employee_id] = $format_payment;
            }
            /*
            if($employees_payment1 != null && count($employees_payment1) > 0){
                foreach($employees_payment1 as $employee_id => $employee_payment1){
                    
                    $format_payment = new LeadPayment;
                    $format_payment->employee_id = $employee_id;
                    $offers_amount = $employee_payment1->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->whereNotIn('lead_id',$first_total_payments)->sum('amount');
                    $offers_count = $employee_payment1->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->whereNotIn('lead_id',$first_total_payments)->count();
                    
                    if(isset($employees_payment2[$employee_id]) && count($employees_payment2[$employee_id]) > 0){
                        $offers_amount += $employees_payment2[$employee_id]->whereNotIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                        $offers_count += $employees_payment2[$employee_id]->whereNotIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    }
                    
                    $format_payment->offers_amount = $offers_amount;
                    $format_payment->offers_count = $offers_count;
                    
                    $activations_amount = $employee_payment1->where('lead_type',2)->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->whereIn('lead_id',$first_total_payments)->sum('amount');
                    $activations_count = $employee_payment1->where('lead_type',2)->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->whereIn('lead_id',$first_total_payments)->count();
                    if(isset($employees_payment2[$employee_id]) && count($employees_payment2[$employee_id]) > 0){
                        $activations_amount += $employees_payment2[$employee_id]->where('lead_type',2)->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                        $activations_count += $employees_payment2[$employee_id]->where('lead_type',2)->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    }
                    $format_payment->activations_amount = $activations_amount;
                    $format_payment->activations_count = $activations_count;
                    
                    $activations_amount_clients = $employee_payment1->where('lead_type',3)->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->whereIn('lead_id',$first_total_payments)->sum('amount');
                    $activations_count_clients = $employee_payment1->where('lead_type',3)->whereIn('paymentable_type',['App\Models\Offer','App\Models\ServiceFee'])->whereIn('lead_id',$first_total_payments)->count();
                    if(isset($employees_payment2[$employee_id]) && count($employees_payment2[$employee_id]) > 0){
                        $activations_amount_clients += $employees_payment2[$employee_id]->where('lead_type',3)->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                        $activations_count_clients += $employees_payment2[$employee_id]->where('lead_type',3)->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    }
                    $format_payment->activations_amount_clients = $activations_amount_clients;
                    $format_payment->activations_count_clients = $activations_count_clients;
                    
                    $format_payment->items_amount = $employee_payment1->where('lead_type',2)->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',[2,3,28,31,4,5,6,7,8,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,29,30,33,34,35,36,37,39,40])->sum('amount');
                    $format_payment->items_count = $employee_payment1->where('lead_type',2)->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',[2,3,28,31,4,5,6,7,8,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,29,30,33,34,35,36,37,39,40])->count();
                    
                    $format_payment->items_amount_clients = $employee_payment1->where('lead_type',3)->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',[2,3,28,31,4,5,6,7,8,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,29,30,33,34,35,36,37,39,40])->sum('amount');
                    $format_payment->items_count_clients = $employee_payment1->where('lead_type',3)->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',[2,3,28,31,4,5,6,7,8,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,29,30,33,34,35,36,37,39,40])->count();
                    
                    $format_payment->items_amount_leads = $employee_payment1->where('lead_type',1)->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',[2,3,28,31,4,5,6,7,8,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,29,30,33,34,35,36,37,39,40])->sum('amount');
                    $format_payment->items_count_leads = $employee_payment1->where('lead_type',1)->where('paymentable_type','App\Models\ExtraItem')->whereIn('paymentable_id',[2,3,28,31,4,5,6,7,8,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,29,30,33,34,35,36,37,39,40])->count();
                    
                    $completting_payment = 0;
                    $completting_payment_count = 0;
                    if(isset($employees_payment2[$employee_id]) && count($employees_payment2[$employee_id]) > 0){
                        $completting_payment += $employees_payment2[$employee_id]->filter(function ($value, $key) { return $value->payment_date != date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                        $completting_payment_count += $employees_payment2[$employee_id]->filter(function ($value, $key) { return $value->payment_date != date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    }
                    if(isset($employees_old_payment[$employee_id]) && count($employees_old_payment[$employee_id]) > 0){
                        $completting_payment += $employees_old_payment[$employee_id]->sum('amount');
                        $completting_payment_count += $employees_old_payment[$employee_id]->count();
                    }
                    $format_payment->completting_payment = $completting_payment;
                    $format_payment->completting_payment_count = $completting_payment_count;
                    $employees_payment[$employee_id] = $format_payment;
                    
                    if(isset($employees_payment2[$employee_id]) && count($employees_payment2[$employee_id]) > 0){
                        unset($employees_payment2[$employee_id]);
                    }
                    
                    if(isset($employees_old_payment[$employee_id]) && count($employees_old_payment[$employee_id]) > 0){
                        unset($employees_old_payment[$employee_id]);
                    }
                }
            }
            
            if($employees_payment2 != null && count($employees_payment2) > 0){
                foreach($employees_payment2 as $employee_id => $employee_payment2){
                    //dd($employee_payment2);
                    
                    $format_payment = new LeadPayment;
                    $format_payment->employee_id = $employee_id;
                    $format_payment->offers_amount = $employee_payment2->whereNotIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                    $format_payment->offers_count = $employee_payment2->whereNotIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    
                    $format_payment->activations_amount = $employee_payment2->where('lead_type',2)->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                    $format_payment->activations_count = $employee_payment2->where('lead_type',2)->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    
                    $format_payment->activations_amount_clients = $employee_payment2->where('lead_type',3)->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                    $format_payment->activations_count_clients = $employee_payment2->where('lead_type',3)->whereIn('lead_id',$first_total_payments)->filter(function ($value, $key) { return $value->payment_date == date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    
                    
                    $format_payment->items_amount = 0;
                    $format_payment->items_count = 0;
                    $format_payment->items_amount_clients = 0;
                    $format_payment->items_count_clients = 0;
                    $format_payment->items_amount_leads = 0;
                    $format_payment->items_count_leads = 0;
                    
                    $completting_payment_count = $employee_payment2->filter(function ($value, $key) { return $value->payment_date != date_format(date_create($value->created_at),'Y-m-d'); })->count();
                    $completting_payment = $employee_payment2->filter(function ($value, $key) { return $value->payment_date != date_format(date_create($value->created_at),'Y-m-d'); })->sum('amount');
                    if(isset($employees_old_payment[$employee_id]) && count($employees_old_payment[$employee_id]) > 0){
                        $completting_payment += $employees_old_payment[$employee_id]->sum('amount');
                        $completting_payment_count += $employees_old_payment[$employee_id]->count();
                    }
                    $format_payment->completting_payment = $completting_payment;
                    $format_payment->completting_payment_count = $completting_payment_count;
                    
                    if(isset($employees_old_payment[$employee_id]) && count($employees_old_payment[$employee_id]) > 0){
                        unset($employees_old_payment[$employee_id]);
                    }
                    
                    $employees_payment[$employee_id] = $format_payment;
                }
            }
            
            if($employees_old_payment != null && count($employees_old_payment) > 0){
                foreach($employees_old_payment as $employee_id => $employee_old_payment){
                    $format_payment = new LeadPayment;
                    $format_payment->employee_id = $employee_id;
                    $format_payment->offers_amount = 0;
                    $format_payment->offers_count = 0;
                    $format_payment->activations_amount = 0;
                    $format_payment->activations_count = 0;
                    $format_payment->activations_amount_clients = 0;
                    $format_payment->activations_count_clients = 0;
                    $format_payment->items_amount = 0;
                    $format_payment->items_count = 0;
                    $format_payment->items_amount_clients = 0;
                    $format_payment->items_count_clients = 0;
                    $format_payment->items_amount_leads = 0;
                    $format_payment->items_count_leads = 0;
                    $format_payment->completting_payment = $employee_old_payment->sum('amount');
                    $format_payment->completting_payment_count = $employee_old_payment->count();
                    
                    $employees_payment[$employee_id] = $format_payment;
                }
            }
            */
        }
        
        $allbranches=[];
        $total=[];
      
            $allbranches = Branch::where('status',1)->get();
            $total= Lead::selectRaw('count(IF(type = 1, 1, null)) as totallead')
             ->selectRaw('count(IF(type = 2, 1, null)) as totalcustomer')
             ->selectRaw('count(IF(type = 3, 1, null)) as totalclient')
             ->selectRaw('count(IF(type = 4, 1, null)) as tatalgraduate')
             ->selectRaw('count(*) as total')
             ->get();
             
             
            $events = [];
 
        $eloquentEvents = TODoListRandom::get(); //EventModel implements LaravelFullcalendar\Event

 
        foreach ($eloquentEvents as $event) {
            $events[] = [
                'title' => $event->name,
                'start' => $event->start_date,
                'end' => $event->end_date,
            ];
        }

// In the index method, add these conditions to the payment queries:


        // return $total;
        //dd(round(microtime(true) * 1000) - $testProcess);
        return view('home', compact('total','attendance_count','attendance_count','events','allbranches','lead_count','employees_payment','branches','leads','employeeBranches','kidsApplicantsCount','view_type','loop_through','leadCases', 'safeQueryCount','leadsCount', 'applicantsCount','expenseQuery','agentss'));
    }
    
    /**
     * Show the instructor dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function instructor()
    {
        return view('instructor.home');
    }

    /**
     * Show the customer dashboard.
     *
     * @return \Illuminate\Http\Response
     */
     
    public function show_offer($id)
    {
        $offer = Offer::with('branches','services','track','course','paymentPlan','disciplines','timeframes','installment')->findOrFail($id);
        
        return view('customer.show_offers',compact('offer'));
    }

    
    public function customer()
    {
        $user = Auth::guard('customer')->user();
        $branches = Branch::where('status',1)->select('id','name')->get();
        if(session()->has('contactBranchId')){
            $user->branch_id = session()->get('contactBranchId');
            $user->save();
        }

        if($user->email != null && $user->email != '' && $user->mobile_1 != null && $user->mobile_1 != '' && $user->branch_id != null && $user->branch_id != ''){
            if(! $user->getPT() && session()->has('redirectToPlacementTest') && session()->get('redirectToPlacementTest')){
                if(session()->has('contactBranchId')){
                    return redirect('customerPortal/placement-test/'.session()->get('contactBranchId'));
                }else{
                    return redirect('customerPortal/placement-test/'.$user->branch_id);
                }
            }
        }
        $branchesId = $user->branch->id;
        $no_levels_offers = Offer::whereDate('start_date', '<=', now())->whereDate('end_date', '>=', now())
                    ->whereHas('branches', function ($query) use ($branchesId) {
                        $query->where('id', $branchesId);
                    })->where('status',1)->whereIn('show_in',['cusPortal','both'])->where('has_levels',0)->orderBy('order_by')->get();
                    
        $offers = $no_levels_offers;
        
        $pt_level = $user->getPT($user->prefered_track_id);
        if ($pt_level != null && $pt_level != '') {
            $levels_offers = Offer::whereDate('start_date', '<=', now())->whereDate('end_date', '>=', now())
                    ->whereHas('branches', function ($query) use ($branchesId) {
                        $query->where('id', $branchesId);
                    })->where('has_levels',1)->whereHas('services.trainingService.levels', function ($query) use ($user){
                        $query->where('value', $pt_level->level);
                    })->where('status',1)->whereIn('show_in',['cusPortal','both'])->orderBy('order_by')->get();
            //dd($levels_offers);
            $offers = $no_levels_offers->merge($levels_offers);
        }
        //dd($offers);
        
        if($pt_level != null && $pt_level != ''){
            $pt_result = $pt_level;
            $total_pt = $pt_result->vocabulary_score + $pt_result->grammar_score + $pt_result->reading_score + $pt_result->listening_score + $pt_result->speaking_score + $pt_result->writing_score;
        }elseif($user->getKidsPT() != null && $user->getKidsPT() != ''){
            $pt_result = $user->getKidsPT();
            $total_pt = $pt_result->vocabulary_score + $pt_result->grammar_score + $pt_result->reading_score + $pt_result->listening_score + $pt_result->speaking_score + $pt_result->writing_score;
        }
        else{
            $pt_result = null;
            $total_pt = 0;
        }
        
        $exams_result = StudentExam::where('finish',1)->where('lead_id',$user->id)->get();
        return view('customer.home',compact('user','branches','offers','pt_result','total_pt','exams_result'));
    }

    public function showKidsPlacementTest()
    {
        if(Auth::guard('customer')->check()){
            $user = Auth::guard('customer')->user();
            if($user->mobile_1 != null && $user->mobile_1 != '' && $user->branch_id != null && $user->branch_id != ''){
                //dd('ddd');
                $request->session()->put('step', 1);
                return redirect('customerPortal/kids-placement-test/'.$user->branch_id);
            }else{
                session(['redirectToKidsPlacementTest' => true]);
                return redirect(route('customer.home'));
            }
        }else{
            session(['redirectToKidsPlacementTest' => true]);
            return redirect(route('customer.login'));
        }
    }

    public function showPlacementTest(Request $request)
    {
        if(Auth::guard('customer')->check()){
            $user = Auth::guard('customer')->user();
            if($user->mobile_1 != null && $user->mobile_1 != '' && $user->branch_id != null && $user->branch_id != ''){
                //dd('ddd');
                $request->session()->put('step', 1);
                    
                return redirect('customerPortal/placement-test/'.$user->branch_id);
            }else{
                session(['redirectToPlacementTest' => true]);
                return redirect(route('customer.home'));
            }
        }else{
            session(['redirectToPlacementTest' => true]);
            return redirect(route('customer.login'));
        }
    }

    /**
     * Show the customer invoice.
     *
     * @return \Illuminate\Http\Response
     */
    public function invoice($id)
    {
        $leadPayment = LeadPayment::with('lead', 'paymentPlan', 'subPayments', 'paymentable')->find($id);

        return view('invoice', compact('leadPayment'));
    }
}
