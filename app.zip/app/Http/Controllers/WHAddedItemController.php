<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateWHExpendableItemRequest;
use App\Http\Requests\UpdateWHExpendableItemRequest;
use App\Http\Controllers\AppBaseController;
use App\Models\WHItem;
use App\Models\WHUsedItem;
use App\Models\WHAddedItem;
use App\Models\WHItemCategory;
use App\Models\Place;
use Illuminate\Http\Request;
use Flash;
use Response;

class WHAddedItemController extends AppBaseController
{
    /**
     * Display a listing of the WHAddedItem.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var WHAddedItem $added_items */
        $categories = WHItemCategory::all()->pluck('name','id');
        $wh_items = WHItem::select('id','name','item_category_id')->get();
        $wh_items = $wh_items->groupBy('item_category_id');
        $places = auth()->user()->places->pluck('name', 'id')->toArray();
        
        $addedItemsQuary = WHAddedItem::whereIn('place_id',array_keys($places));;
        $per_page = 10;
        
        if($request->per_page && $request->per_page){
            $per_page = $request->per_page;
        }
        if($request->item_category_id && $request->item_category_id){
            $addedItemsQuary->where('item_category_id',$request->item_category_id);
        }
        if($request->item_id && $request->item_id){
            $addedItemsQuary->where('item_id',$request->item_id);
        }
        if($request->place_id && $request->place_id){
            $addedItemsQuary->where('place_id',$request->place_id);
        }
        $countadded_items = $addedItemsQuary->count();
        $added_items = $addedItemsQuary->paginate($per_page);

        return view('wh_added_items.index',compact('added_items','countadded_items','categories','wh_items','places'));
    }

    /**
     * Show the form for creating a new WHAddedItem.
     *
     * @return Response
     */
    public function create()
    {
        $categories = WHItemCategory::all()->pluck('name','id');
        $wh_items = WHItem::select('id','name','item_category_id')->get();
        $wh_items = $wh_items->groupBy('item_category_id');
        $places = auth()->user()->places->pluck('name', 'id')->toArray();
        
        return view('wh_added_items.create',compact('categories','wh_items','places'));
    }

    /**
     * Store a newly created WHItem in storage.
     *
     * @param CreateWHItemRequest $request
     *
     * @return Response
     */
    public function store(CreateWHExpendableItemRequest $request)
    {
        $input = $request->all();
        //dd($input);
        $check_used_items = WHUsedItem::where('item_category_id',$request->item_category_id)
                                      ->where('item_id',$request->item_id)
                                      ->where('place_id',$request->place_id)->first();
        if($check_used_items != null && $check_used_items != ''){
            $check_used_items->balance += $request->item_count;
            $check_used_items->save();
            
            $input['balance'] = $check_used_items->balance;
            
        }else{
            WHUsedItem::create([
                'item_category_id' => $request->item_category_id,
                'item_id' => $request->item_id,
                'place_id' => $request->place_id,
                'balance' => $request->item_count,
                'employee_id' => auth()->user()->id
            ]);
            
            $input['balance'] = $request->item_count;
        }
        
        $input['employee_id'] = auth()->user()->id;
        /** @var WHItem $added_item */
        $added_item = WHAddedItem::create($input);

        Flash::success('Warehouse Item saved successfully.');

        return redirect(route('admin.whAddedItems.index'));
    }

    /**
     * Display the specified WHItem.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var WHItem $added_item */
        $added_item = WHAddedItem::find($id);

        if (empty($added_item)) {
            Flash::error('Warehouse Item not found');

            return redirect(route('admin.whAddedItems.index'));
        }

        return view('wh_added_items.show')->with('added_item', $added_item);
    }

    /**
     * Show the form for editing the specified WHItem.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var WHAddedItem $added_item */
        $categories = WHItemCategory::all()->pluck('name','id');
        $wh_items = WHItem::select('id','name','item_category_id')->get();
        $wh_items = $wh_items->groupBy('item_category_id');
        $places = auth()->user()->places->pluck('name', 'id')->toArray();
        
        $added_item = WHAddedItem::find($id);

        if (empty($added_item)) {
            Flash::error('Warehouse Item not found');

            return redirect(route('admin.whAddedItems.index'));
        }

        return view('wh_added_items.edit')->with('added_item', $added_item)->with('categories',$categories)->with('wh_items',$wh_items)->with('places',$places);
    }

    /**
     * Update the specified WHAddedItem in storage.
     *
     * @param int $id
     * @param UpdateWHItemRequest $request
     *
     * @return Response
     */
    public function update($id, Request $request)
    {
        /** @var WHAddedItem $added_item */
        $added_item = WHAddedItem::find($id);
        $input = $request->all();
        
        if (empty($added_item)) {
            Flash::error('Warehouse Item not found');

            return redirect(route('admin.whAddedItems.index'));
        }
        
        $added_item->fill($input);
        $added_item->save();

        Flash::success('Warehouse Item updated successfully.');
        
        return redirect(route('admin.whAddedItems.index'));
    }

    /**
     * Remove the specified WHAddedItem from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var WHAddedItem $added_item */
        $added_item = WHAddedItem::find($id);

        if (empty($added_item)) {
            Flash::error('Warehouse Item not found');

            return redirect(route('admin.whAddedItems.index'));
        }

        $added_item->delete();

        Flash::success('Warehouse Item deleted successfully.');

        return redirect(route('admin.whAddedItems.index'));
    }
}
