<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\Employee;
use App\Models\Expense;
use App\Models\LeadSourceTrack;
use App\Models\Lead;
use App\Models\LeadPayment;
use App\Models\PlacementApplicant;
use App\Models\PlacementKidsApplicant;
use App\Models\Offer;
use App\Models\CustomerTrack;
use App\Models\ExtraItem;
use App\Models\StageLevel;
use App\Models\Safe;
use App\Models\LeadSourceCategory;
use App\Models\GroupSessionAttendance;
use App\Models\GroupSession;
use App\Models\Group;
use App\Models\GroupStudent;
use App\Models\LeadSource;
use App\Models\LabelType;
use App\Models\LeadCase;
use App\Models\SubPayment;
use App\Models\Timeframe;
use App\Models\Round;
use App\Models\StudentExam;
use App\Models\SubRound;
use App\Models\Track;
use App\Models\TODoListRandom;
use App\Models\GroupWaitingList;
use App\Models\LeadsDutch;
use App\Events\MyEvent;
use Illuminate\Http\Request;
use Flash;
use Response;
use Carbon\Carbon;
use DB;

class LeadSourceTrackController extends Controller
{
    /**
     * Display a listing of the lead source tracks.
     *
     * @return \Illuminate\Http\Response
     */
   public function index(Request $request)
{
    $leadSources = LeadSource::pluck('name', 'id')->toArray();
    $branches = Branch::pluck('name', 'id')->toArray();
    $today = Carbon::today()->format('Y-m-d');
    
    $query = LeadSourceTrack::with(['lead', 'branch', 'employee', 'leadSourceA', 'leadSourceB', 'leadSourceC']);
    
    $tracks = Track::where('status', 1)
        ->whereNull('parent_id')
        ->pluck('title', 'id')
        ->toArray();
        
    $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();

    // Filter by search term (name, mobile, or email)
    if ($request->filled('search')) {
        $search = $request->get('search');
        $query->whereHas('lead', function ($q) use ($search) {
            $q->where('f_name', 'like', "%$search%")
                ->orWhere('mobile_1', 'like', "%$search%")
                ->orWhere('email', 'like', "%$search%");
        });
    }

    // Filter by Lead Source A ID
    if ($request->filled('lead_source_a_id')) {
        $query->where('lead_source_a_id', $request->get('lead_source_a_id'));
    }

    // Filter by Lead Source B ID
    if ($request->filled('lead_source_b_id')) {
        $query->where('lead_source_b_id', $request->get('lead_source_b_id'));
    }

    // Filter by Branch ID
    if ($request->filled('branch_id')) {
        $query->where('branch_id', $request->get('branch_id'));
    }

    // Filter by Employee ID
    if ($request->filled('employee_id')) {
        $query->where('employee_id', $request->get('employee_id'));
    }

    // Filter by Registration Date Range
    if ($request->filled('registration_daterange')) {
        $daterange = explode(' - ', $request->get('registration_daterange'));
        if (count($daterange) === 2) {
            $from = date('Y-m-d', strtotime($daterange[0]));
            $to = date('Y-m-d', strtotime('+1 day', strtotime($daterange[1])));
            $query->whereBetween('created_at', [$from, $to]);
        }
    }

    // Filter by Track ID
    if ($trackIds = $request->get('track_id')) {
        $query->whereIn('track_id', $trackIds);
    }
    
    $agents = $this->getFilteredAgents($request, $employeeBranches);

    // Pagination with fallback
    $perPage = (int)$request->get('per_page', 10);
    $perPage = $perPage > 0 ? $perPage : 10;

    $leadSourceTracks = $query->paginate($perPage);

    return view('lead_source_tracks.index', compact('leadSourceTracks', 'leadSources', 'branches', 'today', 'tracks', 'agents'));
}


    /**
     * Display the specified lead source track.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        // Find the LeadSourceTrack by ID
        $leadSourceTrack = LeadSourceTrack::findOrFail($id);
        
        // Return the view with the record
        return view('lead_source_tracks.show', compact('leadSourceTrack'));
    }

   public function showSourcesCountReport(Request $request)
{
    // Initialize totals for each lead source
    $total_total = 0;

    // Default view type and date range
    $view_type = $request->get('view_type', 'branches');
    $dateRange = $this->getDateRange($request);

    // Get basic data
    $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
    $tracks = Track::where('status', 1)
        ->whereNull('parent_id')
        ->pluck('title', 'id')
        ->toArray();

    // Get agents based on branch filter
    $agents = $this->getFilteredAgents($request, $employeeBranches);

    // Get lead sources grouped by category
    $leadSources = LeadSource::with('category')->where('status',1)->get();
    foreach ($leadSources as $leadSource) {
        $leadSource->total = 0;
    }
    $leadSourcesGrouped = $leadSources->groupBy(function ($item) {
        return $item->category ? $item->category->name : 'No category';
    });

    // Get lead source totals
    $lead = LeadSourceTrack::select('lead_source_a_id', DB::raw('count(*) as total_leads'))
        ->whereBetween('created_at', [$dateRange['from'], $dateRange['to']])
        ->groupBy('lead_source_a_id')
        ->pluck('total_leads', 'lead_source_a_id')
        ->toArray();

    // Build main query
    $leadsQuery = LeadSourceTrack::select(
        $view_type == 'employees' ? 'employee_id' : 'branch_id',
        'lead_source_a_id',
        DB::raw('count(lead_source_a_id) as source_count')
    )
    ->whereBetween('created_at', [$dateRange['from'], $dateRange['to']]);

    // Apply track filter if specified
    if ($trackIds = $request->get('track_id')) {
        $leadsQuery->whereIn('track_id', $trackIds); // Filter by track_id
    }
      if ($request->filled('agent')) {
        $leadsQuery->where('employee_id', $request->get('agent'));
    }


    // Group and get results
    $leads = $leadsQuery
        ->groupBy($view_type == 'employees' ? 'employee_id' : 'branch_id', 'lead_source_a_id')
        ->get()
        ->groupBy($view_type == 'employees' ? 'employee_id' : 'branch_id');

    // Get loops data based on view type
    $loops = $this->getLoopsData($view_type, $leads);

    return view('lead_source_tracks.sources_count_report', compact(
        'view_type',
        'tracks', 
        'lead',
        'employeeBranches',
        'agents',
        'leadSources',
        'leads',
        'loops',
        'leadSourcesGrouped',
        'total_total'
    ));
}


    private function getDateRange(Request $request)
    {
        if ($request->get('daterange')) {
            $dates = explode(' - ', $request->get('daterange'));
            return [
                'from' => date('Y-m-d', strtotime($dates[0])),
                'to' => date('Y-m-d', strtotime('+1 day', strtotime($dates[1])))
            ];
        }
        
        return [
            'from' => date('Y-m-d'),
            'to' => date('Y-m-d', strtotime('+1 day'))
        ];
    }

    private function getFilteredAgents(Request $request, array $employeeBranches)
    {
        if ($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null) {
            return Employee::where('account_Type', 'Operations Account')
                ->where('status', 1)
                ->whereIn('current_branch', $request->get('branches'))
                ->groupBy('id')
                ->get()
                ->pluck('name', 'id')
                ->toArray();
        }

        return Employee::where('account_Type', 'Operations Account')
            ->where('status', 1)
            ->whereHas('branches', function ($query) use ($employeeBranches) {
                $query->whereIn('id', array_keys($employeeBranches));
            })
            ->groupBy('id')
            ->get()
            ->pluck('name', 'id')
            ->toArray();
    }

    private function getLoopsData($view_type, $leads)
    {
        $ids = array_keys($leads->toArray());
        
        if ($view_type == 'employees') {
            return Employee::where('status', 1)
                ->whereIn('id', $ids)
                ->get();
        }
        
        return Branch::whereIn('id', $ids)
            ->get();
    }
}
