<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateTrainingServiceRequest;
use App\Http\Requests\UpdateTrainingServiceRequest;
use App\Http\Controllers\AppBaseController;
use App\Models\TrainingService;
use App\Models\StageLevel;
use App\Models\Track;
use Illuminate\Http\Request;
use File;
use Flash;
use DB;
use Response;
use App\Traits\StoreImageTrait;

class TrainingServiceController extends AppBaseController
{
                             use StoreImageTrait;

    public function trainingServices_editWeb($id)
    {
        $trainingService = TrainingService::find($id);

        if (empty($trainingService)) {
            Flash::error('training service not found');

            return redirect(route('admin.trainingServices.index'));
        }

        return view('training_services.editWeb')->with('trainingService', $trainingService);
    }
    
    public function trainingServices_updateWeb($id,Request $request)
    {
        $trainingService = TrainingService::find($id);

        if (empty($trainingService)) {
            Flash::error('training service not found');

            return redirect(route('admin.trainingServices.index'));
        }
        $data = $request->except('image','_token');
        
       
                 $data['image'] = $this->verifyAndUpdateImageSource($trainingService->image,$request,'image','uploads/trainingServices');

        $trainingService->fill($data);
        $trainingService->save();

        Flash::success('training service updated successfully.');

        return redirect(route('admin.trainingServices.index'));
    }
    
    /**
     * Display a listing of the TrainingService.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var TrainingService $trainingServices */
        $trainingServices = TrainingService::orderBy('order_by')->get();

        return view('training_services.index')
            ->with('trainingServices', $trainingServices);
    }

    /**
     * Show the form for creating a new TrainingService.
     *
     * @return Response
     */
    public function create()
    {
        $tracks = Track::whereNull('parent_id')->pluck('title', 'id');
        $stageLevels=[];
        $courses=[];
        
        
        return view('training_services.create',compact('tracks','stageLevels','courses'));
    }

    /**
     * Store a newly created TrainingService in storage.
     *
     * @param CreateTrainingServiceRequest $request
     *
     * @return Response
     */
    public function store(Request $request)
    {
        // $input = $request->all();
        // dd($input);
        /** @var TrainingService $trainingService */
        // $trainingService = TrainingService::create($input);
        
        $trainingService = new TrainingService;
        $trainingService->title =     $request->title;
        $trainingService->track_id =  $request->track_id;
        $trainingService->course_id = $request->course_id;
        $trainingService->pattern =   $request->pattern;
        // 
        $levels = [];
        $levels = $request->level_id;
        // return $levels; 
        
        $trainingService->save();
        $trainingService->levels()->sync($levels);
        Flash::success('TrainingService saved successfully.');

        return redirect(route('admin.trainingServices.index'));
    }

    /**
     * Display the specified TrainingService.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var TrainingService $trainingService */
        $trainingService = TrainingService::with('levels')->find($id);

        if (empty($trainingService)) {
            Flash::error('TrainingService not found');

            return redirect(route('admin.trainingServices.index'));
        }

        return view('training_services.show')->with('trainingService', $trainingService);
    }

    /**
     * Show the form for editing the specified TrainingService.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var TrainingService $trainingService */
        $trainingService = TrainingService::with('levels')->find($id);
        // $trainingService_levels = $trainingService->with('levels')->get();
        $tracks = Track::whereNull('parent_id')->pluck('title', 'id');
        $levels_ids = DB::table('training_service_levels')->where('training_service_id',$trainingService->id)->pluck('level_id')->toArray();
        $stageLevels = StageLevel::leftJoin('stages','stages.id','=','stage_levels.stage_id')
            ->where('stages.track_id',$trainingService->course_id)
            ->pluck('stage_levels.name', 'stage_levels.id')->toArray();
        $courses = Track::where('parent_id',$trainingService->track_id)->pluck('title', 'id');

        // return $trainingService;
        

        if (empty($trainingService)) {
            Flash::error('TrainingService not found');

            return redirect(route('admin.trainingServices.index'));
        }

        return view('training_services.edit',compact('tracks','stageLevels','courses','levels_ids'))->with('trainingService', $trainingService);
    }

    /**
     * Update the specified TrainingService in storage.
     *
     * @param int $id
     * @param UpdateTrainingServiceRequest $request
     *
     * @return Response
     */
    public function updatee($id,Request $request)
    {
        /** @var TrainingService $trainingService */
        $trainingService = TrainingService::with('levels')->find($id);
        // return $trainingService;
        if (empty($trainingService)) {
            Flash::error('TrainingService not found');

            return redirect(route('admin.trainingServices.index'));
        }

        // $trainingService->fill($request->all());
        // $trainingService->save();
        $trainingService->title =     $request->title;
        $trainingService->track_id =  $request->track_id;
        $trainingService->course_id = $request->course_id;
        $trainingService->pattern =   $request->pattern;
        $trainingService->save();
        $levels = [];
        $levels = $request->level_id;
        
        $trainingService->levels()->sync( $request->level_id);

        Flash::success('TrainingService updated successfully.');

        return redirect(route('admin.trainingServices.index'));
    }

    /**
     * Remove the specified TrainingService from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var TrainingService $trainingService */
        $trainingService = TrainingService::find($id);

        if (empty($trainingService)) {
            Flash::error('TrainingService not found');

            return redirect(route('admin.trainingServices.index'));
        }

        $trainingService->delete();

        Flash::success('TrainingService deleted successfully.');

        return redirect(route('admin.trainingServices.index'));
    }
}
