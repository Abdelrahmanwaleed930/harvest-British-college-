<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateWHUsedItemRequest;
use App\Http\Requests\UpdateWHUsedItemRequest;
use App\Http\Controllers\AppBaseController;
use App\Models\WHItem;
use App\Models\WHUsedItem;
use App\Models\WHItemCategory;
use App\Models\Place;
use Illuminate\Http\Request;
use Flash;
use Response;

class WHUsedItemController extends AppBaseController
{
    /**
     * Display a listing of the WHUsedItem.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var WHUsedItem $used_items */
        $categories = WHItemCategory::all()->pluck('name','id');
        $wh_items = WHItem::select('id','name','item_category_id')->get();
        $wh_items = $wh_items->groupBy('item_category_id');
        $places = auth()->user()->places->pluck('name', 'id')->toArray();
        
        $usedItemsQuary = WHUsedItem::whereIn('place_id',array_keys($places));
        $per_page = 10;
        
        if($request->per_page && $request->per_page){
            $per_page = $request->per_page;
        }
        if($request->item_category_id && $request->item_category_id){
            $usedItemsQuary->where('item_category_id',$request->item_category_id);
        }
        if($request->item_id && $request->item_id){
            $usedItemsQuary->where('item_id',$request->item_id);
        }
        if($request->place_id && $request->place_id){
            $usedItemsQuary->where('place_id',$request->place_id);
        }
        $used_itemCount = $usedItemsQuary->count();
        $used_items = $usedItemsQuary->paginate(10);

        return view('wh_used_items.index',compact('used_items','used_itemCount','categories','wh_items','places','used_itemCount'));
    }

    /**
     * Show the form for creating a new WHUsedItem.
     *
     * @return Response
     */
    public function create()
    {
        $categories = WHItemCategory::all()->pluck('name','id');
        $wh_items = WHItem::select('id','name','item_category_id')->get();
        $wh_items = $wh_items->groupBy('item_category_id');
        $places = auth()->user()->places->pluck('name', 'id')->toArray();
        
        return view('wh_used_items.create',compact('categories','wh_items','places'));
    }

    /**
     * Store a newly created WHItem in storage.
     *
     * @param CreateWHItemRequest $request
     *
     * @return Response
     */
    public function store(CreateWHUsedItemRequest $request)
    {
        $input = $request->all();
        $input['employee_id'] = auth()->user()->id;
        /** @var WHItem $used_item */
        $used_item = WHUsedItem::create($input);

        Flash::success('Warehouse Item saved successfully.');

        return redirect(route('admin.whUsedItems.index'));
    }

    /**
     * Display the specified WHItem.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var WHItem $used_item */
        $used_item = WHUsedItem::find($id);

        if (empty($used_item)) {
            Flash::error('Warehouse Item not found');

            return redirect(route('admin.whUsedItems.index'));
        }

        return view('wh_used_items.show')->with('used_item', $used_item);
    }

    /**
     * Show the form for editing the specified WHItem.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var WHUsedItem $used_item */
        $categories = WHItemCategory::all()->pluck('name','id');
        $wh_items = WHItem::select('id','name','item_category_id')->get();
        $wh_items = $wh_items->groupBy('item_category_id');
        $places = auth()->user()->places->pluck('name', 'id')->toArray();
        
        $used_item = WHUsedItem::find($id);

        if (empty($used_item)) {
            Flash::error('Warehouse Item not found');

            return redirect(route('admin.whUsedItems.index'));
        }

        return view('wh_used_items.edit')->with('used_item', $used_item)->with('categories',$categories)->with('wh_items',$wh_items)->with('places',$places);
    }

    /**
     * Update the specified WHUsedItem in storage.
     *
     * @param int $id
     * @param UpdateWHItemRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateWHUsedItemRequest $request)
    {
        /** @var WHUsedItem $used_item */
        $used_item = WHUsedItem::find($id);

        if (empty($used_item)) {
            Flash::error('Warehouse Item not found');

            return redirect(route('admin.whUsedItems.index'));
        }

        $used_item->fill($request->all());
        $used_item->save();

        Flash::success('Warehouse Item updated successfully.');

        return redirect(route('admin.whUsedItems.index'));
    }

    /**
     * Remove the specified WHUsedItem from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var WHUsedItem $used_item */
        $used_item = WHUsedItem::find($id);

        if (empty($used_item)) {
            Flash::error('Warehouse Item not found');

            return redirect(route('admin.whUsedItems.index'));
        }

        $used_item->delete();

        Flash::success('Warehouse Item deleted successfully.');

        return redirect(route('admin.whUsedItems.index'));
    }
}
