<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ItAddedItems;
use App\Models\ItCurrentItems;
use App\Models\Branch;
use App\Models\ITItem;
use App\Models\ITItemCategory;

use Flash;
use Auth;
class ItAddedItemsController extends Controller
{
    public function index(){
        $ItAddedItems = ItAddedItems::with('ititemCategory','ititem','branch','created_by')->get();
        return view('ItAddedItems.index',compact('ItAddedItems'));
    }
    public function create(){
        $branches = Branch::where('status',1)->pluck('name','id');
        $ititemcategories =ITItemCategory::pluck('name','id');
        $ititem =[];
        
        
        return view('ItAddedItems.create',compact('branches','ititemcategories','ititem'));
    }
    public function store(Request $request){
        // return $request;
        $data = $request->validate([
            'branch_id' => 'required',
            'it_items_categories_id' => 'required',
            'it_item_id' => 'required',
            'item_count' => 'required',
            
            'details' => 'required',
            'notes' => 'required',
        ]);
        $check_current_items = ItCurrentItems::where('it_items_categories_id',$request->it_items_categories_id)
                                      ->where('it_item_id',$request->it_item_id)
                                      ->where('branch_id',$request->branch_id)->first();
        if($check_current_items != null && $check_current_items != ''){
            $check_current_items->balance += $request->item_count;
            $check_current_items->save();
            
            $balance = $check_current_items->balance;
            
        }else{
            ItCurrentItems::create([
                'it_items_categories_id' => $request->it_items_categories_id,
                'it_item_id' => $request->it_item_id,
                'branch_id' => $request->branch_id,
                'balance' => $request->item_count,
                'created_by_id' => auth()->user()->id
            ]);
            
            $balance = $request->item_count;
        }
        
        
        $ItAddedItems = new ItAddedItems;
        $ItAddedItems->branch_id = $request->branch_id;
        $ItAddedItems->it_items_categories_id = $request->it_items_categories_id;  
        $ItAddedItems->it_item_id = $request->it_item_id;
        $ItAddedItems->item_count = $request->item_count;
        $ItAddedItems->balance = $balance;
        $ItAddedItems->details = $request->details;
        $ItAddedItems->notes = $request->notes;
        $ItAddedItems->created_by_id = auth()->user()->id;
        $ItAddedItems->save();
        
        
         Flash::success('It Added Items saved successfully.');

        return redirect(route('admin.ItAddedItems.index'));
 
    }
    public function edit($id , Request $request){
        $ItAddedItems = ItAddedItems::find($id);
        $branches = Branch::where('status',1)->pluck('name','id');
        $ititemcategories =ITItemCategory::pluck('name','id');
        $ititem =ITItem::find($ItAddedItems->it_item_id)->pluck('name','id');
        
        return view('ItAddedItems.edit',compact('branches','ititemcategories','ititem','ItAddedItems'));
 
    }
    public function update($id , Request $request){
        
        $data = $request->validate([
            'branch_id' => 'required',
            'it_items_categories_id' => 'required',
            'it_item_id' => 'required',
            'item_count' => 'required',
            'details' => 'required',
            'notes' => 'required',
        ]);
        
        
        $ItAddedItems = ItAddedItems::find($id);
        $ItAddedItems->branch_id = $request->branch_id;
        $ItAddedItems->it_items_categories_id = $request->it_items_categories_id;
        $ItAddedItems->it_item_id = $request->it_item_id;
        $ItAddedItems->item_count = $request->item_count;
        $ItAddedItems->details = $request->details;
        $ItAddedItems->notes = $request->notes;
       
        $ItAddedItems ->save();
        
        
         Flash::success('It updated Items saved successfully.');

        return redirect(route('admin.ItAddedItems.index'));
    }
    public function destroy($id){
        $ItAddedItems = ItAddedItems::find($id);
        $ItAddedItems->delete();
        return redirect(route('admin.ItAddedItems.index'));
    }
    
    public function getititem(Request $request){
        $ititem = ITItem::where('item_category_id',$request->it_items_categories_id)->select('name','id')->get();
        return $ititem;
        
        
    }
    
}
