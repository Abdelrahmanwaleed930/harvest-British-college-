<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\CreateHrBoardingRequest;
use App\Http\Requests\UpdateHrBoardingRequest;

use App\Models\Employee;
use App\Models\HrBoarding;
use App\Models\HrBoardingSectionsStudent;
use App\Models\HrBoardingSections;
use App\Models\HrBoardingSectionsTopics;
use Flash;
use DB;
class HrBoardingController extends Controller
{
    public function index(Request $request){
        $HrBoardings = HrBoarding::get();
        return view('HrBoarding.index',compact('HrBoardings')); 
    }
    
    public function create()
    {
         $employee = Employee::find(request('employee'));
        $HrBoardingSections = HrBoardingSections::where('type',request('hr_type'))->get();
        return view('HrBoarding.create',compact('employee','HrBoardingSections')); 
    }
    
    public function store(CreateHrBoardingRequest $request){
        $data = $request->all();
        // dd($data);
        $HrBoarding = HrBoarding::create($data);
        
        foreach($request->hr_boarding_sections_topics_id as $key => $topic){
           
            $HrBoardingSectionsEmployee = new HrBoardingSectionsEmployee;
            $HrBoardingSectionsEmployee->hr_boarding_sections_id   = $request->hr_boarding_sections_id[$topic];
            $HrBoardingSectionsEmployee->hr_boarding_sections_topics_id = $topic;
            $HrBoardingSectionsEmployee->hr_boarding_id = $HrBoarding->id;
            $HrBoardingSectionsEmployee->type = $request->type[$topic];
            $HrBoardingSectionsEmployee->status = $request->status[$topic];           
            $HrBoardingSectionsEmployee->notes = $request->notes[$topic];           
            $HrBoardingSectionsEmployee->statement = $request->statement[$topic];           
            $HrBoardingSectionsEmployee->save();
        }
        
        Flash::success(' HrBoarding Create successfully.');
        
         return redirect()->back();
    }
    public function edit($id){
        
        $HrBoarding = HrBoarding::find($id);
        $HrBoardingSections = HrBoardingSections::where('type',$HrBoarding->hr_type)->get();
        
        return view('HrBoarding.edit',compact('HrBoarding','HrBoardingSections')); 

    }
    public function update($id,UpdateHrBoardingRequest $request){
      
        $HrBoarding =HrBoarding::find($id);
        $data = $request->all();
        $HrBoarding->update($data); 
     
        if($request->hr_boarding_sections_topics_id != null && count($request->hr_boarding_sections_topics_id) > 0)
        {
             HrBoardingSectionsEmployee::where('hr_boarding_id',$HrBoarding->id)->delete();
            
            foreach($request->hr_boarding_sections_topics_id as $key => $topic){
                $HrBoardingSectionsEmployee = new HrBoardingSectionsEmployee;
                $HrBoardingSectionsEmployee->hr_boarding_sections_id   = $request->hr_boarding_sections_id[$topic];
                $HrBoardingSectionsEmployee->hr_boarding_sections_topics_id = $topic;
                $HrBoardingSectionsEmployee->hr_boarding_id = $HrBoarding->id;
                $HrBoardingSectionsEmployee->type = $request->type[$topic];
                $HrBoardingSectionsEmployee->status = $request->status[$topic];           
                $HrBoardingSectionsEmployee->notes = $request->notes[$topic];           
                $HrBoardingSectionsEmployee->statement = $request->statement[$topic];           
                $HrBoardingSectionsEmployee->save();
            }
        }
      
        
        
        
        Flash::success('HrBoarding  updated successfully.');
         return redirect(route('admin.HrBoarding.index'));
        
       
    }
    public function show($id){
        $HrBoarding = HrBoarding::find($id); 
        return view('HrBoarding.show',compact('HrBoarding')); 
        
    }
    public function destroy($id){
        $HrBoarding = HrBoarding::find($id);
        $HrBoarding->delete();
        Flash::success(' HrBoarding delete  successfully.');
        
        return redirect(route('admin.HrBoarding.index'));
    }
}
