<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\CreateSurveySectionsTopicRequest;
use App\Http\Requests\UpdateSurveySectionsTopicRequest;

use App\Models\SurveySections;
use App\Models\SurveySectionTopicAnswer;
use App\Models\SurveySectionsTopic;
use Flash;
use Response;
class SurveySectionsTopicController extends Controller
{
    public function index()
    {
        $SurveySectionsTopics = SurveySectionsTopic::get();
        
        return view('SurveySectionsTopic.index',compact('SurveySectionsTopics'));
    }
    public function create()
    {
        $SurveySections = SurveySections::pluck('title','id');
        return view('SurveySectionsTopic.create',compact('SurveySections'));
    }
    public function store(CreateSurveySectionsTopicRequest $request)
    {
        $input = $request->all();
        // return $input;
        $SurveySectionsTopic = SurveySectionsTopic::create($input);
        
        if($request->has('answer_en') && $request->answer_en != null && count($request->answer_en) > 0){
            foreach($request->answer_en as $key => $answer){
                $SurveySectionTopicAnswer = new SurveySectionTopicAnswer;
                $SurveySectionTopicAnswer->survey_section_topic_id = $SurveySectionsTopic->id;
                $SurveySectionTopicAnswer->answer_en = $request->answer_en[$key]; 
                $SurveySectionTopicAnswer->answer_ar = $request->answer_ar[$key];
                $SurveySectionTopicAnswer->save();
            }
        }
        Flash::success('SurveySectionsTopic saved successfully.');
        return redirect(route('admin.SurveySectionsTopic.index'));
    }
    public function show($id)
    {
        $SurveySectionsTopic = SurveySectionsTopic::find($id);
        if (empty($SurveySectionsTopic)) {
            Flash::error('SurveySectionsTopic not found');

            return redirect(route('admin.SurveySectionsTopic.index'));
        }
        
        return view('SurveySectionsTopic.show',compact('SurveySectionsTopic'));
    }
    public function edit($id)
    {
        $SurveySectionsTopic = SurveySectionsTopic::find($id);
        
        $SurveySections = SurveySections::pluck('title','id');
        
        $SurveySectionTopicAnswers = SurveySectionTopicAnswer::where('survey_section_topic_id',$SurveySectionsTopic->id)->get();
        // return $SurveySectionTopicAnswers;
        if (empty($SurveySectionsTopic)) {
            Flash::error('SurveySectionsTopic not found');

            return redirect(route('admin.SurveySectionsTopic.index'));
        }
        
        return view('SurveySectionsTopic.edit',compact('SurveySectionsTopic','SurveySections','SurveySectionTopicAnswers'));
    }
    public function update(UpdateSurveySectionsTopicRequest $request , $id)
    {
        $SurveySectionsTopic = SurveySectionsTopic::find($id);
        $data =  $request->all();
        // dd($data);
        if (empty($SurveySectionsTopic)) {
            Flash::error('SurveySectionsTopic not found');

            return redirect(route('admin.SurveySectionsTopic.index'));
        }
        $SurveySectionsTopic->update($data);
        if($request->SurveySectionTopicAnswer_id != null && count($request->SurveySectionTopicAnswer_id) > 0)
        {
         
            foreach($request->SurveySectionTopicAnswer_id as $key => $answer){
               
                $SurveySectionTopicAnswer = SurveySectionTopicAnswer::find($answer);
                $SurveySectionTopicAnswer->answer_en = $request->answer_en_old[$key]; 
                $SurveySectionTopicAnswer->answer_ar = $request->answer_ar_old[$key];
                $SurveySectionTopicAnswer->save();
            }
        }
        if($request->has('answer_en') && $request->answer_en != null && count($request->answer_en) > 0){
            foreach($request->answer_en as $key => $answer){
               
                $SurveySectionTopicAnswer = new SurveySectionTopicAnswer;
                $SurveySectionTopicAnswer->survey_section_topic_id = $SurveySectionsTopic->id;
                $SurveySectionTopicAnswer->answer_en = $request->answer_en[$key]; 
                $SurveySectionTopicAnswer->answer_ar = $request->answer_ar[$key];
                $SurveySectionTopicAnswer->save();
            }
        }
        
        Flash::success('SurveySectionsTopic updated successfully.');
        return redirect(route('admin.SurveySectionsTopic.index'));
    }
    public function destroy($id)
    {
        $SurveySectionsTopic = SurveySectionsTopic::find($id);
        if (empty($SurveySectionsTopic)) {
            Flash::error('SurveySectionsTopic not found');

            return redirect(route('admin.SurveySectionsTopic.index'));
        }
        $SurveySectionsTopic->delete();
        
        Flash::success('SurveySectionsTopic Deleted successfully.');
        return redirect(route('admin.SurveySectionsTopic.index'));
    }
}
