<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateOperationVacationRequest;
use App\Http\Requests\UpdateOperationVacationRequest;
use App\Http\Controllers\AppBaseController;
use App\Models\OperationVacation;
use App\Models\SubRound;
use Illuminate\Http\Request;
use Flash;
use Response;
use ArrayObject;
use Carbon\Carbon;
use DB;

class OperationVacationController extends AppBaseController
{
    /**
     * Display a listing of the OperationVacation.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var OperationVacation $operationVacations */
        $operationVacations = OperationVacation::all();

        return view('operation_vacations.index')->with('operationVacations', $operationVacations);
    }

    /**
     * Show the form for creating a new OperationVacation.
     *
     * @return Response
     */
    public function create()
    {
        return view('operation_vacations.create');
    }

    /**
     * Store a newly created OperationVacation in storage.
     *
     * @param CreateOperationVacationRequest $request
     *
     * @return Response
     */
    public function store(CreateOperationVacationRequest $request)
    {
        $input = $request->all();

        /** @var OperationVacation $operationVacation */
        $operationVacation = OperationVacation::create($input);
        
        $days_ids = SubRound::whereHas('subRoundSessions',function($query) use($request){
            return $query->where('date','>=',$request->from_date)->where('date','<=',$request->to_date);
        })->pluck('days')->toArray();
        //dd($days_ids);
        $sub_rounds1 = SubRound::whereIn('days',array_unique($days_ids))->where('end_date','>=',$request->to_date)->get();
        $sub_rounds2 = SubRound::whereIn('days',array_unique($days_ids))->where('end_date','>=',$request->from_date)->where('end_date','<=',$request->to_date)->get();
        $all_sub_rounds = $sub_rounds2->merge($sub_rounds1);
        $round_sub_rounds = $all_sub_rounds->groupBy('round_id');
        foreach($round_sub_rounds as $round_id => $sub_rounds){
            $sub_rounds = $sub_rounds->groupBy('days');
            //dd($sub_rounds);
            foreach($sub_rounds as $day => $day_sub_rounds){
                $startDate = Carbon::parse($day_sub_rounds[0]->start_date);
                foreach($day_sub_rounds as $key => $sub_round){
                    //dd($sub_round);
                    $days = explode('/', config('system_variables.timeframes.days')[$day]);
                    $start_day = date_format(date_create($sub_round['start_date']),'D');
                    if(in_array($start_day,['Tue','Wed','Thu'])){
                        $days = array_reverse($days);
                    }
                    $daysObj = new ArrayObject($days);
                    $daysIt = $daysObj->getIterator();
                    $date = $startDate;
                    
                    if($key > 0){
                        $sub_round->update(['start_date' => $startDate]);
                    }else{
                        $this->checkDate($date,$request->from_date,$request->to_date,$daysIt);
                        $sub_round->update(['start_date' => $date]);
                    }
                    
                    $sessions = $sub_round->subRoundSessions;
                    foreach($sessions as $index => $session){
                        if ($index) {
                            if (!$daysIt->valid()) {
                                $daysIt->rewind();
                            }
                            $date = $date->next($daysIt->current());
                        }
                        $this->checkDate($date,$request->from_date,$request->to_date,$daysIt);
                        DB::table('group_sessions')->where('date',$session->date)->update(['date' => $date,]);
                        $session->update([
                            'date' => $date,
                        ]);
                        $daysIt->next();
                    }
                    
                    $sub_round->update(['end_date' => $date]);
                    $startDate = $date->next($days[0]);
                }
            }
            
        }
        Flash::success('Operation Vacation saved successfully.');

        return redirect(route('admin.operationVacations.index'));
    }
    
    public function checkDate(&$date,$from_date,$to_date,&$daysIt)
    {
        $string_date = $date->format('Y-m-d');
        if($string_date >= $from_date && $string_date <= $to_date){
            $daysIt->next();
            
            if (!$daysIt->valid()) {
                $daysIt->rewind();
            }
            $date = $date->next($daysIt->current());
            
            $this->checkDate($date,$from_date,$to_date,$daysIt);
        }
    }

    /**
     * Display the specified OperationVacation.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var OperationVacation $operationVacation */
        $operationVacation = OperationVacation::find($id);

        if (empty($operationVacation)) {
            Flash::error('Operation Vacation not found');

            return redirect(route('admin.operationVacations.index'));
        }

        return view('operation_vacations.show')->with('operationVacation', $operationVacation);
    }

    /**
     * Show the form for editing the specified OperationVacation.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var OperationVacation $operationVacation */
        
    }

    /**
     * Update the specified OperationVacation in storage.
     *
     * @param int $id
     * @param UpdateOperationVacationRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateOperationVacationRequest $request)
    {
        /** @var OperationVacation $operationVacation */
        
    }

    /**
     * Remove the specified OperationVacation from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var OperationVacation $operationVacation */
        
    }
}
