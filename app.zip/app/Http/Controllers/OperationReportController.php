<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\Employee;
use App\Models\Expense;
use App\Models\Lead;
use App\Models\LeadPayment;
use App\Models\PlacementApplicant;
use App\Models\Offer;
use App\Models\LeadSource;
use App\Models\Track;
use App\Models\CustomerTrack;
use App\Models\LabelType;
use App\Models\Timeframe;
use App\Models\GroupSessionAttendance;
use App\Models\GroupStudent;
use App\Models\LeadCase;
use App\Models\Group;
use App\Models\Round;
use App\Models\SubRound;
use App\Models\SubPayment;
use App\Models\DisciplineCategory;
use App\Models\KnowChannel;
use App\Models\StudentExam;
use Illuminate\Http\Request;
use Auth;
use DB;

class OperationReportController extends Controller
{
    
    public function operation_inquiry_report(Request $request){
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $agents = [];
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id')->toArray();
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })
                            //->whereIn('current_branch' , $request->get('branches'))
                            ->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        $from = null;
        $to = null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $from = date_format(date_create($daterange[0]),'Y-m-d');
            // $to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $to= date_format($reg_to,"Y-m-d");
        }
        
        $labelTypes = LabelType::where('status', 1)->where('category', 4)->get();
        $labelTypess = LabelType::where('status', 1)->where('category', 4)->pluck('name', 'id')->toArray();
        
        $followupsQuery = LeadCase::whereIn('label_type_id',array_keys($labelTypess));
                
        if($request->has('status') && $request->get('status') != null && $request->get('status') != ''){
            $followupsQuery->where('status', $request->get('status'));
        }
        
        if($from != null && $from != '' && $to != null && $to != ''){
            $followupsQuery->whereBetween('created_at',[$from,$to]);
        }else{
            $followupsQuery->where('created_at','like','%'.date('Y-m-d').'%');
        }
        
            
             $leads = $followupsQuery->select('branch_id','status','label_type_id',DB::raw('count(*) as followup_count'))->groupBy('branch_id')->groupBy('label_type_id')->orderBy('branch_id')->get();
             $leads = $leads->groupBy('branch_id');
            
            $branches_ids = array_keys($leads->toArray());
            
            $loops = Branch::where('status',1)->whereIn('id',$branches_ids)->pluck('name','id');
                
             
        return view('operations_reports.operation_inquiry_report',compact('employeeBranches','agents','labelTypes','leads','loops'));
    
        
    }
    public function exam_report(Request $request)
    {
        $view_type = 'branches';
        if($request->has('view_type')){
            $view_type = $request->get('view_type');
        }
         $employeeBranches = auth()->user()->branches->where('id','!=',19)->where('id','!=',8)->pluck('name', 'id')->toArray();
        $rounds = Round::all();
        
            $instructors = [];
        $subrounds = SubRound::join('rounds','rounds.id','=','sub_rounds.round_id')->where('sub_rounds.start_date','<=',date('Y-m-d'))->orderBy('sub_rounds.start_date','desc')->take(20)->select(DB::raw('concat(rounds.title,", ",sub_rounds.start_date) as sub_round_name'),'sub_rounds.id')->get()->pluck('sub_round_name', 'id');
        
        $current_day = date('Y-m-d');
        
        if($view_type == 'branches'){
            $group_query = Group::whereNotNull('branch_id');
            $group_id = Group::join('sub_rounds','sub_rounds.id','groups.sub_round_id');
            
              
            if($request->has('sub_round_id') && $request->get('sub_round_id') != null && $request->get('sub_round_id') != ''){
                    $group_query->whereIn('sub_round_id',$request->get('sub_round_id'));
             }
                
            
             $groups_id = $group_query->pluck('groups.id')->ToArray();
             $groups_student = GroupStudent::join('groups','groups.id','group_students.group_id')->
                                             join('sub_rounds','sub_rounds.id','groups.sub_round_id')->
                                        whereIn('groups.id',$groups_id)
                                        ->select('groups.branch_id','group_students.lead_id')->get()->groupBy('branch_id');
            
             $students_exam = StudentExam::join('groups','groups.id','student_exams.group_id')->
                                          join('sub_rounds','sub_rounds.id','groups.sub_round_id')->
                                          whereIn('groups.id',$groups_id)
                                          ->select('groups.branch_id','student_exams.lead_id')->get()->groupBy('branch_id');
                                   
            $groups = $group_query->get()->groupBy('branch_id');
            $exams =[];
            
            if($employeeBranches != null && count($employeeBranches) >0){
                foreach($employeeBranches as $branch_id=> $branch){
                    $exams[$branch_id]['branch_id'] = $branch_id;
                    if(isset($groups[$branch_id]))
                    {
                      $exams[$branch_id]['groups_count'] = $groups[$branch_id]->count() ;
                    }else{
                      $exams[$branch_id]['groups_count'] = 0;
                    }
                    if(isset($groups_student[$branch_id])){
                       $exams[$branch_id]['groups_student_count'] = $groups_student[$branch_id]->count() ;
                    }else{
                        $exams[$branch_id]['groups_student_count'] = 0;
                    }
                    if(isset($students_exam[$branch_id])){
                        $exams[$branch_id]['student_exam_count'] = $students_exam[$branch_id]->count() ;
                    }else{
                       $exams[$branch_id]['student_exam_count'] = 0;
                    }
                    if(isset($groups_student[$branch_id]) && isset($students_exam[$branch_id])){
                        
                      $exams[$branch_id]['student_not_exam_count'] = ($groups_student[$branch_id]->count() - $students_exam[$branch_id]->count()) ;
                    }else{
                        
                       $exams[$branch_id]['student_not_exam_count'] = 0;
                    }
                    
                }
            }
            
        }else{
            
            if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
                $instructors = Employee::where('account_Type', 'ESL Account Profile')->has('Group')->where('status',1)
                                ->whereHas('branches', function ($query) use ($request) {
                                    $query->whereIn('id', $request->get('branches'));
                                })->groupBy('id')->get()->pluck('name', 'id')->toArray();
            }else{
                $instructors = Employee::where('account_Type', 'ESL Account Profile')->has('Group')->where('status',1)
                                ->whereHas('branches', function ($query) use ($employeeBranches) {
                                    $query->whereIn('id', array_keys($employeeBranches));
                                })->groupBy('id')->get()->pluck('name', 'id')->toArray();
            }
            $group_query = Group::whereNotNull('instructor_id');
            $group_id = Group::join('sub_rounds','sub_rounds.id','groups.sub_round_id');
            
              
            if($request->has('sub_round_id') && $request->get('sub_round_id') != null && $request->get('sub_round_id') != ''){
                    $group_query->whereIn('sub_round_id',$request->get('sub_round_id'));
            }
                
            
            $groups_id = $group_query->pluck('groups.id')->ToArray();
            $groups_student = GroupStudent::join('groups','groups.id','group_students.group_id')->
                                            join('sub_rounds','sub_rounds.id','groups.sub_round_id')->
                                            whereIn('groups.id',$groups_id)
                                            ->select('groups.instructor_id','group_students.lead_id')->get()->groupBy('instructor_id');
            
            $students_exam = StudentExam::join('groups','groups.id','student_exams.group_id')->
                                          join('sub_rounds','sub_rounds.id','groups.sub_round_id')->
                                          whereIn('groups.id',$groups_id)
                                          ->select('groups.instructor_id','student_exams.lead_id')->get()->groupBy('instructor_id');
                                   
            $groups = $group_query->get()->groupBy('instructor_id');
            // return $groups['285']['1']['branch_id'];
            $exams =[];
            
            if($instructors != null && count($instructors) >0){
                foreach($instructors as $instructor_id=> $instructor){
                    $exams[$instructor_id]['instructor_id'] = $instructor_id;
                    
                    if(isset($groups[$instructor_id]))
                    {
                      $exams[$instructor_id]['groups_count'] = $groups[$instructor_id]->count() ;
                    }else{
                      $exams[$instructor_id]['groups_count'] = 0;
                    }
                    if(isset($groups_student[$instructor_id])){
                       $exams[$instructor_id]['groups_student_count'] = $groups_student[$instructor_id]->count() ;
                    }else{
                        $exams[$instructor_id]['groups_student_count'] = 0;
                    }
                    if(isset($students_exam[$instructor_id])){
                        $exams[$instructor_id]['student_exam_count'] = $students_exam[$instructor_id]->count() ;
                    }else{
                       $exams[$instructor_id]['student_exam_count'] = 0;
                    }
                    if(isset($groups_student[$instructor_id]) && isset($students_exam[$instructor_id])){
                        
                      $exams[$instructor_id]['student_not_exam_count'] = ($groups_student[$instructor_id]->count() - $students_exam[$instructor_id]->count()) ;
                    }else{
                        
                       $exams[$instructor_id]['student_not_exam_count'] = 0;
                    }
                    
                }
            }
        }
        // return $exams;
      
        return view('operations_reports.exam_report',compact('employeeBranches','view_type','instructors','exams','groups','subrounds','rounds'));
    }
    
    public function clientsTracker(Request $request)
    {
        
        $operation_cash =  Offer::whereHas('disciplines',function($query){
            $query->where('discipline_id',1);
            
        })->where('offer_type' ,2)->where('duration',3)->where('num_levels',3)->where('end_date','>=',date('Y-m-d'))->where('payment_plan_id',2)->first();
        
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id')->toArray();
        //$this->rounds = Round::pluck('title', 'id')->toArray();
        $disciplines = DisciplineCategory::pluck('name', 'id')->toArray(); 
        
        //dd($courses);
        $agents = [];
        $track = $request->track_id;
        if($request->has('current_branches') && $request->get('current_branches') != '' && $request->get('current_branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request){
                                $query->whereIn('id', $request->get('current_branches'));
                            })
                            /*->whereIn('current_branch' , $request->get('current_branches'))*/
                            ->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->get()->pluck('name', 'id')->toArray();
        }
        
        $registration_from = null;
        $registration_to = null;
        if ($request->has('registration_daterange') && $request->get('registration_daterange') != null && $request->get('registration_daterange') != ''){
            $daterange = explode(' - ',$request->get('registration_daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            // $registration_to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
        } 
        $leadsQuery = Lead::leftJoin('placement_applicants','placement_applicants.lead_id','=','leads.id')
            ->leftJoin('customer_tracks','customer_tracks.lead_id','=','leads.id')
            // ->leftJoin('group_students','group_students.lead_id','=','customer_tracks.lead_id')
            ->leftJoin('groups','groups.id','=','customer_tracks.last_group_id')
            ->whereRaw('(placement_applicants.track_id = '.$track.' or placement_applicants.track_id is null)')
            ->where('customer_tracks.track_id', $track)
            ->whereNotNull('customer_tracks.last_level_id')
            ->whereNotNull('customer_tracks.last_group_id');

        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $leadsQuery->where(function ($query) use ($request){
                $query->where('leads.name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.mobile_1', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.email', 'like', '%' . $request->get('search') . '%');
            });
        }elseif(auth()->user()->can('leads leadsAssign')){
            
        }else{
            $leadsQuery->whereIn('leads.branch_id', array_keys($employeeBranches));
        }
        
        if($request->has('admin') && $request->get('admin') != null && $request->get('admin') != ''){
            $leadsQuery->where('groups.admin_id', $request->get('admin'));
        }
        
        if ($request->has('current_branches') && $request->get('current_branches') != null && $request->get('current_branches') != '') {
            $leadsQuery->whereIn('leads.branch_id', $request->get('current_branches'));
        }
        
        if ($registration_from != null && $registration_to != '') {
            $leadsQuery->whereBetween('leads.created_at', [$registration_from, $registration_to]);
        }
        
        $courses = [];
        $stageLevels = [];
        $stageLevelss = [];
        $timeframes = [];
        $rounds = [];
        $daysData = [];
        $subRounds = [];
        // $stage_level=[];
        
        
        if($request->has('discipline_id') && $request->get('discipline_id') != null && $request->get('discipline_id') != ''){
            $leadsQuery->where('groups.discipline_id',$request->get('discipline_id'));
        }
        
        if($request->has('track_id') && $request->get('track_id') != null && $request->get('track_id') != ''){
            $leadsQuery->where('groups.track_id',$track);
        }
        
        if($request->has('course_id') && $request->get('course_id') != null && $request->get('course_id') != ''){
            $leadsQuery->where('groups.course_id',$request->get('course_id'));
            // dd($leadsQuery);
            $timeframe_ids = DB::table('timeframe_courses')->where('course_id',$request->get('course_id'))->pluck('timeframe_id')->toArray();
            $timeframes = Timeframe::whereIn('id',$timeframe_ids)->where('status',1)->pluck('title','id')->toArray();
        }
            
        if($request->has('timeframe_id') && $request->get('timeframe_id') != null && $request->get('timeframe_id') != ''){
            $leadsQuery->where('groups.timeframe_id',$request->get('timeframe_id'));
            $rounds = Round::where('timeframe_id',$request->get('timeframe_id'))->pluck('title', 'id')->toArray();
        }
        
        if($request->has('round_id') && $request->get('round_id') != null && $request->get('round_id') != ''){
            $leadsQuery->where('groups.round_id',$request->get('round_id'));
            $round = Round::with('timeframe.intervals')->find($request->get('round_id'));

            $daysData = $round->timeframe->days;
        }
        if($request->has('days') && $request->get('days') != null && $request->get('days') != ''){
            $leadsQuery->where('groups.days',$request->get('days'));
            $subRounds = SubRound::where('days', $request->get('days'))
                                -> where('round_id', $request->get('round_id'))
                                -> whereDate('start_date', '>=', now())
                                -> orderBy('start_date')->pluck('start_date', 'id');
        }
            
        if($request->has('interval_id') && $request->get('interval_id') != null && $request->get('interval_id') != ''){
            $leadsQuery->where('groups.interval_id',$request->get('interval_id'));
        }

        if($request->has('sub_round_id') && $request->get('sub_round_id') != null && $request->get('sub_round_id') != ''){
            $leadsQuery->whereIn('groups.sub_round_id',$request->get('sub_round_id'));
        }
        
        if($request->has('level_id') && $request->get('level_id') != null && $request->get('level_id') != ''){
            $leadsQuery->whereIn('groups.sub_round_id',$request->get('sub_round_id'));
        }
        
        if($request->has('group_id') && $request->get('group_id') != null && $request->get('group_id') != ''){
            $leadsQuery->where('leads.last_group_id',$request->get('group_id'));
        }
        $leadsCount = $leadsQuery->count();
        $leads = $leadsQuery->select('leads.*','placement_applicants.level as pt_level','customer_tracks.last_level_id','customer_tracks.last_group_id')->with('branch','getLastGroup','getLastLevel','payments','customerTracks','getOldCustomerPayment')->latest()->paginate($per_page);
        //$leads; 
        //dd($leads);
        //dd($request->all());
        return view('operations_reports.clientsTracker',compact('rounds','daysData','operation_cash','subRounds','stageLevels','timeframes','leads','leadsCount','employeeBranches','agents','tracks','disciplines','courses'));
    
    }
    
    public function customersTracker(Request $request)
    {
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();

        //dd($courses);
        $agents = [];
        if($request->has('current_branches') && $request->get('current_branches') != '' && $request->get('current_branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('current_branches'));
                            })
                            /*->whereIn('current_branch' , $request->get('current_branches'))*/
                            ->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->get()->pluck('name', 'id')->toArray();
        }
        
        $registration_from = null;
        $registration_to = null;
        if ($request->has('registration_daterange') && $request->get('registration_daterange') != null && $request->get('registration_daterange') != ''){
            $daterange = explode(' - ',$request->get('registration_daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            // $registration_to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
        } 
        $track = $request->track_id;
        $leadsQuery = Lead::leftJoin('placement_applicants','placement_applicants.lead_id','=','leads.id')
            ->leftJoin('group_waiting_lists','group_waiting_lists.lead_id','=','leads.id')
            ->whereRaw('(placement_applicants.track_id = '.$track.' or placement_applicants.track_id is null)')
            ->whereRaw('(group_waiting_lists.track_id = '.$track.' or (leads.type = 2 and leads.prefered_track_id = '.$track.' and group_waiting_lists.track_id is null))');
            //->where('leads.type', $type);
        
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $leadsQuery->where(function ($query) use ($request){
                $query->where('leads.name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.mobile_1', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.email', 'like', '%' . $request->get('search') . '%');
            });
        }elseif(auth()->user()->can('leads leadsAssign')){
            
        }else{
            $leadsQuery->whereIn('leads.branch_id', array_keys($employeeBranches));
        }
        
        if($request->has('admin') && $request->get('admin') != null && $request->get('admin') != ''){
            $leadsQuery->where('groups.admin_id', $request->get('admin'));
        }
        
        if ($request->has('current_branches') && $request->get('current_branches') != null && $request->get('current_branches') != '') {
            $leadsQuery->whereIn('leads.branch_id', $request->get('current_branches'));
        }
        
        if ($registration_from != null && $registration_to != '') {
            $leadsQuery->whereBetween('leads.created_at', [$registration_from, $registration_to]);
        }
        
        $stageLevels = [];
        $courses = Track::where('status',1)->where('parent_id',$request->get('track_id'))->pluck('title','id');
        // dd($courses);
        
        if($request->has('course_id') && $request->get('course_id') != null && $request->get('course_id') != ''){
            $stageLevels = Track::find($request->course_id)->stageLevels;
            // dd($stageLevelss);
            
            $leadsQuery->whereIn('group_waiting_lists.level_id',$stageLevels->pluck('id'));
            $stageLevels = $stageLevels->pluck('name','id');
        }
        
        if($request->has('level_id') && $request->get('level_id') != null && $request->get('level_id') != ''){
            $leadsQuery->where('group_waiting_lists.level_id',$request->get('level_id'));
        }
        $leads = $leadsQuery->select('leads.*','placement_applicants.level as pt_level','group_waiting_lists.level_id as last_level_id')->with('assignedEmployee','branch','getLastLevel','payments','customerTracks','getOldCustomerPayment')->latest()->paginate($per_page);
        $leadsCount = $leadsQuery->count();
        //  $leads; 
        // dd($leads);
        // dd($request->all());
        return view('operations_reports.customersTracker',compact('stageLevels','leads','leadsCount','employeeBranches','agents','courses'));
    }
    
    public function ratePerHourReport(Request $request)
    {
        $view_type = 'instructors';
        if($request->has('view_type')){
            $view_type = $request->get('view_type');
        }
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        if($view_type == 'instructors'){
            $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
            $instructors = [];
            if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
                $instructors = Employee::with('branches','attendances','places','department')->where('account_Type', 'ESL Account Profile')->where('status',1)
                                ->whereHas('branches', function ($query) use ($request) {
                                    $query->whereIn('id', $request->get('branches'));
                                })->get();
                //dd($instructors);
            }else{
                $instructors = Employee::with('branches','attendances','places','department')->where('account_Type', 'ESL Account Profile')->where('status',1)
                                ->whereHas('branches', function ($query) use ($employeeBranches) {
                                    $query->whereIn('id', array_keys($employeeBranches));
                                })->get();
            }
            
            foreach($instructors as $key => $instructor){
                $instructors[$key]['plan'] = $instructor->getPlan();
                if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
                    $instructors[$key]['actual_plan'] = $instructor->getActualPlan($request->get('branches'));
                    $instructors[$key]['actual_customers'] = $instructor->getActualCustomers($request->get('branches'));
                }else{
                    $instructors[$key]['actual_plan'] = $instructor->getActualPlan();
                    $instructors[$key]['actual_customers'] = $instructor->getActualCustomers();
                }
            }
            
            return view('operations_reports.ratePerHourReport',compact('employeeBranches','instructors','view_type'));
        }else{
            $employeeBranches = auth()->user()->branches;
            
            foreach($employeeBranches as $key => $branch){
                $instructors = Employee::with('branches','attendances','places','department')->where('account_Type', 'ESL Account Profile')->where('status',1)
                                ->whereHas('branches', function ($query) use ($branch) {
                                    $query->where('id', $branch->id);
                                })->get();
                //dd($branch,$instructors);
                if($instructors != null && count($instructors) > 0){
                    $employeeBranches[$key]['starting_salary'] = $instructors->sum('starting_salary');
                    $employeeBranches[$key]['plan'] = $branch->getPlan($instructors->pluck('id')->toArray());
                    $employeeBranches[$key]['actual_plan'] = $branch->getActualPlan($instructors->pluck('id')->toArray());
                    $employeeBranches[$key]['actual_customers'] = $branch->getActualCustomers($instructors->pluck('id')->toArray());
                }else{
                    unset($employeeBranches[$key]);
                }
            }       
            return view('operations_reports.ratePerHourReport',compact('employeeBranches','view_type'));
        }
        
    }
    
    public function targetCashReport(Request $request)
    {
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $instructors = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $instructors = Employee::where('account_Type', 'ESL Account Profile')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $instructors = Employee::where('account_Type', 'ESL Account Profile')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        
        $admins = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $admins = Employee::where('account_Type', 'Operations Account')->where('status',1)
                           /* ->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })->*/->whereIn('current_branch' , $request->get('branches'))->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $admins = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $groupsQuery = Group::whereIn('branch_id',$request->get('branches'))->has('students');
        }else{
            $groupsQuery = Group::whereIn('branch_id',array_keys($employeeBranches))->has('students');
        }
        
        //dd($groupsQuery->get());
        
        if($request->has('admin_id') && $request->get('admin_id') != '' && $request->get('admin_id') != null){
            $groupsQuery->where('admin_id',$request->get('admin_id'));
        }
        
        if($request->has('instructor_id') && $request->get('instructor_id') != '' && $request->get('instructor_id') != null){
            $groupsQuery->where('instructor_id',$request->get('instructor_id'));
        }
        
        if($request->has('status') && $request->get('status') != '' && $request->get('status') != null && $request->get('status') != 'running'){
            if($request->get('status') == 'complete'){
                $groupsQuery->whereHas('subRound',function($query){
                    $query->where('end_date','<',date('Y-m-d'));
                });
            } 
            if($request->get('status') == 'upcoming'){
                $groupsQuery->whereHas('subRound',function($query){
                    $query->where('start_date','>=',date('Y-m-d'));
                });
            }
        }else{
            $groupsQuery->whereHas('subRound',function($query){
                $query->where('start_date','<',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
            });
        }
        
        $groups = $groupsQuery->select('id','code','branch_id','instructor_id','admin_id','timeframe_id','room_id','sub_round_id','course_id','level_id','discipline_id')->with('discipline','branch','instructor','admin','getStudents','timeframe','room','subRound')->withCount('students')->orderBy('branch_id')->orderBy('timeframe_id')->paginate($per_page);
        
        foreach($groups as $key => $group){
            $students_ids = $group->getStudents->pluck('id');
            
            $paymentQuery1 = LeadPayment::whereIn('lead_payments.lead_id',$students_ids);
            
            $groups[$key]['total_unpaid'] = $paymentQuery1->sum('rest');
            
            $paymentQuery2 = LeadPayment::join('sub_payments','sub_payments.lead_payment_id','=','lead_payments.id')
                                    ->where('lead_payments.payment_plan_id','!=',2)
                                    ->where('lead_payments.rest','>',0)
                                    ->where('sub_payments.paid',0)
                                    ->whereIn('lead_payments.lead_id',$students_ids)
                                    ->select('sub_payments.amount','sub_payments.due_date');
            
            
            $groups[$key]['round_unpaid'] = $paymentQuery2->where('sub_payments.due_date','<=',$group->subRound->end_date)->sum('sub_payments.amount');
            
            $cashBooksCount = 0;
            $free_books = 0;
            $activation_levels = 0;
            $harvestCertificate = 0;
            $cambridgeCertificate = 0;
            foreach($group->getStudents as $lead){
                if($lead->customerTracks != null && count($lead->customerTracks) > 0){
                    $freeBooksCount = $lead->freeBooksCount($lead->customerTracks[0]->total);
                    $free_books += $freeBooksCount;
                    if($freeBooksCount == 0){
                        $cashBooksCount += ($lead->customerTracks[0]->total - $lead->customerTracks[0]->used);
                    }
                    if($freeBooksCount > 0 && $freeBooksCount < $lead->customerTracks[0]->total){
                        $cashBooksCount += ($lead->customerTracks[0]->total - $freeBooksCount);
                    }
                    $activationLevelsCount = 0;
                    if(in_array($lead->customerTracks[0]->course_id,[2,13])){
                        $activationLevelsCount += (115 - ($lead->getLastLevel->id + ($lead->customerTracks[0]->total - $lead->customerTracks[0]->used) - 1));
                    }elseif($lead->customerTracks[0]->course_id == 3){
                        $activationLevelsCount += (117 - ($lead->getLastLevel->id + ($lead->customerTracks[0]->total - $lead->customerTracks[0]->used) - 1));
                    }else{
                    
                    }
                    $cashBooksCount += $activationLevelsCount;
                    $activation_levels += $activationLevelsCount;
                    $harvestCertificate += $lead->freeCertificate(2);
                    $cambridgeCertificate += $lead->freeCertificate(3);
                    
                }
                
            }
            $groups[$key]['free_books'] = $free_books;
            $groups[$key]['cash_books'] = $cashBooksCount;
            $groups[$key]['cash_books_amount'] = ($cashBooksCount * 110);
            $groups[$key]['activation_levels'] = $activation_levels;
            $groups[$key]['total_activation_levels'] = ($activation_levels * 550);
            $groups[$key]['total_harvest'] = $harvestCertificate;
            $groups[$key]['total_cambridge'] = $cambridgeCertificate;
            $groups[$key]['certifications_amount'] = (($groups[$key]['total_harvest'] * 550) + ($groups[$key]['total_cambridge'] * 1200));
            
            $groups[$key]['total_amount'] = ($groups[$key]['total_unpaid'] + $groups[$key]['cash_books_amount'] + $groups[$key]['certifications_amount'] + $groups[$key]['total_activation_levels']);
            //dd($leads_ids,$groups[$key]['total_free_offers_books']);
        }
        return view('operations_reports.targetCashReport',compact('employeeBranches','instructors','admins','groups'));
    }
    public function makeupsessionReport(Request $request){
        
        
        $branches = auth()->user()->branches->pluck('name', 'id')->toArray();
        
        $admins = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $admins = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            /*+->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })*/->whereIn('current_branch' , $request->get('branches'))->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $admins = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($branches) {
                                $query->whereIn('id', array_keys($branches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id')->toArray();
        $courses = [];
        $stageLevels = [];
        $timeframes = [];
        $rounds = [];
        $subRounds = [];
        
        
       
        $makeup_session_query = GroupSessionAttendance::join('groups','groups.id','=','group_session_attendances.group_id')
                                                    ->join('leads','leads.id','=','group_session_attendances.lead_id')
                                                    ->select('leads.f_name','leads.m_name','leads.l_name','leads.mobile_1','leads.branch_id'
                                                    ,'groups.id','groups.track_id','groups.course_id','groups.level_id','group_session_attendances.lead_id',
                                                    DB::raw('COUNT(IF(group_session_attendances.attendance = 0,1,NULL)) as absent_count' ));
                                        
       if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
        $makeup_session_query->where(function ($query) use ($request){
                $query->where('leads.name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.mobile_1', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.email', 'like', '%' . $request->get('search') . '%');
            });
        }
        
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $makeup_session_query->whereIn('leads.branch_id',$request->get('branches'));
        }
        if($request->has('admin_id') && $request->get('admin_id') != null && $request->get('admin_id') != ''){
            $makeup_session_query->where('leads.assigned_employee_id',$request->get('admin_id'));
        }
        
        if($request->has('track_id') && $request->get('track_id') != null && $request->get('track_id') != ''){
            $courses = Track::where('status',1)->where('parent_id',$request->get('track_id'))->pluck('title','id');
            $makeup_session_query->where('groups.track_id',$request->get('track_id'));
        }
        if($request->has('course_id') && $request->get('course_id') != null && $request->get('course_id') != ''){
            $stageLevels = Track::find($request->get('course_id'))->stageLevels->pluck('name', 'id')->toArray();
            $timeframe_ids = DB::table('timeframe_courses')->where('course_id',$request->get('course_id'))->pluck('timeframe_id')->toArray();
            $timeframes = Timeframe::whereIn('id',$timeframe_ids)->where('status',1)->pluck('title','id')->toArray();
            $makeup_session_query->where('groups.course_id',$request->get('course_id'));
        }
        if($request->has('level_id') && $request->get('level_id') != null && $request->get('level_id') != ''){
            $makeup_session_query->where('groups.level_id',$request->get('level_id'));
        }
        if($request->has('round_id') && $request->get('round_id') != null && $request->get('round_id') != ''){
            $makeup_session_query->where('groups.round_id',$request->get('round_id'));
            $round = Round::with('timeframe.intervals')->find($request->get('round_id'));
        }
        if($request->has('timeframe_id') && $request->get('timeframe_id') != null && $request->get('timeframe_id') != ''){
            $rounds = Round::where('timeframe_id',$request->get('timeframe_id'))->pluck('title', 'id')->toArray();
            $makeup_session_query->where('groups.timeframe_id',$request->get('timeframe_id'));
        }
        if($request->has('sub_round_id') && $request->get('sub_round_id') != null && $request->get('sub_round_id') != ''){
            $makeup_session_query->where('groups.sub_round_id',$request->get('sub_round_id'));
        }else{
            //  $Running= subRound::where('end_date','<',date('Y-m-d'))->pluck('id');
             $Running= subRound::where('start_date','<=',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'))->pluck('id');
                
            $makeup_session_query->whereIn('groups.sub_round_id',$Running);     
            
            
        }
     
        $makeup_session_query = $makeup_session_query->groupBy('group_session_attendances.lead_id')->having('absent_count','>=', 1);                                         
        $total_makeupsessions =  $makeup_session_query->count();                                           
        $makeup_sessions = $makeup_session_query->paginate(10);                                           
        
        return view('operations_reports.makeupsessionsReport',compact('branches','admins','tracks','courses','stageLevels','makeup_sessions','total_makeupsessions','timeframes','rounds','subRounds')); 
                                                    
    }
    
    public function activationReport(Request $request)
    {
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        $branches = auth()->user()->branches->pluck('name', 'id')->toArray();
        
        $admins = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $admins = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            /*+->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })*/->whereIn('current_branch' , $request->get('branches'))->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $admins = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($branches) {
                                $query->whereIn('id', array_keys($branches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id')->toArray();
        $courses = [];
        $stageLevels = [];
        
        $customerTracksQuery = CustomerTrack::join('leads','customer_tracks.lead_id','=','leads.id')->where('total','>',0)->whereRaw('(total - used) <= 1');
        
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $customerTracksQuery->where(function ($query) use ($request){
                $query->where('leads.name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.mobile_1', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.email', 'like', '%' . $request->get('search') . '%');
            });
        }
        
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $customerTracksQuery->whereIn('leads.branch_id',$request->get('branches'));
        }
        if($request->has('admin_id') && $request->get('admin_id') != null && $request->get('admin_id') != ''){
            $customerTracksQuery->where('leads.assigned_employee_id',$request->get('admin_id'));
        }
        
        if($request->has('track_id') && $request->get('track_id') != null && $request->get('track_id') != ''){
            $courses = Track::where('status',1)->where('parent_id',$request->get('track_id'))->pluck('title','id');
            $customerTracksQuery->where('customer_tracks.track_id',$request->get('track_id'));
        }
        if($request->has('course_id') && $request->get('course_id') != null && $request->get('course_id') != ''){
            $stageLevels = Track::find($request->get('course_id'))->stageLevels->pluck('name', 'id')->toArray();
            
            $customerTracksQuery->where('customer_tracks.course_id',$request->get('course_id'));
        }
        if($request->has('level_id') && $request->get('level_id') != null && $request->get('level_id') != ''){
            $customerTracksQuery->where('customer_tracks.level_id',$request->get('level_id'));
        }
        $total_activation = $customerTracksQuery->count();
       
        $customer_tracks = $customerTracksQuery->select('customer_tracks.*')->with('lead','track','course','level')->orderBy('customer_tracks.lead_id','desc')->paginate($per_page);
        // return $customer_tracks->groups;
        return view('operations_reports.activationReport',compact('branches','total_activation','admins','tracks','courses','stageLevels','customer_tracks'));
    }
    
    public function fillingRatioReport(Request $request)
    {
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        $timeframes = Timeframe::pluck('title','id');
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $instructors = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $instructors = Employee::where('account_Type', 'ESL Account Profile')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $instructors = Employee::where('account_Type', 'ESL Account Profile')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        
        $admins = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $admins = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $admins = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $groupsQuery = Group::whereIn('branch_id',$request->get('branches'));
        }else{
            $groupsQuery = Group::whereIn('branch_id',array_keys($employeeBranches));
        }
        //dd($groupsQuery->get());
        
        if($request->has('timeframe_id') && $request->get('timeframe_id') != '' && $request->get('timeframe_id') != null){
            $groupsQuery = $groupsQuery->where('timeframe_id',$request->get('timeframe_id'));
        }
        
        if($request->has('admin_id') && $request->get('admin_id') != '' && $request->get('admin_id') != null){
            $groupsQuery->where('admin_id',$request->get('admin_id'));
        }
        
        if($request->has('instructor_id') && $request->get('instructor_id') != '' && $request->get('instructor_id') != null){
            $groupsQuery->where('instructor_id',$request->get('instructor_id'));
        }
        
        if($request->has('status') && $request->get('status') != '' && $request->get('status') != null && $request->get('status') != 'running'){
            if($request->get('status') == 'complete'){
                $groupsQuery->whereHas('subRound',function($query){
                    $query->where('end_date','<',date('Y-m-d'));
                })->has('students');
            } 
            if($request->get('status') == 'upcoming'){
                $groupsQuery->whereHas('subRound',function($query){
                    $query->where('start_date','>=',date('Y-m-d'));
                })->has('students');
            }
        }else{
            $groupsQuery->whereHas('subRound',function($query){
                $query->where('start_date','<',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
            });
        }
        
        
        $groups = $groupsQuery->select('id','code','timeframe_id','branch_id','room_id','instructor_id','admin_id','discipline_id','sub_round_id')->with('timeframe','branch','room','instructor','admin','discipline','subRound')->withCount('students')->get();
        
        //dd($groups);
        return view('operations_reports.fillingRatioReport',compact('employeeBranches','instructors','admins','timeframes','groups'));
    }
    
    public function roundFeedBackReport(Request $request)
{
    $timeframes = Timeframe::where('status', 1)->get();
    $employeeBranches = auth()->user()->branches->toArray();

    $round = [];
    $loop_timeframes = $timeframes;
    if ($request->timeframe_id != null && $request->timeframe_id != '') {
        $loop_timeframes = $timeframes->where('id', $request->timeframe_id)->values();
        $round = Round::where('timeframe_id', $request->get('timeframe_id'))->pluck('title', 'id')->toArray();
    }
    
    $subRounds = [];
    $timeframeid = $request->timeframe_id;
    $roundid = $request->round_id;
    $subroundid = $request->sub_round_id;

    if ($request->has('round_id') && $request->get('round_id') != null && $request->get('round_id') != '') {
        $subRounds = SubRound::where('round_id', $request->get('round_id'))
                             ->orderBy('start_date')
                             ->pluck('start_date', 'id');
    }

    foreach ($employeeBranches as $key => $branch) {
        // Fetch the Branch instance
        $branchInstance = Branch::find($branch['id']);
        
        if ($branchInstance) {
            $instructors = Employee::where('account_Type', 'ESL Account Profile')
                                    ->where('status', 1)
                                    ->whereHas('branches', function ($query) use ($branch) {
                                        $query->where('id', $branch['id']);
                                    })
                                    ->get();

            if ($instructors->count() > 0) {
                // Initialize data
                $employeeBranches[$key]['timeframes'] = [];
                $employeeBranches[$key]['total_reserved'] = 0;
                $employeeBranches[$key]['total_attended'] = 0;
                $employeeBranches[$key]['total_missing'] = 0;

                foreach ($loop_timeframes as $timeframe) {
                    // Call the methods on the instance
                    $array = $branchInstance->getReservedByTimeframe($branch['id'], $instructors->pluck('id')->toArray(), $timeframe, $roundid, $subroundid);
                    $attend_by_timeframe = $branchInstance->getAbsentCustomersByTimeframe($branch['id'], $instructors->pluck('id')->toArray(), $timeframe, $roundid, $subroundid);

                    $employeeBranches[$key]['timeframes'][$timeframe->id] = [
                        'reserved_customers' => $array['groups_students_count'],
                        'groups_ids' => $array['groups_ids'],
                        'missing_customers' => isset($attend_by_timeframe['absent_by_timeframe']) ? $attend_by_timeframe['absent_by_timeframe'] : 0,
                        'attend_students_ids' => isset($attend_by_timeframe['attend_students_ids']) ? $attend_by_timeframe['attend_students_ids'] : 0,
                        'absent_students_ids' => isset($attend_by_timeframe['absent_students_ids']) ? $attend_by_timeframe['absent_students_ids'] : 0,
                        'attended_customers' => $array['groups_students_count'] - (isset($attend_by_timeframe['absent_by_timeframe']) ? $attend_by_timeframe['absent_by_timeframe'] : 0)
                    ];

                    // Accumulate totals
                    $employeeBranches[$key]['total_reserved'] += $employeeBranches[$key]['timeframes'][$timeframe->id]['reserved_customers'];
                    $employeeBranches[$key]['total_attended'] += $employeeBranches[$key]['timeframes'][$timeframe->id]['attended_customers'];
                    $employeeBranches[$key]['total_missing'] += $employeeBranches[$key]['timeframes'][$timeframe->id]['missing_customers'];
                }
            } else {
                unset($employeeBranches[$key]);
            }
        }
    }

    return view('operations_reports.roundFeedBackReport', compact('timeframes', 'timeframeid', 'employeeBranches', 'loop_timeframes', 'round', 'subRounds', 'roundid', 'subroundid'));
}


    public function getround(Request $request)
    {
        $round=[];
        $round = Round::where('timeframe_id',$request->timeframe_id)->select('title', 'id')->get()->toArray();
        
        // $round = Round::find($request->round_id);
       return response()->json($round);
    }
    public function getsubround(Request $request){
        $round=[];
        
        $round = Round::find($request->round_id);
        $subround=[];
        $subround=SubRound::where('round_id',$round->id)->select('id','start_date')->get();
        return $subround ;

    }
}

