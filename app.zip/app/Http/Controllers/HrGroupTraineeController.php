<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\HrGroups;
use App\Models\HrGroupTrainee;
use App\Models\JobApplication;
use Flash;


class HrGroupTraineeController extends Controller
{
    public function show( $id){
         
         $groups = HrGroups::with('hr_group_trainee')->find($id);
         return view('hr_group_trainee.index',compact('groups'));
    }
    public function edit( $id,Request $request){
         $group_trainee = HrGroupTrainee::find($id);
        
        return view('hr_group_trainee.edit',compact('group_trainee'));
    }
    public function update($id,Request $request){
        $group_trainee = HrGroupTrainee::find($id);
        $job_app = JobApplication::find($group_trainee->job_application_id);
        $group_trainee->score = $request->score;
        $group_trainee->save();
        if($group_trainee->score >= 60)
        {
            $job_app->status = 3;
            $job_app->save();
        }
         Flash::success(' Score Updated successfully.');
        
         return redirect( route('admin.HrGroupTrainee.show',  [$group_trainee->hr_group_id]) );
         
    }
}
