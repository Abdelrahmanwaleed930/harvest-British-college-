<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Laravel\Socialite\Facades\Socialite;
use App\Models\Lead;
use App\Models\Branch;
use App\Models\SMS;
use Carbon\Carbon;
use App\Models\MessageLog;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Str;
use Auth;
use Flash;

class AuthCustomerController extends Controller
{
    // public function login()
    // {
    //     if(Auth::guard('customer')->check() ){
            
    //         return redirect(route('customer.home'));
            
    //     }else{
    //         return view('auth.customer_login');
    //     }
        
    // }
    
    public function mobile_verify()
    {
        if(session()->has('mobile_verify') && session()->get('mobile_verify') != null && session()->get('mobile_verify') != ''){
            $mobile = session()->get('mobile_verify');
            $check_lead = Lead::where('mobile_1',$mobile)->first();
            $mazadTime = null;
            if($check_lead != null && $check_lead->last_resent_time != null && $check_lead->last_resent_time != ''){
                $date = date_format(date_create($check_lead->last_resent_time),'F j, Y, H:i:s');
                $dt = Carbon::parse($date);
                $mazadTime = $dt;
            }
            return view('auth.customer_mobile_verify',compact('mobile','mazadTime','check_lead'));
        }else{
            return redirect()->route('customer.login');
        }
    }
    
    public function resend_mobile_verify(Request $request)
    {
        $credentials = $request->validate([
            'mobile_1' => 'required|digits_between:8,15',
        ]);
        
        $check_lead = Lead::where('mobile_1',$request->mobile_1)->first();
        if($check_lead){
            $check_lead->last_resent_time = date('Y-m-d H:i:s');
            $check_lead->save();
            
            $sms = new SMS;
            $mobiles = [$check_lead->id => $check_lead->mobile_1];
            $msg = 'reset password code '.$check_lead->reset_code;
            $sms->send($mobiles, $msg);
            //dd($check_lead);
            $log = MessageLog::create([
                'type' => 1,
                'content' => $msg,
            ]);
            $log->leads()->sync(array_keys($mobiles));
            Flash::message('Sent Successfully.');
            
            return redirect()->back();
        }
    }
    
    public function post_mobile_verify(Request $request)
    {
        $credentials = $request->validate([
            'mobile_1' => 'required|digits_between:8,15',
            'code' => 'required|digits:5',
        ]);
        
        $check_lead = Lead::where('mobile_1',$request->mobile_1)->first();
        if($check_lead){
            if($check_lead->reset_code == $request->code){
                session(['is_verify' => true]);
                return redirect()->route('customer.new_password');
            }else{
                return redirect()->back()->withErrors(['code' => 'code not fount']);
            }
        }else{
            return redirect()->route('customer.login');
        }
    }
    
    public function new_password()
    {
        if(session()->has('mobile_verify') && session()->get('mobile_verify') != null &&
           session()->get('mobile_verify') != '' && session()->has('is_verify') && session()->get('is_verify') == true){
               
            $mobile = session()->get('mobile_verify');
            $check_lead = Lead::where('mobile_1',$mobile)->first();
            if($check_lead){
                return view('auth.customer_new_password',compact('mobile'));
            }else{
                return redirect()->route('customer.login');
            }
        }else{
            return redirect()->route('customer.login');
        }
        return view('auth.customer_new_password');
    }
    
    public function post_new_password(Request $request)
    {
        $credentials = $request->validate([
            'mobile_1' => 'required|digits_between:8,15',
            'password' => 'required|min:8|confirmed',
        ]);
        
        $check_lead = Lead::where('mobile_1',$request->mobile_1)->first();
        if($check_lead){
            //dd(Hash::make($request->password),$request->password);
            $lead = Lead::find($check_lead->id);
            $lead->update([
                'password' => $request->password,
            ]);
            
            Flash::message('reset password success');
        }
        return redirect()->route('customer.login');
    }
    
    public function forget_password()
    {
        return view('auth.customer_forget_password');
    }
    
    public function post_forget_password(Request $request)
    {
        $credentials = $request->validate([
            'mobile_1' => 'required|digits_between:8,15',
        ]);
        
        $check_lead = Lead::where('mobile_1',$request->mobile_1)->first();
        if($check_lead){
            session(['mobile_verify' => $check_lead->mobile_1]);
            $check_lead->reset_code = rand(11111,99999);
            $check_lead->last_resent_time = date('Y-m-d H:i:s');
            $check_lead->save();
            
            $sms = new SMS;
            $mobiles = [$check_lead->id => $check_lead->mobile_1];
            $msg = 'reset password code '.$check_lead->reset_code;
            $sms->send($mobiles, $msg);
            
            $log = MessageLog::create([
                'type' => 1,
                'content' => $msg,
            ]);
            $log->leads()->sync(array_keys($mobiles));
            
            Flash::message('Sent Successfully.');
            
            return redirect()->route('customer.mobile_verify');
        }else{
            return redirect()->back()->withErrors(['mobile_1' => 'mobile number not fount']);
        }
    }
    
    // public function register()
    // {
    //     $branches = Branch::select('id','name')->where('status',1)->get();
    //     return view('auth.customer_register',compact('branches'));
    // }

    // public function postRegister(Request $request)
    // {
    //     $credentials = $request->validate([
    //         'f_name' => 'required|string|max:50',
    //         'l_name' => 'required|string|max:50',
    //         'email' => 'required|string|email',
    //         'gender' => 'required|string',
    //         'branch_id' => 'required',
    //         'mobile_1' => 'required|digits_between:8,15|unique:leads',
    //         'password' => 'required|string|min:8',
    //         'g-recaptcha-response' => 'required|captcha',
    //     ]);

    //     $user = Lead::Create([
    //         'f_name' => $request->f_name,
    //         'l_name' => $request->l_name,
    //         'name' => ['en' => $request->f_name, 'ar' => $request->f_name],
    //         'gender' => $request->gender,
    //         'mobile_1' => $request->mobile_1,
    //         'email' => $request->email,
    //         'lead_source_id' => 1,
    //         'branch_id' => $request->branch_id,
    //         'password' => $request->password,
    //         'register_from' => 'register_form',
    //     ]);
    //     Auth::guard('customer')->login($user);

    //     return redirect('customerPortal/placement_test');
    // }

    public function redirectToProvider($provider)
    {
        if($provider == 'facebook'){
            return Socialite::driver($provider)->redirect();
        }else{
            return Socialite::driver($provider)->setScopes(['openid', 'email'])->redirect();
        }
    }

    public function handleProviderCallback($provider)
    {
        $userSocial = Socialite::driver($provider)->stateless()->user();
        $password = 'Harvest@123';
        
        $findUser=Lead::where('email',$userSocial->email)->first();

        if($findUser){
            Auth::guard('customer')->login($findUser);
            //Auth::loginUsingId($findUser->id);
        }else{
            $user_name = ($userSocial->name)?$userSocial->name:'under modification';
            $user = Lead::Create([
                'name' => ['en' => $user_name, 'ar' => $user_name],
                //'gender' => $data['gender'],
                //'mobile_1' => $data['mobile'],
                'email' => $userSocial->email,
                'lead_source_id' => 1,
                //'branch_id' => $data['branch_id'],
                'password' => $password,
                'register_from' => $provider,
            ]);
            Auth::guard('customer')->login($user);
            //Auth::loginUsingId($user->id);
        }
        return redirect(route('customer.home'));
        //dd($userSocial);
    }


    // public function postLogin(Request $request)
    // {
    //     $credentials = $request->validate([
    //         'mobile_1' => 'required|digits_between:8,15',
    //         'password' => 'required',
    //     ]);

    //     $user = Lead::where('mobile_1' ,$request->mobile_1 )->first();
        
        
    //     // dd($user);

        
    //     if (auth('customer')->attempt($credentials)) {
    //         if($user->type == 1)
    //         {
                
    //              if($user->pt_level != null || $user->pt_level === 0 )
    //             {
    //                 return redirect('customerPortal/placement_test_result');   
    //             }
    //             else if($user->pt_level == null  ){
    //                 return redirect('customerPortal/placement_test');    
                    
    //             } 

    //         }
    //         if($user->type == 2 )
    //         {

    //             return redirect('/customerPortal/courses');    
    //         }
    //         else{
    //             return redirect(route('customer.home'));
    //         }
    //     }
        
    //     //dd('ddd');
        
    //     if(auth('customer')->attempt(['email' => $request->mobile_1,'password' => $request->password])){
    //         //dd('ddd');
    //         // return redirect(route('customer.home'));
    //         if($user->type == 1)
    //         {
    //             if($user->pt_level == null)
    //             {
    //                 return redirect('customerPortal/placement_test');    
    //             }
    //             else{
    //                 return redirect('customerPortal/placement_test_result');   
                    
    //             }

    //             // return redirect('customerPortal/placement_test');    
    //         }
    //         if($user->type == 2 )
    //         {

    //             return redirect('/customerPortal/courses');    
    //         }
            
    //         else{
    //             return redirect(route('customer.home'));
    //         }
    //     }
    //     Flash::error(__('auth.failed'));
    //     return back();
    // }

    public function logout()
    {
        auth('customer')->logout();

        return redirect('/');
    }
}
