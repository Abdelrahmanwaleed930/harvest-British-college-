<?php

namespace App\Http\Livewire\CustomerPortal;

use Livewire\Component;
use App\Models\ExtraItem;
use App\Models\GroupStudent;

class Courses extends Component
{
    public $customer, $active = 'running';

    public function mount()
    {
        $this->customer = auth()->user();
    }

    public function render()
    {
        $groupsrunning = $this->customer->groups()->status('running')->get();
        
        $groupscomplete = $this->customer->groups()->status('complete')->get();
        
        $groupsupcomming = $this->customer->groups()->status('upcoming')->get();
        
        
        $harvest_certificate = ExtraItem::find(2);
        $cambridge_certificate = ExtraItem::find(3);
        //dd($groupsrunning[0]->pivot,$groupsrunning[0]->level);
        
        return view('livewire.customer-portal.courses', compact('groupsrunning','groupscomplete','groupsupcomming','harvest_certificate','cambridge_certificate'));
    }
}
