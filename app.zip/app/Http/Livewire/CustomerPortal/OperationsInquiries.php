<?php

namespace App\Http\Livewire\CustomerPortal;

use Livewire\Component;
use App\Models\LeadCase;
use App\Models\LeadLastCase;
use App\Models\LabelType;
use Laracasts\Flash\Flash;
use Livewire\WithFileUploads;
use Auth;
use File;

class OperationsInquiries extends Component
{
    use WithFileUploads;
    
    public $customer,$active = 'open',$label_type_id,$customer_notes,$labelTypes,$image;

    public function mount()
    {
        $this->customer = Auth::guard('customer')->user();
        $this->labelTypes = LabelType::where('status', 1)->where('category', 4)->pluck('name', 'id');
    }
    
    public function openModal()
    {
        $this->dispatchBrowserEvent('openFormModal');
    }
    
    public function closeModal()
    {
        $this->dispatchBrowserEvent('closeFormModal');
    }
    
    protected function rules()
    {
        $rules = [
            'label_type_id' => 'required',
            'customer_notes' => 'nullable',
            'image' => 'image|nullable',
        ];

        return $rules;
    }

    public function saveInquiry()
    {
        //dd($this->label_type_id,$this->customer_notes);
        $data = $this->validate();
        
        $data['lead_id'] = $this->customer->id;
        //$data['employee_id'] = $this->customer->assigned_employee_id;
        $data['branch_id'] = $this->customer->branch_id;
        $data['label_type_id'] = $this->label_type_id;
        $data['customer_notes'] = $this->customer_notes;
        $data['type'] = 4;
        $data['status'] = 0;
        $data['follow_up_type'] = 3;
        $data['serial'] = time();
        
        if($this->image){
            $file = $this->image;
            
            $file_name = rand(11111,99999).'-'.$file->getClientOriginalName();
            $file->storeAs('/uploads/lead_cases', $file_name);
            $data['image'] = $file_name;
            
            File::move(storage_path('app/uploads/lead_cases/'.$file_name), '/home/harvestc/public_html/uploads/lead_cases/'.$file_name);
            
        }
        //dd($data);
        $leadCase = LeadCase::create($data);
        
        $lastcase = $this->customer->lastcase;
        if($lastcase){
            $lastcase->update($data);
        }else{
            $lastcase = LeadLastCase::create($data);
        }
        
        Flash::success('Inquiry saved successfully.');
        
        $this->dispatchBrowserEvent('closeFormModal');
    }
    
    public function render()
    {
        if($this->active == 'open'){
            $inquiries = LeadCase::where('lead_id',$this->customer->id)->where('type',4)->where('status',0)->orderBy('id','desc')->get();
        }else{
            $inquiries = LeadCase::where('lead_id',$this->customer->id)->where('type',4)->where('status',1)->orderBy('id','desc')->get();
        }
        //dd($groups[0]->pivot);
        return view('livewire.customer-portal.operations-inquiries', compact('inquiries'));
    }
}
