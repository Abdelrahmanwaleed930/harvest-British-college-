<?php

namespace App\Http\Livewire\KidsPlacementTest;

use App\Models\SMS;
use App\Models\Lead;
use Livewire\Component;
use App\Models\MessageLog;

class Thanks extends Component
{
    
    public $ptApplicant;
    
    public function mount($applicant)
    {
        // $sms = new SMS;
        // $mobile = $applicant->mobile;
        // $msg = "Thank you for completing your placement test. We will contact you in the following hours to manage the oral test for you.";
        // $sms->send($mobile, $msg);

        // $lead = Lead::where('mobile_1', $mobile)->first();

        // $log = MessageLog::create([
        //     'type' => 1,
        //     'content' => $msg
        // ]);
        // $log->leads()->sync(array_keys($lead->id));
        $this->ptApplicant = $applicant;
        return redirect(route('customer.ptKidsResult'));
    }

    public function render()
    {
        return view('livewire.kids-placement-test.thanks');
    }
}
