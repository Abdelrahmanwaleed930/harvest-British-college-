<?php

namespace App\Http\Livewire\PlacementTest;

use App\Models\PlacementAnswer;
use App\Models\PlacementQuestion;
use Livewire\Component;

class Reading extends Component
{
    public $applicant,$limit = 10, $questions, $answers = [],$shown_ques,$show_next_msg = false;

    private $paragraphLimit = 2, $point = 1;

    public function mount($applicant)
    {
        //dd('ddd');
        $this->applicant = $applicant;

        $paragraphs = PlacementQuestion::where('skill', 'Reading')->whereNull('parent_id')
            ->with('children.answers')
            ->limit($this->paragraphLimit)->inRandomOrder()->get()->map(function ($para) {
                $para->setRelation('children', $para->children->take(5));
                return $para;
            });
        $questions = collect();
        foreach($paragraphs as $paragraph){
            foreach($paragraph->children as $question){
                $questions->push($question);
            }
        }
        $this->questions = $questions;
        //dd($this->questions);
        $this->shown_ques = $questions[0]->id;
        //$this->paragraphs = $paragraphs;
    }
    
    public function previosBtn($key)
    {
        $this->shown_ques = $this->questions[($key - 1)]['id'];
        $this->show_next_msg = false;
    }
    
    public function updatedAnswers()
    {
        $key = count(array_keys($this->answers));
        if($key < count($this->questions)){
            $this->shown_ques = $this->questions[$key]['id'];
        }
        $this->show_next_msg = false;
    }
    
    public function nextBtn($key)
    {
        if(array_key_exists($this->questions[$key]['id'],$this->answers)){
            $this->shown_ques = $this->questions[($key + 1)]['id'];
        }else{
            $this->show_next_msg = true;
        }
    }
    
    protected function rules()
    {
        return [
            'answers' => 'array|size:' . $this->limit
        ];
    }

    protected $messages = [
        'array' => 'يجب إجابة كل الاسئلة',
        'size' => 'يجب إجابة كل الاسئلة',
    ];

    public function save()
    {
        //$this->validate();
        if(count($this->answers) == $this->limit){
            $correctCount = PlacementAnswer::whereIn('id', array_values($this->answers))->sum('is_correct', 1);
    
            $score = $correctCount * $this->point;
    
            $this->applicant->update(['reading_score' => $score,'step' => 5]);
    
            $this->emitUp('next');
        }else{
            $this->show_next_msg = true;
        }
    }

    public function render()
    {
        return view('livewire.placement-test.reading');
    }
}
