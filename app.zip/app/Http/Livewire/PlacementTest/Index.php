<?php

namespace App\Http\Livewire\PlacementTest;

use App\Models\Branch;
use Livewire\Component;
use Auth;
use App\Models\PlacementApplicant;

class Index extends Component
{
    public $applicant, $branchId, $type = 1,$timer = 3600,$hours,$minutes;

    protected $listeners = ['registered', 'next'];

    public function mount($branchId)
    {
        //dd($this->type);
        if(Auth::guard('customer')->check()){
            $user = Auth::guard('customer')->user();
            if($user->mobile_1 != null && $user->mobile_1 != '' && $user->branch_id != null && $user->branch_id != ''){
                $branch = Branch::findOrFail($branchId);
                $this->branchId = $branch->id;
                //$this->type = 2;
                $do_new_test = 0;
                $check_pt = PlacementApplicant::where('mobile',$user->mobile_1)->first();
                if($check_pt != null && $check_pt != ''){
                    if($check_pt->finish == 0){
                        $do_new_test = 1;
                    }
                }else{
                    $do_new_test = 1;
                }
                //dd($do_new_test);
                if($do_new_test){
                    $applicant = PlacementApplicant::updateOrCreate([
                        'mobile' => $user->mobile_1
                    ], [
                        'name' => $user->getName(),
                        'email' => $user->email,
                        'mobile' => $user->mobile_1,
                        'branch_id' => $user->branch_id,
                        'gender' => $user->gender,
                    ]);
                    $this->applicant = $applicant;
    
                    session()->remove('redirectToPlacementTest');
                    session()->remove('contactBranchId');
                    
                    $this->hours = (int)($this->timer / 60);
                    $this->minutes = (int)($this->timer - ($this->hours * 60));
                }else{
                    return redirect()->route('customer.ptResult');
                }
            
            }else{
                session(['redirectToPlacementTest' => true]);
                session(['contactBranchId' => $branchId]);
                return redirect(route('customer.home'));
            }
        }else{
            session(['redirectToPlacementTest' => true]);
            session(['contactBranchId' => $branchId]);
            return redirect(route('customer.login'));
        }
        
    }
    
    public function countDownTimer()
    {
        if($this->timer > 0){
            $this->timer -= 1;
            $this->hours = (int)($this->timer / 60);
            $this->minutes = (int)($this->timer - ($this->hours * 60));
        }
    }

    public function registered()
    {
        //$this->applicant = PlacementApplicant::find($id);
        $this->next();
    }

    public function next()
    {
        //$this->type = 5;
        $this->type += 1;
    }

    public function render()
    {
        return view('livewire.placement-test.index')->layout('layouts.customer_app');
    }
}
