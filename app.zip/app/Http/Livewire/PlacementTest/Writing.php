<?php

namespace App\Http\Livewire\PlacementTest;

use App\Models\ApplicantAnswer;
use App\Models\PlacementAnswer;
use App\Models\PlacementQuestion;
use Livewire\Component;

class Writing extends Component
{
    public $applicant,$limit = 2, $questions, $answers = [],$shown_ques;

    public function mount($applicant)
    {
        $this->applicant = $applicant;

        $questions = PlacementQuestion::where('skill', 'Writing')->whereNull('parent_id')
            ->with('children')
            ->limit($this->limit)->inRandomOrder()->get();
        $this->questions = $questions;
        $this->shown_ques = $questions[0]->id;
    }
    
    public function previosBtn($key)
    {
        $this->shown_ques = $this->questions[($key - 1)]['id'];
    }
    
    public function nextBtn($key)
    {
        if(array_key_exists($this->questions[$key]['id'],$this->answers)){
            $this->shown_ques = $this->questions[($key + 1)]['id'];
        }else{
            
        }
    }
    
    protected function rules()
    {
        return [
            'answers' => 'array|size:' . $this->limit,
            'answers.*' => 'array',
            'answers.*.*' => 'string|min:10'
        ];
    }

    protected $messages = [
        'array' => 'يجب إجابة كل الاسئلة',
        'size' => 'يجب إجابة كل الاسئلة',
        'answers.*.*.min' => 'الاجابة يجب ان تكون اكثر من 10 حرف',
    ];

    public function save()
    {
        //$this->validate();
        
        if($this->answers != null && count($this->answers) > 0){
            ApplicantAnswer::where('placement_applicant_id',$this->applicant->id)->delete();
            
            foreach ($this->answers as $key => $answers) {
                ApplicantAnswer::create([
                    'placement_applicant_id' => $this->applicant->id,
                    'placement_question_id' => $key,
                    'type' => 'text',
                    'answer' => implode('<br/>',$answers)
                ]);
            }
            
            $this->applicant->update(['finish' => 1,'finish_date' => date('Y-m-d')]);
        }
        //dd($this->answers);
        //$this->emitUp('next');
        return redirect(route('customer.ptResult'));
    }

    public function render()
    {
        return view('livewire.placement-test.writing');
    }
}
