<?php

namespace App\Http\Livewire\LeadCases;

use App\Models\Lead;
use App\Models\Label;
use App\Models\Action;
use App\Models\Branch;
use Livewire\Component;
use App\Models\Feedback;
use App\Models\LeadLastCase;
use App\Models\LeadCase;
use App\Models\LabelType;
use Illuminate\Http\Request;
use Laracasts\Flash\Flash;
use App\Models\SMS;
use App\Models\WhatsApp;
use App\Models\MessageLog;
use Auth;


class Form extends Component
{
    public $lead,
        $leadCase,
        $lead_id,
        $student_id,
        $branch_id,
        $employee_id,
        $label_id,
        $label_type_id,
        $follow_up_type,
        $type,
        $serial,
        $call_type,
        $feedback_id,
        $feedback_date,
        $action_id,
        $notes,
        $status,
        $date,
        $leads,
        //$branches,
        //$labels,
        $labelType = null,
        $labelTypes = [],
        $feedbacks = [],
        $actions = [],
        $oldUpdate = null;

    public function mount(Request $request, $lead, $leadCase = null)
    {
        if ($leadCase) {
            $this->fill([
                'lead_id' => $leadCase->lead_id,
                'branch_id' => $leadCase->branch_id,
                'employee_id' => $leadCase->employee_id,
                //'label_id' => $leadCase->label_id,
                'label_type_id' => $leadCase->label_type_id,
                'follow_up_type' => $leadCase->follow_up_type,
                'type' => $leadCase->type,
                'serial' => $leadCase->serial,
                'call_type' => $leadCase->call_type,
                'feedback_id' => $leadCase->feedback_id,
                'feedback_date' => $leadCase->feedback_date,
                'action_id' => $leadCase->action_id,
                'notes' => $leadCase->notes,
                'status' => $leadCase->status,
                'date' => $leadCase->date,
            ]);
            $this->labelType = LabelType::find($leadCase->label_type_id);
            $this->feedbacks = Feedback::where('status', 1)->where('label_type_id', $leadCase->label_type_id)->pluck('name', 'id');
            $this->actions = Action::where('status', 1)->where('label_type_id', $leadCase->label_type_id)->pluck('name', 'id');
        } else {
            $this->fill([
                'lead_id' => $lead->id,
                'type' => $request->get('type'),
                'branch_id' => Auth::user()->branches[0]->id,
            ]);
            //dd(Auth::user()->branches[0]->id,$lead->branch_id);
            
            if($request->filled('student_id')){
                $this->student_id = $request->get('student_id');
            }
            if ($request->filled('old')) {
                $this->oldUpdate = $request->get('old');
            }
        }
        
        $labelTypesQuery = LabelType::where('status', 1)->where('category', $this->type);
        if($this->call_type != null && $this->call_type != '' && $this->call_type == 1){
            $labelTypesQuery->where('name','not like','%back%');
        }
        $this->labelTypes = $labelTypesQuery->pluck('name', 'id');
        //$this->branches = Branch::pluck('name', 'id');
        //$this->labels = Label::where('category', $this->type)->where('status', 1)->pluck('name', 'id');
    }

    protected function rules()
    {
        $rules = [
            'lead_id' => 'nullable',
            'student_id' => 'nullable',
            'branch_id' => 'required',
            //'label_id' => 'required',
            'label_type_id' => 'required',
            'type' => 'required',
            'follow_up_type' => 'required',
            'call_type' => 'nullable',
            'feedback_id' => 'nullable',
            'feedback_date' => 'nullable',
            'action_id' => 'nullable',
            'notes' => 'required',
            'date' => 'nullable',
        ];

        return $rules;
    }

    public function updated($name)
    {
        $this->validateOnly($name);
    }
    /*
    public function updatedLabelId($value)
    {
        $this->labelTypes = LabelType::where('status', 1)->where('label_id', $value)->pluck('name', 'id');
        $this->label_type_id = '';
        $this->feedback_id = '';
        $this->action_id = '';
        $this->feedbacks = [];
        $this->actions = [];
    }
    */
    
    public function updatedCallType($value)
    {
        $labelTypesQuery = LabelType::where('status', 1)->where('category', $this->type);
        if($this->call_type != null && $this->call_type != '' && $this->call_type == 1){
            $labelTypesQuery->where('name','not like','%back%');
        }
        $this->labelTypes = $labelTypesQuery->pluck('name', 'id');
    }
    
    public function updatedLabelTypeId($value)
    {
        $this->labelType = LabelType::find($value);
        $this->feedbacks = Feedback::where('status', 1)->where('label_type_id', $value)->pluck('name', 'id');
        $this->actions = Action::where('status', 1)->where('label_type_id', $value)->pluck('name', 'id');
        $this->feedback_id = '';
        $this->action_id = '';
        //$this->actions = [];
    }
    /*
    public function updatedFeedbackId($value)
    {
        $this->actions = Action::where('status', 1)->where('feedback_id', $value)->pluck('name', 'id');
        $this->action_id = '';
    }
    */
    public function save()
    {
        $data = $this->validate();
        
        if(isset($data['action_id']) && $data['action_id'] != null && $data['action_id'] != ''){
            $action = Action::findOrFail($data['action_id']);
            //dd($action);
            if(strtolower($action->name) == 'open'){
                $data['status'] = 0;
            }
            if(strtolower($action->name) == 'close' || strtolower($action->name) == 'closed'){
                $data['status'] = 1;
            }
        }
        
        if(isset($data['label_type_id']) && $data['label_type_id'] != null && $data['label_type_id'] != ''){
            $label_type = LabelType::findOrFail($data['label_type_id']);
            //dd($action);
            if(strtolower($label_type->name) == 'reserved'){
                $data['status'] = 1;
            }
        }
        //dd($data);
        $leadCase = $this->leadCase;
        if($leadCase){
            $leadCase->update($data);
                        
         activity('Lead Case')
           ->causedBy(Auth::user()->id)
           ->performedOn($leadCase)
           
           ->log('Lead Case Update');

        }else{
            $data['employee_id'] = Auth::user()->id;
            $data['serial'] = time();
            
            $leadCase = LeadCase::create($data);
            activity('Lead Case')
           ->causedBy(Auth::user()->id)
           ->performedOn($leadCase)
           
           ->log('Create Lead Case');


            if($this->oldUpdate) {
                $followup = LeadCase::find($this->oldUpdate);
                $followup->update(['status' => 1]);
            }
            /*
            //whatsup
            if(in_array($leadCase->action_id,[6,38,39,40]) && $this->lead->mobile_1 != null && $this->lead->mobile_1 != ''){
                $whatsApp = new WhatsApp;
                $mobiles = [$this->lead->id => $this->lead->mobile_1];
                $msg = 'test whatsup msg from follow up';
    
                $whatsApp->send($mobiles, $msg);
    
                $log = MessageLog::create([
                    'type' => 2,
                    'content' => $msg,
                    'employee_id' => auth()->id(),
                ]);
                $log->leads()->sync(array_keys($mobiles));
    
                Flash::success('Sent Successfully.');
            }
            //sms
            if(in_array($leadCase->action_id,[44,45,46,47]) && $this->lead->mobile_1 != null && $this->lead->mobile_1 != ''){
                $sms = new SMS;
                $mobiles = [$this->lead->id => $this->lead->mobile_1];
                $msg = 'test sms msg from follow up';
    
                $sms->send($mobiles, $msg);
    
                $log = MessageLog::create([
                    'type' => 1,
                    'content' => $msg,
                    'employee_id' => auth()->id(),
                ]);
                $log->leads()->sync(array_keys($mobiles));
    
                Flash::success('Sent Successfully.');

            }
            */
            $lastcase = $this->lead->lastcase;
            $last_case_date = array_merge(['lead_case_id' => $leadCase->id ],$data);
            if($lastcase){
                $lastcase->update($last_case_date);
            }else{
                $lastcase = LeadLastCase::create($last_case_date);
            }
        }

        Flash::success('LeadCase saved successfully.');
        if(!auth()->user()->can('followup manager')){
            $employeeBranches = auth()->user()->branches->pluck('id')->toArray();
            $leadsId = Lead::where('type',1)->whereIn('branch_id', $employeeBranches)->pluck('id')->toArray();
            
            $next_followup = LeadCase::whereIn('lead_id', $leadsId)
                ->where('status', 0)
                ->where('employee_id', auth()->id())
                ->whereDate('date', '<=', now())
                ->orderBy('id','desc')
                ->first();
            if($next_followup != null){
                $quary = '?lead='.$next_followup->lead_id.'&type=1&old='.$next_followup->id;
                return redirect('leadCases'.$quary);
            }else{
                return redirect('followup');
            }
            
        }else{
            $query = ['lead' => $leadCase->lead_id,'type' => $leadCase->type];
    
            if ($leadCase->student_id) {
                $query['student'] = $leadCase->student_id;
            }
    
            return redirect(route('admin.leadCases.index', $query));
        }
    }

    public function render()
    {
        return view('livewire.lead-cases.form');
    }
}
