<?php

namespace App\Http\Livewire\GroupSessions;

use App\Models\Room;
use Livewire\Component;
use App\Models\Employee;
use App\Models\Interval;
use Laracasts\Flash\Flash;
use App\Models\GroupSession;
use Illuminate\Database\Eloquent\Builder;
use Auth;
use Spatie\Activitylog\Contracts\Activity;


class Edit extends Component
{
    public $groupSession,
        $intervals,
        $instructors,
        $rooms,
        $date,
        $interval_id,
        $instructor_id,
        $room_id,
        $status,
        $zoom_id,
        $zoom_password;

    public function mount($groupSession = null)
    {
        $this->fill([
            'date' => $groupSession->date,
            'interval_id' => $groupSession->interval_id,
            'instructor_id' => $groupSession->instructor_id,
            'room_id' => $groupSession->room_id,
            'status' => $groupSession->status,
            'zoom_id'=>$groupSession->zoom_id,
            'zoom_password'=>$groupSession->zoom_password,
        ]);

        $groupSession->load('group.round.timeframe.intervals');

        $this->intervals = $groupSession->group->round->timeframe->intervals->pluck('name', 'id')->toArray();

        $this->instructors = Employee::whereHas('branches', function (Builder $query) use ($groupSession) {
            $query->where('id', $groupSession->group->branch_id);
        })->get()->pluck('name', 'id')->toArray();

        $this->rooms = Room::where('branch_id', $groupSession->group->branch_id)->pluck('name', 'id');
    }

    protected function rules()
    {
        $rules = [
            'date' => 'required',
            'room_id' => 'required',
            'instructor_id' => 'required',
            'interval_id' => 'required',
            'status' => 'required',
            'zoom_id'=>'required',
            'zoom_password'=>'required',
        ];

        return $rules;
    }

    public function save()
    {
        $data = $this->validate();

        $this->groupSession->update($data);
        
             activity('Group Session')
               ->causedBy(Auth::user()->id)
               ->performedOn($this->groupSession)
         
               ->log('update group session');

        Flash::success('Group Session saved successfully.');

        redirect(route('admin.groupSessions.index', ['group' => $this->groupSession->group_id]));
    }

    public function render()
    {
        return view('livewire.group-sessions.edit');
    }
}
