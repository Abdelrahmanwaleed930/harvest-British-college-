<?php

namespace App\Http\Livewire\Customers;

use App\Models\SMS;
use App\Models\Lead;
use App\Models\Offer;
use Livewire\Component;
use App\Models\Employee;
use App\Models\LeadCase;
use App\Models\WhatsApp;
use App\Models\LabelType;
use App\Models\LeadSource;
use App\Models\MessageLog;
use Laracasts\Flash\Flash;
use App\Models\KnowChannel;
use Livewire\WithPagination;
use App\Models\TrainingService;
use Illuminate\Database\Eloquent\Builder;

class Index extends Component
{
    use WithPagination;

    protected $paginationTheme = 'bootstrap';

    public $leadSources,
        $search,
        $mobile_1,
        $name,
        $case_from,
        $case_to,
        $registration_from,
        $registration_to,
        $knowChannels,
        $services,
        $offers,
        $per_page = 10,
        $selectAll = false,
        $branchesData,
        $employeeBranches,
        $agents,
        $labelTypes,
        $label_type_id,
        $has_followup,
        $show_filter = false,
        $show_assign = false,
        $show_sms = false,
        $shown_leads = [],
        $assign_leads = [],
        $assigned_employee,
        $select_assigned,
        $sms_message,
        $lead_source,
        $know_channel,
        $time,
        $service,
        $offer,
        $branches,
        $agent;

    public function mount()
    {
        $this->leadSources = LeadSource::pluck('name', 'id')->toArray();
        $this->knowChannels = KnowChannel::pluck('name', 'id')->toArray();
        $this->services = TrainingService::pluck('title', 'id')->toArray();
        $this->offers = Offer::pluck('title', 'id')->toArray();
        $this->labelTypes = LabelType::where('status', 1)->where('category', 2)->pluck('name', 'id')->toArray();
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $this->branchesData = $employeeBranches;
        $this->employeeBranches = $employeeBranches;
        $this->agents = Employee::where('account_Type', 'Operations Account')->whereHas('branches', function (Builder $query) use ($employeeBranches) {
            $query->whereIn('id', array_keys($employeeBranches));
        })->get()->pluck('name', 'id')->toArray();
    }

    public function updatedSelectAll()
    {
        if(! $this->selectAll){
            foreach($this->shown_leads as $key => $show_lead){
                unset($this->assign_leads[$show_lead]);
            }
        }else{
            foreach($this->shown_leads as $key => $show_lead){
                $this->assign_leads[$show_lead] = $show_lead;
            }
        }
    }
    
    public function updating($field_name)
    {
        if(!str_starts_with($field_name,'assign_leads') && $field_name != 'selectAll'){
            $this->resetPage();
        }else{
        }
    }

    public function toggleFilter()
    {
        $this->show_filter = !$this->show_filter;
        $this->show_assign = false;
        $this->show_sms = false;
    }

    public function toggleAssign()
    {
        $this->show_assign = !$this->show_assign;
        $this->show_filter = false;
        $this->show_sms = false;
    }

    public function toggleSms()
    {
        $this->show_sms = !$this->show_sms;
        $this->show_filter = false;
        $this->show_assign = false;
    }

    public function selectShownLeads()
    {
        $this->assign_leads = $this->shown_leads;
    }

    public function submitAssign()
    {
        $assignLeads = array_filter($this->assign_leads);
        if (!$this->assigned_employee) {
            Flash::error('Assigned Employee is required.');
        } elseif (count($assignLeads) > 0) {
            Lead::whereIn('id', $assignLeads)->update(['assigned_employee_id' => $this->assigned_employee]);
            LeadCase::whereIn('lead_id', $assignLeads)->where('status', 0)->update(['employee_id' => $this->assigned_employee]);

            Flash::success('Assigned Successfully.');

            $this->show_assign = false;
            $this->assign_leads = [];
            $this->assigned_employee = null;
        } else {
            Flash::error('Selected Employees is required.');
        }
    }

    public function submitSms()
    {
        $assignLeads = array_filter($this->assign_leads);
        if (!$this->sms_message) {
            Flash::error('Message is required.');
        } elseif (count($assignLeads) > 0) {
            $sms = new SMS;

            $mobiles = Lead::whereIn('id', $assignLeads)->pluck('mobile_1', 'id')->toArray();
            $msg = $this->sms_message;

            $sms->send($mobiles, $msg);

            $log = MessageLog::create([
                'type' => 1,
                'content' => $msg,
                'employee_id' => auth()->id()
            ]);
            $log->leads()->sync(array_keys($mobiles));

            Flash::success('Sent Successfully.');

            $this->show_sms = false;
            $this->show_assign = false;
            $this->assign_leads = [];
            $this->sms_message = null;
        } else {
            Flash::error('Selected Employees is required.');
        }
    }

    public function submitWhatsApp()
    {
        $assignLeads = array_filter($this->assign_leads);
        if (!$this->sms_message) {
            Flash::error('Message is required.');
        } elseif (count($assignLeads) > 0) {
            $whatsApp = new WhatsApp;

            $mobiles = Lead::whereIn('id', $assignLeads)->pluck('mobile_1', 'id')->toArray();
            $msg = $this->sms_message;

            $whatsApp->send($mobiles, $msg);

            $log = MessageLog::create([
                'type' => 2,
                'content' => $msg,
                'employee_id' => auth()->id()
            ]);
            $log->leads()->sync(array_keys($mobiles));

            Flash::success('Sent Successfully.');

            $this->show_sms = false;
            $this->show_assign = false;
            $this->assign_leads = [];
            $this->sms_message = null;
        } else {
            Flash::error('Selected Employees is required.');
        }
    }

    public function updatedBranches($val)
    {
        $this->agents = Employee::where('account_Type', 'Operations Account')->whereHas('branches', function (Builder $query) use ($val) {
            $query->whereIn('id', $val);
        })->get()->pluck('name', 'id')->toArray();
    }

    public function render()
    {
        $leadsQuery = Lead::withCount('payments', 'cases')->with(['cases' => function ($query) {
            $query->orderBy('created_at', 'desc')->first();
        }])
        ->whereIn('type', [2, 3]);

        if ($this->search) {
            $leadsQuery->where(function ($query) {
                $query->where('name', 'like', '%' . $this->search . '%')
                    ->orWhere('mobile_1', 'like', '%' . $this->search . '%')
                    ->orWhere('email', 'like', '%' . $this->search . '%');
            });
        } else {
            $leadsQuery->whereIn('branch_id', array_keys($this->employeeBranches));
        }
        if ($this->agent) {
            $leadsQuery->where('assigned_employee_id', $this->agent);
        } elseif (auth()->user()->can('leads leadsAssign')) {
            // show all
        } else {
            $leadsQuery->where('assigned_employee_id', auth()->id());
        }
        if ($this->lead_source) {
            $leadsQuery->where('lead_source_id', $this->lead_source);
        }
        if ($this->know_channel) {
            $leadsQuery->where('know_channel_id', $this->know_channel);
        }
        if ($this->time) {
            $leadsQuery->where('preferred_time', $this->time);
        }
        if ($this->service) {
            $leadsQuery->where('training_service_id', $this->service);
        }
        if ($this->select_assigned === '0') {
            $leadsQuery->whereNull('assigned_employee_id');
        } elseif ($this->select_assigned === '1') {
            $leadsQuery->whereNotNull('assigned_employee_id');
        }
        if ($this->offer) {
            $leadsQuery->where('offer_id', $this->offer);
        }
        if ($this->branches) {
            $leadsQuery->whereIn('branch_id', $this->branches);
        }
        if ($this->label_type_id || ($this->case_from && $this->case_to)) {
            $leadsQuery->whereHas('cases', function (Builder $query) {
                if ($this->case_from && $this->case_to) {
                    $query->whereBetween('date', [$this->case_from, $this->case_to]);
                }
                if ($this->label_type_id) {
                    $query->where('label_type_id', $this->label_type_id);
                }
            });
        }
        if ($this->has_followup === '0') {
            $leadsQuery->doesntHave('cases');
        } elseif ($this->has_followup === '1') {
            $leadsQuery->has('cases');
        }
        if ($this->registration_from && $this->registration_to) {
            $leadsQuery->whereBetween('created_at', [$this->registration_from, $this->registration_to]);
        }

        $leadsCount = $leadsQuery->count();
        $leads = $leadsQuery->latest()->paginate($this->per_page);

        $this->shown_leads = $leads->pluck('id')->toArray();
        
        if(! $this->selectAll){
            $all_checked = array_values($this->assign_leads);
            if(in_array(false,$all_checked)){
                $this->selectAll = false;
            }else{
                if (count(array_intersect_key(array_flip($this->shown_leads), $this->assign_leads)) === count($this->shown_leads)) {
                    $this->selectAll = 1;
                }
            }
        }else{
            
            $all_checked = array_values($this->assign_leads);
            if(in_array(false,$all_checked)){
                $this->selectAll = false;
            }else{
                foreach($this->shown_leads as $key => $show_lead){
                    $this->assign_leads[$show_lead] = $show_lead;
                }
            }
        }

        return view('livewire.customers.index', compact('leads', 'leadsCount'));
    }
}
