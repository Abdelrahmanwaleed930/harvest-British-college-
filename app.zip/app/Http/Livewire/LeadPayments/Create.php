<?php

namespace App\Http\Livewire\LeadPayments;

use App\Models\SMS;
use App\Models\Safe;
use DB;
use Mail;
use Exception;
use App\Models\Offer;
use Livewire\Component;
use App\Models\ExtraItem;
use App\Models\MessageLog;
use App\Models\StageLevel;
use App\Models\SafeOperation;
use App\Models\ServiceFee;
use Laracasts\Flash\Flash;
use App\Models\LeadPayment;
use App\Mail\PaymentInvoice;
use App\Models\GroupSession;
use Illuminate\Http\Request;
use App\Models\CustomerTrack;
use App\Models\PaymentMethod;
use App\Models\LeadCase;
use App\Models\LeadLastCase;
use App\Models\SafeTrancation;
use App\Models\CertificateRequest;
use App\Models\Employee;
use App\Models\Group;
use App\Models\GroupWaitingList;
use App\Models\PlacementApplicant;
use App\Models\GroupSessionAttendance;
use Illuminate\Database\Eloquent\Builder;
use Livewire\WithFileUploads;

class Create extends Component
{
    use WithFileUploads;
    
    public $lead,
        $paymentable_type,
        $paymentable_id,
        $amount,
        $discount,
        $subPayments,
        $convertToCustomer = false,
        $service = null,
        $services = [],
        $paymentMethods,
        $suggested_groups,
        $extraitem_groups,
        $branchesData,
        $employeeBranches,
        $agents,
        $employee_id,
        $group_id,
        $request_group_id;

    public function mount(Request $request, $lead)
    {
        $this->convertToCustomer = ($lead->type == 1)?true:false;
        
        $this->paymentMethods = PaymentMethod::where('status', 1)->where('transfer', 1)->pluck('title', 'id');
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $this->branchesData = $employeeBranches;
        $this->employee_id = auth()->id();
        $this->employeeBranches = $employeeBranches;
        $this->agents = Employee::where('status',1)->where('account_Type', 'Operations Account')->whereHas('branches', function (Builder $query) use ($employeeBranches) {
            $query->whereIn('id', array_keys($employeeBranches));
        })->get()->pluck('name', 'id')->toArray();
    }

    protected function rules()
    {
        $payed = ($this->service && ($this->service->payment_plan_id == 1 || $this->service->payment_plan_id == 3)) ? $this->subPayments[0]['amount'] : $this->amount;
        //dd($this->service);
        $min_amount = ($this->service != null && ($this->service->payment_plan_id == 1 || $this->service->payment_plan_id == 3) && $this->service->installment)?$this->service->installment->deposit:$this->amount;
        $rules = [
            'paymentable_type' => 'required',
            'paymentable_id' => 'required',
            'employee_id' => 'required',
            'amount' => 'required|integer',
            'discount' => 'nullable|integer|max:' . $payed,
            'subPayments' => 'required|array',
            'group_id' => 'nullable',
            'request_group_id'=>'nullable',
        ];
        if($this->service != null && ($this->service->payment_plan_id == 1 || $this->service->payment_plan_id == 3) && $this->service->installment){
            $rules['subPayments.0.amount'] = 'required|integer|min:'.$min_amount.'|max:' . $this->amount;
            $rules['subPayments.0.payment_method_id'] = 'required';
            $rules['subPayments.0.reference_num'] = 'required_unless:subPayments.0.payment_method_id,1';
            $rules['subPayments.0.upload_bill'] = 'required_unless:subPayments.0.payment_method_id,1|image';
        }
        return $rules;
    }

    public function updated($name)
    {
        $this->validateOnly($name);
    }

    public function updatedPaymentableType($value)
    {
        $this->getServices($value);
        $this->paymentable_id = '';
    }

    public function updatedPaymentableId($value)
    {
        $this->getService($value);
    }

    public function getServices($type)
    {
        switch ($type) {
            case 'App\\Models\\ExtraItem':
                //if($this->lead->pt_level){
                $this->services = ExtraItem::pluck('name', 'id');
                /*}else{
                    $this->services = [];
                }*/
                break;

            case 'App\\Models\\Offer':
                $branchesId = auth()->user()->branches->pluck('id')->toArray();
                //dd($branchesId);
                $no_levels_offers = Offer::whereDate('start_date', '<=', now())->whereDate('end_date', '>=', now())
                    ->whereHas('branches', function ($query) use ($branchesId) {
                        $query->whereIn('id', $branchesId);
                    })->where('has_levels',0)->get();
                    
                $offers = $no_levels_offers;
                if ($this->lead->pt_level !== null && $this->lead->pt_level !== '') {
                    $levels_offers = Offer::whereDate('start_date', '<=', now())->whereDate('end_date', '>=', now())
                            ->whereHas('branches', function ($query) use ($branchesId) {
                                $query->whereIn('id', $branchesId);
                            })->where('has_levels',1)->whereHas('services.trainingService.levels', function ($query) {
                                $query->where('value', $this->lead->pt_level);
                            })->get();
                    //dd($levels_offers);
                    $offers = $no_levels_offers->merge($levels_offers);
                }
                /*
                $serviceQuery = Offer::whereDate('start_date', '<=', now())->whereDate('end_date', '>=', now())
                    ->whereHas('branches', function (Builder $query) use ($branchesId) {
                        $query->whereIn('id', $branchesId);
                    });

                if ($this->lead->pt_level) {
                    $serviceQuery->where('has_levels',1)->whereHas('services.trainingService.levels', function (Builder $query) {
                        $query->where('value', $this->lead->pt_level);
                    });
                }else{
                    $serviceQuery->where('has_levels',0);
                }
                */
                $this->services = $offers->pluck('title', 'id');
                break;

            default:
                if($this->lead->pt_level !== '' && $this->lead->pt_level !== null){
                    $serviceQuery = ServiceFee::with('trainingService');
                    
                    $serviceQuery->whereHas('trainingService.levels', function (Builder $query) {
                        $query->where('value', $this->lead->pt_level);
                    });
                    $this->services = $serviceQuery->get()->pluck('trainingService.title', 'id');
                }else{
                    $this->services = [];
                }
                break;
        }
    }

    public function getService($id)
    {
        switch ($this->paymentable_type) {
            case 'App\\Models\\ExtraItem':
                $service = ExtraItem::find($id);

                $amount = $service->price;
                $this->service = $service;


                if($this->lead->pt_level !== null && $this->lead->pt_level !== ''){
                    if(in_array($id,[29,31,34,36,37])){
                        $this->extraitem_groups = $this->lead->groups;
                    }else{
                        $this->extraitem_groups = [];
                    }
                    // dd($this->extraitem_groups->first()->orderBy('created_at' ,'desc') );
                    $this->suggested_groups = [];
                    // $this->extraitem_groups = [];

                
                }else{
                    $this->suggested_groups = [];
                    $this->extraitem_groups = [];
                }

                break;

            case 'App\\Models\\Offer':
                $service = Offer::find($id);

                $amount = $service->fees;
                $this->service = $service;

                $intervalsId = $service->intervals->pluck('id')->toArray();
                $disciplinesIds = $service->disciplines->pluck('id')->toArray();
                $timeframesId = $service->timeframes->pluck('id')->toArray();
                $level = StageLevel::where('value',$this->lead->pt_level)->/*whereIn('stage_id',$service->course->stages->pluck('id'))->*/first();
                //dd($level);
                if($this->lead->pt_level !== null && $this->lead->pt_level !== ''){
                    //dd($this->lead->pt_level,$timeframesId,$intervalsId);
                    $this->suggested_groups = Group::where('level_id', $level->id)
                    ->whereIn('discipline_id',$disciplinesIds)
                    ->whereIn('timeframe_id', $timeframesId)
                    ->whereIn('interval_id', $intervalsId)
                    ->whereHas('subRound',function($query){
                        $query->where('start_date','<=',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
                    })->get();
                    // $this->suggested_groups = [];
                    $this->extraitem_groups = [];
                }else{
                    // $this->suggested_groups = [];
                    $this->suggested_groups = [];
                    $this->extraitem_groups = [];
                }
                break;

            default:
                $service = ServiceFee::find($id);

                $amount = $service->fees;
                $this->service = $service;

                $this->suggested_groups = Group::where('level_id', $this->lead->pt_level)
                    ->whereHas('subRound',function($query){
                        $query->where('start_date','<=',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
                    })->get();
                // $this->suggested_groups = [];
                $this->extraitem_groups = [];

                break;
        }

        $this->subPayments = null;
        $this->amount = $amount;
        $this->handleSubPayments($service, $amount);
    }

    public function handleSubPayments($service, $amount)
    {
        $installment = $service->installment;
        $now = now();
        //dd($installment);
        
        $this->subPayments[0] = [
            'amount' => $installment ? $installment->deposit : $amount,
            'payment_date' => $now->format('Y-m-d'),
            'due_date' => $now->format('Y-m-d'),
            'paid' => 1,
            'branch_id' => $this->lead->branch_id,
            'employee_id' => auth()->id(),
        ];
        if ($installment) {
            $first_due_date = $this->calcDueDate($now, $installment->first_due_date);
            $this->subPayments[1] = [
                'amount' => $installment->first_payment,
                'due_date' => $first_due_date
            ];

            if ($installment->second_payment) {
                $second_due_date = $this->calcDueDate($now, $installment->second_due_date);
                $this->subPayments[2] = [
                    'amount' => $installment->second_payment,
                    'due_date' => $second_due_date
                ];
            }

            if ($installment->third_payment) {
                $third_due_date = $this->calcDueDate($now, $installment->third_due_date);
                $this->subPayments[3] = [
                    'amount' => $installment->third_payment,
                    'due_date' => $third_due_date
                ];
            }

            if ($installment->fourth_payment) {
                $fourth_due_date = $this->calcDueDate($now, $installment->fourth_due_date);
                $this->subPayments[4] = [
                    'amount' => $installment->fourth_payment,
                    'due_date' => $fourth_due_date
                ];
            }
        }
    }

    public function calcDueDate($date, $after)
    {
        if ($after > 12) {
            return $date->addWeeks($after == 13 ? 1 : 2)->format('Y-m-d');
        } else {
            return $date->addMonths($after)->format('Y-m-d');
        }
    }

    public function save()
    {
        $data = $this->validate();
        //dd($data);
        $lead = $this->lead;
        $service = $this->service;

        if ($data['subPayments'][0]['payment_method_id'] == 1) {
            $safe = Safe::where('employee_id', $this->employee_id)->where('payment_method_id',1)
                ->where('is_manager',0)->where('is_hq', 0)->where('status',1)->first();
            if (!$safe) {
                Flash::error('Employee doesn\'t have safe.');
                return null;
            }/*else{
                if($safe->branch_id != $lead->branch_id){
                    Flash::error('customer in another branch, transfer it first.');
                    return null;
                }
            }*/
        } else {
            $safe = Safe::where('payment_method_id',$data['subPayments'][0]['payment_method_id'])->where('status',1)->first();
            /*
            $senderSafe = Safe::where('employee_id', $this->employee_id)->where('branch_id', $lead->branch_id)
                ->whereNull('is_manager')->where('is_hq', 0)->first();
            */
            if (!$safe) {
                Flash::error('No safe found for this payment method.');
                return null;
            }
            /*
            if (!$senderSafe) {
                Flash::error('Employee doesn\'t have safe.');
                return null;
            }*/
        }

        $data['lead_id'] = $lead->id;
        $data['branch_id'] = $lead->branch_id;
        $data['payment_plan_id'] = $service->payment_plan_id;
        if($data['paymentable_type'] == 'App\\Models\\Offer'){
            //dd($service);
            $data['include_books'] = $service->include_books;
        }
        $payment = LeadPayment::create($data);
        
        if($service->payment_plan_id == 1 || $service->payment_plan_id == 3){
            $subPayments = $data['subPayments'];
            //dd($subPayments);
            $paid = 0;
            $discount = $payment->discount ?? 0;
            foreach ($subPayments as $key => $subPayment) {
                if ($key === 0) {
                    $paid = ($this->discount)?$subPayment['amount'] - $this->discount:$subPayment['amount'];
                }
                if ($key === 1 && $service->payment_plan_id == 3){
                    $subPayment['amount'] = $payment->amount - $discount - $paid;
                }
                if($subPayment['amount'] > 0){
                    if(isset($subPayments[$key]['upload_bill']) && $subPayments[$key]['upload_bill'] != null && $subPayments[$key]['upload_bill'] != ''){
                        $file = $subPayments[$key]['upload_bill']->store('/');
                        $subPayment['upload_bill'] = $file;
                        if (env('APP_ENV') == 'production') {
                            rename(storage_path('app/' . $file), '/home/harvestc/public_html/uploads/lead_payments_bills/' . $file);
                        } else {
                            rename(storage_path('app/' . $file), public_path('uploads/' . $file));
                        }
                    }
                    
                    $payment->subPayments()->create($subPayment);
                }
            }
            
            $rest = $payment->amount - $discount - $paid;
            $rest = $rest < 0 ? 0 : $rest;
            $payment->update(['rest' => $rest]);
        }else{
            $paid = $payment->amount;
            $file_name = null;
            if(isset($data['subPayments'][0]['upload_bill']) && $data['subPayments'][0]['upload_bill'] != null && $data['subPayments'][0]['upload_bill'] != ''){
                $file = $this->subPayments[0]['upload_bill']->store('/');
                $file_name = $file;
                if (env('APP_ENV') == 'production') {
                    rename(storage_path('app/' . $file), '/home/harvestc/public_html/uploads/lead_payments_bills/' . $file);
                } else {
                    rename(storage_path('app/' . $file), public_path('uploads/' . $file));
                }
            }
            $payment->update([
                'payment_method_id' => $data['subPayments'][0]['payment_method_id'],
                'reference_num' => ((isset($data['subPayments'][0]['reference_num']))?$data['subPayments'][0]['reference_num']:''),
                'upload_bill' => $file_name
            ]);
            
        }
        // add to safe
        $safe->increment('balance', $paid);
        // add safe_aoperation 
        $safe_operation = new SafeOperation;
        $safe_operation->safe_id = $safe->id;
        $safe_operation->operation_type = 'income';
        $safe_operation->amount = $paid;
        $safe_operation->source = 'new_payment';
        $safe_operation->save();
        



        /*
        if ($safe->is_hq){
            
            SafeTrancation::create([
                'sender' => auth()->id(),
                'receiver' => $safe->employee_id,
                'safe_sender' => $senderSafe->id,
                'safe_receiver' => $safe->id,
                'amount' => $paid,
                //'description' => ,
                'payment_methods_id' => $data['subPayments'][0]['payment_method_id'],
                'status' => 'approve',
            ]);
        }
        */
        $msg = "Your purchase was successful. Invoice Number:" . $payment->id;
        
        $groupLevel = null;
        if ($payment->paymentable_type == 'App\\Models\\ServiceFee') {
            if ($this->convertToCustomer) {
                $lead->update(['type' => 2]);
                // PlacementApplicant::where('mobile', $lead->mobile_1)->delete();
            }

            $trainingService = ServiceFee::with('trainingService.levels')->find($payment->paymentable_id)->trainingService;
            $trackId = $trainingService->track_id;
            $courseId = $trainingService->course_id;
            $levelId = $trainingService->levels[0]->id;
            $levelsCount = $trainingService->levels->count();
            $groupLevel = $trainingService->levels[0];

            $customerTrack = CustomerTrack::where('lead_id',$lead->id)->where('course_id', $courseId)->first();

            if ($customerTrack){
                $customerTrack->increment('total', $levelsCount);
            }else{
                $customerTrack = CustomerTrack::create([
                    'lead_id' => $lead->id,
                    'track_id' => $trackId,
                    'course_id' => $courseId,
                    'level_id' => $levelId,
                    'total' => $levelsCount,
                    'used' => $this->group_id ? 1 : 0,
                ]);
            }

            if (!$this->group_id) {
                GroupWaitingList::create([
                    'lead_id' => $lead->id,
                    'level_id' => $groupLevel->id,
                    'lead_payment_id' => $payment->id,
                    'discipline_id' => 1
                ]);
            }
        } elseif ($payment->paymentable_type == 'App\\Models\\Offer') {
            if ($this->convertToCustomer) {
                $lead->update(['type' => 2]);
                // PlacementApplicant::where('mobile', $lead->mobile_1)->delete();
            }
            
            $offer = Offer::with('services.trainingService.levels', 'timeframes', 'intervals')->find($payment->paymentable_id);
            $servicesFee = $offer->services;
            //dd($offer);
            if($offer->has_levels == 1 && $servicesFee != null && count($servicesFee) > 0){
                foreach ($servicesFee as $service){
                    $trainingService = $service->trainingService;
                    $trackId = $trainingService->track_id;
                    $courseId = $trainingService->course_id;
                    $levelId = $trainingService->levels[0]->id;
                    $levelsCount = $trainingService->levels->count();
                    $groupLevel = $trainingService->levels[0];
    
                    $customerTrack = CustomerTrack::where('lead_id',$lead->id)->where('course_id', $courseId)->first();
    
                    if ($customerTrack) {
                        $customerTrack->increment('total', $levelsCount);
                    } else {
                        $customerTrack = CustomerTrack::create([
                            'lead_id' => $lead->id,
                            'track_id' => $trackId,
                            'course_id' => $courseId,
                            'level_id' => $levelId,
                            'total' => $levelsCount,
                            'used' => $this->group_id ? 1 : 0,
                        ]);
                    }
                }
    
                if(!$this->group_id){
                    $timeframesString = implode(',', $offer->timeframes->pluck('id')->toArray());
                    $intervalsString = implode(',', $offer->intervals->pluck('id')->toArray());
                    $disciplinesIds = DB::table('offer_disciplines')->where('offer_id',$offer->id)->pluck('discipline_id')->toArray();
                    GroupWaitingList::create([
                        'lead_id' => $lead->id,
                        'level_id' => $groupLevel->id,
                        'timeframes' => $timeframesString,
                        'intervals' => $intervalsString,
                        'lead_payment_id' => $payment->id,
                        'discipline_id' => ($disciplinesIds != null && count($disciplinesIds) > 0)?$disciplinesIds[0]:null
                    ]);
                }
            }elseif($offer->has_levels == 0 && $offer->num_levels > 0 && $lead->pt_level !== '' && $lead->pt_level !== null){
                $course = $offer->course;
                if($lead->groups != null && count($lead->groups) > 0){
                    $last_level = $lead->groups->sortByDesc('level_id')->first();
                    
                    $stage_levels = StageLevel::leftJoin('stages','stages.id','=','stage_levels.stage_id')->where('stages.track_id',$offer->course_id)->where('stage_levels.value','>=',$last_level->level->value)->take($offer->num_levels)->pluck('stage_levels.id')->toArray();
                }else{
                    $stage_levels = StageLevel::leftJoin('stages','stages.id','=','stage_levels.stage_id')->where('stages.track_id',$offer->course_id)->where('stage_levels.value','>=',$lead->pt_level)->take($offer->num_levels)->pluck('stage_levels.id')->toArray();
                }
                $customerTrack = CustomerTrack::where('lead_id',$lead->id)->where('track_id',$offer->track_id)->where('course_id',$offer->course_id)->first();
                $groupLevel = StageLevel::find($stage_levels[0]);
                //dd($stage_levels);
                if ($customerTrack){
                    $customerTrack->increment('total', $offer->num_levels); 
                }else{
                    $customerTrack = CustomerTrack::create([
                        'lead_id' => $lead->id,
                        'track_id' => $offer->track_id,
                        'course_id' => $offer->course_id,
                        'level_id' => $stage_levels[0],
                        'total' => $offer->num_levels,
                        'used' => 0,
                    ]);
                }
                
                if(!$this->group_id){
                    //dd($stage_levels,$training_service_levels,$total,$training_services->pluck('id'));
                    $timeframesString = implode(',', $offer->timeframes->pluck('id')->toArray());
                    $intervalsString = implode(',', $offer->intervals->pluck('id')->toArray());
                    $disciplinesIds = DB::table('offer_disciplines')->where('offer_id',$offer->id)->pluck('discipline_id')->toArray();
                    GroupWaitingList::create([
                        'lead_id' => $lead->id,
                        'level_id' => $stage_levels[0],
                        'timeframes' => $timeframesString,
                        'intervals' => $intervalsString,
                        'lead_payment_id' => $payment->id,
                        'discipline_id' => ($disciplinesIds != null && count($disciplinesIds) > 0)?$disciplinesIds[0]:null
                    ]);
                }
            }else{
                
            }
        }
         elseif ($payment->paymentable_type == 'App\\Models\\ExtraItem') {
           if(in_array($payment->paymentable_id,[2,3]) ){
            $request_data = [
                'name' => $lead->getName(),
                'email' => $lead->email,
                'phone' => $lead->mobile_1,
                
                'certificate_id' => $payment->paymentable_id,
                'invoice_id' => $payment->id,
            ];
            $certificate_request = CertificateRequest::create($request_data);
            
               $req_data = [
                'lead_id' => $lead->id,
                'branch_id' => $lead->branch_id,
                'label_type_id' => 39,
                'customer_notes' => 'cretificate request',
                'type' => 4,
                'status' => 0,
                'follow_up_type' => 3,
                'serial' => time(),
               ];
               //operation inquiry 
               $leadCase = LeadCase::create($req_data);
               $lastcase = $lead->lastcase;
               if($lastcase){
                   $lastcase->update($req_data);
               }else{
                   $lastcase = LeadLastCase::create($req_data);
               }
           }
        }

        if ($this->group_id) {
            //dd($groupLevel);
            $group = Group::find($this->group_id);
            $lead->groups()->attach($this->group_id, [
                'level_id' => $group->level_id,
                'payment' => $payment->payment_plan_id == 1 ? 0 : 1,
                'lead_payment_id' => $payment->id
            ]);

            $lead->update(['type' => 3]);

            $sessions = GroupSession::with('level')->where('group_id', $this->group_id)->get();
            foreach ($sessions as $session){
                $session->attendances()->create([
                    'lead_id' => $lead->id,
                    'group_id' => $session->group_id,
                    'level_id' => $session->level_id,
                ]);
            }
            $msg .= ". You had been assigned to new group. Group Number:" . $this->group_id;
        }

        if ($lead->email) {
            $payment->load('lead', 'paymentPlan', 'subPayments', 'paymentable');
            try{
                Mail::to($lead->email)->send(new PaymentInvoice($payment));
            }catch(Exception $e){
                
            }
        }

        // $sms = new SMS;
        // $mobile = $lead->mobile_1;
        // $sms->send($mobile, $msg);

        // $log = MessageLog::create([
        //     'type' => 1,
        //     'content' => $msg
        // ]);
        // $log->leads()->sync($lead->id);

        Flash::success('Lead Payment saved successfully.');

        redirect(route('admin.leadPayments.show', $payment->id));
    }

    public function render()
    {
        return view('livewire.lead-payments.create');
    }
}
