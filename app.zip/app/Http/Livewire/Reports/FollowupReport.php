<?php

namespace App\Http\Livewire\Reports;

use App\Models\SMS;
use App\Models\Lead;
use App\Models\Offer;
use Livewire\Component;
use App\Models\Employee;
use App\Models\WhatsApp;
use App\Models\LeadSource;
use App\Models\MessageLog;
use Laracasts\Flash\Flash;
use App\Models\KnowChannel;
use App\Imports\LeadsImport;
use App\Models\LabelType;
use App\Models\LeadPayment;
use App\Models\LeadCase;
use Livewire\WithPagination;
use Livewire\WithFileUploads;
use App\Models\TrainingService;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Database\Eloquent\Builder;
use DB;

class FollowupReport extends Component
{
    use WithPagination;

    protected $paginationTheme = 'bootstrap';

    public $search,
        
        $case_from,
        $case_to,
        $view_type = 'employees',
        $per_page = 20,
        $branchesData,
        $employeeBranches,
        $agents,
        $labelTypes = null,
        $show_filter = false,
        $branches = [],
        $agent,
        $excel;

    public function mount()
    {
        $this->labelTypes = LabelType::select('id','name')->where('status',1)->get();
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $this->branchesData = $employeeBranches;
        $this->employeeBranches = $employeeBranches;
        $this->agents = Employee::where('account_Type', 'Operations Account')->where('status',1)->whereHas('branches', function (Builder $query) use ($employeeBranches) {
            $query->whereIn('id', array_keys($employeeBranches));
        })->get()->pluck('name', 'id')->toArray();
    }

    public function updating($field_name)
    {
        $this->resetPage();
    }

    public function toggleFilter()
    {
        $this->show_filter = !$this->show_filter;
    }

    public function updatedBranches($val)
    {
        //dd($val);
        $this->agent = null;
        if($val[0] != 'Select Branch...'){
            $this->agents = Employee::where('account_Type', 'Operations Account')->where('status',1)->whereHas('branches', function (Builder $query) use ($val) {
                $query->whereIn('id', $val);
            })->get()->pluck('name', 'id')->toArray();
        }else{
            $this->agents = [];
        }
    }

    public function render()
    {
        //dd('dddd');
        //$testProcess = round(microtime(true) * 1000);
        $targetCall = 0;
        $actualReachable = 0;
        if($this->view_type == 'employees'){
            $leadCasesQuary = LeadCase::whereNotNull('employee_id')->whereHas('employee',function($quary){
                $quary->where('account_Type', 'Operations Account')->where('status',1);
            });
            
            if ($this->case_from && $this->case_to) {
                
                $now = strtotime($this->case_from); // or your date as well
                $your_date = strtotime($this->case_to);
                $datediff = $your_date - $now ;
                
                $targetCall = 40 * round($datediff / (60 * 60 * 24));
                $actualReachable = 25 * round($datediff / (60 * 60 * 24));
                
                $leadCasesQuary->whereBetween('created_at', [$this->case_from, $this->case_to]);
            }else{
                $targetCall = 40;
                $actualReachable = 25;
                $leadCasesQuary->where('created_at','like','%'.date('Y-m-d').'%');
            }
            
            if($this->branches){
                $leadCasesQuary->whereIn('employee_id', array_keys($this->agents));
            }
            
            if ($this->agent){
                //dd($this->agent);
                $leadCasesQuary->where('employee_id', $this->agent);
            }
            
            if(! auth()->user()->can('reports show_all_data')){
                $leadCasesQuary->where('employee_id', auth()->user()->id);
            }
            
            $quary = '';
            foreach($this->labelTypes as $key => $labelType){
                $quary .= 'count(case when label_type_id = '.$labelType->id.' then label_type_id end) as labelTypeCount'.$labelType->id;
                if($key < (count($this->labelTypes) - 1)){
                    $quary .= ' , ';
                }
            }
            $leadCases = $leadCasesQuary->select('employee_id',DB::raw($quary))->groupBy('employee_id')->orderBy('employee_id')->paginate($this->per_page);
            //dd($leadCases);
            foreach ($leadCases as $key => $leadCase){
                $actual_reachable = 0; 
                $total_target_calls = 0;
                foreach($this->labelTypes as $labelType){
                    $total_target_calls += $leadCase->{'labelTypeCount'.$labelType->id};
                    if(in_array($labelType->id,[6,7,8,12])){
                        $actual_reachable += $leadCase->{'labelTypeCount'.$labelType->id};
                    }
                }
                $leadCases[$key]['total_target_calls'] = $total_target_calls;
                $leadCases[$key]['actual_reachable'] = $actual_reachable;
            }
            
            //dd($targetCall,$actualReachable);
        }else{
            $leadCasesQuary = LeadCase::whereNotNull('branch_id')->whereIn('branch_id',array_keys($this->branchesData))
                ->whereHas('employee',function($quary){
                    $quary->where('account_Type', 'Operations Account')->where('status',1);
                });
            
            if ($this->case_from && $this->case_to) {
                $leadCasesQuary->whereBetween('created_at', [$this->case_from, $this->case_to]);
            }else{
                $leadCasesQuary->where('created_at','like','%'.date('Y-m-d').'%');
            }
            
            
            $quary = '';
            foreach($this->labelTypes as $key => $labelType){
                $quary .= 'count(case when label_type_id = '.$labelType->id.' then label_type_id end) as labelTypeCount'.$labelType->id;
                if($key < (count($this->labelTypes) - 1)){
                    $quary .= ' , ';
                }
            }
            $leadCases = $leadCasesQuary->select('branch_id',DB::raw($quary))->groupBy('branch_id')->orderBy('branch_id')->paginate($this->per_page);
            //dd($leadCases);
            foreach ($leadCases as $key => $leadCase){
                $actual_reachable = 0; 
                $total_target_calls = 0;
                foreach($this->labelTypes as $labelType){
                    $total_target_calls += $leadCase->{'labelTypeCount'.$labelType->id};
                    if(in_array($labelType->id,[6,7,8,12])){
                        $actual_reachable += $leadCase->{'labelTypeCount'.$labelType->id};
                    }
                }
                if ($this->case_from && $this->case_to) {
                    $now = strtotime($this->case_from); // or your date as well
                    $your_date = strtotime($this->case_to);
                    $datediff = $your_date - $now ;
                    
                    $leadCases[$key]['targetCall'] = $leadCase->branch->getEmployeesCount() * 40 * round($datediff / (60 * 60 * 24));
                    $leadCases[$key]['actualReachable'] = $leadCase->branch->getEmployeesCount() * 25 * round($datediff / (60 * 60 * 24));
                }else{
                    $leadCases[$key]['targetCall'] = $leadCase->branch->getEmployeesCount() * 40;
                    $leadCases[$key]['actualReachable'] = $leadCase->branch->getEmployeesCount() * 25;
                }
                $leadCases[$key]['employeesCount'] = $leadCase->branch->getEmployeesCount();
                $leadCases[$key]['total_target_calls'] = $total_target_calls;
                $leadCases[$key]['actual_reachable'] = $actual_reachable;
            }
            
        }
        //dd(round(microtime(true) * 1000) - $testProcess);
        return view('livewire.reports.followup-report', compact('leadCases','targetCall','actualReachable'));
    }
}
