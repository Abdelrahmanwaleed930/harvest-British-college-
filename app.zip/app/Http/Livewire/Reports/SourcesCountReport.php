<?php

namespace App\Http\Livewire\Reports;

use App\Models\SMS;
use App\Models\Lead;
use App\Models\Offer;
use Livewire\Component;
use App\Models\Employee;
use App\Models\WhatsApp;
use App\Models\LeadSource;
use App\Models\MessageLog;
use Laracasts\Flash\Flash;
use App\Models\KnowChannel;
use App\Imports\LeadsImport;
use App\Models\LabelType;
use App\Models\LeadPayment;
use App\Models\Branch;
use App\Models\LeadCase;
use Livewire\WithPagination;
use Livewire\WithFileUploads;
use App\Models\TrainingService;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Database\Eloquent\Builder;
use DB;

class SourcesCountReport extends Component
{

    protected $paginationTheme = 'bootstrap';

    public $search,
        
        $case_from,
        $case_to,
        
        $per_page = 10,
        $branchesData,
        $employeeBranches,
        $agents,
        $labelTypes = null,
        $show_filter = false,
        $view_type = 'branches',
        $branches = [],
        $agent,
        $excel,
        $knowChannels = [],
        $leadSources = [];

    public function mount()
    {
        $this->labelTypes = LabelType::select('id','name')->where('status',1)->get();
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $this->branchesData = $employeeBranches;
        $this->employeeBranches = $employeeBranches;
        $this->knowChannels = KnowChannel::where('status',1)->get();
        $this->leadSources = LeadSource::where('status',1)->get();
        $this->agents = Employee::where('account_Type', 'Operations Account')->where('status',1)->whereHas('branches', function (Builder $query) use ($employeeBranches) {
            $query->whereIn('id', array_keys($employeeBranches));
        })->groupBy('id')->get()->pluck('name', 'id')->toArray();
    }

    public function toggleFilter()
    {
        $this->show_filter = !$this->show_filter;
    }
    
    public function updatedBranches($val)
    {
        //dd($val);
        $this->agent = null;
        if($val[0] != 'Select Branch...'){
            $this->agents = Employee::where('account_Type', 'Operations Account')->where('status',1)->whereHas('branches', function (Builder $query) use ($val) {
                $query->whereIn('id', $val);
            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $this->agents = [];
        }
    }
    
    public function render()
    {
        //dd('dddd');
        //$testProcess = round(microtime(true) * 1000);
        if($this->view_type == 'employees'){
            $leadsQuary = Lead::whereNotNull('lead_source_id')->whereNotNull('assigned_employee_id')->whereHas('assignedEmployee',function($quary){
                $quary->where('account_Type', 'Operations Account')->where('status',1);
            });
            
            if($this->branches){
                $leadsQuary->whereIn('assigned_employee_id', array_keys($this->agents));
            }
            
            if ($this->agent){
                $leadsQuary->where('assigned_employee_id', $this->agent);
            }
        
            if($this->case_from != null && $this->case_from != '' && $this->case_to != null && $this->case_to != ''){
                $leadsQuary->whereBetween('created_at',[$this->case_from,$this->case_to]);
            }else{
                $leadsQuary->where('created_at','like','%'.date('Y-m-d').'%');
            }
            
            $leads = $leadsQuary->select('assigned_employee_id','lead_source_id',DB::raw('count(*) as source_count'))->groupBy('assigned_employee_id')->groupBy('lead_source_id')->orderBy('assigned_employee_id')->get();
            $leads = $leads->groupBy('assigned_employee_id');
            $employees_ids = array_keys($leads->toArray());
            
            $loops = Employee::select('id','first_name','middle_name','last_name')->whereIn('id',$employees_ids)->get();
        }else{
            $leadsQuary = Lead::whereNotNull('lead_source_id');
        
            if($this->case_from != null && $this->case_from != '' && $this->case_to != null && $this->case_to != ''){
                $leadsQuary->whereBetween('created_at',[$this->case_from,$this->case_to]);
            }else{
                $leadsQuary->where('created_at','like','%'.date('Y-m-d').'%');
            }
            
            $leads = $leadsQuary->select('branch_id','lead_source_id',DB::raw('count(*) as source_count'))->groupBy('branch_id')->groupBy('lead_source_id')->orderBy('branch_id')->get();
            $leads = $leads->groupBy('branch_id');
            $branches_ids = array_keys($leads->toArray());
            
            $loops = Branch::whereIn('id',$branches_ids)->pluck('name','id');
        }
        //dd(round(microtime(true) * 1000) - $testProcess);
        //dd($leads);
        return view('livewire.reports.sources-count-report', compact('leads','loops'));
    }
}
