<?php

namespace App\Http\Livewire\Reports;

use App\Models\SMS;
use App\Models\Lead;
use App\Models\Offer;
use Livewire\Component;
use App\Models\Employee;
use App\Models\WhatsApp;
use App\Models\LeadSource;
use App\Models\MessageLog;
use Laracasts\Flash\Flash;
use App\Models\KnowChannel;
use App\Imports\LeadsImport;
use App\Models\LabelType;
use App\Models\LeadPayment;
use App\Models\LeadCase;
use Livewire\WithPagination;
use Livewire\WithFileUploads;
use App\Models\TrainingService;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Database\Eloquent\Builder;
use DB;

class NotdoneFollowupReport extends Component
{
    use WithPagination;

    protected $paginationTheme = 'bootstrap';

    public $search,
        
        $case_from,
        $case_to,
        $view_type = 'employees',
        $per_page = 20,
        $branchesData,
        $employeeBranches,
        $agents,
        
        $show_filter = false,
        $branches = [],
        $agent,
        $excel;

    public function mount()
    {
        
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $this->branchesData = $employeeBranches;
        $this->employeeBranches = $employeeBranches;
        $this->agents = Employee::where('account_Type', 'Operations Account')->where('status',1)->whereHas('branches', function (Builder $query) use ($employeeBranches) {
            $query->whereIn('id', array_keys($employeeBranches));
        })->groupBy('id')->get()->pluck('name', 'id')->toArray();
    }

    public function updating($field_name)
    {
        $this->resetPage();
    }

    public function toggleFilter()
    {
        $this->show_filter = !$this->show_filter;
    }

    public function updatedBranches($val)
    {
        //dd($val);
        $this->agent = null;
        if($val[0] != 'Select Branch...'){
            $this->agents = Employee::where('account_Type', 'Operations Account')->where('status',1)->whereHas('branches', function (Builder $query) use ($val) {
                $query->whereIn('id', $val);
            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $this->agents = [];
        }
    }

    public function render()
    {
        //dd('dddd');
        //$testProcess = round(microtime(true) * 1000);
        if($this->view_type == 'employees'){
            $leadsQuery = Lead::whereNotNull('assigned_employee_id')->whereHas('assignedEmployee',function($quary){
                $quary->where('account_Type', 'Operations Account')->where('status',1);
            });
            
            if($this->branches){
                $leadsQuery->whereIn('assigned_employee_id', array_keys($this->agents));
            }
            
            if ($this->agent){
                $leadsQuery->where('assigned_employee_id', $this->agent);
            }
            if(! auth()->user()->can('reports show_all_data')){
                $leadsQuery->where('assigned_employee_id', auth()->user()->id);
            }
            $leads = $leadsQuery->select(DB::raw('GROUP_CONCAT(id) as leads_ids'),'assigned_employee_id')->groupBy('assigned_employee_id')->paginate($this->per_page);
            
            foreach($leads as $key => $lead){
                $leads_ids = explode(',',$lead->leads_ids);
                
                $leadCasesQuary = LeadCase::where('employee_id', $lead->assigned_employee_id);
                if($this->branches){
                    $leadCasesQuary->whereIn('employee_id', array_keys($this->agents));
                }
                if($this->agent){
                    $leadCasesQuary->where('employee_id', $this->agent);
                }
                $overdueQuary = LeadCase::where('employee_id', $lead->assigned_employee_id);
                if($this->branches){
                    $overdueQuary->whereIn('employee_id', array_keys($this->agents));
                }
                if($this->agent){
                    $overdueQuary->where('employee_id', $this->agent);
                }
                $leads[$key]['leads_no_followup'] = count(array_diff($leads_ids,array_unique($leadCasesQuary->pluck('lead_id')->toArray())));
                $leads[$key]['overdue_followup'] = $overdueQuary->where('status',0)->where('date','<',date('Y-m-d'))->count();
                //dd($leadCasesQuary);
                if($this->case_from && $this->case_to){
                    $leadCasesQuary->whereBetween('date', [$this->case_from, $this->case_to]);
                }else{
                    $leadCasesQuary->where('date','like','%'.date('Y-m-d').'%');
                }
                $leadCasesQuary = $leadCasesQuary->get();
                $followup_count = $leadCasesQuary->count();
                
                $done_followup_count = $leadCasesQuary->where('status',1)->count();
                $notdone_followup_count = $leadCasesQuary->where('status',0)->count();
                $not_interested = $leadCasesQuary->where('label_type_id',12)->count();
                
                $leads[$key]['followup_count'] = $followup_count;
                $leads[$key]['done_followup_count'] = $done_followup_count;
                $leads[$key]['notdone_followup_count'] = $notdone_followup_count;
                $leads[$key]['not_interested'] = $not_interested;
            }
        }else{
            $leadsQuery = Lead::whereNotNull('branch_id')->whereIn('branch_id',array_keys($this->branchesData))->whereHas('assignedEmployee',function($quary){
                $quary->where('account_Type', 'Operations Account')->where('status',1);
            });
            
            $leadsQuery = $leadsQuery->select('id','branch_id')->get();
            $leadsQuery = $leadsQuery->groupBy('branch_id');
            $leads = array();
            foreach($leadsQuery as $key => $lead){
                $leads_ids = $lead->pluck('id')->toArray();
                
                $new_lead_case = new LeadCase;
                $new_lead_case->branch_id = $key;
                $leadCasesQuary = LeadCase::where('branch_id', $key)->whereHas('employee',function($quary){
                    $quary->where('account_Type', 'Operations Account')->where('status',1);
                });
                $overdueQuary = LeadCase::where('branch_id', $key)->whereHas('employee',function($quary){
                    $quary->where('account_Type', 'Operations Account')->where('status',1);
                });
                //dd($leads_ids,array_unique($leadCasesQuary->pluck('lead_id')->toArray()));
                $new_lead_case['leads_no_followup'] = count(array_diff($leads_ids,array_unique($leadCasesQuary->pluck('lead_id')->toArray())));
                $new_lead_case['overdue_followup'] = $overdueQuary->where('status',0)->where('date','<',date('Y-m-d'))->count();;
                
                if($this->case_from && $this->case_to){
                    $leadCasesQuary->whereBetween('date', [$this->case_from, $this->case_to]);
                }else{
                    $leadCasesQuary->where('date','like','%'.date('Y-m-d').'%');
                }
                $leadCasesQuary = $leadCasesQuary->get();
                $followup_count = $leadCasesQuary->count();
                //dd($followup_count,$leadCasesQuary->where('status',1)->count(),$leadCasesQuary->where('status',0)->count());
                $done_followup_count = $leadCasesQuary->where('status',1)->count();
                $notdone_followup_count = $leadCasesQuary->where('status',0)->count();
                $not_interested = $leadCasesQuary->where('label_type_id',12)->count();
                //dd($followup_count,$leadCasesQuary->where('status',1)->count(),$leadCasesQuary->where('status',0)->count(),$done_followup_count,$notdone_followup_count);
                $new_lead_case['followup_count'] = $followup_count;
                $new_lead_case['done_followup_count'] = $done_followup_count;
                $new_lead_case['notdone_followup_count'] = $notdone_followup_count;
                $new_lead_case['not_interested'] = $not_interested;
                
                $leads[] = $new_lead_case;
            }
        }
        //dd(round(microtime(true) * 1000) - $testProcess);
        return view('livewire.reports.notdone-followup-report', compact('leads'));
    }
}
