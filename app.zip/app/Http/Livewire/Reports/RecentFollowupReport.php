<?php

namespace App\Http\Livewire\Reports;

use App\Models\SMS;
use App\Models\Lead;
use App\Models\Offer;
use Livewire\Component;
use App\Models\Employee;
use App\Models\WhatsApp;
use App\Models\LeadSource;
use App\Models\MessageLog;
use Laracasts\Flash\Flash;
use App\Models\KnowChannel;
use App\Imports\LeadsImport;
use App\Models\LabelType;
use App\Models\LeadPayment;
use App\Models\LeadCase;
use Livewire\WithPagination;
use Livewire\WithFileUploads;
use App\Models\TrainingService;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Database\Eloquent\Builder;
use DB;

class RecentFollowupReport extends Component
{
    use WithPagination;

    protected $paginationTheme = 'bootstrap';

    public $search,
        $case_from,
        $case_to,
        $per_page = 20,
        $branchesData,
        $employeeBranches,
        $agents,
        $labelTypes = null,
        $show_filter = false,
        $branches = [],
        $agent,
        $excel;

    public function mount()
    {
        $this->labelTypes = LabelType::select('id','name')->where('status',1)->get();
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $this->branchesData = $employeeBranches;
        $this->employeeBranches = $employeeBranches;
        $this->agents = Employee::where('account_Type', 'Operations Account')->where('status',1)->whereHas('branches', function (Builder $query) use ($employeeBranches) {
            $query->whereIn('id', array_keys($employeeBranches));
        })->get()->pluck('name', 'id')->toArray();
    }

    public function updating($field_name)
    {
        $this->resetPage();
    }

    public function toggleFilter()
    {
        $this->show_filter = !$this->show_filter;
    }

    public function updatedBranches($val)
    {
        //dd($val);
        $this->agent = null;
        if($val[0] != 'Select Branch...'){
            
            $this->agents = Employee::where('account_Type', 'Operations Account')->where('status',1)->whereHas('branches', function (Builder $query) use ($val) {
                $query->whereIn('id', $val);
            })->get()->pluck('name', 'id')->toArray();
        }else{
            $this->agents = [];
        }
    }

    public function render()
    {
        //$testProcess = round(microtime(true) * 1000);
        //dd('dddd');
        $leadCasesQuary = LeadCase::with('lead')->whereHas('employee',function($quary){
            $quary->where('account_Type', 'Operations Account')->where('status',1);
        });
        
        if($this->case_from && $this->case_to){
            $leadCasesQuary->whereBetween('created_at', [$this->case_from, $this->case_to]);
        }else{
            $leadCasesQuary->where('created_at','like','%'.date('Y-m-d').'%');
        }
        
        if($this->branches){
            $leadCasesQuary->whereIn('employee_id', array_keys($this->agents));
        }
        
        if($this->agent){
            $leadCasesQuary->where('employee_id', $this->agent);
        }
        
        if(! auth()->user()->can('reports show_all_data')){
            $leadCasesQuary->where('employee_id', auth()->user()->id);
        }
        
        if($this->search){
            $leadCasesQuary->whereHas('lead',function ($query) {
                $query->where('name', 'like', '%' . $this->search . '%')
                    ->orWhere('mobile_1', 'like', '%' . $this->search . '%')
                    ->orWhere('email', 'like', '%' . $this->search . '%');
            });
        }
        
        $followupsCount = $leadCasesQuary->count();
        $leadCases = $leadCasesQuary->orderBy('id','desc')->paginate($this->per_page);
        //dd(round(microtime(true) * 1000) - $testProcess);
        return view('livewire.reports.recent-followup-report', compact('leadCases','followupsCount'));
    }
}
