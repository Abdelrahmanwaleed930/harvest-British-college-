<?php

namespace App\Http\Livewire\Groups;

use App\Models\Room;
use App\Models\Group;
use App\Models\Round;
use App\Models\Track;
use App\Models\Branch;
use Livewire\Component;
use App\Models\StageLevel;
use App\Models\Stage;
use App\Models\Employee;
use Carbon\Carbon;
use Laracasts\Flash\Flash;
use Illuminate\Http\Request;
use App\Models\DisciplineCategory;
use App\Models\Timeframe;
use App\Models\GroupSession;
use App\Models\Interval;
use App\Models\SubRound;
use App\Models\SubRoundSession;
use DB;
use ArrayObject;
use Illuminate\Database\Eloquent\Builder;
use Auth;
// use Response;
use Spatie\Activitylog\Contracts\Activity;


class Form extends Component
{
    public $group,
        $title,
        $parent_id,
        $track_id,
        $course_id,
        $round_id,
        $busy_instructors = [],
        $is_upgraded = 0,
        $upgraded = 0,
        $level_id,
        $sub_round_id,
        $days,
        $discipline_id,
        $timeframe_id,
        $branch_id,
        $room_id,
        $instructor_id,
        $interval_id,
        $admin_id,
        $employeeBranches,
        //$levels,
        $tracks,
        $busy_rooms,
        $courses = [],
        $rounds = [],
        $subRounds = [],
        $daysData = [],
        $disciplines,
        $timeframes = [],
        $branches,
        $rooms,
        $instructors,
        $admins = [],
        $intervals,
        $stageLevels,
        $edit_form = false;

    public function mount(Request $request, $group = null)
    {
        if($request->filled('parent')){
            $this->parent_id = $request->get('parent');
            $group = Group::find($request->get('parent'));
        }
        if ($group) {
            $this->fill([
                'title' => $group->title,
                'parent_id' => !!$group->parent_id,
                'track_id' => $group->track_id,
                'level_id' => $group->level_id,
                'course_id' => $group->course_id,
                'timeframe_id' => $group->timeframe_id,
                'round_id' => $group->round_id,
                'sub_round_id' => $group->sub_round_id,
                'days' => $group->days,
                'discipline_id' => $group->discipline_id,
                'branch_id' => $group->branch_id,
                'room_id' => $group->room_id,
                'instructor_id' => $group->instructor_id,
                'admin_id' => $group->admin_id,
                'is_upgraded' => $group->is_upgraded,
                'upgraded' => $group->is_upgraded,
                'interval_id' => $group->interval_id,
                //'levels' => $group->levels->pluck('id')->toArray(),
                'rounds' => Round::where('timeframe_id',$group->timeframe_id)->pluck('title','id')->toArray(),
                'subRounds' => SubRound::where(['round_id' => $group->round_id, 'days' => $group->days])->pluck('start_date', 'id')->toArray(),
                'courses' => Track::where('parent_id', $group->track_id)->pluck('title', 'id')->toArray(),
                //'stageLevels' => Track::find($group->course_id)->stageLevels->pluck('name', 'id')->toArray(),
            ]);

            $this->round_idUpdated($group->round_id);
            $this->branchIdUpdated();
            $this->updatedCourseId($group->course_id,false);
            $this->edit_form = true;
        } else {
            $this->rooms = [];
            $this->intervals = [];
            $this->stageLevels = [];
        }
        
        $this->tracks = Track::whereNull('parent_id')->pluck('title', 'id')->toArray();
        //$this->rounds = Round::pluck('title', 'id')->toArray();
        $this->disciplines = DisciplineCategory::pluck('name', 'id')->toArray();
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $this->employeeBranches = $employeeBranches;
        $this->branches = $employeeBranches;
        $this->admins = Employee::where('status',1)->where('account_Type', 'Operations Account')->whereHas('branches', function (Builder $query) use ($employeeBranches) {
            $query->whereIn('id', array_keys($employeeBranches));
        })->get()->pluck('name', 'id')->toArray();
        //$this->admins = Employee::where('account_Type', 'Operations Account')->get()->pluck('name', 'id')->toArray();
        //dd($this->rounds);
        $this->getInstructors(false);
    }

    protected function rules()
    {
        $rules = [
            // 'title' => 'required',
            'track_id' => 'required',
            'course_id' => 'required',
            'round_id' => 'required',
            'timeframe_id' => 'required',
            'sub_round_id' => 'required',
            'days' => 'required',
            'discipline_id' => 'required',
            'branch_id' => 'required',
            'room_id' => 'required',
            'instructor_id' => 'nullable',
            'admin_id' => 'required',
            'interval_id' => 'required',
            'level_id' => 'required',
            'upgraded' => 'nullable',
            //'levels' => 'required|array',
        ];

        return $rules;
    }

    public function updated($name)
    {
        $this->validateOnly($name);
    }

    public function updatedTrackId($value)
    {
        $this->courses = Track::where('parent_id', $value)->pluck('title', 'id')->toArray();
        $this->course_id = '';
    }

    public function updatedCourseId($value,$reset = true)
    {
        //dd($value);
        $this->stageLevels = Track::find($value)->stageLevels->pluck('name', 'id')->toArray();
        $timeframe_ids = DB::table('timeframe_courses')->where('course_id',$value)->pluck('timeframe_id')->toArray();
        $this->timeframes = Timeframe::whereIn('id',$timeframe_ids)->where('status',1)->pluck('title','id')->toArray();
        if($reset){
            $this->level_id = '';
            $this->timeframe_id = '';
        }
    }
    
    public function updatedTimeframeId($value)
    {
        $this->rounds = Round::where('timeframe_id',$value)->pluck('title', 'id')->toArray();
        $this->round_id = '';
    }

    public function updatedRoundId($val)
    {
        $this->round_idUpdated($val);
        
        $this->interval_id = '';
        //$this->levels = [];
        //$this->level_id = '';
        $this->getInstructors();
    }

    public function round_idUpdated($round_id)
    {
        $round = Round::with('timeframe.intervals')->find($round_id);

        $this->daysData = $round->timeframe->days;
        $this->intervals = $round->timeframe->intervals->pluck('name', 'id')->toArray();
    }

    public function updatedDays($day)
    {
        $this->subRounds = SubRound::where('days', $day)->where('round_id', $this->round_id)
            ->whereDate('end_date', '>', now())->orderBy('start_date')->take(4)->pluck('start_date', 'id');

        $this->sub_round_id = '';
        $this->getInstructors();
        $this->branchIdUpdated();
    }

    public function updatedBranchId($val)
    {
        $this->admins = Employee::whereHas('branches', function (Builder $query) use ($val){
                                    $query->where('branch_id', $val);
                                })->where('account_Type', 'Operations Account')->where('status',1)->get()->pluck('name', 'id')->toArray();
        $this->branchIdUpdated();
        
        $this->admin_id = '';
        $this->room_id = '';

        $this->getInstructors();
    }

    public function branchIdUpdated()
    {
        if($this->branch_id){
            $this->rooms = Room::where('branch_id', $this->branch_id)->pluck('name', 'id');
            
            $this->busy_rooms = [];
        
            if ($this->days && $this->sub_round_id && $this->interval_id) {
                $this->busy_rooms = Group::where(['branch_id' => $this->branch_id,'days' => $this->days,'sub_round_id' => $this->sub_round_id, 'interval_id' => $this->interval_id])
                    ->pluck('room_id')->toArray();
            }
        }
    }

    public function updatedIntervalId($val)
    {
        $this->getInstructors();
        $this->branchIdUpdated();
    }
    
    public function updatedSubRoundId($val)
    {
        $this->getInstructors();
        $this->branchIdUpdated();
    }

    public function getInstructors($reset = true)
    {
        $instructorsQuery = Employee::where('status',1)->where('account_Type', 'ESL Account Profile')->whereHas('attendances',function($query){
            $query->where('day',$this->days)->where('interval_id',$this->interval_id);
        });

        if ($this->branch_id) {
            $instructorsQuery->whereHas('branches', function (Builder $query) {
                $query->where('id', $this->branch_id);
            });
        }else{
            $employeeBranches = $this->employeeBranches;
            $instructorsQuery->whereHas('branches', function (Builder $query) use ($employeeBranches){
                $query->whereIn('id', array_keys($employeeBranches));
            });
        }
        $this->busy_instructors = [];
        
        if ($this->days && $this->sub_round_id && $this->interval_id && $reset) {
            $this->busy_instructors = Group::where(['days' => $this->days,'sub_round_id' => $this->sub_round_id, 'interval_id' => $this->interval_id])
                ->pluck('instructor_id')->toArray();

        }

        $this->instructors = $instructorsQuery->get()->pluck('name', 'id')->toArray();

        if ($reset) {
            $this->instructor_id = '';
        }
    }

    public function save()
    {
        $data = $this->validate();
        
        foreach($data as $key => $value){
            if($value == ''){
                $data[$key] = null;
            }
        }
        //dd($data);
        $group = $this->group;

        $subRound = SubRound::with('round.timeframe')->find($data['sub_round_id']);
        $interval = Interval::find($data['interval_id']);
        $data['title'] = "group " . $subRound->round->timeframe->title . " | " . $interval->name;
        
        if ($group) {
            $group->update($data);
            
            $sessions  = $group->sessions;
            if($sessions != null && count($sessions) > 0){
                foreach($sessions as $session){
                    $session->update([
                        'room_id' => $group->room_id,
                        'instructor_id' => $group->instructor_id
                    ]);
                }
            }
            
         activity('Groups')
           ->causedBy(Auth::user()->id)
           ->performedOn($group)
        //   ->withProperties(['group_id' =>$group->id ])
           ->log('update group');
            
        } else {
            $last_group = Group::orderBy('id','desc')->first();
            $data['code'] = ($last_group)?sprintf("%07d",($last_group->id + 1)):sprintf("%07d",1);
            
            if ($this->parent_id) {
                $data['parent_id'] = $this->parent_id;
            }
            $group = Group::create($data);

            $dates = SubRoundSession::where('sub_round_id', $group->sub_round_id)->pluck('date')->toArray();

            //$levels = $data['levels'];
            //$levelsCount = count($levels);
            $perSession = count($dates) - 1;
            $end = end($dates);

            //$key = 0;
            //$i = 1;
            foreach ($dates as $date) {
                $sessionData = [
                    'group_id' => $group->id,
                    'date' => $date,
                    'room_id' => $group->room_id,
                    'instructor_id' => $group->instructor_id,
                    'interval_id' => $group->interval_id,
                    'level_id' => $group->level_id,
                ];
                /*
                if ($date != $end) {
                    $sessionData['level_id'] = $levels[$key];
                }
                */
                GroupSession::create($sessionData);
                /*
                if (($i % $perSession) == 0) {
                    $key++;
                }
                $i++;
                */
                
            }
             activity('Groups')
               ->causedBy(Auth::user()->id)
               ->performedOn($group)
          //   ->withProperties(['group_id' =>$group->id ])
               ->log('create group');
            
        }
        
        
        if($this->is_upgraded == 0 && $this->upgraded == 1){
            //$level = StageLevel::find($group->level_id);
            $count=0;
            $stages_ids = Stage::where('track_id',$group->course_id)->pluck('id');
            $next_levels = StageLevel::whereIn('stage_id',$stages_ids)->where('id','>',$group->level_id)->orderBy('value')->get();
            $next_sub_rounds = SubRound::where('round_id',$group->round_id)->where('days',$group->days)->where('id','>',$group->sub_round_id)->orderBy('id')->get();
            if($next_levels != null && count($next_levels) > 0){
                foreach($next_levels as $key => $next_level){
                    
                      if(isset($next_sub_rounds[$key])){
                          $next_sub_round = $next_sub_rounds[$key];
                      }else{
                          
                          if($next_sub_rounds != null && count($next_sub_rounds) > 0){
                              $last_sub_round = $next_sub_rounds->last();
                          }else{
                              $last_sub_round = SubRound::find($group->sub_round_id);
                          }
                          $timeframe = Round::with('timeframe')->find($group->round_id)->timeframe;
                          $total_hours = $timeframe->total_hours;
                          $session_hours = $timeframe->session_hours;
                          $session_count = ($total_hours / $session_hours) + 1;
                          
                          $last_session_date = Carbon::parse($last_sub_round->subRoundSessions->last()->date);
                          $days = explode('/', config('system_variables.timeframes.days')[$last_sub_round->days]);
                          $startDate = $last_session_date->next($days[0]);
                          $n = 1;
                          while ($n <= 30) {
                              $new_subRound = SubRound::create([
                                  'round_id' => $group->round_id,
                                  'days' => $group->days,
                                  'start_date' => $startDate,
                              ]);
  
                              $days = explode('/', config('system_variables.timeframes.days')[$last_sub_round->days]);
                              $daysObj = new ArrayObject($days);
                              $daysIt = $daysObj->getIterator();
                              $date = $startDate;
                              for ($i = 0; $i < $session_count; $i++) {
                                  if ($i) {
                                      if (!$daysIt->valid()) {
                                          $daysIt->rewind();
                                      }
                                      $date = $date->next($daysIt->current());
                                  }
                                  $session = SubRoundSession::create([
                                      'sub_round_id' => $new_subRound->id,
                                      'date' => $date,
                                  ]);
                                  $daysIt->next();
                              }
                              $new_subRound->update(['end_date' => $session->date]);
                              $startDate = $date->next($days[0]);
                              $n++;
                          }
                          
                          $next_sub_rounds = SubRound::where('round_id',$group->round_id)->where('days',$group->days)->where('id','>',$group->sub_round_id)->orderBy('id')->get();
                          $next_sub_round = $next_sub_rounds[$key];
                          
                      }
                      $next_group_data = [
                          'track_id' => $group->track_id,
                          'level_id' => $next_level->id,
                          'course_id' => $group->course_id,
                          'timeframe_id' => $group->timeframe_id,
                          'round_id' => $group->round_id,
                          'sub_round_id' => $next_sub_round->id,
                          'days' => $group->days,
                          'discipline_id' => $group->discipline_id,
                          'branch_id' => $group->branch_id,
                          'room_id' => $group->room_id,
                          'instructor_id' => $group->instructor_id,
                          'admin_id' => $group->admin_id,
                          'is_upgraded' => 1,
                          'interval_id' => $group->interval_id,
                      ];
                      $last_group = Group::orderBy('id','desc')->first();
                      $next_group_data['code'] = ($last_group)?sprintf("%07d",($last_group->id + 1)):sprintf("%07d",1);
                      $next_group_data['title'] = "group " . $next_sub_round->round->timeframe->title . " | " . $interval->name;
                      $next_group_data['parent_id'] = $group->id;
                      
                      $next_group = Group::create($next_group_data);
                      
                      $dates = SubRoundSession::where('sub_round_id', $next_sub_round->id)->pluck('date')->toArray();
                      $perSession = count($dates) - 1;
                      $end = end($dates);
          
                       foreach ($dates as $date) {
                           $sessionData = [
                               'group_id' => $next_group->id,
                               'date' => $date,
                               'room_id' => $next_group->room_id,
                               'instructor_id' => $next_group->instructor_id,
                               'interval_id' => $next_group->interval_id,
                               'level_id' => $next_group->level_id,
                           ];
                           
                           GroupSession::create($sessionData);
                           
                       }
                       activity('Groups')
                        ->causedBy(Auth::user()->id)
                        ->performedOn($next_group)
          //            ->withProperties(['group_id' =>$group->id ])
                        ->log('create group');
                    
                }
            }
            
            $group->is_upgraded = 1;
            $group->save();
            
        }
            
        //$group->levels()->sync($data['levels']);

        Flash::success('Group saved successfully.');

        redirect(route('admin.groups.index'));
    }

    public function render()
    {
        return view('livewire.groups.form');
    }
}
