<?php

namespace App\Http\Livewire\Courses;

use App\Models\Track;
use App\Models\ExtraItem;
use Livewire\Component;
use Laracasts\Flash\Flash;
use DB;

class Create extends Component
{
    public $tracks,
        $parent_id,
        $title,
        $certificates = [],
        $certificates_ids = [],
        $items = [],
        $levels = 0,
        $stages = [];

    public function mount()
    {
        $this->certificates = ExtraItem::where('item_category_id',2)->pluck('name','id');
        $this->items = ExtraItem::pluck('name','id');
        $this->fill([
            'tracks' => Track::whereNull('parent_id')->pluck('title', 'id'),
        ]);
    }

    protected function rules()
    {
        $rules = [
            'parent_id' => 'required',
            'title' => 'required',
            'certificates_ids' => 'nullable',
            'levels' => '',
            'stages' => 'required|array',
            'stages.*.name' => 'required',
            'stages.*.levels.*.name' => 'required',
            'stages.*.levels.*.value' => 'required|integer',
            'stages.*.levels.*.items' => 'nullable',
        ];

        return $rules;
    }

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
    }

    public function addStage()
    {
        $this->stages[]['levels'][] = ['name' => '', 'value' => '','items' => []];
        $this->levels += 1;
    }

    public function deleteStage($idx)
    {
        $stages = $this->stages;
        $levels_count = count($stages[$idx]['levels']);
        $this->levels -= $levels_count;
        unset($stages[$idx]);
        $this->stages = $stages;
    }

    public function addStageLevel($i)
    {
        $this->stages[$i]['levels'][] = ['name' => '', 'value' => '','items' => []];
        $this->levels += 1;
    }

    public function save()
    {
        $data = $this->validate();

        $course = Track::create($data);

        foreach ($data['stages'] as $stageData) {
            $stage = $course->stages()->create($stageData);

            foreach ($stageData['levels'] as $levelData) {
                $level = $stage->levels()->create($levelData);
                //dd($level);
                if(isset($levelData['items']) && $levelData['items'] != null && count($levelData['items']) > 0){
                    foreach($levelData['items'] as $item_id){
                        DB::table('stage_level_items')->insert(['level_id' => $level->id,'item_id' => $item_id]);
                    }
                }
            }
        }
        if($data['certificates_ids'] != null && count($data['certificates_ids']) > 0){
            foreach($data['certificates_ids'] as $certificate_id){
                DB::table('track_items')->insert(['track_id' => $course->id,'item_id' => $certificate_id]);
            }
        }
        Flash::success('Sub Track saved successfully.');

        redirect(route('admin.courses.index'));
    }

    public function render()
    {
        return view('livewire.courses.create');
    }
}
