<?php

namespace App\Http\Livewire\StudentExam;

use App\Models\StudentExamAnswer;
use App\Models\Answer;
use App\Models\Question;
use Livewire\Component;

class Writing extends Component
{
    public $applicant, $limit = 2,$questions, $answers = [],$shown_ques;

    public function mount($applicant)
    {
        $this->applicant = $applicant;

        $questions = Question::where('track_id',$applicant->track_id)->where('course_id',$applicant->course_id)->where('level_id',$applicant->level_id)->where('skill', 'Writing')->whereNull('parent_id')
            ->with('children')
            ->limit($this->limit)->inRandomOrder()->get();
        $this->questions = $questions;
        $this->shown_ques = $questions[0]->id;
    }
    
    public function previosBtn($key)
    {
        $this->shown_ques = $this->questions[($key - 1)]['id'];
    }
    
    public function nextBtn($key)
    {
        if(array_key_exists($this->questions[$key]['id'],$this->answers)){
            $this->shown_ques = $this->questions[($key + 1)]['id'];
        }else{
            
        }
    }
    
    protected function rules()
    {
        return [
            'answers' => 'array|size:' . $this->limit,
            'answers.*' => 'array',
            'answers.*.*' => 'string|min:10'
        ];
    }

    protected $messages = [
        'array' => 'يجب إجابة كل الاسئلة',
        'size' => 'يجب إجابة كل الاسئلة',
        'answers.*.*.min' => 'الاجبة يجب ان تكون اكثر من 10 حرف',
    ];

    public function save()
    {
        //$this->validate();
        
        $this->applicant->update(['step' => 7,'finish' => 1]);
        if($this->answers != null && count($this->answers) > 0){
            StudentExamAnswer::where('student_exam_id',$this->applicant->id)->delete();
            
            //dd($this->applicant,$this->answers);
            foreach($this->answers as $key => $answers){
                StudentExamAnswer::create([
                    'student_exam_id' => $this->applicant->id,
                    'question_id' => $key,
                    'type' => 'text',
                    'answer' => implode('<br/>',$answers),
                ]);
            }
        }

        //$this->emitUp('next');
        return redirect(route('customer.show_exam_result',$this->applicant->id));
    }

    public function render()
    {
        return view('livewire.student-exam.writing');
    }
}
