<?php

namespace App\Http\Livewire\StudentExam;

use App\Models\GroupStudent;
use App\Models\Lead;
use App\Models\StudentExam;
use Livewire\Component;

class Applicant extends Component
{
    public $student_id;

    public function mount($studentId)
    {
        //dd($studentId);
        $this->student_id = $studentId;
    }

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
    }

    public function save()
    {
        $this->emitUp('registered');
    }

    public function render()
    {
        $student = GroupStudent::findOrFail($this->student_id);
        return view('livewire.student-exam.applicant',compact('student'));
    }
}
