<?php

namespace App\Http\Livewire\StudentExam;

use App\Models\Answer;
use App\Models\Question;
use Livewire\Component;

class Vocabulary extends Component
{
    public $applicant,$limit = 20, $questions, $answers = [],$shown_ques,$show_next_msg = false;

    private $point = 0.5;

    public function mount($applicant)
    {
        $this->applicant = $applicant;

        $questions = Question::where('track_id',$applicant->track_id)
        ->where('course_id',$applicant->course_id)->where('level_id',$applicant->level_id)
        ->where('skill', 'Vocabulary')->with('answers')->limit($this->limit)->inRandomOrder()->get();
        $this->shown_ques = $questions[0]->id;
        $this->questions = $questions;
    }
    
    public function previosBtn($key)
    {
        $this->shown_ques = $this->questions[($key - 1)]->id;
        $this->show_next_msg = false;
    }
    
    public function updatedAnswers()
    {
        $key = count(array_keys($this->answers));
        if($key < count($this->questions)){
            $this->shown_ques = $this->questions[$key]->id;
        }
        
        $this->show_next_msg = false;
    }
    
    public function nextBtn($key)
    {
        if(array_key_exists($this->questions[$key]->id,$this->answers)){
            $this->shown_ques = $this->questions[($key + 1)]->id;
        }else{
            $this->show_next_msg = true;
        }
    }
    
    protected function rules()
    {
        return [
            'answers' => 'array|size:' . $this->limit
        ];
    }

    protected $messages = [
        'array' => 'يجب إجابة كل الاسئلة',
        'size' => 'يجب إجابة كل الاسئلة',
    ];

    public function save()
    {
        //$this->validate();
        if(count($this->answers) == $this->limit){
            $correctCount = Answer::whereIn('id', array_values($this->answers))->sum('is_correct', 1);
            $score = $correctCount * $this->point;
            $this->applicant->update(['vocabulary_score' => $score,'step' => 3]);
            $this->emitUp('next');
        }else{
            $this->show_next_msg = true;
        }
    }

    public function render()
    {
        return view('livewire.student-exam.vocabulary');
    }
}
