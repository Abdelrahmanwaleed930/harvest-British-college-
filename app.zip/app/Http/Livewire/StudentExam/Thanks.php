<?php

namespace App\Http\Livewire\StudentExam;

use Livewire\Component;
use Auth;

class Thanks extends Component
{
    public $applicant;
    
    public function mount($applicant)
    {
        $this->applicant = $applicant;
        //dd($applicant);
        return redirect(route('customer.show_exam_result',$applicant->id));
    }
    
    public function render()
    {
        $customer = Auth::guard('customer')->user();
        
        return view('livewire.student-exam.thanks',compact('customer'));
    }
}
