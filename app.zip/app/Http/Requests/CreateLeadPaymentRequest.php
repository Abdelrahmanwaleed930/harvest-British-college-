<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\LeadPayment;
use App\Models\ExtraItem;
use App\Models\Offer;
use App\Models\ServiceFee;

class CreateLeadPaymentRequest extends FormRequest
{

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        //dd($this->all());
        $rules = [
            'branch_id' => 'required',
            'lead_id' => 'required',
            'employee_id' => 'required',
            'total_price' => 'required',
            'total_discount' => 'required',
            'payment_method_id' => 'required',
            'reference_num' => 'required_unless:payment_method_id,1',
            'upload_bill' => 'required_unless:payment_method_id,1',
        ];
        if($this->service_id != null && $this->service_id != ''){
            $service = ServiceFee::find($this->service_id);
            $service_amount = $service->fees;
            
            $payed = ($service && ($service->payment_plan_id == 1 || $service->payment_plan_id == 3)) ? $this->service_subPayments[0]['amount'] : $service_amount;
            $rules['service_discount'] = 'nullable|integer|max:' . $payed;
            $min_amount = ($service != null && ($service->payment_plan_id == 1 || $service->payment_plan_id == 3) && $service->installment)?$service->installment->deposit:$service_amount;
            
            if($service != null && ($service->payment_plan_id == 1 || $service->payment_plan_id == 3) && $service->installment){
                $rules['service_subPayments.0.amount'] = 'required|integer|min:'.$min_amount.'|max:' . $service_amount;
            }
        }
        
        if($this->offer_id != '' && $this->offer_id != null){
            $offer = Offer::find($this->offer_id);
            $offer_amount = $offer->fees;
            
            $payed = ($offer && ($offer->payment_plan_id == 1 || $offer->payment_plan_id == 3)) ? $this->offer_subPayments[0]['amount'] : $offer_amount;
            $rules['offer_discount'] = 'nullable|integer|max:' . $payed;
            $min_amount = ($offer != null && ($offer->payment_plan_id == 1 || $offer->payment_plan_id == 3) && $offer->installment)?$offer->installment->deposit:$offer_amount;
            
            if($offer != null && ($offer->payment_plan_id == 1 || $offer->payment_plan_id == 3) && $offer->installment){
                $rules['offer_subPayments.0.amount'] = 'required|integer|min:'.$min_amount.'|max:' . $offer_amount;
                $rules['offer_subPayments.0.due_date'] = 'required';
            }
        }
        return $rules;
    }
}
