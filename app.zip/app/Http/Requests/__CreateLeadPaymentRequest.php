<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\LeadPayment;
use App\Models\ExtraItem;
use App\Models\Offer;
use App\Models\ServiceFee;

class CreateLeadPaymentRequest extends FormRequest
{

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        //dd($this->all());
        $service = null;
        switch ($this->paymentable_type) {
            case 'App\\Models\\ExtraItem':
                $service = ExtraItem::find($this->paymentable_id);
                $amount = $service->price;

                break;

            case 'App\\Models\\Offer':
                $service = Offer::find($this->paymentable_id);
                $amount = $service->fees;

                break;

            default:
                $service = ServiceFee::find($this->paymentable_id);
                $amount = $service->fees;

                break;
        }
        $payed = ($service && ($service->payment_plan_id == 1 || $service->payment_plan_id == 3)) ? $this->subPayments[0]['amount'] : $amount;
        
        $min_amount = ($service != null && ($service->payment_plan_id == 1 || $service->payment_plan_id == 3) && $service->installment)?$service->installment->deposit:$amount;
        $rules = [
            'paymentable_type' => 'required',
            'paymentable_id' => 'required',
            'branch_id' => 'required',
            'employee_id' => 'required',
            'amount' => 'required|integer',
            'discount' => 'nullable|integer|max:' . $payed,
            'subPayments' => 'required|array',
            'group_id' => 'nullable',
            'request_group_id'=>'nullable',
        ];
        if($service != null && ($service->payment_plan_id == 1 || $service->payment_plan_id == 3) && $service->installment){
            $rules['subPayments.0.amount'] = 'required|integer|min:'.$min_amount.'|max:' . $amount;
            $rules['subPayments.0.payment_method_id'] = 'required';
            $rules['subPayments.0.reference_num'] = 'required_unless:subPayments.0.payment_method_id,1';
            $rules['subPayments.0.upload_bill'] = 'required_unless:subPayments.0.payment_method_id,1|image';
        }
        return $rules;
    }
}
