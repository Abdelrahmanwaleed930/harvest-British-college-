<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ResetPassword extends Mailable
{
    use Queueable, SerializesModels;

    public $resetCode; // Public property to store the reset code

    /**
     * Create a new message instance.
     *
     * @param  string  $resetCode
     * @return void
     */
    public function __construct($resetCode)
    {
        $this->resetCode = $resetCode; // Store the reset code
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject('Reset Your Password')
                    ->view('emails.resetpassword')
                    ->with(['resetCode' => $this->resetCode]); // Pass the reset code to the view
    }
}
