<?php

namespace App\Imports;

use DB;
use App\Models\Lead;
use App\Models\CustomerTrack;
use App\Models\Interval;
use App\Models\LeadPayment;
use App\Models\SubPayment;
use App\Models\OldCustomerPayment;
use App\Models\StageLevel;
use App\Models\GroupWaitingList;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\WithUpserts;
use Maatwebsite\Excel\Concerns\SkipsFailures;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;

class CustomerImport implements ToModel, SkipsEmptyRows, WithValidation, WithHeadingRow/*, WithUpserts*/
{
    use Importable, SkipsFailures;

    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function model(array $row)
    {
        //dd($row);
        if (!isset($row['name'])) {
            return null;
        }
        $check_lead = Lead::where('mobile_1',$row['mobile_1'])->first();
        
        if($check_lead != null && $check_lead != ''){
            
            $lead = $check_lead;
            if($lead->type == 1){
                $data = [
                    'first_branch_id' => $row['first_branch_id'],
                    'transfer_branch_id' => $row['transfer_branch_id'],
                    'type' => '2',
                    'old_customer' => 1,
                ];
                
                if($lead->branch_id != $row['current_branch_id']){
                    $data['branch_id'] = $row['current_branch_id'];
                    $data['first_branch_id'] = $lead->branch_id;
                }
                
                $lead->update($data);
            }
            
        }else{
            $data = [
                //'name'     => ['en' => $row['name'], 'ar' => $row['name']],
                'f_name' => $row['name'],
                'gender' => $row['gender'],
                'mobile_1' => $row['mobile_1'],
                'mobile_2' => $row['mobile_2'],
                'email' => $row['email'],
                'password' => 'Harvest@123',
                'lead_source_id' => $row['lead_source_id'],
                'know_channel_id' => $row['know_channel_id'],
                'first_branch_id' => $row['first_branch_id'],
                'branch_id' => $row['current_branch_id'],
                'transfer_branch_id' => $row['transfer_branch_id'],
                'notes' => $row['notes'],
                'assigned_employee_id' => $row['assigned_employee_id'],
                'register_from' => 'customer excel',
                'type' => '2',
                'old_customer' => 1,
            ];
            
            $lead = Lead::create($data);
        }
        
        $level = null;
        //dd(isset($row['current_level']),$row['current_level']);
        if(isset($row['current_level']) && $row['current_level'] !== ''){
            $level = StageLevel::leftJoin('stages','stages.id','=','stage_levels.stage_id')->where('stages.track_id',$row['sub_track_id'])->where('stage_levels.value',$row['current_level'])->select('stage_levels.*')->first();
            //dd($level);
            $checkGroupWaitingList = GroupWaitingList::where('lead_id',$lead->id)->first();
            $intervals_ids = [];
            $interval_timeframe = DB::table('interval_timeframe')->where('timeframe_id',$row['timeframe_id'])->pluck('interval_id')->toArray();
            if($row['interval'] == 'am'){
                $intervals_ids = Interval::whereIn('id',$interval_timeframe)->where('pattern','AM')->pluck('id')->toArray();
            }
            if($row['interval'] == 'pm'){
                $intervals_ids = Interval::whereIn('id',$interval_timeframe)->where('pattern','PM')->pluck('id')->toArray();
            }
                
            if($checkGroupWaitingList != null && $checkGroupWaitingList != ''){
                /*
                $checkGroupWaitingList->update([
                    'level_id' => $level->id,
                    'timeframes' => $row['timeframe_id'],
                    'intervals' => implode(',',$intervals_ids),
                    'discipline_id' => $row['discipline_id']
                ]);
                */
            }else{
                GroupWaitingList::create([
                    'lead_id' => $lead->id,
                    'track_id' => $row['track_id'],
                    'course_id' => $row['sub_track_id'],
                    'level_id' => $level->id,
                    'timeframes' => $row['timeframe_id'],
                    'intervals' => implode(',',$intervals_ids),
                    'discipline_id' => $row['discipline_id']
                ]);
            }
        }
        
        //dd($row['current_level'],$level);
        $customerTrack = CustomerTrack::where('lead_id',$lead->id)->first();
        
        if ($customerTrack){
            /*
            if($customerTrack->used == 0){
                $customerTrack->update([
                    'track_id' => $row['track_id'],
                    'course_id' => $row['sub_track_id'],
                    'level_id' => ($level != null)?$level->id:null,
                    'total' => $row['num_of_levels'],
                ]);
            }
            */
        }else{
            $customerTrack = CustomerTrack::create([
                'lead_id' => $lead->id,
                'track_id' => $row['track_id'],
                'course_id' => $row['sub_track_id'],
                'level_id' => ($level != null)?$level->id:null,
                'total' => $row['num_of_levels'],
                'used' => 0,
            ]);
        }
        
        $old_customer_payment = OldCustomerPayment::where('customer_id',$lead->id)->first();
        
        if($old_customer_payment != null && $old_customer_payment != ''){
            /*
            $old_customer_payment->update([
                'course_id' => $row['sub_track_id'],
                'level_id' => ($level != null)?$level->id:null,
                'harvest_certificate' => ($row['harvest_certificate'] == 'yes')?'1':'0',
                'cambridge_certificate' => ($row['cambridge_certificate'] == 'yes')?'1':'0',
                'books' => ($row['books'] == 'yes')?'1':'0'
            ]);
            */
        }else{
            $add = new OldCustomerPayment;
            $add->create([
                'customer_id' => $lead->id,
                'course_id' => $row['sub_track_id'],
                'level_id' => ($level != null)?$level->id:null,
                'harvest_certificate' => ($row['harvest_certificate'] == 'yes')?'1':'0',
                'cambridge_certificate' => ($row['cambridge_certificate'] == 'yes')?'1':'0',
                'books' => ($row['books'] == 'yes')?'1':'0'
            ]);
        }
        
        $check_payment = LeadPayment::where('lead_id',$lead->id)->first();
        if($check_payment != null && $check_payment != ''){
            /*
            $payment_data = [
                'lead_id' => $lead->id,
                //'employee_id' => $row['assigned_employee_id'],
                'amount' => $row['total_amount'],
                'include_books' => ($row['books'] == 'yes')?'1':'0',
            ];
            if($row['total_amount'] > $row['paid']){
                $payment_data['payment_plan_id'] = 3;
                $payment_data['rest'] = ($row['total_amount'] - $row['paid']);
            }else{
                $payment_data['payment_plan_id'] = 2;
                $payment_data['rest'] = 0;
            }
            $check_payment->update($payment_data);
            
            if($row['total_amount'] > $row['paid']){
                SubPayment::where('lead_payment_id',$check_payment->id)->delete();
                
                $deposit = new SubPayment;
                $deposit->create([
                    'lead_payment_id' => $check_payment->id,
                    'amount' => $row['paid'],
                    'payment_method_id' => 1,
                    'branch_id' => $lead->branch_id,
                    'due_date' => date('Y-m-d'),
                    'paid' => 1,
                ]);
                
                $sub_payment = new SubPayment;
                $sub_payment->create([
                    'lead_payment_id' => $check_payment->id,
                    'amount' => ($row['total_amount'] - $row['paid']),
                    'branch_id' => $lead->branch_id,
                    'due_date' => date('Y-m-d',strtotime('+ 7 days')),
                    'paid' => 0,
                ]);
            }
            */
        }else{
            $payment = new LeadPayment;
            $payment_data = [
                'lead_id' => $lead->id,
                //'employee_id' => $row['assigned_employee_id'],
                'amount' => $row['total_amount'],
                'include_books' => ($row['books'] == 'yes')?'1':'0',
            ];
            if($row['total_amount'] > $row['paid']){
                $payment_data['payment_plan_id'] = 3;
                $payment_data['rest'] = ($row['total_amount'] - $row['paid']);
            }else{
                $payment_data['payment_plan_id'] = 2;
                $payment_data['rest'] = 0;
            }
            
            $payment = $payment->create($payment_data);
            
            if($row['total_amount'] > $row['paid']){
                $deposit = new SubPayment;
                $deposit->create([
                    'lead_payment_id' => $payment->id,
                    'amount' => $row['paid'],
                    'payment_method_id' => 1,
                    'branch_id' => $lead->branch_id,
                    'due_date' => date('Y-m-d'),
                    'paid' => 1,
                ]);
                
                $sub_payment = new SubPayment;
                $sub_payment->create([
                    'lead_payment_id' => $payment->id,
                    'amount' => ($row['total_amount'] - $row['paid']),
                    'branch_id' => $lead->branch_id,
                    'due_date' => date('Y-m-d',strtotime('+ 7 days')),
                    'paid' => 0,
                ]);
            }
        }
        return ($lead->wasRecentlyCreated)?$lead:null;
    }

    public function rules(): array
    {
        /*
        return [
            'name' => 'required',
            'gender' => 'required',
            'branch_id' => 'required',
            'mobile_1' => 'required|digits:11|starts_with:0|unique:leads,mobile_1',
        ];
        */
        
        return [
            'name' => 'required|string',
            'gender' => 'required|string',
            'current_branch_id' => 'required|integer',
            'mobile_1' => 'required|digits:11|starts_with:0|unique:leads,mobile_1',
            'lead_source_id' => 'required|integer',
            //'assigned_employee_id' => 'required',
            'track_id' => 'required|integer',
            'sub_track_id' => 'required|integer',
            //'current_level' => 'required',
            'num_of_levels' => 'required|integer',
            'discipline_id' => 'required|integer',
            //'timeframe_id' => 'required',
            //'interval' => 'required',
            'harvest_certificate' => 'required|string',
            'cambridge_certificate' => 'required|string',
            'books' => 'required|string',
            'total_amount' => 'required|integer',
            'paid' => 'required|integer',
        ];
    }

    /**
     * @return string|array
     */
    /*
    public function uniqueBy()
    {
        return 'mobile_1';
    }
    */
    
}
