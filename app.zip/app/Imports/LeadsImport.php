<?php

namespace App\Imports;

use App\Models\Lead;
use App\Models\LeadSourceTrack;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\WithUpserts;
use Maatwebsite\Excel\Concerns\SkipsFailures;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Spatie\Activitylog\Contracts\Activity;
use Auth;
class LeadsImport implements ToModel, SkipsEmptyRows, WithValidation, WithHeadingRow, WithUpserts
{
    use Importable, SkipsFailures;

    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function model(array $row)
    {
        if (!isset($row['name'])) {
            return null;
        }
        
        $check = Lead::where('mobile_1',$row['mobile_1'])->first();
        // dd(date('Y-m-d h:i:sa'));
        if($check && $check != null){
             $source = $check->lead_source_id;
             $check->lead_source_id= 22;  
             $check->created_at= date('Y-m-d h:i:sa');  
             $check->prefered_track_id = $row['prefered_track_id'];  
             $check->save();
             return new LeadSourceTrack([
                'lead_id' => $check->id,
                'lead_source_b_id' => $source,
                'lead_source_a_id' => $row['lead_source_id'],
                'lead_source_c_id' => $check->lead_source_id,
                'branch_id' => $check->branch_id,
                'employee_id' => Auth::user()->id, 
                'track_id' => $row['prefered_track_id'],
                ]);
            
        }else{
            return new Lead([
            //'name'     => ['en' => $row['name'], 'ar' => $row['name']],
            'f_name' => $row['name'],
            'gender' => $row['gender'],
            'mobile_1' => $row['mobile_1'],
            'mobile_2' => $row['mobile_2'],
            'email' => $row['email'],
            'password' => 'Harvest@123',
            'preferred_time' => $row['preferred_time'],
            'lead_source_id' => $row['lead_source_id'],
            'know_channel_id' => $row['know_channel_id'],
            'prefered_track_id' => $row['prefered_track_id'],
            'offer_id' => $row['offer_id'],
            'branch_id' => $row['branch_id'],
            'training_service_id' => $row['training_service_id'],
            'timeframe_id' => $row['timeframe_id'],
            //'pt_level' => $row['pt_level'],
            'notes' => $row['notes'],
            'assigned_employee_id' => $row['assigned_employee_id'],
            'register_from' => 'excel',
        ]);
        }
        
         activity('Excel Leads')
            ->causedBy(Auth::user()->id)
            ->performedOn($check)
            ->log('Excel Lead');
        //return ($lead->wasRecentlyCreated)?$lead:null;
    }

    public function rules(): array
    {
        /*
        return [
            'name' => 'required',
            'gender' => 'required',
            'branch_id' => 'required',
            'mobile_1' => 'required|digits:11|starts_with:0|unique:leads,mobile_1',
        ];
        */
        
        return [
            'name' => 'required',
            'gender' => 'required',
            'branch_id' => 'required',
            'prefered_track_id' => 'required',
            'mobile_1' => 'required|digits:11|starts_with:0',
        ];
    }

    /**
     * @return string|array
     */
    
    public function uniqueBy()
    {
        return 'mobile_1';
    }
    
}
