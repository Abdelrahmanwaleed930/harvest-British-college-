<?php

namespace App\Imports;

use App\Models\JobApplication;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\WithUpserts;
use Maatwebsite\Excel\Concerns\SkipsFailures;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;

class JobsApplicationsImport implements ToModel, SkipsEmptyRows, WithValidation, WithHeadingRow, WithUpserts
{
    use Importable, SkipsFailures;

    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function model(array $row)
    {
        if (!isset($row['full_name'])) {
            return null;
        }
        //dd($row);
        //$check = JobApplication::where()
        return new JobApplication([
            'full_name' => $row['full_name'],
            'phone' => $row['phone'],
            'email' => $row['email'],
            'age' => $row['age'],
            'english_level' => $row['english_level'],
            'job_id' => $row['job_id'],
            'branch_id' => $row['branch_id'],
            'assigned_employee_id' => $row['assigned_employee_id'],
            'status' => $row['status'],
            'register_from' => 'excel',
            
        ]);
        
        //return ($lead->wasRecentlyCreated)?$lead:null;
    }

    public function rules(): array
    {
        
        return [
            'full_name' => 'required',
            // 'email' => 'required',
            //'branch_id' => 'required',
            'job_id' => 'required',
            'phone' => 'required|regex:/(^[0-9]*$)/u|unique:jobs_applications,phone',
        ];
    }

    /**
     * @return string|array
     */
    
    public function uniqueBy()
    {
        return 'phone';
    }
    
}
