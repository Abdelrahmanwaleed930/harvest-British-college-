<?php

namespace App\Imports;

use App\Models\EmployeeFingerPrint;
use App\Models\EmployeeFingers;
use App\Models\Branch;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\WithUpserts;
use Maatwebsite\Excel\Concerns\SkipsFailures;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Spatie\Activitylog\Contracts\Activity;
use Auth;
class Finger implements ToModel, SkipsEmptyRows, WithValidation, WithHeadingRow, WithUpserts
{
    use Importable, SkipsFailures;

    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function model(array $row)
    {
        
        
        $date = date('Y-m-d', strtotime($row['date']));
        
        $time = date('H:i:s', strtotime($row['date']));
        $finger = EmployeeFingers::where('employee_finger_id' , $row['employee_fingerprint_id'])->first();
        $branch = Branch::where('finger_id',$row['branch_fingerprint_id'])->first();
        
        return new EmployeeFingerPrint([
            'employee_id' => $finger->employee_id,
            'date' => $date,
            'time' => $time,
            'branch_id' => $branch->id,
            'employee_fingerprint_id' => $row['employee_fingerprint_id'],
            'branch_fingerprint_id' => $row['branch_fingerprint_id'],
            
        ]);
        
        
        
         activity('Excel Finger')
            ->causedBy(Auth::user()->id)
            ->performedOn($row['employee_id'])
            ->log('Excel Finger');
        //return ($lead->wasRecentlyCreated)?$lead:null;
    }

    public function rules(): array
    {
        
        
        return [
            'date' => 'required',
            //'employee_id' => 'nullable',
            //'branch_id' => 'nullable',
            'employee_fingerprint_id' => 'required',
            'branch_fingerprint_id' => 'required',
            
        ];
    }

    /**
     * @return string|array
     */
    
    public function uniqueBy()
    {
        // return 'mobile_1';
    }
    
}
