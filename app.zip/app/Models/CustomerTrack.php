<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CustomerTrack extends Model
{

    public $table = 'customer_tracks';

    public $fillable = [
        'lead_id',
        'track_id',
        'course_id',
        'level_id',
        'total',
        'used',
        //'pt_level',
        'last_level_id',
        'last_group_id',
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function lead()
    {
        return $this->belongsTo(\App\Models\Lead::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function track()
    {
        return $this->belongsTo(\App\Models\Track::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function course()
    {
        return $this->belongsTo(\App\Models\Track::class, 'course_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function level()
    {
        return $this->belongsTo(\App\Models\StageLevel::class, 'level_id');
    }
    public function getLastGroup(): BelongsTo
    {
        return $this->belongsTo(Group::class,'last_group_id','id')->with('instructor');
    }

    public function getLastLevel(): BelongsTo
    {
        return $this->belongsTo(StageLevel::class,'last_level_id','id');
    }
    
    public function getCurrentLevelNameAttribute()
    {
        //$check_in_groups = GroupStudent::where('lead_id',$this->id)->orderBy('id','desc')->first();
        $groups = GroupStudent::where('lead_id',$this->lead_id)->pluck('group_id');
        $check_in_groups = Group::whereIn('id',$groups)->orderBy('level_id','desc')->first();
        $pt = PlacementApplicant::where('lead_id',$this->lead_id)->where('track_id',$this->track_id)->first();
        if($this->type == 3 && $check_in_groups != null && $check_in_groups != ''){
            return $check_in_groups->level->name;
        }else{
            $group_waiting_lead = GroupWaitingList::where('lead_id',$this->lead_id)->where('track_id',$this->track_id)->first();
            if($group_waiting_lead != null && $group_waiting_lead != ''){
                return $group_waiting_lead->level->name;
            }elseif($pt->level !== null && $pt->level !== ''){
                return PlacementApplicant::$PT_levels[$pt->level];
            }else{
                return "";
            }
        }
    }
    
    public function getCurrentLevelIdAttribute()
    {
        // $check_in_groups = GroupStudent::where('lead_id',$this->id)->orderBy('id','desc')->first();
        $groups = GroupStudent::where('lead_id',$this->lead_id)->pluck('group_id');
        $check_in_groups = Group::whereIn('id',$groups)->orderBy('level_id','desc')->first();
        $pt = PlacementApplicant::where('lead_id',$this->lead_id)->where('track_id',$this->track_id)->first();
        if($check_in_groups != null && $check_in_groups != ''){
            return $check_in_groups->level->id;
        }else{
            $group_waiting_lead = GroupWaitingList::where('lead_id',$this->lead_id)->where('track_id',$this->track_id)->first();
            
            if($group_waiting_lead != null && $group_waiting_lead != ''){
                return $group_waiting_lead->level->id;
            }elseif($pt !== null && $pt !== ''){
                $stage_level = StageLevel::where('value',$pt->level)->with('stage')->first();
                return $stage_level->id;
            }else{
                return null;
            }
        }
    }
}
