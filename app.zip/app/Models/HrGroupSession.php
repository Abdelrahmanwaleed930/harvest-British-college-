<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class HrGroupSession extends Model
{
    use HasFactory;
     protected $table ='hr_group_sessions';
     public $fillable = [
        'hr_group_id',
        'date',
        'trainer_id',
    ];
    public function hr_group_session_attendance() : HasMany {
        return $this->hasMany(HrGroupSessionAttendance::class,'hr_group_session_id');
    }
     public function hr_group()
    {
        return $this->belongsTo(HrGroups::class,'hr_group_id');
    }
    public function employee()
    {
        return $this->belongsTo(Employee::class,'trainer_id');
    }
    
}
