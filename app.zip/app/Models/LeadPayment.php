<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;


/**
 * Class LeadPayment
 * @package App\Models
 * @version July 11, 2021, 4:03 am UTC
 *
 * @property \App\Models\PaymentMethod $paymentMethod
 * @property integer $lead_id
 * @property integer $paymentable_type
 * @property integer $paymentable_id
 * @property integer $amount
 * @property integer $payment_plan_id
 */
class LeadPayment extends Model
{
    use SoftDeletes;

    public $table = 'lead_payments';

    protected $dates = ['deleted_at'];

    public $fillable = [
        'branch_id',
        'track_id',
        'lead_id',
        'employee_id',
        'owner_id',
        'paymentable_type',
        'paymentable_id',
        'amount',
        'discount',
        'rest',
        'invoice_pdf',
        'payment_plan_id',
        'group_id',
        'request_group_id',
        'print_count',
        'include_books',
        'payment_method_id',
        'reference_num',
        'upload_bill',
        'payment_status',
        'payment_method',
        'merchantRefNumber',
        'fawryFees',
        'platform',
        'lead_type',
        'invoice_id',
        'expire_date',
        'track_id',
        'type',
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    
    public function updatePaymentStatus($payment_status,$reference_num = null)
    {
        
        if($this->merchantRefNumber != null && $this->merchantRefNumber != ''){
            $this->payment_status = $payment_status;
            $this->reference_num = $reference_num;
            $this->save();
            
            $sub_payments = $this->subPayments;
            if($sub_payments != null && count($sub_payments) > 0){
                foreach($sub_payments as $sub_payment){
                    if($sub_payment->merchantRefNumber != null && $sub_payment->merchantRefNumber != ''){
                        $sub_payment->payment_status = $payment_status;
                        $sub_payment->reference_num = $reference_num;
                        $sub_payment->save();
                    }
                }
            }
        }else{
            
            $sub_payments = $this->subPayments;
            if($sub_payments != null && $sub_payments){
                foreach($sub_payments as $sub_payment){
                    if($sub_payment->merchantRefNumber != null && $sub_payment->merchantRefNumber != ''){
                        $sub_payment->payment_status = $payment_status;
                        $sub_payment->reference_num = $reference_num;
                        $sub_payment->save();
                    }
                }
            }
        }

    }
    public function branch()
    {
        return $this->belongsTo(\App\Models\Branch::class);
    }
    
    public function lead()
    {
        return $this->belongsTo(\App\Models\Lead::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function employee()
    {
        return $this->belongsTo(\App\Models\Employee::class,'employee_id');
    }
    public function Owner()
    {
        return $this->belongsTo(\App\Models\Employee::class,'owner_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function paymentPlan()
    {
        return $this->belongsTo(\App\Models\PaymentPlan::class);
    }
    
    public function paymentMethod()
    {
        return $this->belongsTo(\App\Models\PaymentMethod::class,'payment_method_id','id');
    }

    /**
     * Get all of the subPayments for the LeadPayment
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function subPayments(): HasMany
    {
        return $this->hasMany(SubPayment::class);
    }

    /**
     * Get the group that owns the LeadPayment
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function group(): BelongsTo
    {
        return $this->belongsTo(Group::class);
    }

    /**
     * Get the parent paymentable model (service fees or extra items or offers).
     */
    public function paymentable()
    {
        return $this->morphTo();
    }
    public function track()
    {
        return $this->belongsTo(\App\Models\Track::class);
    }
}
