<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Notifications\Notifiable;
use DB;

/**
 * Class Lead
 * @package App\Models
 * @version May 8, 2021, 1:27 pm UTC
 *
 * @property string $name
 * @property string $gender
 * @property string $mobile_1
 * @property string $mobile_2
 * @property string $email
 * @property string $preferred_time
 * @property integer $lead_source_id
 * @property integer $know_channel_id
 * @property integer $offer_id
 * @property integer $branch_id
 * @property integer $training_service_id
 * @property string $notes
 * @property integer $assigned_employee_id
 * @property string $nationality
 * @property string $identification
 * @property string $dob
 * @property string $country
 * @property string $governorate
 * @property string $city
 * @property string $university
 * @property string $customer_jop
 * @property string $workplace
 * @property string $full_address
 */
class Lead extends Authenticatable implements JWTSubject
{
    use SoftDeletes;
    use HasFactory, Notifiable;

    public $table = 'leads';
    public static $lead_type = ["1" => "lead","2" => "customer","3" => "client" ,"4" => "Graduate"];
    public static $PT_levels = [
                        "-1" => "Scratch",
                        "0" => "Starter",
                        "1" => "Level 1",
                        "2" => "Level 2",
                        "3" => "Level 3",
                        "4" => "Level 4",
                        "5" => "Level 5",
                        "6" => "Level 6",
                        "7" => "Level 7",
                        "8" => "Level 8",
                        "9" => "Level 9",
                        "10" => "Level 10",
                        "11" => "Level 11",
                        "12" => "Level 12",
                        "13" => "Stage 1",
                        "14" => "Stage 2",
                        "15" => "Stage 3",
                        "16" => "Stage 4",
                        "17" => "Kidzy Diploma 1",
                        "18" => "Kidzy Diploma 2",
                        "19" => "TOEFL",
                        "20" => "TEFL",
                        "21" => "IELTS",
                        "30" => "Dutch Lv1",
                        "31" => "Dutch Lv2",
                        "32" => "Dutch Lv3",
                        "33" => "Dutch Lv4",
                        "34" => "Dutch Lv5",
                        "35" => "Dutch Lv6",
                        "36" => "Dutch Lv7",
                        "37" => "Dutch Lv8",
                        "38" => "Dutch Lv9",
                        "39" => "Dutch Lv10",
                        "40" => "Dutch Lv11",
                        "41" => "Dutch Lv12",
                        
                        
                    ];
    
    public static $PT_levels_ids = [
                        "-1" => [2,98],
                        "0" => [2,99],
                        "1" => [2,100],
                        "2" => [2,101],
                        "3" => [2,102],
                        "4" => [2,103],
                        "5" => [2,104],
                        "6" => [2,105],
                        "7" => [2,106],
                        "8" => [2,107],
                        "9" => [2,108],
                        "10" => [2,109],
                        "11" => [2,110],
                        "12" => [2,111],
                        "13" => [13,112],
                        "14" => [13,113],
                        "15" => [13,114],
                        "16" => [13,115],
                        "17" => [3,116],
                        "18" => [3,117],
                        "19" => [5,95],
                        "20" => [6,96],
                        "21" => [4,97],
                        "30" => [15,149],
                        "31" => [15,150],
                        "32" => [15,151],
                        "33" => [15,152],
                        "34" => [15,153],
                        "35" => [15,154],
                        "36" => [15,155],
                        "37" => [15,156],
                        "38" => [15,157],
                        "39" => [15,158],
                        "40" => [15,159],
                        "41" => [15,160],
                        
                    ];

    protected $dates = ['deleted_at'];

    public $fillable = [
        'name',
        'type',
        'old_customer',
        'gender',
        'preferred_type',
        'mobile_1',
        'f_name',
        'l_name',
        'm_name',
        'name_ar',
        'name_en',
        'mobile_2',
        'email',
        'password',
        'preferred_time',
        'lead_source_id',
        'know_channel_id',
        'offer_id',
        'first_branch_id',
        'branch_id',
        'transfer_branch_id',
        'training_service_id',
        'timeframe_id',
        'notes',
        'reset_code',
        'last_resent_time',
        'assigned_employee_id',
        'remember_token',
        'register_from',
        'nationality',
        'identification',
        'identificationp',
        'identification_type',
        'dob',
        'country',
        'governorate',
        'city',
        'university',
        'customer_jop',
        'workplace',
        'address',
        'image',
        'prefer_branch_id',
        'prefered_track_id',
        'prefer_discipline_id',
        'device_token',
        'trans_customer',
        'customer_to_client',
        'customer_type',
        'approve',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];
    
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }
    
    public function getOldCustomerPayment()
    {
        return $this->hasOne(OldCustomerPayment::class,'customer_id');
    }
    
   public function freeCertificate($certificate_id)
{
    if ($this->payments != null && count($this->payments) > 0) {
        foreach ($this->payments as $payment) {
            if ($payment->paymentable_type == 'App\\Models\\Offer') {
                // Find the offer and check if it's null
                $offer = Offer::find($payment->paymentable_id);
                
                if ($offer !== null) {
                    $offer_certificate = $offer->items->where('id', $certificate_id)->first();
                    if ($offer_certificate != null && $offer_certificate != '') {
                        return 0;
                    }
                } else {
                    // Handle the case where the offer is not found, if necessary
                }
                
            } elseif ($payment->paymentable_type == 'App\\Models\\ExtraItem' && $payment->paymentable_id == $certificate_id) {
                return 0;
            } else {
                // Handle other cases, if necessary
            }
        }
    } else {
        if ($certificate_id == 2 && $this->getOldCustomerPayment != null && $this->getOldCustomerPayment->harvest_certificate == 1) {
            return 0;
        }
        if ($certificate_id == 3 && $this->getOldCustomerPayment != null && $this->getOldCustomerPayment->cambridge_certificate == 1) {
            return 0;
        }
    }
    return 1;
}

    public function freeBooksCount($levels_count)
{
    $free_books_count = 0;
    if ($this->payments != null && count($this->payments) > 0) {
        foreach ($this->payments as $payment) {
            if ($payment->paymentable_type == 'App\\Models\\Offer') {
                $offer = Offer::find($payment->paymentable_id);
                
                // Check if the offer was found
                if ($offer !== null) {
                    if ($offer->include_books == 1) {
                        $free_books_count += $offer->num_levels;
                    } else {
                        $offer_items = $offer->items->where('item_category_id', 1);
                        $free_books_count += count($offer_items);
                    }
                } else {
                    // Handle the case where the offer is not found, if necessary
                }
            } elseif ($payment->paymentable_type == 'App\\Models\\ExtraItem' && in_array($payment->paymentable_id, [4, 5, 6, 7, 8, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25])) {
                $free_books_count += 1;
            } elseif ($payment->paymentable_type == null && $payment->include_books == 1) {
                if ($free_books_count == 0) {
                    $free_books_count += $levels_count;
                }
            } else {
                // Handle other cases, if necessary
            }
        }
    }
    return $free_books_count;
}

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }
    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'name' => 'array',
        'f_name' => 'string',
        'l_name' => 'string',
        'm_name' => 'string',
        'name_ar' => 'string',
        'name_en' => 'string',
        'type' => 'integer',
        'gender' => 'string',
        'mobile_1' => 'string',
        'mobile_2' => 'string',
        'email' => 'string',
        'preferred_time' => 'string',
        'lead_source_id' => 'integer',
        'know_channel_id' => 'integer',
        'offer_id' => 'integer',
        'first_branch_id' => 'integer',
        'branch_id' => 'integer',
        'transfer_branch_id' => 'integer',
        'training_service_id' => 'integer',
        'notes' => 'string',
        'assigned_employee_id' => 'integer',
        'nationality' => 'string',
        'identification' => 'string',
        'identification_type' => 'string',
        'identificationp'=>'string',

        'dob' => 'date',
        'country' => 'string',
        'governorate' => 'string',
        'city' => 'string',
        'university' => 'string',
        'customer_jop' => 'string',
        'workplace' => 'string',
        'address' => 'string',
        'prefer_branch_id'=>'integer',
        'prefer_discipline_id'=>'integer',
        'prefered_track_id'=>'integer',

    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'f_name' => 'required|regex:/(^([a-zA-Z\s]+)(\d+)?$)/u',
        'l_name' => 'required|regex:/(^([a-zA-Z\s]+)(\d+)?$)/u',
        'm_name' => 'required|regex:/(^([a-zA-Z\s]+)(\d+)?$)/u',
        'name_ar' => 'required',
        //'name.en' => 'required|regex:/(^([a-zA-Z\s]+)(\d+)?$)/u',
        //'name.ar' => 'required',
        'gender' => 'required',
        'preferred_type' => 'nullable',
        'mobile_1' => 'required|string',
        'mobile_2' => 'nullable|string|unique:leads,mobile_1',
        'email' => 'nullable|email',
        'lead_source_id' => 'required',
        'know_channel_id' => 'required',
        'prefered_track_id' => 'required',
        'preferred_time' => 'nullable',
        'offer_id' => 'nullable',
        'branch_id' => 'required',
        'training_service_id' => 'nullable',
        'timeframe_id' => 'nullable',
        'prefer_branch_id'=>'nullable',
        'prefer_discipline_id'=>'nullable',
        'identification_type' => 'nullable|string',
        'identification' => 'nullable|string',
        
    ];

    /**
     * Set password encryption.
     *
     * @param String $val
     * @return void
     */
    public function setPasswordAttribute($val)
    {
        if ($val) {
            $this->attributes['password'] = bcrypt($val);
        }
    }
    
    public function invoices()
    {
        return $this->hasMany(Invoice::class);
    }
    public function getLastGroup(): BelongsTo
    {
        return $this->belongsTo(Group::class,'last_group_id','id')->with('instructor');
    }

    public function getLastLevel(): BelongsTo
    {
        return $this->belongsTo(StageLevel::class,'last_level_id','id');
    }
    
    public function getName()
    {
        if($this->f_name || $this->m_name || $this->l_name){
            return $this->f_name.' '.$this->m_name.' '.$this->l_name;
        }elseif(isset($this->name['en'])){
            return $this->name['en'];
        }else{
            return 'name not setting';
        }
    }

    /**
     * Get the lead source that owns the Lead
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function lead_source(): BelongsTo
    {
        return $this->belongsTo(LeadSource::class);
    }
    
    // public function getconfirmation()
    // {
    //     return GroupStudent::where('lead_id',$this->id)->first();
    // }
    
    public function getCurrentGroupAttribute()
    {
        // $group_student = DB::table('group_students')->where('lead_id',$this->id)->orderBy('id','desc')->first();
        // $group = DB::table('groups')->select('id','code')->where('id',$group_student->group_id)->first();
        //dd($group->toArray());
        // return $this->groups->sortByDesc('id')->first();
        
        $groups = GroupStudent::where('lead_id',$this->id)->pluck('group_id');
        $check_in_groups = Group::whereIn('id',$groups)->orderBy('level_id','desc')->first();
        return $check_in_groups;
    }
    
    public function getWaitingList(): HasOne
    {
        return $this->hasOne(GroupWaitingList::class);
    }
    
    public function checkWaitingList($track)
    {
        return GroupWaitingList::where('lead_id',$this->id)->where('track_id',$track)->first();
    }
    
    
    public function getRecommenedGroups($waiting_list)
    {
        $groups = [];
        
        if($waiting_list){
            $groupQuery = Group::with('level', 'students', 'discipline','branch','timeframe','track' ,'round','subRound','interval')->
            whereHas('subRound',function($query){
                $query->where('end_date','>=',date('Y-m-d'));
            })->where('level_id',$waiting_list->level_id)->where('track_id',$waiting_list->track_id); 
            
            if($waiting_list->discipline_id != null && $waiting_list->discipline_id != ''){
               $groupQuery->where('discipline_id',$waiting_list->discipline_id);
            }
            if($waiting_list->timeframes != null && $waiting_list->timeframes != ''){
                $groupQuery->whereIn('timeframe_id',explode(',',$waiting_list->timeframes));
            }
            /*
            if($waiting_list->intervals != null && $waiting_list->intervals != ''){
                $groupQuery->whereIn('interval_id',explode(',',$waiting_list->intervals));
            }
            */
            $groups = $groupQuery->with('course','timeframe','subRound','discipline','branch','instructor','interval')->withCount('students')->get(); 
        
            //dd($groups);
        }
        return $groups;
    }
    
    
    public function checktrack($track)
    {
        return CustomerTrack::where('lead_id',$this->id)->where('track_id',$track)->first();
    }
    
    
    
    public function hasInquiry()
    {
        $labelTypes = LabelType::where('status', 1)->where('category', 4)->pluck('name', 'id')->toArray();
        
        $has = LeadCase::where('lead_id',$this->id)->whereIn('label_type_id',array_keys($labelTypes))->where('status',0)->first();
        return ($has != null && $has != '')?true:false;
    }
    
    public function getNationality(): BelongsTo
    {
        return $this->belongsTo(Country::class,'nationality','id');
    }
    
    public function getCountry(): BelongsTo
    {
        return $this->belongsTo(Country::class,'country','id');
    }
    
    public function Track(): BelongsTo
    {
        return $this->belongsTo(Track::class,'prefered_track_id');
    }
    
    public function getGovernorate(): BelongsTo
    {
        return $this->belongsTo(Governorate::class,'governorate','id');
    }
    
    public function getCity(): BelongsTo
    {
        return $this->belongsTo(City::class,'city','id');
    }
    
    public function getUniversity(): BelongsTo
    {
        return $this->belongsTo(University::class,'university','id');
    }
    
    public function getCustomerJob(): BelongsTo
    {
        return $this->belongsTo(CustomerJob::class,'customer_jop','id');
    }

    /**
     * Get the know channel that owns the Lead
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function know_channel(): BelongsTo
    {
        return $this->belongsTo(KnowChannel::class);
    }

    /**
     * Get the offer that owns the Lead
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function offer(): BelongsTo
    {
        return $this->belongsTo(Offer::class);
    }

    /**
     * Get the branch that owns the Lead
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class,'branch_id');
    }
    public function prefer_branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class,'prefer_branch_id');
    }
    
    public function transfer_branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class,'transfer_branch_id');
    }
    public function first_branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class,'first_branch_id');
    }
    public function descipline()
    {
        return  $this->belongsTo(DisciplineCategory::class,'prefer_discipline_id');
    }

    /**
     * Get the training service that owns the Lead
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function training_service(): BelongsTo
    {
        return $this->belongsTo(TrainingService::class);
    }

    /**
     * Get the training service that owns the Lead
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function timeframe(): BelongsTo
    {
        return $this->belongsTo(Timeframe::class);
    }

    /**
     * Get the assignedEmployee that owns the Lead
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function assignedEmployee(): BelongsTo
    {
        return $this->belongsTo(Employee::class, 'assigned_employee_id');
    }

    /**
     * Get all of the cases for the Lead
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function cases(): HasMany
    {
        return $this->hasMany(LeadCase::class);
    }
    public function GroupStudent(): HasMany
    {
        return $this->hasMany(GroupStudent::class);
    }
    
    public function lastcase(): HasOne
    {
        return $this->hasOne(LeadLastCase::class)->with('labelType');
    }
    
    public function lastFollowup($type)
    {
        $label_types = LabelType::where('category',$type)->pluck('id')->toArray();
        
        return LeadLastCase::where('lead_id',$this->id)->whereIn('label_type_id',$label_types)->orderBy('updated_at','desc')->first();
    }
    // public function LeadLastCase()
    // {

    // }
    
    
    /**
     * Get all of the payments for the Lead
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function payments(): HasMany
    {
        return $this->hasMany(LeadPayment::class);
    }
    

    /**
     * The groups that belong to the Lead
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function groups(): BelongsToMany
    {
        return $this->belongsToMany(Group::class, 'group_students', 'lead_id', 'group_id')->withPivot('books','payment','exam_per','exam_status','id','lead_id','Confirmation')->orderBy('group_students.id','desc');
    }

 

    /**
     * Get all of the attendances for the GroupSession
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function attendances(): HasMany
    {
        return $this->hasMany(GroupSessionAttendance::class,'lead_id');
    }

    /**
     * Get all of the customerTracks for the Lead
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function customerTracks(): HasMany
    {
        return $this->hasMany(CustomerTrack::class,'lead_id');
    }
    public function checkcustomertrack()
    {
        return CustomerTrack::where('lead_id',$this->id)->first();
    }
   
    public function getPT($track = null)
    {
        $pt = PlacementApplicant::where('lead_id',$this->id)->where('track_id',(($track)?$track:1))->first();
        
        return $pt;
    }
    
    
    public function getKidsPT($track = null)
    {
        $pt = PlacementKidsApplicant::where('lead_id',$this->id)->where('track_id',(($track)?$track:1))->first();
        
        return $pt;
    }
    
    public function checkAdultPT($track)
    {
        $pt = PlacementApplicant::where('lead_id',$this->id)->where('track_id',$track)->first();
        
        return $pt;
    }
    
    
    public function checkKidsPT($track)
    {
        $pt = PlacementKidsApplicant::where('lead_id',$this->id)->where('track_id',$track)->first();
        
        return $pt;
    }
    
    public function checkPT($track)
    {
        $pt = PlacementApplicant::where('lead_id',$this->id)->where('track_id',$track)->first();
        if(! $pt){
            $pt = PlacementKidsApplicant::where('lead_id',$this->id)->where('track_id',$track)->first();
        }
        return $pt;
    }
    
    public function checkgrade(){
        $grade = GroupStudent::where('lead_id',$this->id)->WhereNotNull('exam_per')->WhereNotNull('exam_status')->orderBy('id','desc')->first();
        return $grade;
        
    }
   
}
