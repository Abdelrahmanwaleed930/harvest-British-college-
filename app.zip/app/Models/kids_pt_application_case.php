<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class kids_pt_application_case extends Model
{
    public $table = 'kids_pt_applications_case';

    public $fillable = [
        'kids_pt_application_id',
        'employee_id',
        'label_type_id',
        'branch_id',
        'follow_up_type',
        'serial',
        'call_type',
        'feedback_id',
        'other_feedback',
        'feedback_date',
        'action_id',
        'other_action',
        'note',
        'status',
        'date'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'kids_pt_application_id' => 'required',
        'label_type_id' => 'required',
        'follow_up_type' => 'required',
        'call_type' => 'required',
        'branch_id' => 'required',
        'feedback_id' => 'required',
        'other_feedback' => 'required_if:feedback,other',
        'action_id' => 'required',
        'other_action' => 'required_if:action,other',
        'note' => 'required',
        'date' => 'required|date_format:Y-m-d',
        'feedback_date' => 'required|date_format:Y-m-d',
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function pt_application()
    {
        return $this->belongsTo(\App\Models\PlacementKidsApplicant::class,'kids_pt_application_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function employee()
    {
        return $this->belongsTo(\App\Models\Employee::class);
    }
    
    public function branch()
    {
        return $this->belongsTo(\App\Models\Branch::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function label()
    {
        return $this->belongsTo(\App\Models\Label::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function labelType()
    {
        return $this->belongsTo(\App\Models\LabelType::class,'label_type_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function feedback()
    {
        return $this->belongsTo(\App\Models\Feedback::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function action()
    {
        return $this->belongsTo(\App\Models\Action::class);
    }
    
}
