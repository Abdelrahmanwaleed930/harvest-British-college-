<?php

namespace App\Models;

use Eloquent as Model;

/**
 * Class Stage
 * @package App\Models
 * @version June 13, 2021, 8:39 pm UTC
 *
 * @property \App\Models\Track $track
 * @property integer $track_id
 * @property string $name
 */
class Video extends Model
{

    public $table = 'videos';

    public $fillable = [
        'title_en',
        'title_ar',
        'video',
        'status',
        'views',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'status' => 'integer',
        'views' => 'integer',
        'title_en' => 'string',
        'title_ar' => 'string',
        'video' => 'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'status' => 'required',
        'views' => 'required',
        'title_en' => 'required',
        'title_ar' => 'required',
        'video' => 'required',
    ];

}
