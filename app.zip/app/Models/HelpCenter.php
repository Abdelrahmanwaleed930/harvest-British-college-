<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HelpCenter extends Model
{
    protected $table = 'help_center'; // Update to match the actual table name
    protected $fillable = [
        'title', 'video_url', 'description', 'parent_id'
    ];

    public function parent()
    {
        return $this->belongsTo(HelpCenter::class, 'parent_id');
    }
    public function children()
    {
        return $this->hasMany(HelpCenter::class, 'parent_id')->with('children');
    }
}