<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

use Illuminate\Database\Eloquent\SoftDeletes;


/**
 * Class PlacementApplicant
 * @package App\Models
 * @version May 28, 2021, 1:51 pm UTC
 *
 * @property string $name
 * @property string $email
 * @property string $mobile
 * @property string $gender
 * @property string $job
 * @property string $university
 * @property number $vocabulary_score
 * @property number $grammar_score
 * @property number $reading_score
 * @property number $writing_score
 * @property number $listening_score
 * @property number $speaking_score
 * @property integer $level
 * @property string $notes
 * @property integer $status
 */
class PlacementApplicant extends Model
{
     use SoftDeletes;

    public $table = 'placement_applicants';
    
    protected $dates = ['deleted_at'];

    public static $PT_levels = [
                        "-1" => "Scratch",
                        "0" => "Starter",
                        "1" => "Level 1",
                        "2" => "Level 2",
                        "3" => "Level 3",
                        "4" => "Level 4",
                        "5" => "Level 5",
                        "6" => "Level 6",
                        "7" => "Level 7",
                        "8" => "Level 8",
                        "9" => "Level 9",
                        "10" => "Level 10",
                        "11" => "Level 11",
                        "12" => "Level 12",
                        "13" => "Stage 1",
                        "14" => "Stage 2",
                        "15" => "Stage 3",
                        "16" => "Stage 4",
                        "30" => "Dutch Lv1",
                        "31" => "Dutch Lv2",
                        "32" => "Dutch Lv3",
                        "33" => "Dutch Lv4",
                        "34" => "Dutch Lv5",
                        "35" => "Dutch Lv6",
                        "36" => "Dutch Lv7",
                        "37" => "Dutch Lv8",
                        "38" => "Dutch Lv9",
                        "39" => "Dutch Lv10",
                        "40" => "Dutch Lv11",
                        "41" => "Dutch Lv12",
                        
                    ];
    


    public $fillable = [
        'name',
        'email',
        'mobile',
        'branch_id',
        'lead_id',
        'track_id',
        'instructor_id',
        'gender',
        'job',
        'university',
        'vocabulary_score',
        'grammar_score',
        'reading_score',
        'writing_score',
        'listening_score',
        'speaking_score',
        'level',
        'notes',
        'status',
        'finish',
        'finish_date',
        'remain_duration'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'lead_id' => 'integer',
        'track_id' => 'integer',
        'remain_duration' => 'integer',
        'name' => 'string',
        'email' => 'string',
        'mobile' => 'string',
        'gender' => 'string',
        'job' => 'string',
        'university' => 'string',
        'vocabulary_score' => 'decimal:1',
        'grammar_score' => 'decimal:1',
        'reading_score' => 'decimal:1',
        'listening_score' => 'decimal:1',
        'speaking_score' => 'decimal:1',
        'writing_score' => 'decimal:1',
        'level' => 'integer',
        'notes' => 'string',
        'status' => 'string',
        'finish' => 'string',
        'finish_date' => 'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        // 'vocabulary_score' => 'numeric|between:0,99.5',
        // 'grammar_score' => 'numeric|between:0,99.5',
        // 'reading_score' => 'numeric|between:0,99.5',
        'writing_score' => 'numeric|between:0,99.5',
        'listening_score' => 'numeric|between:0,99.5',
        'speaking_score' => 'numeric|between:0,99.5',
        'level' => 'integer'
    ];

    /**
     * Get the branch that owns the PlacementApplicant
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }
    public function lead()
    {
        return $this->belongsTo(Lead::class ,'lead_id');
    }
    public function track()
    {
        return $this->belongsTo(Track::class ,'track_id');
    }
    
    public function getLead()
    {
        return Lead::where('mobile_1',$this->mobile)->first();
    }
    
    public function getstatus($id){
        if($id == 1){
            return Lead::where('mobile_1',$this->mobile)->where('type',1)->get()->count();
        }elseif($id == 2){
            return Lead::where('mobile_1',$this->mobile)->where('type',2)->get()->count();
        }elseif($id == 3){
            return Lead::where('mobile_1',$this->mobile)->where('type',3)->get()->count();
        }
    }
    
    public function instructor(): BelongsTo
    {
        return $this->belongsTo(Employee::class,'instructor_id','id');
    }
    
    public function answers()
    {
        return $this->hasMany('App\Models\ApplicantAnswer', 'placement_applicant_id');
    }
    
    
    public function cases()
    {
        return $this->hasMany(PTApplicationCase::class,'pt_application_id','id');
    }
    
    public function lastcase()
    {
        return $this->hasOne(PTApplicationLastCase::class,'pt_application_id','id');
    }
    
    public function lastFollowup()
    {
        return PTApplicationLastCase::where('pt_application_id',$this->id)->orderBy('created_at','desc')->first();
    }
    
}
