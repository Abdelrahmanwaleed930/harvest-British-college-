<?php

namespace App\Models;

use Carbon\Carbon;
use Eloquent as Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Class Group
 * @package App\Models
 * @version July 30, 2021, 11:35 am UTC
 *
 * @property \App\Models\Round $round
 * @property \App\Models\DisciplineCategory $discipline
 * @property \App\Models\Branch $branch
 * @property \App\Models\Room $room
 * @property \App\Models\Employee $instructor
 * @property \App\Models\Interval $interval
 * @property \Illuminate\Database\Eloquent\Collection $stageLevels
 * @property string $title
 * @property integer $round_id
 * @property integer $discipline_id
 * @property integer $branch_id
 * @property integer $room_id
 * @property integer $instructor_id
 * @property integer $interval_id
 */
class Group extends Model
{
    use SoftDeletes;


    public $table = 'groups';


    protected $dates = ['deleted_at'];

    public $fillable = [
        'title',
        'parent_id',
        'track_id',
        'course_id',
        'timeframe_id',
        'level_id',
        'code',
        'training_service_id',
        'round_id',
        'sub_round_id',
        'days',
        'discipline_id',
        'branch_id',
        'room_id',
        'instructor_id',
        'admin_id',
        'interval_id',
        'is_upgraded',
        'is_last',
    ];
    
    public static $rules = [
        // 'title' => 'required',
        'track_id' => 'required',
        'course_id' => 'required',
        'round_id' => 'required',
        'timeframe_id' => 'required',
        'sub_round_id' => 'required',
        'days' => 'required',
        'discipline_id' => 'required',
        'branch_id' => 'required',
        'room_id' => 'required',
        'instructor_id' => 'nullable',
        'admin_id' => 'required',
        'interval_id' => 'required',
        'level_id' => 'required',
        //'upgraded' => 'nullable',
        //'levels' => 'required|array',
    ];
    /**
     * The accessors to append to the model's array form.
     *
     * @var array
     */
    protected $appends = ['status','startDate','endDate'];
    
    /**
     * Get the status
     *
     * @param  string  $value
     * @return string
     */
    public function getStartDateAttribute()
    {
        $subRound = $this->subRound;
        return $subRound->start_date;
    }
    
    public function getStudents(){
        return $this->hasMany(Lead::class,'last_group_id')->with('customerTracks');
    }
    
    public function getEndDateAttribute()
    {
        $subRound = $this->subRound;
        return $subRound->end_date;
    }

    public function studentexam(){
        return $this->hasMany(StudentExam::class);
    } 
    
    public function getStudentExam($student_id,$lead_id)
    {
        return StudentExam::where('student_id',$student_id)->where('lead_id',$lead_id)->where('group_id',$this->id)
                ->where('track_id',$this->track_id)->where('course_id',$this->course_id)->where('level_id',$this->level_id)->first();
    }
    
    public function getStatusAttribute()
    {
        $subRound = $this->subRound;
        //$startDate = Carbon::parse($subRound->start_date);
        //$endDate = Carbon::parse($subRound->end_date);

        $today = today();
        $status = '';

        switch (true) {
            case ($subRound->end_date < date('Y-m-d')):
                $status = 'complete';
                break;
            case ($subRound->start_date > date('Y-m-d')):
                $status = 'upcoming';
                break;
            default:
                $status = 'running';
                break;
        }

        return $status;
    }

    /**
     * Scope a query to only include status
     *
     * @param  \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeStatus($query, $type)
    {
        //dd('dddd');
        $today = today();
        $query->whereHas('subRound', function (Builder $subQuery) use ($type, $today) {
            if ($type == 'complete') {
                $subQuery->whereDate('end_date', '<', $today);
            } elseif ($type == 'upcoming') {
                $subQuery->whereDate('start_date', '>', $today);
            } else{
                $subQuery->whereDate('end_date', '>=', $today)->whereDate('start_date', '<=', $today);
            }
        });
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function parent()
    {
        return $this->belongsTo(\App\Models\Group::class, 'parent_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function children()
    {
        return $this->belongsTo(\App\Models\Group::class, 'parent_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function track()
    {
        return $this->belongsTo(\App\Models\Track::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function course()
    {
        return $this->belongsTo(\App\Models\Track::class, 'course_id');
    }
    
    public function timeframe()
    {
        return $this->belongsTo(\App\Models\Timeframe::class, 'timeframe_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function round()
    {
        return $this->belongsTo(\App\Models\Round::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function subRound()
    {
        return $this->belongsTo(\App\Models\SubRound::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function discipline()
    {
        return $this->belongsTo(\App\Models\DisciplineCategory::class, 'discipline_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function branch()
    {
        return $this->belongsTo(\App\Models\Branch::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function room()
    {
        return $this->belongsTo(\App\Models\Room::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function instructor()
    {
        return $this->belongsTo(\App\Models\Employee::class, 'instructor_id');
    }
    
    public function pastSessions()
    {
        return GroupSession::where('group_id', $this->id)->where('status', '!=', 1)->count();
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function admin()
    {
        return $this->belongsTo(\App\Models\Employee::class, 'admin_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function interval()
    {
        return $this->belongsTo(\App\Models\Interval::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     **/
    public function level()
    {
        return $this->belongsTo(\App\Models\StageLevel::class,'level_id','id');
    }

    /**
     * Get all of the sessions for the Group
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function sessions(): HasMany
    {
        return $this->hasMany(GroupSession::class);
    }
    
    
    public function getAttendance($lead_id)
    {
        return GroupSessionAttendance::where('lead_id',$lead_id)->where('group_id',$this->id)->where('level_id',$this->level_id)->where('attendance',1)->count();
    }
    public function groupsessionAttendance(): HasMany
    {
        return $this->hasMany(GroupSessionAttendance::class);
    }

    
    public function lastSession()
    {
        return GroupSession::where('group_id',$this->id)->orderBy('date','desc')->first();
    }
    /**
     * Get all of the students for the Group
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function students(): HasMany
    {
        return $this->hasMany(GroupStudent::class, 'group_id');
    }
    public function getStudentquiz($student_id,$lead_id)
    {
        return StudentQuiz::where('student_id',$student_id)->where('lead_id',$lead_id)->where('group_id',$this->id)
                ->where('track_id',$this->track_id)->where('course_id',$this->course_id)->where('level_id',$this->level_id)->first();
    }
    
}
