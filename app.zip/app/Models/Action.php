<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;



/**
 * Class Action
 * @package App\Models
 * @version November 19, 2021, 6:28 am EET
 *
 * @property integer $name
 * @property integer $label_type_id
 * @property string $status
 */
class Action extends Model
{


    public $table = 'actions';




    public $fillable = [
        'name',
        'label_type_id',
        'status'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'name' => 'string',
        'label_type_id' => 'integer',
        'status' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'name' => 'required',
        'label_type_id' => 'required',
        'status' => 'required'
    ];

    /**
     * Get the label_type that owns the Action
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function label_type(): BelongsTo
    {
        return $this->belongsTo(LabelType::class);
    }
}
