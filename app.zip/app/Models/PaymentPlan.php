<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;


/**
 * Class PaymentPlan
 * @package App\Models
 * @version May 21, 2021, 10:12 pm UTC
 *
 * @property string $title
 * @property integer $status
 */
class PaymentPlan extends Model
{
    use SoftDeletes;


    public $table = 'payment_plans';
    

    protected $dates = ['deleted_at'];



    public $fillable = [
        'title',
        'title_ar',
        'status',
        	'offer_type',
        	'offer_status'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'title' => 'string',
        'title_ar' => 'string',
        'status' => 'integer',
        'offer_type' => 'integer',
        	'offer_status' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'title' => 'required',
        'title_ar' => 'required',
        'status' => 'required',
        'offer_type' => 'required',
        	'offer_status' => 'required'
    
    ];

    
}
