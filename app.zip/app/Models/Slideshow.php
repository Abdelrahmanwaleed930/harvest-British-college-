<?php

namespace App\Models;

use Eloquent as Model;

class Slideshow extends Model
{
    // use SoftDeletes;


    public $table = 'slideshow';

    public $fillable = [
        'title',
        'text',
        'image',
        'bk_image',
        'lang',
        'status',
        'link',
    ];
    
    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'title' => 'string',
        'text' => 'string',
        'image' => 'string',
        'bk_image' => 'string',

        'lang' => 'string',
        'status' => 'string',
        'link' => 'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        //'image' => 'required',
        'lang' => 'required',
        'status' => 'required',
    ];
}