<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;


/**
 * Class Job
 * @package App\Models
 * @version May 8, 2021, 4:03 pm UTC
 *
 * @property \App\Models\Department $department
 * @property integer $department_id
 * @property string $title
 */
class JobApplication extends Model
{
    use SoftDeletes;

    public $table = 'jobs_applications';
    
    protected $dates = ['deleted_at'];

    public $fillable = [
        'full_name',
        'phone',
        'phone2',
        'email',
        'age',
        'english_level',
        'job_id',
        'know_channel_id',
        'branch_id',
        'experience',
        'upload_cv',
        'status',
        'assigned_employee_id',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'assigned_employee_id' => 'integer',
        'job_id' => 'integer',
        'branch_id' => 'integer',
        'know_channel_id' => 'integer',
        'full_name' => 'string',
        'phone' => 'string',
        'phone2' => 'string',
        'email' => 'string',
        'age' => 'string',
        'english_level' => 'string',
        'experience' => 'string',
        'upload_cv' => 'string',
        'status'=>'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'job_id' => 'required',
        'branch_id' => 'required',
        'full_name' => 'required',
        'phone' => 'required|string|unique:jobs_applications,phone',
        'phone2' => 'nullable',
        'email' => 'required',
        'age' => 'required',
        'english_level' => 'required',
        'upload_cv' => 'nullable',
        'status' =>'nullable',
        'know_channel_id' =>'nullable',
    ];
    public function know_channel()
    {
        return $this->belongsTo(\App\Models\KnowChannel::class,'know_channel_id');
    }


    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function job()
    {
        return $this->belongsTo(\App\Models\Job::class,'job_id','id');
    }
    
    /**
     * Get the assignedEmployee that owns the Lead
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function assignedEmployee()
    {
        return $this->belongsTo(Employee::class, 'assigned_employee_id');
    }

    public function branch()
    {
        return $this->belongsTo(\App\Models\Branch::class,'branch_id');
    }
    
    public function cases()
    {
        return $this->hasMany(JobApplicationCase::class,'job_application_id','id');
    }
    
    public function lastcase()
    {
        return $this->hasOne(JobApplicationLastCase::class,'job_application_id','id');
    }
    
    public function lastFollowup()
    {
        return JobApplicationLastCase::where('job_application_id',$this->id)->orderBy('created_at','desc')->first();
    }
    
}
