<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExamModelQuestion extends Model
{
    // use HasFactory;
    
    public $table = 'exam_model_questions';

    public $fillable = [
        'exam_model_id',
        'question_id',
        'parent_id',
        'skill'
    ];

    public function question()
    {
        
        return $this->belongsTo(\App\Models\Question::class,'question_id');

        
    }
    public function exam_model()
    {
        return $this->belongsTo(\App\Models\ExamModel::class);


    }
}
