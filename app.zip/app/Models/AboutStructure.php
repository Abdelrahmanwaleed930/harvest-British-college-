<?php

namespace App\Models;

use Eloquent as Model;

class AboutStructure extends Model
{
    // use SoftDeletes;

    public $table = 'about_structure';

    public $fillable = [
        'title_en',
        'text_en',
        'title_ar',
        'text_ar',
        'status',
        'order_by',
        'image',
    ];
    
    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'title_en' => 'string',
        'text_en' => 'string',
        'title_ar' => 'string',
        'status' => 'string',
        'text_ar' => 'string',
        'order_by' => 'integer',
        'image' => 'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        //'image' => 'required',
        'title_en' => 'required',
        'title_ar' => 'required',
        'text_en' => 'required',
        'text_ar' => 'required',
        'status' => 'required',
        'order_by' => 'required'
    ];
}