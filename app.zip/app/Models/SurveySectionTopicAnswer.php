<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SurveySectionTopicAnswer extends Model
{
    use HasFactory;
    protected $table = 'survey_section_topic_answers';
    public $fillable = [
         'survey_section_topic_id',
         'answer_en',
         'answer_ar',
         ];
         
     public static $rules = [
        'survey_section_topic_id' => 'required',
        'answer_en' => 'nullable',
        'answer_ar' => 'nullable',
    ];
     
    public function SurveySectionsTopic()
    {
        return $this->belongsTo('\App\Models\SurveySectionsTopic','survey_section_topic_id');
        
    }
}
