<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;



/**
 * Class Action
 * @package App\Models
 * @version November 19, 2021, 6:28 am EET
 *
 * @property integer $name
 * @property integer $label_type_id
 * @property string $status
 */
class OldCustomerPayment extends Model
{

    public $table = 'old_customers_payment';

    public $fillable = [
        'customer_id',
        'course_id',
        'level_id',
        'harvest_certificate',
        'cambridge_certificate',
        'books',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'customer_id' => 'integer',
        'course_id' => 'integer',
        'level_id' => 'integer',
        'harvest_certificate' => 'integer',
        'cambridge_certificate' => 'integer',
        'books' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     
    public static $rules = [
        'name' => 'required',
        'label_type_id' => 'required',
        'status' => 'required'
    ];
    */
    
    /**
     * Get the label_type that owns the Action
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     
    public function label_type(): BelongsTo
    {
        return $this->belongsTo(LabelType::class);
    }
    */
}
