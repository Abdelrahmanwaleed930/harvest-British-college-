<?php

namespace App\Models;

use Eloquent as Model;

/**
 * Class ItemCategory
 * @package App\Models
 * @version July 8, 2021, 8:04 pm UTC
 *
 * @property string $name
 */
class Event extends Model
{

    public $table = 'events';

    public $fillable = [
        'image',
        'title_en',
        'title_ar',
        'short_desc_en',
        'short_desc_ar',
        'date_from',
        'date_to',
        'time_from',
        'time_to',
        'address_en',
        'address_ar',
        'desc_en',
        'desc_ar',
        'latitude',
        'longitude',
        'phone',
        'email',
        'link',
        'status',
        
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'image' => 'string',
        'title_en' => 'string',
        'title_ar' => 'string',
        'short_desc_en' => 'string',
        'short_desc_ar' => 'string',
        'date_from' => 'string',
        'date_to' => 'string',
        'time_from' => 'string',
        'time_to' => 'string',
        'address_en' => 'string',
        'address_ar' => 'string',
        'desc_en' => 'string',
        'desc_ar' => 'string',
        'latitude' => 'string',
        'longitude' => 'string',
        'phone' => 'string',
        'email' => 'string',
        'link' => 'string',
        'status' => 'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'title_en' => 'required',
        'title_ar' => 'required',
        'date_from' => 'required',
        'date_to' => 'required',
        'time_from' =>'required',
        'time_to' => 'required',
        
    ];

    
}
