<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;
use Eloquent as Model;
use Illuminate\Support\Str;

/**
 * Class Question
 * @package App\Models
 * @version November 12, 2021, 8:47 pm EET
 *
 * @property string $question
 */
class Question extends Model
{
    use SoftDeletes;
    public $table = 'questions';

    public $fillable = [
        'skill',
        'question',
        'photo',
        'parent_id',
        'track_id',
        'course_id',
        'level_id',
    ];

    /**
     * The accessors to append to the model's array form.
     *
     * @var array
     */
    protected $appends = ['paragraph'];

    /**
     * Get the paragraph for reading skill.
     *
     * @return string
     */
    public function getParagraphAttribute()
    {
        return Str::limit($this->attributes['question'], 150, '...');
    }
    public function countquestion($id)
    {
        return Question::where('parent_id' ,$this->id)->get()->count();
    }

    public function parent()
    {
        return $this->belongsTo('App\Models\Question', 'parent_id');
    }

    
    public function track()
    {
        return $this->belongsTo('App\Models\Track', 'track_id');
    }
    
    public function course()
    {
        return $this->belongsTo('App\Models\Track', 'course_id');
    }
    
    public function level()
    {
        return $this->belongsTo('App\Models\StageLevel', 'level_id');
    }

    public function children()
    {
        return $this->hasMany('App\Models\Question', 'parent_id')/*->inRandomOrder()*/;
    }

    public function answers()
    {
        return $this->hasMany('App\Models\Answer');
    }
    public function student_answer()
    {
        return $this->hasMany('App\Models\StudentExamAnswer');
    }

    public function answersRandom()
    {
        return $this->hasMany('App\Models\Answer')->inRandomOrder();
    }
    
    public function getchild()
    {
        return $question = Question::where('parent_id' , $this->id)->count();
    }
    
    
}
