<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TODoList extends Model
{
    use HasFactory;
    
    public $table = 'To_Do_List';
    
     public $fillable = [
        'dept_id ',
        'job_id ',
        'employee_id ',
        'start_date',
        'end_date',
        'status',
        'created_by_id',
        'note',
    ];
    
    public function TODoListRandom()
    {
        return $this->hasMany(TODoListRandom::class, 'to_do_list_id');
    }
    public function employee()
    {
        return $this->belongsTo(Employee::class,'employee_id');
    }
    public function created_by()
    {
        return $this->belongsTo(Employee::class,'created_by_id');
    }
    public function job()
    {
        return $this->belongsTo(Job::class,'job_id');
    }
    
    public function department()
    {
        return $this->belongsTo(Department::class,'dept_id');
    }
    
    
    
    
}
