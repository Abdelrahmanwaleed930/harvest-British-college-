<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HrBoardingSectionsTopics extends Model
{
    use HasFactory;
    protected $table = 'hr_boarding_sections_topics';
    
    public $fillable = [
         'title',
         'hr_boarding_sections_id',
         ];
         
     public static $rules = [
        'title' => 'required',
        'hr_boarding_sections_id' => 'required',
    ];
    public function HrBoardingSections()
    {
        return $this->belongsTo('\App\Models\HrBoardingSections','hr_boarding_sections_id');
        
    } 
}
