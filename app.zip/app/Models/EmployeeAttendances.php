<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmployeeAttendances extends Model
{
    use HasFactory;
    public $table = 'employee_attendances';

    public $fillable = [
        'employee_id',
        'date',
        'time_in',
        'time_out',
        'attendance_hours',
        'status',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'employee_id' => 'integer',
        'status' => 'integer',
    ];
    
    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'employee_id' => 'required',
        'date' => 'required',
        'time_in' => 'required',
        'time_out' => 'required',
        'attendance_hours' => 'required',
        'status' => 'required',
    ];
    public function employee()
    {
        return $this->belongsTo(Employee::class,'employee_id');
    }
}
