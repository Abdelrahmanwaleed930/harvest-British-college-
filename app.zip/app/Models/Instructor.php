<?php

namespace App\Models;

use Eloquent as Model;

/**
 * Class ItemCategory
 * @package App\Models
 * @version July 8, 2021, 8:04 pm UTC
 *
 * @property string $name
 */
class Instructor extends Model
{

    public $table = 'instructors';

    public $fillable = [
        'instructor_id',
        'name_en',
        'link_en',
        'order_by',
        'image',
        'job_title_en',
        'brief_en',
        'education_en',
        'experience_en',
        'phone',
        'email',
        'facebook',
        'linkedin',
        'instgram',
        'twitter',
        'whatsapp',
        'status',
        'name_ar',
        'link_ar',
        'job_title_ar',
        'brief_ar',
        'education_ar',
        'experience_ar',
        
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'instructor_id' => 'integer',
        'name_en' => 'string',
        'link_en' => 'string',
        'order_by' => 'integer',
        'image' => 'string',
        'job_title_en' => 'string',
        'brief_en' => 'string',
        'education_en' => 'string',
        'experience_en' => 'string',
        'phone' => 'string',
        'email' => 'string',
        'facebook' => 'string',
        'linkedin' => 'string',
        'instgram' => 'string',
        'twitter' => 'string',
        'whatsapp' => 'string',
        'status' => 'integer',
        'name_ar' => 'string',
        'link_ar' => 'string',
        'job_title_ar' => 'string',
        'brief_ar' => 'string',
        'education_ar' => 'string',
        'experience_ar' => 'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'name_en' => 'required',
        'link_en' => 'required',
        'order_by' => 'required',
        'status' => 'required',
    ];

    public function groups(){
        return $this->hasMany(Group::class);

    }

    
}
