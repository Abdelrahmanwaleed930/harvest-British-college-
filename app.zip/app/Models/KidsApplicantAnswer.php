<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class KidsApplicantAnswer extends Model
{

    public $table = 'kids_applicant_answers';

    public $fillable = [
        'placement_applicant_id',
        'placement_question_id',
        'type',
        'answer',
        'score',
    ];

    public function applicant()
    {
        return $this->belongsTo('App\Models\PlacementKidsApplicant', 'placement_applicant_id');
    }

    public function question()
    {
        return $this->belongsTo('App\Models\PlacementKidsQuestion', 'placement_question_id');
    }
}
