<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Safe extends Model
{
    use HasFactory;
    public $table = 'safes';
    public $fillable = [
        'employee_id',
        'branch_id',
        'is_manager',
        'is_hq',
        'status',
        'balance',
        'payment_method_id',
        'safe_type_id'
    ];

    /**
     * The accessors to append to the model's array form.
     *
     * @var array
     */
    protected $appends = ['type'];

    /**
     * Get the type
     *
     * @return string
     */
    public function getTypeAttribute()
    {
        switch (true) {
            case $this->attributes['is_hq'] == 1:
                $safeType = "HQ";
                break;

            case $this->attributes['is_manager'] == 1:
                $safeType = "Branch";
                break;

            default:
                $safeType = "Employee";
                break;
        }

        return $safeType;
    }

    public function employee(): BelongsTo
    {
        return $this->belongsTo(Employee::class);
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }
    public function payment_method(): BelongsTo
    {
        return $this->belongsTo(PaymentMethod::class);

    }
    public function safe_type(): BelongsTo
    {
        return $this->belongsTo(SafeType::class);
    }

    public function safe_operations()
    {
        return $this->hasMany(\App\Models\SafeOperation::class ,'safe_id');

    }
    public function get_employee_name(){
        $employee = Employee::where('id',$this->employee_id)->select('first_name' ,'last_name')->first();
        return $employee->first_name. ' ' .$employee->last_name;
        
    }
    public function totalbefore($date,$safe_id,$branch_id)
    {
         $registration_to=null;
        $reg_to=null;

        if ($date && $date != null && $date != '') {
            $daterange = explode(' - ',$date);
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
            
        }
        
        if ( $registration_to != '' && $registration_to != null)
         {
            // return $count = Safe::where('status',1)->where('safe_type_id' ,10)
            // ->where('id',$safe_id)->where('branch_id',$branch_id)
            // ->where('created_at', '<', $registration_to)->get()->sum('balance');
             $countbeforeincome =SafeOperation::whereHas('safe',function($quary)use ($safe_id ) {
                        $quary->where('id' ,$safe_id);
                    })->where('operation_type' ,'income')->where('created_at', '<', $registration_to)->get()->sum('amount');
             $countbeforeoutcome =SafeOperation::whereHas('safe',function($quary)use ($safe_id ) {
                        $quary->where('id' ,$safe_id);
                    })->where('operation_type' ,'outcome')->where('created_at', '<', $registration_to)->get()->sum('amount');
            return $count = $countbeforeincome - $countbeforeoutcome;
         }
    }
    public function countoperation($id ,$date,$safe_id,$branch_id){
        // return $date;
        $registration_from=null;
        $reg_to=null;
        $registration_to=null;

        if ($date && $date != null && $date != '') {
            $daterange = explode(' - ',$date);
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
            
        }
        if($id ==0)
        {
            if ($registration_from != null && $registration_to != '')
         {
            
             return $count =SafeOperation::whereHas('safe',function($quary)use ($safe_id ,$branch_id) {
                        $quary->where('id' ,$safe_id)->where('branch_id' ,$branch_id);
                    })->where('operation_type' ,'income')
                    
                    ->whereBetween('created_at', [$registration_from, $registration_to])->count();
                    
            
         }
                

         else{
             return $count =SafeOperation::whereHas('safe',function($quary)use ($safe_id,$branch_id) {
                        $quary->where('id' ,$safe_id)->where('branch_id' ,$branch_id);
                    })->where('operation_type' ,'income')
                    ->where('created_at','like','%'.date('Y-m-d').'%')->count();
                    
        
         }
        
        }
        else if($id ==1){
            if ($registration_from != null && $registration_to != '')
         {
     
             return $count =SafeOperation::whereHas('safe',function($quary)use ($safe_id,$branch_id) {
                        $quary->where('id' ,$safe_id)->where('branch_id' ,$branch_id);
                    })->where('operation_type' ,'outcome')
                    ->whereBetween('created_at', [$registration_from, $registration_to])->count();
                    
         }
                

        else{
            return $count =SafeOperation::whereHas('safe',function($quary)use ($safe_id,$branch_id) {
                   $quary->where('id' ,$safe_id)->where('branch_id' ,$branch_id);
               })->where('operation_type' ,'outcome')
               ->where('created_at','like','%'.date('Y-m-d').'%')->count();
        
        
        }
        
        } 
        
          

    }
    
    public function totalamountcount($id,$date,$safe_id,$branch_id){
        $registration_from=null;
        $reg_to=null;

        if ($date && $date != null && $date != '') {
            $daterange = explode(' - ',$date);
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
            
        }
        
        if($id ==0)
        {
            
          if ($registration_from != null && $registration_to != '')
           {
              return $count =SafeOperation::whereHas('safe',function($quary)use ($safe_id,$branch_id) {
                        $quary->where('safe_id' ,$safe_id)->where('branch_id' ,$branch_id);
                        
                    })->where('operation_type' ,'income')
                    ->whereBetween('created_at', [$registration_from, $registration_to])->get()->sum('amount');
           }
          else{
                    
             return $count =SafeOperation::whereHas('safe',function($quary)use ($safe_id,$branch_id) {
                $quary->where('id' ,$safe_id)->where('branch_id' ,$branch_id);
            })->where('operation_type' ,'income')
            ->where('created_at','like','%'.date('Y-m-d').'%')->get()->sum('amount');
                
            
           }
        }
        elseif($id ==1){
            
          if ($registration_from != null && $registration_to != '')
           {
              return $count =SafeOperation::whereHas('safe',function($quary)use ($safe_id,$branch_id) {
                        $quary->where('safe_id' ,$safe_id)->where('branch_id' ,$branch_id);
                    })->where('operation_type' ,'outcome')
                    ->whereBetween('created_at', [$registration_from, $registration_to])->get()->sum('amount');
           }
          else{
                    
             return $count =SafeOperation::whereHas('safe',function($quary)use ($safe_id,$branch_id) {
                $quary->where('safe_id' ,$safe_id)->where('branch_id' ,$branch_id);
            })->where('operation_type' ,'outcome')
            ->where('created_at','like','%'.date('Y-m-d').'%')->get()->sum('amount');
                
            
        }
        }
        
    }


}
