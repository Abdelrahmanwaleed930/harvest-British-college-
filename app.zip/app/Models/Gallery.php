<?php

namespace App\Models;

use Eloquent as Model;

/**
 * Class Feedback
 * @package App\Models
 * @version November 19, 2021, 6:15 am EET
 *
 * @property string $name
 * @property integer $label_type_id
 * @property integer $status
 */
class Gallery extends Model
{

    public $table = 'gallery';

    public $fillable = [
        'title_en',
        'title_ar',
        'link_en',
        'link_ar',
        'image',
        'status'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'title_en' => 'string',
        'title_ar' => 'string',
        'link_en' => 'string',
        'link_ar' => 'string',
        'image' => 'string',
        'status' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'title_en' => 'required',
        'title_ar' => 'required',
        'status' => 'required'
    ];

    public function getImages()
    {
        return $this->hasMany(GalleryImage::class,'gallery_id','id');
    }
}
