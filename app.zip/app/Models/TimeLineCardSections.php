<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TimeLineCardSections extends Model
{
    use HasFactory;
    
    public $table = 'timeline_card_section';

    public $fillable = [
         'title',
         'description',
         'max_score',
         ];
        
     public function TimeLineCard()
    {
        return $this->hasMany('\App\Models\TimeLineCard','timeline_card_id');
    }
    
    public function SectionsTimeLineCard()
    {
        return $this->hasMany('\App\Models\SectionsTimeLineCard','timeline_card_sections_id');
    }    
    

}
