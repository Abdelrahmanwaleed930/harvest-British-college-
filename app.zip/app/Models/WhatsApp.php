<?php

namespace App\Models;

use Twilio\Rest\Client;

class WhatsApp
{

    public function send($to, $message,$buttons = array())
    {
        /*
        $sid = config('services.twilio.sid');
        $token = config('services.twilio.token');
        $from = config('services.twilio.whatsapp_from');

        $twilio = new Client($sid, $token);

        if (is_array($to)) {
            foreach ($to as $value) {
                $twilio->messages
                    ->create(
                        "whatsapp:+2" . $value, // to
                        [
                            "from" => "whatsapp:" . $from,
                            "body" => $message
                        ]
                    );
            }
        } else {
            $twilio->messages
                ->create(
                    "whatsapp:+2" . $to, // to
                    [
                        "from" => "whatsapp:" . $from,
                        "body" => $message
                    ]
                );
        }
        */  
        
        $nodeurl = 'https://api.fekrawhats.com/send';
        
        $mediaurl = 'https://harvestcollege.co.uk/uploads/configurations/whatsapp.png';
        /*
        $buttons = [
            
            'templateButtons' => [
                ['index' => 1, 'urlButton' => ['displayText' => 'Visit my website!', 'url' => 'https://harvestcollege.co.uk/']],
                //['index' => 2, 'callButton' => ['displayText' => 'Call me!', 'phoneNumber' => '+1 (234) 5678-9012']],
                //['index' => 3, 'quickReplyButton' => ['displayText' => 'This is a reply, just like normal buttons!', 'id' => 'info']],
            ],
         
            // 'listButtons' => [
            //     ['title' => 'Level', 'rows' => [['title' => 'Super hot', 'description' => 'Spicy level: super hot', 'rowId' => 'level_super_hot'], ['title' => 'Medium hot', 'description' => 'Spicy level: medium hot', 'rowId' => 'level_medium_hot']]],
            //     ['title' => 'Extra', 'rows' => [['title' => 'Pickles', 'description' => 'Free pickles', 'rowId' => 'free_pickles']]],
            // ],
            // 'mainTitle' => 'Main title', // listButtons only
            // 'buttonText' => 'Text on button', // listButtons only
            
            'replyButtons' => [
                ['buttonId' => 'yesContinue', 'buttonText' => ['displayText' => 'YES'], 'type' => 1],
                ['buttonId' => 'noContinue', 'buttonText' => ['displayText' => 'NO'], 'type' => 1],
                ['buttonId' => 'info', 'buttonText' => ['displayText' => 'More Info'], 'type' => 1],
            ],
            'footerText' => 'This is footer',
            
        ];*/
        //dd($to,$message);
        if (is_array($to)) {
            foreach ($to as $value) {
                $data = [
                    'receiver'  => '+2'.$value,
                    'msgtext'   => $message,
                    'token'     => 'hndzTgrwcbf1RU1ZFkE9',
                    'mediaurl'  => $mediaurl, // delete this line if no media
                    'buttons'   => $buttons, // delete this line if no buttons
                ];
                 
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                curl_setopt($ch, CURLOPT_URL, $nodeurl);
                curl_setopt($ch, CURLOPT_TIMEOUT, 30);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                $response = curl_exec($ch);
                curl_close($ch);
                 
                //dd($response);
            }
        }
        else{
            $data = [
                'receiver'  => '+2'.$to,
                'msgtext'   => $message,
                //'token'     => 'Hp1RGnDp9fb9yqQa5KuI',
                'token'     => 'rnII7YoV1wBDl7CN6urf',
                'mediaurl'  => $mediaurl, // delete this line if no media
                'buttons'   => $buttons, // delete this line if no buttons
            ];
             
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
            curl_setopt($ch, CURLOPT_URL, $nodeurl);
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            $response = curl_exec($ch);
            curl_close($ch);
             
            //dd($response);
        }
    }
}
