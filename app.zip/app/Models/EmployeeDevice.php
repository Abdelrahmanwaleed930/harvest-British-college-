<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmployeeDevice extends Model
{
    use HasFactory;
    
    public $table = 'employee_device';
    public $fillable = [
        'branch_id',
        'employee_id',
        'serial_number',
        'version',
        'os',
        'os_installation',
        'computer_type',
        'cpu_type',
        'system_memory',
        'max_memory_capacity',
        'type',
        'bios_type',
        'hand_disk_size',
        'accessories',
        
        
    ];
    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }
    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }
     
     
}
