<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes;
use DB;
/**
 * Class Branch
 * @package App\Models
 * @version May 8, 2021, 2:55 pm UTC
 *
 * @property string $name
 * @property string $address
 * @property string $phone
 */
class Place extends Model
{
    use SoftDeletes;

    public $table = 'places';

    protected $dates = ['deleted_at'];

    public $fillable = [
        'name',
        'address',
        'phone',
        'manager_id',
        'status',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'name' => 'string',
        'address' => 'string',
        'phone' => 'string',
        'manager_id' => 'integer',
        'status' => 'integer',
    ];
    
    public function manager()
    {
        return $this->belongsTo(Employee::class,'manager_id','id');
    }
    
    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'name' => 'required',
        'address' => 'required',
        'phone' => 'required',
        'status' => 'required',
        'manager_id' => 'required',
    ];
    
}
