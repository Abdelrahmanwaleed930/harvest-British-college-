<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IzabellaCall extends Model
{
  
    public $table ='izabella_call';
    
    public $fillable=[
        'employee_id',
        'phone',
        'lead_id',
        'status',
        'url',
        'type',
        'izabella_code',
        'date',
    ];
    public function employee(){
        return $this->belongsTo(\App\Models\Employee::class,'employee_id');
        
    }
    public function lead(){
        return $this->belongsTo(\App\Models\Lead::class,'lead_id');
        
    }
        

    
    
}
