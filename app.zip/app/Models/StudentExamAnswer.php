<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StudentExamAnswer extends Model
{

    public $table = 'student_exam_answers';

    public $fillable = [
        'student_exam_id',
        'question_id',
        'type',
        'answer',
        'score',
    ];

    public function applicant()
    {
        return $this->belongsTo('App\Models\StudentExam', 'student_exam_id');
    }

    public function question()
    {
        return $this->belongsTo('App\Models\Question', 'question_id');
    }
    public function answer()
    {
        return $this->belongsTo('App\Models\Answer','answer');
    }
}
