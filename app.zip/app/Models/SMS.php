<?php

namespace App\Models;

class SMS
{

    public function send($to, $message)
    {
        if (is_array($to)) {
            $toUpdated = [];
            foreach ($to as $key => $value) {
                $toUpdated[] = '2' . $value;
            }
            $mobile = implode(',', $toUpdated);
        } else {
            $mobile = '2' . $to;
        }
        //dd($to,$mobile);
        $username = '084d92190818a35656f880a273ccdbc00a299c6fdf2da546635b98f1013c51f8';
        $password = '208883ad710d4556e1a4ecc924f6e4fcd4be606cb7fe2b09621f49571cd39517';
        $delayUntil = date('YmdHi');
        $sender = '04b258412afe7d02a135babd9fb5cebafb9144098e27eb9944196d4dee53108d';
        $message = rawurlencode($message);

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://smsmisr.com/api/SMS?environment=1&username=$username&password=$password&language=2&sender=$sender&mobile=$mobile&message=$message&delayUntil=".$delayUntil,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            // CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_HTTPHEADER => array(
                'Content-Length: 0'
            ),
        ));

        $response = curl_exec($curl);
        // dd($response);
        curl_close($curl);
        // echo $response;
    }
}
