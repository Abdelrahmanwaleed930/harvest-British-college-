<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;


/**
 * Class CustomerJob
 * @package App\Models
 * @version May 20, 2021, 12:19 am UTC
 *
 * @property string $name

 */
class CertificateRequest extends Model
{
    use SoftDeletes;

    public $table = 'certificates_requests';

    protected $dates = ['deleted_at'];

    public $fillable = [
        'lead_id',
        'display_name',
        'certificate_id',
        'status',
        'invoice_id',
        'note',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'lead_id' => 'integer',
        'display_name' => 'string',
        'certificate_id' => 'integer',
        'invoice_id' => 'integer',
        'status'=>'string',
        'note'=>'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'lead_id' => 'required',
        'display_name' => 'required',
        'certificate_id' => 'required',
        'invoice_id' => 'required',
        'status' => 'nullable',
        'note' => 'nullable',
    ];

    public function Certificate()
    {
        return $this->belongsTo('App\Models\ExtraItem','certificate_id','id');
    }
    
    public function Lead()
    {
        return $this->belongsTo('App\Models\Lead','lead_id','id');
    }
}
