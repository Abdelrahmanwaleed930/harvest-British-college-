<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes;
use DB;
/**
 * Class Branch
 * @package App\Models
 * @version May 8, 2021, 2:55 pm UTC
 *
 * @property string $name
 * @property string $address
 * @property string $phone
 */
class Coupon extends Model
{
    use SoftDeletes;

    public $table = 'coupons';

    protected $dates = ['deleted_at'];

    public $fillable = [
        'title',
        'code',
        //'for_items',
        //'for_services',
        //'for_offers',
        //'items',
        //'services',
        //'offers',
        'value',
        'value_type',
        'expired_date',
        'min_item_price',
        'status',
    ];
    /*
    public function getItemsAttribute()
    {
        return ($this->attributes['items'] != null && $this->attributes['items'] != '')?explode(',',$this->attributes['items']):[];
    }

    public function getServicesAttribute()
    {
        return ($this->attributes['services'] != null && $this->attributes['services'] != '')?explode(',',$this->attributes['services']):[];
    }

    public function getOffersAttribute()
    {
        return ($this->attributes['offers'] != null && $this->attributes['offers'] != '')?explode(',',$this->attributes['offers']):[];
    }
    */
    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'title' => 'string',
        'code' => 'string',
        //'for_items' => 'integer',
        //'for_services' => 'integer',
        //'for_offers' => 'integer',
        //'items' => 'string',
        //'services' => 'string',
        //'offers' => 'string',
        'value' => 'string',
        'value_type' => 'string',
        'expired_date' => 'string',
        'min_item_price' => 'string',
        'status' => 'integer',
    ];
    
    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'title' => 'required',
        'code' => 'required',
        //'for_items' => 'required',
        //'for_services' => 'required',
        //'for_offers' => 'required',
        'value' => 'required',
        'value_type' => 'required',
        'expired_date' => 'required',
        'min_item_price' => 'required',
        'status' => 'required',
    ];
    
}
