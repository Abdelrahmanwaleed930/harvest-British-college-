<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GroupWaitingList extends Model
{
    public $table = 'group_waiting_lists';

    public $fillable = [
        'lead_id',
        'level_id',
        'track_id',
        'course_id',
        'timeframes',
        'intervals',
        'lead_payment_id',
        'discipline_id',
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function lead()
    {
        return $this->belongsTo(\App\Models\Lead::class);
    }
    
    public function payment()
    {
        return $this->belongsTo(\App\Models\LeadPayment::class,'lead_payment_id','id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function level()
    {
        return $this->belongsTo(\App\Models\StageLevel::class, 'level_id');
    }
    
    public function track()
    {
        return $this->belongsTo(\App\Models\Track::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function course()
    {
        return $this->belongsTo(\App\Models\Track::class, 'course_id');
    }
}
