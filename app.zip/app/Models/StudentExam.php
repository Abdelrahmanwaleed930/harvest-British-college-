<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;


/**
 * Class PlacementApplicant
 * @package App\Models
 * @version May 28, 2021, 1:51 pm UTC
 *
 * @property string $name
 * @property string $email
 * @property string $mobile
 * @property string $gender
 * @property string $job
 * @property string $university
 * @property number $vocabulary_score
 * @property number $grammar_score
 * @property number $reading_score
 * @property number $writing_score
 * @property number $listening_score
 * @property number $speaking_score
 * @property number $evaluation_score
 * @property integer $level
 * @property string $notes
 * @property integer $status
 */
class StudentExam extends Model
{

    use SoftDeletes;
    public $table = 'student_exams';

    public $fillable = [
        'student_id',
        'group_id',
        'lead_id',
        'track_id',
        'course_id',
        'level_id',
        'step',
        'vocabulary_score',
        'grammar_score',
        'reading_score',
        'writing_score',
        'listening_score',
        'speaking_score',
        'evaluation_score',
        'finish',
        'notes',
        'status',
        'exam_model_id',
        'remain_duration',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'student_id' => 'integer',
        'group_id' => 'integer',
        'lead_id' => 'integer',
        'track_id' => 'integer',
        'course_id' => 'integer',
        'level_id' => 'integer',
        'step' => 'integer',
        'vocabulary_score' => 'decimal:1',
        'grammar_score' => 'decimal:1',
        'reading_score' => 'decimal:1',
        'listening_score' => 'decimal:1',
        'speaking_score' => 'decimal:1',
        'writing_score' => 'decimal:1',
        'evaluation_score' => 'decimal:1',
        'finish' => 'integer',
        'notes' => 'string',
        'status' => 'string',
        'exam_model_id' => 'integer',
        'remain_duration' => 'integer',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        // 'vocabulary_score' => 'numeric|between:0,99.5',
        // 'grammar_score' => 'numeric|between:0,99.5',
        // 'reading_score' => 'numeric|between:0,99.5',
        'writing_score' => 'numeric|between:0,99.5',
        'listening_score' => 'numeric|between:0,99.5',
        'speaking_score' => 'numeric|between:0,99.5',
        'evaluation_score' => 'numeric|between:0,99.5',
        //'level' => 'integer'
    ];

    /**
     * Get the branch that owns the PlacementApplicant
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function student(): BelongsTo 
    {
        return $this->belongsTo(GroupStudent::class,'student_id','id');
    }
    public function group(): BelongsTo
    {
        return $this->belongsTo(Group::class,'group_id','id');
    }
    public function lead(): BelongsTo
    {
        return $this->belongsTo(Lead::class,'lead_id','id');
    }
    
    public function track(): BelongsTo
    {
        return $this->belongsTo(Track::class,'track_id','id');
    }
    public function course(): BelongsTo
    {
        return $this->belongsTo(Track::class,'course_id','id');
    }
    public function level(): BelongsTo
    {
        return $this->belongsTo(StageLevel::class,'level_id','');
    }
    public function exam_model()
    {
        return $this->belongsTo(ExamModel::class,'exam_model_id');
    }

    public function answers()
    {
        return $this->hasMany('App\Models\StudentExamAnswer', 'student_exam_id');
    }
}
