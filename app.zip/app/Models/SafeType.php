<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SafeType extends Model
{
    use HasFactory;

    public $table = 'safes_types';
    public $fillable = [
        'name',
        'parent_id'
    ];
    
    public function getParent()
    {
        return $this->belongsTo('App\Models\SafeType','parent_id','id');
    }
}
