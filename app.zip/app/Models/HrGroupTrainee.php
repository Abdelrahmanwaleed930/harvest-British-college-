<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HrGroupTrainee extends Model
{
    use HasFactory;
    
    protected $table ='hr_group_trainees';
     public $fillable = [
        'hr_group_id',
        'job_application_id',
        'score',
        
    ];
    
     public function hr_group()
    {
        return $this->belongsTo(HrGroups::class,'hr_group_id');
    }
    public function job_application()
    {
        return $this->belongsTo(JobApplication::class,'job_application_id');
    }
    public function getSessionAttendance()
    {
        return HrGroupSessionAttendance::where('job_application_id',$this->job_application_id)
        ->where('hr_group_id',$this->hr_group_id)->get();
    }
    

}
