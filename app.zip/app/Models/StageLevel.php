<?php

namespace App\Models;
use DB;

use Eloquent as Model;


/**
 * Class Stage
 * @package App\Models
 * @version June 13, 2021, 8:39 pm UTC
 *
 * @property \App\Models\Track $track
 * @property integer $stage_id
 * @property string $name
 */
class StageLevel extends Model
{

    public $table = 'stage_levels';

    public $fillable = [
        'stage_id',
        'name',
        'name_ar',
        'value',
        'items',
        'digital_material',
        'material_link',
        'min_degree',
        'max_degree',
        
    ];
    
    public function getItems()
    {
        return $this->belongsToMany(ExtraItem::class,'stage_level_items','level_id','item_id');
    }

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'stage_id' => 'integer',
        'name' => 'string',
        'name_ar' => 'string',
        'value' => 'integer',
        'min_degree' => 'integer',
        'max_degree' => 'integer',
        'items' => 'array'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function stage()
    {
        return $this->belongsTo(\App\Models\Stage::class);
    }
}
