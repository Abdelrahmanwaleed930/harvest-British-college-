<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StudentQuizAnswer extends Model
{
    use HasFactory;
     public $table = 'student_quiz_answer';

    public $fillable = [
        'student_quiz_id',
        'question_id',
        'type',
        'answer',
        'score',
    ];

    public function applicant()
    {
        return $this->belongsTo('App\Models\StudentQuiz', 'student_quiz_id');
    }

    public function question()
    {
        return $this->belongsTo('App\Models\Question', 'question_id');
    }
    public function answer()
    {
        return $this->belongsTo('App\Models\Answer','answer');
    }
}
