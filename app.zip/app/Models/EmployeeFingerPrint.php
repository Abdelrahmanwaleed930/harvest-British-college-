<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmployeeFingerPrint extends Model
{
    use HasFactory;
    public $table = 'employee_finger_prints';

    public $fillable = [
        'employee_id',
        'date',
        'time',
        'branch_id',
        'employee_fingerprint_id',
        'branch_fingerprint_id',
        
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'employee_id' => 'integer',
        'day' => 'integer',
        
    ];
    
    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'employee_id' => 'nullable',
        'date' => 'required',
        'time' => 'required',
        'branch_id' => 'required',
        'employee_fingerprint_id' => 'nullable',
        'branch_fingerprint_id' => 'nullable',
    ];
    
    public function employee()
    {
        return $this->belongsTo(Employee::class,'employee_id');
    }
    public function branch()
    {
        return $this->belongsTo(Branch::class,'branch_id');
    }
}
