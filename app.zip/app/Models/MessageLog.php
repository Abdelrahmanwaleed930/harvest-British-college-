<?php

namespace App\Models;

use Eloquent as Model;

/**
 * Class MessageLog
 * @package App\Models
 * @version December 8, 2021, 11:57 am EET
 *
 * @property \App\Models\Employee $employee
 * @property \Illuminate\Database\Eloquent\Collection $leads
 * @property integer $type
 * @property string $content
 */
class MessageLog extends Model
{
    public $table = 'message_logs';


    public $fillable = [
        'type',
        'content',
        'employee_id',
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function employee()
    {
        return $this->belongsTo(\App\Models\Employee::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     **/
    public function leads()
    {
        return $this->belongsToMany(\App\Models\Lead::class);
    }
    
    public function jobsApplications()
    {
        return $this->belongsToMany(\App\Models\JobApplication::class,'job_application_message_log','message_log_id','job_application_id');
    }
    
    public function PTsApplications()
    {
        return $this->belongsToMany(\App\Models\PlacementApplicant::class,'pt_application_message_log','message_log_id','pt_application_id');
    }
}
