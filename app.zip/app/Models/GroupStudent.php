<?php

namespace App\Models;

use Eloquent as Model;
use DB;

/**
 * Class GroupStudent
 * @package App\Models
 * @version October 9, 2021, 10:32 pm EET
 *
 * @property \App\Models\Group $group
 * @property \App\Models\Lead $lead
 * @property integer $group_id
 * @property integer $lead_id
 * @property integer $payment
 * @property integer $books
 * @property integer $activation
 * @property integer $certification
 * @property integer $absence_per
 * @property integer $exam_per
 */
class GroupStudent extends Model
{

    public $table = 'group_students';

    public $fillable = [
        'group_id',
        'lead_id',
        'level_id',
        'payment',
        'books',
        'activation',
        'harvest_certificate',
        'cambridge_certificate',
        'absence_per',
        'exam_per',
        'exam_status',
        'lead_payment_id',
        'Confirmation',
        'finance_status',
        'finance_employee_id',
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function group()
    {
        return $this->belongsTo(\App\Models\Group::class);
    }
    public function getclienttype($type){
        return Lead::where('id',$this->lead_id)->whereIn('type',[3,2])->where('customer_type' ,$type)->count();
    }
    public function getCustomerTrack()
    {
        return CustomerTrack::where('lead_id',$this->lead_id)->where('track_id',$this->group->track_id)->where('course_id',$this->group->course_id)->first();
    }
    public function checkcustomertrack()
    {
        return CustomerTrack::where('lead_id',$this->lead_id)->where('total','>','used')->first();
    }
    
    public function getSessionAttendance()
    {
        return GroupSessionAttendance::where('lead_id',$this->lead_id)->where('group_id',$this->group_id)->where('level_id',$this->level_id)->orderBy('group_session_id')->get();
    }
    
    public function leadPayment()
    {
        return $this->belongsTo(\App\Models\LeadPayment::class,'lead_payment_id','id');
    }
    
    public function cachBooks()
    {
        $book = DB::table('stage_level_items')->where('level_id',$this->level_id)->first();
        $check_payment = LeadPayment::where('lead_id',$this->lead_id)->where('paymentable_type','App\Models\ExtraItem')->where('paymentable_id',$book->item_id)->first();
        
        return ($check_payment != null && $check_payment != '')?true:false;
    }
    
    public function cashHarvestCertificate()
    {
        $check_payment = LeadPayment::where('lead_id',$this->lead_id)->where('paymentable_type','App\Models\ExtraItem')->where('paymentable_id',2)->first();
        return ($check_payment != null && $check_payment != '')?true:false;
    }
    
    public function cashCambridgeCertificate()
    {
        $check_payment = LeadPayment::where('lead_id',$this->lead_id)->where('paymentable_type','App\Models\ExtraItem')->where('paymentable_id',3)->first();
        return ($check_payment != null && $check_payment != '')?true:false;
    }
    
    public function freeBooks()
    {
        
        $check2 = $this->lead->payments->where('paymentable_type','App\\Models\\Offer')->sortByDesc('id')->first();
        //dd($check2);
        if($check2 != null && $check2 != ''){
            //if($check2->paymentable_type == 'App\\Models\\Offer'){
                $offer = Offer::find($check2->paymentable_id);
                
                $book_id = DB::table('stage_level_items')->where('level_id',$this->level_id)->first();
                if($offer->include_books == 1){
                    return true;
                }
                elseif($book_id != null && $book_id != ''){
                    $offer_items = $offer->items->pluck('id')->toArray();
                
                    return (in_array($book_id->item_id,$offer_items))?true:false;
                }else{
                    return false;
                }
            //}
        }
        $check1 = OldCustomerPayment::where('customer_id',$this->lead_id)->where('books',1)->first();
        if($check1 != null && $check1 != ''){
            return true;
        }
        return false;
    }
    
    public function freeHarvestCertificate()
    {
        $check1 = OldCustomerPayment::where('customer_id',$this->lead_id)->where('harvest_certificate',1)->first();
        if($check1 != null && $check1 != ''){
            return true;
        }
        
        $check2 = $this->leadPayment;
        if($check2 != null && $check2 != ''){
            if($check2->paymentable_type == 'App\\Models\\Offer'){
                $offer = Offer::find($check2->paymentable_id);
                $offer_items = $offer->items->pluck('id')->toArray();
                return (in_array(2,$offer_items))?true:false;
            }
        }
        return false;
    }
    
    public function freeCambridgeCertificate()
    {
        $check1 = OldCustomerPayment::where('customer_id',$this->lead_id)->where('cambridge_certificate',1)->first();
        if($check1 != null && $check1 != ''){
            return true;
        }
        $check2 = $this->leadPayment;
        if($check2 != null && $check2 != ''){
            if($check2->paymentable_type == 'App\\Models\\Offer'){
                $offer = Offer::find($check2->paymentable_id);
                $offer_items = $offer->items->pluck('id')->toArray();
                return (in_array(3,$offer_items))?true:false;
            }
        }
        return false;
    }
    
    public function lead_payment()
    {
        return LeadPayment::where('lead_id',$this->lead_id)->where('rest','>',0)->first();
    }
    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function lead()
    {
        return $this->belongsTo(\App\Models\Lead::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function level()
    {
        return $this->belongsTo(\App\Models\StageLevel::class, 'level_id');
    }



    public function getpayment($paymentable_ids , $check)
    {
        if($check == 1){
            return DB::table('lead_payments')
         ->where('lead_id' , $this->lead_id)
         ->where('request_group_id' ,$this->group_id )
         ->whereIn('paymentable_id',$paymentable_ids)
         ->where('paymentable_type','App\Models\ExtraItem')
         ->first();
        }
        else if($check == 0){
            return DB::table('lead_payments')
         ->where('lead_id' , $this->lead_id)
         ->whereIn('paymentable_id',$paymentable_ids)
         ->where('paymentable_type','App\Models\ExtraItem')
         ->first();

        }
        


    }
}
