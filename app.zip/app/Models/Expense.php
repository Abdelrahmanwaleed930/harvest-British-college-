<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Expense extends Model
{
    use HasFactory;
    
    public $table = 'expenses';
    
    public $fillable = [
        'employee_id',
        'branch_id',
        'expense_type_id',
        'method_id',
        'amount',
        'reference_number',
        'upload_bill',
        'status',
        'note',
    ];
      protected $casts = [
        'employee_id' => 'integer',
        'branch_id' => 'integer',
        'expense_type_id' => 'integer',
        'method_id' => 'integer',
        'amount' => 'integer',
        'reference_number' => 'string',
        'upload_bill' => 'string',
        'status' => 'string',
        'note' => 'string'
        
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'employee_id' => 'required',
        'branch_id' => 'required',
        'expense_type_id' => 'required',
        'method_id' => 'required',
        'amount' => 'required',
        'reference_number' => 'nullable',
        'upload_bill' => 'required',
        'status' => 'required',
        'note' => 'required',
        
    ];  


    public function employee(): BelongsTo
    {
        return $this->belongsTo(Employee::class);
    }
    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }
    public function method(): BelongsTo
    {
        return $this->belongsTo(PaymentMethod::class);
    }
    public function type(): BelongsTo
    {
        return $this->belongsTo(ExpenseType::class,'expense_type_id');
    }
}
