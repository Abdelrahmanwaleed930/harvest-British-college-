<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class LeadCase
 * @package App\Models
 * @version May 9, 2021, 4:13 pm UTC
 *
 * @property \App\Models\Lead $lead
 * @property \App\Models\Employee $employee
 * @property \App\Models\Branch $branch
 * @property \App\Models\Label $label
 * @property \App\Models\LabelType $labelType
 * @property integer $lead_id
 * @property integer $student_id
 * @property integer $employee_id
 * @property integer $branch_id
 * @property integer $label_id
 * @property integer $label_type_id
 * @property string $serial
 * @property string $timeline
 * @property string $details
 * @property string $feedback
 * @property string $other_feedback
 * @property string $action
 * @property string $other_action
 * @property string $notes
 * @property string $status
 * @property string $date
 */
class JobApplicationLastCase extends Model
{
    // use SoftDeletes;

    public $table = 'jobs_applications_last_case';

    public $fillable = [
        'job_application_case_id',
        'job_application_id',
        'employee_id',
        'label_type_id',
        'follow_up_type',
        'serial',
        'call_type',
        'feedback_id',
        'other_feedback',
        'feedback_date',
        'action_id',
        'other_action',
        'notes',
        'status',
        'date'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'label_type_id' => 'required',
        'follow_up_type' => 'required',
        'call_type' => 'required',
        'feedback_id' => 'required',
        'other_feedback' => 'required_if:feedback,other',
        'action_id' => 'required',
        'other_action' => 'required_if:action,other',
        'notes' => 'required',
        'date' => 'required|date_format:Y-m-d',
        'feedback_date' => 'required|date_format:Y-m-d',
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function job_application()
    {
        return $this->belongsTo(\App\Models\JobApplication::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function employee()
    {
        return $this->belongsTo(\App\Models\Employee::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function label()
    {
        return $this->belongsTo(\App\Models\Label::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function labelType()
    {
        return $this->belongsTo(\App\Models\LabelType::class,'label_type_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function feedback()
    {
        return $this->belongsTo(\App\Models\Feedback::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function action()
    {
        return $this->belongsTo(\App\Models\Action::class);
    }

}
