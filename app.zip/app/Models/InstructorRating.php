<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;


/**
 * Class Interval
 * @package App\Models
 * @version May 19, 2021, 11:50 pm UTC
 *
 * @property string $name
 * @property string $time
 * @property string $pattern
 * @property integer $sort
 * @property integer $status
 */
class InstructorRating extends Model
{
    use SoftDeletes;


    public $table = 'instructors_rating';


    protected $dates = ['deleted_at'];



    public $fillable = [
        'branch_id',
        'instructor_id',
        'track_id',
        'sub_track_id',
        'level_id',
        'days',
        'interval_id',
        'total',
        'notes',
        'q1',
        'q2',
        'q3',
        'q4',
        'q5',
        'q6',
        'q7',
        'q8',
        'q9',
        'q10',
        'q11',
        'q12',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'branch_id' => 'integer',
        'instructor_id' => 'integer',
        'track_id' => 'integer',
        'sub_track_id' => 'integer',
        'level_id' => 'integer',
        'days' => 'integer',
        'interval_id' => 'integer',
        'total' => 'integer',
        'notes' => 'string',
        'q1' => 'integer',
        'q2' => 'integer',
        'q3' => 'integer',
        'q4' => 'integer',
        'q5' => 'integer',
        'q6' => 'integer',
        'q7' => 'integer',
        'q8' => 'integer',
        'q9' => 'integer',
        'q10' => 'integer',
        'q11' => 'integer',
        'q12' => 'integer',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'branch_id' => 'required|integer',
        'instructor_id' => 'required|integer',
        'track_id' => 'required|integer',
        'sub_track_id' => 'required|integer',
        'level_id' => 'required|integer',
        'days' => 'required|integer',
        'interval_id' => 'required|integer',
        'total' => 'required|integer',
        'notes' => 'required|string',
        'q1' => 'required|integer',
        'q2' => 'required|integer',
        'q3' => 'required|integer',
        'q4' => 'required|integer',
        'q5' => 'required|integer',
        'q6' => 'required|integer',
        'q7' => 'required|integer',
        'q8' => 'required|integer',
        'q9' => 'required|integer',
        'q10' => 'required|integer',
        'q11' => 'required|integer',
        'q12' => 'required|integer',
        
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     **/
    public function branch()
    {
        return $this->belongsTo(\App\Models\Branch::class, 'branch_id','id');
    }
    
    public function instructor()
    {
        return $this->belongsTo(\App\Models\Employee::class, 'instructor_id','id');
    }
    
    public function track()
    {
        return $this->belongsTo(\App\Models\Track::class, 'sub_track_id','id');
    }
    
    public function level()
    {
        return $this->belongsTo(\App\Models\StageLevel::class, 'level_id','id');
    }
    
    public function interval()
    {
        return $this->belongsTo(\App\Models\Interval::class, 'interval_id','id');
    }
}
