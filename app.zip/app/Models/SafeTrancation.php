<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SafeTrancation extends Model
{
    use HasFactory;

    public $table = 'safe_trancations';
    public $fillable = [
        'sender',
        'receiver',
        'safe_sender',
        'safe_receiver',
        'amount',
        'description',
        'payment_methods_id',
        'reference_num',
        'status'
    ];

    public function senderEmployee(): BelongsTo
    {
        return $this->belongsTo(Employee::class, 'sender');
    }
    public function receiverEmployee(): BelongsTo
    {
        return $this->belongsTo(Employee::class, 'receiver');
    }
    public function senderSafe(): BelongsTo
    {
        return $this->belongsTo(Safe::class, 'safe_sender');
    }
    public function receiverSafe(): BelongsTo
    {
        return $this->belongsTo(Safe::class, 'safe_receiver');
    }
    public function paymentMethods(): BelongsTo
    {
        return $this->belongsTo(PaymentMethod::class, 'payment_methods_id');
    }
}
