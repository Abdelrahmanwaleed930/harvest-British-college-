<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;


/**
 * Class Round
 * @package App\Models
 * @version July 30, 2021, 1:27 am UTC
 *
 * @property \App\Models\ServiceFee $serviceFee
 * @property integer $service_fee_id
 * @property string $title
 */
class Round extends Model
{
    use SoftDeletes;


    public $table = 'rounds';


    protected $dates = ['deleted_at'];



    public $fillable = [
        'timeframe_id',
        'title'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'timeframe_id' => 'integer',
        'title' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'timeframe_id' => 'required',
        'title' => 'required'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function timeframe()
    {
        return $this->belongsTo(\App\Models\Timeframe::class);
    }
    
    
    
    public function nextSubRound($date )
    {
        $timeframe = $this->timeframe;
        $days = $timeframe->days;
        
        $next_sub_rounds = collect();
        foreach($days as $day){
            $next_sub_round = SubRound::where('round_id',$this->id)
            ->where('days',$day)->where('start_date','>',$date)->orderBy('start_date')->first();
            if($next_sub_round != null && $next_sub_round != ''){
                $next_sub_rounds->push($next_sub_round);
            }
        }
        
        if($next_sub_rounds != null && count($next_sub_rounds) > 0){
            return $next_sub_rounds;
        }else{
            return null;
        }
        
    }
    
    public function previousSubRound($date)
    {
        $timeframe = $this->timeframe;
        $days = $timeframe->days;
        
        $previous_sub_rounds = collect();
        foreach($days as $day){
            $previous_sub_round = SubRound::where('round_id',$this->id)->where('days',$day)->where('end_date','<=',$date)->orderBy('end_date','desc')->first();
            if($previous_sub_round != null && $previous_sub_round != ''){
                $previous_sub_rounds->push($previous_sub_round);
            }
        }
        
        if($previous_sub_rounds != null && count($previous_sub_rounds) > 0){
            return $previous_sub_rounds;
        }else{
            return null;
        }
    }
    
    /**
     * Get all of the subRound for the Round
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function subRounds()
    {
        return $this->hasMany(SubRound::class);
    }
    
    public function groups()
    {
        return $this->hasMany(Group::class);
    }
    
    public function groupsCount($sub_rounds_ids)
    {
        return Group::where('round_id',$this->id)->whereIn('sub_round_id',$sub_rounds_ids)->count();
    }
    
}
