<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes;
use DB;
use Carbon\Carbon;
  use DateTime;
/**
 * Class Branch
 * @package App\Models
 * @version May 8, 2021, 2:55 pm UTC
 *
 * @property string $name
 * @property string $address
 * @property string $phone
 */

class Branch extends Model
{
    use SoftDeletes;

    public $table = 'branches';

    protected $dates = ['deleted_at'];

    public $fillable = [
        'name',
        'address',
        'phone',
        'name_ar',
        'address_ar',
        'latitude',
        'longitude',
        'manager_id',
        'status',
        'area_manager_id',
        'request_lead',
        'data_will_be_assigned',
        'finger_id',
    ];    
    
    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'name' => 'string',
        'address' => 'string',
        'phone' => 'string',
        'name_ar' => 'string',
        'address_ar' => 'string',
        'latitude' => 'string',
        'longitude' => 'string',
        'manager_id' => 'integer',
        'status' => 'integer',
        'area_manager_id' => 'integer',
        'finger_id' => 'integer'
    ];
    
    public function manager()
    {
        return $this->belongsTo(Employee::class,'manager_id','id');
    }
    
    public function leads()
    {
        return $this->hasMany(Lead::class);
    }
    
    public function area_manager()
    {
        return $this->belongsTo(Employee::class,'area_manager_id','id');
    }
    
    public function getSafeBalance($date,$payment_method_id = null)
    {
        $cash_amount = LeadPayment::where('branch_id',$this->id)->where('payment_plan_id',2)
        ->where('created_at','like',$date.'%');
        if($payment_method_id != null && $payment_method_id != ''){
            $cash_amount->where('payment_method_id',$payment_method_id);
        }
        $total_cash = $cash_amount->sum('amount');
        
        $deptor_amount = SubPayment::leftJoin('lead_payments','lead_payments.id','=','sub_payments.lead_payment_id')
            ->whereIn('lead_payments.payment_plan_id',[1,3])
            ->where('sub_payments.paid',1)
            ->where('due_date','like',$date.'%')
            ->where('sub_payments.branch_id',$this->id);
            
        if($payment_method_id != null && $payment_method_id != ''){
            $deptor_amount->where('sub_payments.payment_method_id',$payment_method_id);
        }
        $total_deptor = $deptor_amount->sum('sub_payments.amount');
        
        return $total_cash + $total_deptor;
    }
    
    public function getAbsentCustomersByTimeframe($branch_id,$instructors_ids,$timeframe,$roundid , $subroundid)
    {
        $instructor_groups = Group::whereIn('instructor_id',$instructors_ids)
        ->where('timeframe_id',$timeframe->id)->where('branch_id',$branch_id);
        
        
        if($roundid != null && $roundid != ''){
            
            $instructor_groups->where('round_id' , $roundid);
            if($subroundid != null && $subroundid != ''){
                $instructor_groups->where('sub_round_id' , $subroundid);
            }
        }else{
            $instructor_groups->whereHas('subRound',function($query){
                $query->where('start_date','<',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
            });

        }
        
        // ->where('round_id',$roundid)->where('sub_round_id' ,$subroundid);
        $attend_by_timeframe = array();
        $instructor_groups = $instructor_groups->with('sessions')->withCount('sessions')->get();
        if($instructor_groups != null && count($instructor_groups) > 0){
            $sessions_attendance = GroupSessionAttendance::whereIn('group_id',$instructor_groups->pluck('id')->toArray())
                                                        ->whereNotNull('attendance')
                                                        ->select('lead_id',DB::raw('count(case when attendance = 1 then attendance end) as attending , count(case when attendance = 0 then attendance end) as absent'))
                                                        ->groupBy('lead_id')->get();
            if($sessions_attendance != null && count($sessions_attendance) > 0){
                $attend_by_timeframe['absent_by_timeframe'] = $sessions_attendance->where('attending',0)->count();
                $attend_by_timeframe['attend_students_ids'] = implode(',',$sessions_attendance->where('attending','>',0)->pluck('lead_id')->toArray());
                $attend_by_timeframe['absent_students_ids'] = implode(',',$sessions_attendance->where('attending',0)->pluck('lead_id')->toArray());
                //dd($attend_students_ids,$absent_students_ids);
            }
        }
        return $attend_by_timeframe;
    }
    
    public function getActualCustomers($instructors_ids)
    {
        $instructor_groups = Group::whereIn('instructor_id',$instructors_ids)->where('branch_id',$this->id)->whereHas('subRound',function($query){
            $query->where('start_date','<',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
        });
        
        $instructor_groups = $instructor_groups->withCount('students')->get();
        return $instructor_groups->sum('students_count');
    }
    
    public function getActualPlan($instructors_ids)
    {
        //dd($instructors_ids);
        $instructor_groups = Group::whereIn('instructor_id',$instructors_ids)->where('branch_id',$this->id)->whereHas('subRound',function($query){
            $query->where('start_date','<',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
        });
        
        $instructor_groups = $instructor_groups->select('days',DB::raw('count(*) as intervalcount,MAX(interval_id) as intervalid'))->groupBy('days')->get();
        $plan = ['days' => 0,'hours' => 0,'intervalcount' => 0];
        foreach($instructor_groups as $instructor_group){
            $plan['intervalcount'] += $instructor_group->intervalcount;
            $day = 0;
            if($instructor_group->days == 1){
                $plan['days'] += 1;
                $day = 1;
            }
            if(in_array($instructor_group->days,[2,3,4])){
                $plan['days'] += 2;
                $day = 2;
            }
            if(in_array($instructor_group->days,[5,6])){
                $plan['days'] += 3;
                $day = 3;
            }
            if(in_array($instructor_group->intervalid,[11,12,13])){
                $plan['hours'] += 4 * $instructor_group->intervalcount * $day;
            }else{
                $plan['hours'] += 2 * $instructor_group->intervalcount * $day;
            }
        }
        return $plan;
    }
    
    public static function getReservedByTimeframe($branch_id,$instructors_ids,$timeframe,$roundid , $subroundid)
    {
        $instructor_groups = Group::whereIn('instructor_id',$instructors_ids)
        ->where('timeframe_id',$timeframe->id)->where('branch_id',$branch_id);
        
        if($roundid != null && $roundid != ''){
            $instructor_groups->where('round_id' , $roundid);
            if($subroundid != null && $subroundid != ''){
                $instructor_groups->where('sub_round_id' , $subroundid);
            }
        }else{
            $instructor_groups->whereHas('subRound',function($query){
                $query->where('start_date','<',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
            });
        }
        
        $instructor_groups = $instructor_groups->withCount('students')->get();
        $groups_ids = implode(',',$instructor_groups->pluck('id')->toArray());
        $groups_students_count = $instructor_groups->sum('students_count');
        return array('groups_ids' => $groups_ids,'groups_students_count' => $groups_students_count);
    }
    
    public function getPlan($instructors_ids)
    {
        $employee_attendances = DB::table('employee_attendance')->select('employee_id','day',DB::raw('count(*) as intervalcount,MAX(interval_id) as intervalid'))->whereIn('employee_id',$instructors_ids)->groupBy('employee_id','day')->get();
        //dd($instructors_ids,$employee_attendances);
        $plan = ['days' => 0,'hours' => 0,'intervalcount' => 0];
        foreach($employee_attendances as $employee_attendance){
            $plan['intervalcount'] += $employee_attendance->intervalcount;
            $day = 0;
            if($employee_attendance->day == 1){
                $plan['days'] += 1;
                $day = 1;
            }
            if(in_array($employee_attendance->day,[2,3,4])){
                $plan['days'] += 2;
                $day = 2;
            }
            if(in_array($employee_attendance->day,[5,6])){
                $plan['days'] += 3;
                $day = 3;
            }
            if(in_array($employee_attendance->intervalid,[11,12,13])){
                $plan['hours'] += 4 * $employee_attendance->intervalcount * $day;
            }else{
                $plan['hours'] += 2 * $employee_attendance->intervalcount * $day;
            }
        }
        return $plan;
    }

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'name' => 'required',
        'address' => 'required',
        'phone' => 'required',
        'status' => 'required',
        //'manager_id' => 'required',
        //'area_manager_id' => 'required',
    ];
    
    public function getEmployeesCount()
    {
        $val = $this->id;
        return Employee::where('account_Type', 'Operations Account')->where('status',1)->where('current_branch',$this->id)/*->whereHas('branches', function (Builder $query) use ($val) {
                $query->where('id', $val);
            })*/->groupBy('id')->get()->count();
    }
    public function total($type)
    {
        if($type == 1)
        {
            return Employee::where('account_Type', 'Operations Account')
            ->where('status',1)->where('current_branch' ,$this->id)->groupBy('id')->get()->count();
        }
        elseif ($type == 2) {
            return Employee::where('account_Type', 'ESL Account Profile')
            ->where('status',1)->where('current_branch',$this->id)->groupBy('id')->get()->count();
        }
    } 
    public function salaries()
    {
        $agent = Employee::where('account_Type', 'Operations Account')
        ->where('status',1)->where('current_branch',$this->id)->groupBy('id')->get()->sum('starting_salary');
            
        $esl = Employee::where('account_Type', 'ESL Account Profile')
        ->where('status',1)->where('current_branch',$this->id)->groupBy('id')->get()->sum('starting_salary');

        return $agent + $esl;
    }
    
    // public function totallead()
    // {
    //     $datenow = Carbon::now();
    //     $monthName = $datenow->format('F');
    
    //     $date = $monthName.' 1 2023';
    //     $firstday= date('Y-m-d', strtotime($date));
        
        
    //     $month_number = date("n",strtotime($monthName));
    //     if($month_number <= 3){
    //          if($month_number == 3)
    //          { $month_number = 12;}
    //          elseif($month_number == 2)
    //          { $month_number = 11;}
    //          elseif($month_number == 1)
    //          { $month_number = 10;}
    //      }
    //      else{
    //           $month_number;
    //      }
    //     $now = new DateTime();
    //     $dateObj = $now->createFromFormat('!m', $month_number-1);
    //     $oldmonthName = $dateObj->format('F');
    //     $olddate = $oldmonthName.' 1 2023';
    //     $oldfirstday= date('Y-m-d', strtotime($olddate));
        
  
    //     return $countlead = Lead::where('type' , 1)->where('branch_id' , $this->id)
    //     ->where('created_at','>=',$oldfirstday)->where( 'created_at','<',$firstday)->get()->count();
    // }
    
    
    public function targetcash($id)
    {
        $array_moths = [
            "1" => 10,
            "2" => 11,
            "3" => 12,
            "4" => 1,
            "5" => 2,
            "6" => 3,
            "7" => 4,
            "8" => 5,
            "9" => 6,
            "10" => 7,
            "11" => 8,
            "12" => 9,
        ];
        
        $datenow = Carbon::now();
        $monthName = $datenow->format('F');
        $month_number = date("n",strtotime($monthName));
        $date = $monthName.' 1 2023';
        $firstday= date('Y-m-d', strtotime($date));
        // if($month_number <= 3){
        //     if($month_number == 3)
        //     { $month_number = 12;}
        //     elseif($month_number == 2)
        //     { $month_number = 11;}
        //     elseif($month_number == 1)
        //     { $month_number = 10;}
        // }
        // else{
        //      $month_number;
        // }
        $now = new DateTime();
        $dateObj = $now->createFromFormat('m', $array_moths[$month_number]);
        //dd($month_number,$now,$dateObj);
        $oldmonthName = $dateObj->format('F');
        $olddate = $oldmonthName.' 1 2023';
        $oldfirstday= date('Y-m-d', strtotime($olddate));
    
        // $datelastObj = $now->createFromFormat('!m', $month_number-1);
        // $oldlastmonthName = $datelastObj->format('F');
        // $oldlastdate = $oldlastmonthName.' 1 2023';
        // $oldlastfirstday= date('Y-m-d', strtotime($oldlastdate));
        
        // $countlastmonth= $countlead = Lead::where('type' , 1)->where('branch_id' , $this->id)
        // ->where('created_at','>=',$oldlastfirstday)->where( 'created_at','<',$firstday)->get()->count();
        
        // $countlead = Lead::where('type' , 1)->where('branch_id' , $this->id)
        // ->whereBetween('created_at',[$firstday.'%',  date_format($datenow,"Y-m-d").'%'])->count();
        
        $countoldlead = Lead::where('type' , 1)->where('branch_id' , $this->id)
         ->whereBetween('created_at',[$oldfirstday,  $firstday])->count();
        $app_new_lead = number_format(($this->request_lead * 40)/100) ;
        $avg_last_old_lead = number_format(($countoldlead*5) /100);
        $total_app=$app_new_lead+$avg_last_old_lead;  
        $cash = $total_app * 1350;
        // Total Target Cash
        if($id == 0)
         {
             return $cash ;
         }
        //  target agent
        elseif($id == 1)
        {
            $countemployee =Employee::where('account_Type', 'Operations Account')
                ->where('status',1)->where('current_branch' ,$this->id)->groupBy('id')->get()->count();
            if($countemployee != 0 ){
             $target = $cash / $countemployee ;   
             return $target;
            }
            else{
                return $target=0;
            }
        }
        //no of agent          
        elseif($id == 2){
                 return $countemployee =Employee::where('account_Type', 'Operations Account')
                     ->where('status',1)->where('current_branch' ,$this->id)->groupBy('id')->get()->count();
              }
         //   count last 3 month
        elseif($id == 3){
                 
                  return number_format($countoldlead/3);
                  
              }
        //   app last 3 month
        elseif($id == 4){
            return $avg_last_old_lead;
        }
        // total app new lead
        elseif($id == 5){
            return $app_new_lead; 
        }
        // total app
        elseif($id == 6)
        {
            return $total_app;
        }
        // last 3 month
        elseif($id == 7)
        {
            return $countoldlead;
        }
    }
    
    public function sumTargetCashByStatus($status)
{
    $totalTargetCash = 0;

    // Get all branches that match the status
    $branches = Branch::where('status', $status)->get();

    foreach ($branches as $branch) {
        $branchTotalCash = $branch->targetcash(0); // 0 for total target cash

        $totalTargetCash += $branchTotalCash;
    }

    return $totalTargetCash;
}
    public function totalcall($type ,$date){
        $registration_from=null;
        $reg_to=null;

        if ($date && $date != null && $date != '') {
            $daterange = explode(' - ',$date);
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
            
        }
        if ($registration_from != null && $registration_to != '')
         {
            if($type == 1){return LeadCase::where('type',1)->where('branch_id',$this->id)->whereBetween('created_at', [$registration_from, $registration_to])    ->count();}
            elseif($type == 2){return LeadCase::where('type',2)->where('branch_id',$this->id)->whereBetween('created_at', [$registration_from, $registration_to])->count();}
            elseif($type == 3){return LeadCase::where('type',3)->where('branch_id',$this->id)->whereBetween('created_at', [$registration_from, $registration_to])->count();}
            elseif($type == 4){return LeadCase::where('type',4)->where('branch_id',$this->id)->whereBetween('created_at', [$registration_from, $registration_to])->count();}
             
         }

        else{
            if($type == 1){return LeadCase::where('type',1)->where('branch_id',$this->id)->where('created_at','like','%'.date('Y-m-d').'%')    ->count();}
            elseif($type == 2){return LeadCase::where('type',2)->where('branch_id',$this->id)->where('created_at','like','%'.date('Y-m-d').'%')->count();}
            elseif($type == 3){return LeadCase::where('type',3)->where('branch_id',$this->id)->where('created_at','like','%'.date('Y-m-d').'%')->count();}
            elseif($type == 4){return LeadCase::where('type',4)->where('branch_id',$this->id)->where('created_at','like','%'.date('Y-m-d').'%')->count();}
        }
        
    }
    
    public function getdebtor($type,$date){
        $registration_from=null;
        $reg_to=null;

        if ($date && $date != null && $date != '') {
            $daterange = explode(' - ',$date);
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
            
        }
     
        if($registration_from != null && $registration_to != ''){
            if($type == 1){
            // Debtor
                return $allRevenue=SubPayment::where('paid',0)->where('branch_id',$this->id)->whereNull('merchantRefNumber')
                ->whereNull('paymentMethod')->whereNull('payment_status')->whereBetween('due_date', [$registration_from, $registration_to])->sum('amount');
            }elseif($type == 2){
            // Online Debtor
               return $allRevenue=SubPayment::where('paid',0)->where('branch_id',$this->id)->whereNotNull('merchantRefNumber')
                ->whereNotNull('paymentMethod')->whereNotNull('payment_status')->whereBetween('due_date', [$registration_from, $registration_to])->sum('amount');
            }elseif($type == 3){
                // Total Debtor
                return $allRevenue=SubPayment::where('paid',0)->where('branch_id',$this->id)->whereBetween('due_date', [$registration_from, $registration_to])->sum('amount');
            }
            
        }else{
            if($type == 1){
            // Debtor
                return $allRevenue=SubPayment::where('paid',0)->where('branch_id',$this->id)->whereNull('merchantRefNumber')
                ->whereNull('paymentMethod')->whereNull('payment_status')->where('due_date','like','%'.date('Y-m-d').'%')->sum('amount');
            }elseif($type == 2){
            // Online Debtor
               return $allRevenue=SubPayment::where('paid',0)->where('branch_id',$this->id)->whereNotNull('merchantRefNumber')
                ->whereNotNull('paymentMethod')->whereNotNull('payment_status')->where('due_date','like','%'.date('Y-m-d').'%')->sum('amount');
            }elseif($type == 3){
                // Total Debtor
                return $allRevenue=SubPayment::where('paid',0)->where('branch_id',$this->id)->where('due_date','like','%'.date('Y-m-d').'%')->sum('amount');
            }
        }
        
        
    }
    
    public function getlead($type)
    {
        if($type == 1){
          return $leads = Lead::where('type',1)->where('branch_id',$this->id)->count();
        }else if($type ==2 ){
          return $leads = Lead::where('type',2)->where('branch_id',$this->id)->count();
        }else if($type ==3){
          return $leads = Lead::where('type',3)->where('branch_id',$this->id)->count();
        }else if($type == 4){
          return $leads = Lead::where('type',4)->where('branch_id',$this->id)->count();
        }else if($type == 5){
           return $leads = Lead::where('branch_id',$this->id)->count();
        }
    }

}
