<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Department;
use App\Models\Employee;
class Ticket extends Model
{
    use HasFactory;
   
    public $table = 'tickets';
    
    public $fillable = [
        'status',
        'image',
        'to_depart_id',
        'title',
        'description',
        'from_depart_id',
        'created_by_id',
        'last_action_date',
        'description',
        'video',
        'status',
        'last_action_employee_id',
        'note',
    ];
    
    protected $casts = [
        'status' => 'string',
        'image' => 'string',
        'to_depart_id' => 'integer',
        'title' => 'string',
        'description' => 'float',
        'from_depart_id' => 'integer',
        'created_by_id' => 'integer',
        // 'last_action_date' => 'date',
        'description' => 'string',
        'video' => 'string',
        'status' => 'string',
        'last_action_employee_id' => 'integer',
        'note' => 'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        // 'status' => 'integer',
        'image' => 'nullable',
        'to_depart_id' => 'required',
        'title' => 'required',
        'description' => 'required',
        // 'from_depart_id' => 'required',
        // 'created_by_id' => 'required',
        'last_action_date' => 'nullable',
        'description' => 'required',
        'video' => 'nullable',
        // 'status' => 'required',
        // 'last_action_employee_id' => 'required',
        'note' => 'nullable',
    ];

    public function todepartment()
    {
       return $this->belongsTo(Department::class,'to_depart_id');
    }
    public function fromdepartment()
    {
       return $this->belongsTo(Department::class,'from_depart_id');
    }
    public function employee()
    {
       return $this->belongsTo(Employee::class,'created_by_id');
    }
    public function department()
    {
       return $this->belongsTo(Department::class,'from_depart_id');
    }
   //  public function tobranch()
   //  {
   //     return $this->belongsTo(Branch::class,'from_depart_id');
   //  }
   //  public function frombranch()
   //  {
   //     return $this->belongsTo(Branch::class,'from_depart_id');
   //  }


    
    public function actionemployee()
    {
       return $this->belongsTo(Employee::class,'last_action_employee_id');
    }

}
