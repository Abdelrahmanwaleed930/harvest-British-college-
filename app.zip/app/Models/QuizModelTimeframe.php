<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QuizModelTimeframe extends Model
{
    public $table = 'quiz_model_timeframe';

   public $fillable = [
        'quiz_model_id',
        'timeframe_id',
        'session_number',
        'level_id',
        
    ];
    public function level()
    {
        return $this->belongsTo(\App\Models\StageLevel::class);
    }
    public function quiz_model()
    {
        return $this->belongsTo(\App\Models\QuizModel::class);
    }
    public function timeframe()
    {
        return $this->belongsTo(\App\Models\Timeframe::class, 'timeframe_id');
    }
}
