<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SectionsMonitoring extends Model
{
    use HasFactory;
    protected $table = "sections_monitoring";
     public $fillable = [
         'monitoring_id',
         'monitoring_sections_id',
         'monitoring_sections_topic_id',
         'comment',
         'score_type',
         'score',
         'action',
         ];
         
    public function Monitoring()
    {
        return $this->belongsTo('\App\Models\Monitoring','monitoring_id');
    }      
    public function MonitoringSections()
    {
        return $this->belongsTo('\App\Models\MonitoringSections','monitoring_sections_id');
    }      
    public function MonitoringSectionTopic()
    {
        return $this->belongsTo('\App\Models\MonitoringSectionTopic','monitoring_sections_topic_id');
    }      
         
}
