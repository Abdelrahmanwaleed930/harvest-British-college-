<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ItTransferItems extends Model
{
    use HasFactory;
     public $table = 'it_transfer_items';


    public $fillable = [
        'it_items_categories_id',
        'it_item_id',
        'from_branch_id',
        'to_branch_id',
        'item_count',
        'created_by_id',
        'balance_from',
        'balance_to',
        'details',
        'notes'
    ];
     public function ititemCategory()
    {
        return $this->belongsTo(\App\Models\ITItemCategory::class,'it_items_categories_id','id');
    }
    
    public function ititem()
    {
        return $this->belongsTo(\App\Models\ITItem::class,'it_item_id','id');
    }
    public function from_branch()
    {
        return $this->belongsTo(\App\Models\Branch::class,'from_branch_id','id');
    }
    public function to_branch()
    {
        return $this->belongsTo(\App\Models\Branch::class,'to_branch_id','id');
    }
    
    public function created_by()
    {
        return $this->belongsTo(\App\Models\Employee::class,'created_by_id','id');
    }
}
