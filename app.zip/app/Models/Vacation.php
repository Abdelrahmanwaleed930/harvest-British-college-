<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Vacation extends Model
{
    use HasFactory;
    public $table = 'vacations';

    /**
     * Dates array.
     *
     * @var array
     */
    protected $dates = ['deleted_at'];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $fillable = [
        'employee_id',
        'vacations_id',
        'annual',
        'casual',
        'sick',
        'year',
    ];


}
