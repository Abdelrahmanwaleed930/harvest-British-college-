<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ToDoListJobs extends Model
{
    use HasFactory;
    public $table = 'jobs_to_do_list';
     public $fillable = [
        'dept_id',
        'job_id',
        'type',
        'text',
        'status',
        'time',
        'day',
    ];
     public function job()
    {
        return $this->belongsTo(Job::class,'job_id');
    }
    
    public function department()
    {
        return $this->belongsTo(Department::class,'dept_id');
    }
}
