<?php

namespace App\Traits;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

trait StoreImageTrait 
{
    private function getImageManager()
    {
        return new ImageManager(new Driver());
    }

    public function verifyAndDeleteFile($old_file, $directory)
    {
        $file_path = base_path() . '/'.$directory.'/';
        if($old_file != null && $old_file != ''){
            unlink(sprintf($file_path . '%s', $old_file));
        }
    }
    
    public function verifyAndUpdateFile($old_file, Request $request, $fieldname, $directory)
    {
        $filename = $old_file;
        if($request->hasFile($fieldname)){
            $file_path = '/home/harvestc/public_html/'.$directory.'/';
            if($old_file != null && $old_file != ''){
                unlink(sprintf($file_path . '%s', $old_file));
            }
            
            $extension = $request->file($fieldname)->getClientOriginalExtension();
            $filename = rand(11111111, 99999999). '.' . $extension;
            $path = storage_path('app/'.$directory.'/');
            $request->file($fieldname)->move($path, $filename);
            
            File::move(storage_path('app/'.$directory.'/'.$filename), '/home/harvestc/public_html/'.$directory.'/'.$filename);
        }
        return $filename;
    }
    
    public function verifyAndStoreFile(Request $request, $fieldname, $directory)
    {
        $filename = null;
        if($request->hasFile($fieldname)){
            $extension = $request->file($fieldname)->getClientOriginalExtension();
            $filename = rand(11111111, 99999999). '.' . $extension;
            $path = storage_path('app/'.$directory.'/');
            $request->file($fieldname)->move($path, $filename);
            
            File::move(storage_path('app/'.$directory.'/'.$filename), '/home/harvestc/public_html/'.$directory.'/'.$filename);
        }
        return $filename;
    }
    
   public function verifyAndUpdateImageSource($old_image, Request $request, $fieldname, $directory_source) 
    {
        $fileName = $old_image;
        if ($request->hasFile($fieldname)) {
            $file = $request->file($fieldname);
            $img_path = '/home/harvestc/public_html/'.$directory_source.'/';
    
            // Check and delete the old file if it exists
            if ($old_image != null && $old_image != '') {
                $filePath = $img_path . $old_image;
    
                if (file_exists($filePath)) {
                    unlink($filePath);
                } else {
                    \Log::warning("File not found: " . $filePath);
                }
            }
    
            $extension = 'webp';
            $fileName = rand(111111, 999999) . '.' . $extension;
            $path = storage_path('app/'.$directory_source.'/' . $fileName);
    
            // Save new image
            $manager = $this->getImageManager();
            $image = $manager->read($file);
            $image->toWebp(80)->save($path);
    
            // Move the new file to the public directory
            File::move($path, $img_path . $fileName);
        }
        return $fileName;
    }

    public function verifyAndStoreImageSource(Request $request, $fieldname, $directory_source) 
    {
        $fileName = null;
        if($request->hasFile($fieldname)) {
            $file = $request->file($fieldname);
            $extension = 'webp';
            $fileName = rand(111111, 999999) . '.' . $extension;
            $path = storage_path('app/'.$directory_source.'/' . $fileName);

            $manager = $this->getImageManager();
            $image = $manager->read($file);
            $image->toWebp(80)->save($path);

            File::move($path, '/home/harvestc/public_html/'.$directory_source.'/'.$fileName);
        }
        return $fileName;
    }
    
    public function verifyAndStoreImageFileSource($file, $directory_source) 
    {
        $fileName = null;
        if($file != null) {
            $extension = 'webp';
            $fileName = rand(111111, 999999) . '.' . $extension;
            $path = storage_path('app/'.$directory_source.'/' . $fileName);

            $manager = $this->getImageManager();
            $image = $manager->read($file);
            $image->toWebp(80)->save($path);

            File::move($path, '/home/harvestc/public_html/'.$directory_source.'/'.$fileName);
        }
        return $fileName;
    }

    public function verifyAndUpdatefileImageSource($old_image, Request $request, $fieldname, $directory_source) 
    {
        $fileName = $old_image;
        if($request->hasFile($fieldname)) {
            $file = $request->file($fieldname);
            $img_path = '/home/harvestc/public_html/'.$directory_source.'/';

            if($old_image != null && $old_image != ''){
                unlink(sprintf($img_path . '%s', $old_image));
            }

            $extension = 'webp';
            $fileName = rand(111111, 999999) . '.' . $extension;
            $path = storage_path('app/'.$directory_source.'/' . $fileName);

            $manager = $this->getImageManager();
            $image = $manager->read($file);
            $image->toWebp(80)->save($path);

            File::move($path, $img_path . $fileName);
        }
        return $fileName;
    }
}
