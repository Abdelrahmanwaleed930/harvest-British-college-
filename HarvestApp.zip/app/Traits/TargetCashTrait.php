<?php

namespace App\Traits;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\Models\Employee;
use App\Models\Lead;
use App\Models\Offer;
use App\Models\Branch;
use App\Models\SubPayment;
use Carbon\Carbon;
use DateTime;

trait TargetCashTrait {

    public function getTargetCashBranch($branch_id)
    {
        
        $sales_cash = Offer::whereHas('disciplines',function($query){
            $query->where('discipline_id',1);
        })->where('offer_type' ,1)->where('duration',3)->where('num_levels',3)->where('end_date','>=',date('Y-m-d'))->where('payment_plan_id',2)->first();
        $operation_cash =  Offer::whereHas('disciplines',function($query){
            $query->where('discipline_id',1);
        })->where('offer_type' ,2)->where('duration',3)->where('num_levels',3)->where('end_date','>=',date('Y-m-d'))->where('payment_plan_id',2)->first();
        
        $branch = Branch::find($branch_id);
        
        $firstDayOfMonth = Carbon::now()->firstOfMonth();
        $firstDayOfThreeMonthsAgoFromSpecificDate = Carbon::now()->subMonths(3)->firstOfMonth();
        
        $sales = 0;
        $customer = 0;
        $client = 0;
        // $lead = Lead::where('branch_id' , $branch->id);
       
        $fresh_lead = Lead::where('branch_id' , $branch->id)->where('type' , 1)->whereBetween('created_at',[$firstDayOfMonth, date('Y-m-d',strtotime('+1 days'))])->count();
        $app_new_lead = (( $fresh_lead * 20) / 100) ;
        $countoldlead = Lead::where('branch_id' , $branch->id)->where('type' , 1)->where('created_at','<',$firstDayOfThreeMonthsAgoFromSpecificDate)->count();
        $old_lead = (($countoldlead * 10) / 100);
        $counlastQlead = Lead::where('branch_id' , $branch->id)->where('type' , 1)->whereBetween('created_at',[$firstDayOfThreeMonthsAgoFromSpecificDate,  $firstDayOfMonth])->count();
        $last_q_lead = (($counlastQlead * 15) / 100);
        $total_app = $app_new_lead + $old_lead + $last_q_lead;   
        
        $sales = $total_app * (($sales_cash != null) ? $sales_cash->fees: 2640);
        
        $employees_payment = SubPayment::join('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
            ->whereIn('lead_payments.payment_plan_id',[1,3])
            ->where('sub_payments.created_at','>=','2024-09-01')
            ->where('sub_payments.due_date' , '<=' , date('Y-m-d'))
            ->where('sub_payments.branch_id' , $branch_id)
            ->where('sub_payments.paid',0)->get();
        
        $customer_no = Lead::where('branch_id' , $branch->id)->where('type',2)->count();
        $customer_activation = $customer_no * 880;
        $customer_unpaid = $employees_payment->where('type',2)->whereIn('lead_type',[1,2])->sum('amount');
        $customer = $customer_activation + $customer_unpaid;
        
        $client_no = Lead::where('branch_id' , $branch->id)->where('type',3)->count();
        $client_certi = ($client_no * 10) / 100 * 1300;
        $client_activation = (($client_no * 35) / 100) * (($operation_cash != null) ? $operation_cash->fees: 1980);
        $client_unpaid = $employees_payment->where('type',2)->where('lead_type',3)->sum('amount');
        
        $client = $client_certi + $client_activation + $client_unpaid ; 
        $countemployee =Employee::where('account_Type', 'Operations Account')->where('status',1)->where('current_branch' ,$branch->id)->groupBy('id')->get()->count();
        
        $lead_count = new Branch;
        $lead_count->sales= $sales;
        $lead_count->customer= $customer;
        $lead_count->client= $client;
        $lead_count->total_app= $total_app;
        $lead_count->last_q= $counlastQlead; 
        $lead_count->avg_last_q= $last_q_lead / 3;
        $lead_count->request_lead= $branch->request_lead;
        $lead_count->app_new_lead= $app_new_lead;
        $lead_count->employee_count= $countemployee;
        $lead_count->no_leads= Lead::where('branch_id' , $branch->id)->where('type',1)->count();
        $lead_count->no_customer= Lead::where('branch_id' , $branch->id)->where('type',2)->count();
        $lead_count->no_client= Lead::where('branch_id' , $branch->id)->where('type',3)->count();
        $lead_count->name= $branch->name;
        $lead_count->branch_id= $branch->id;
        $lead_count->fresh_lead= $fresh_lead;
        
        $all_lead[$branch->id] = $lead_count;
        
        return $all_lead;        
        
        
    
        
    }
    public function getTargetCashEmployee($employee_id)
    {
        $sales_cash = Offer::whereHas('disciplines',function($query){
            $query->where('discipline_id',1);
        })->where('offer_type' ,1)->where('duration',3)->where('num_levels',3)->where('end_date','>=',date('Y-m-d'))->where('payment_plan_id',2)->first();
        $operation_cash =  Offer::whereHas('disciplines',function($query){
            $query->where('discipline_id',1);
        })->where('offer_type' ,2)->where('duration',3)->where('num_levels',3)->where('end_date','>=',date('Y-m-d'))->where('payment_plan_id',2)->first();
        
        $employee = Employee::find($employee_id);
        $sales = 0;
        $customer = 0;
        $client = 0;
        
        $firstDayOfMonth = Carbon::now()->firstOfMonth();
        $firstDayOfThreeMonthsAgoFromSpecificDate = Carbon::now()->subMonths(3)->firstOfMonth();
        
        $fresh_lead = Lead::where('assigned_employee_id' , $employee->id)->where('type' , 1)->whereBetween('created_at',[$firstDayOfMonth, date('Y-m-d',strtotime('+1 days'))])->count();
        $app_new_lead = (( $fresh_lead * 20) / 100) ;
        $countoldlead = Lead::where('assigned_employee_id' , $employee->id)->where('type' , 1)->where('created_at','<',$firstDayOfThreeMonthsAgoFromSpecificDate)->count();
        $old_lead = (($countoldlead * 10) / 100);
        $counlastQlead = Lead::where('assigned_employee_id' , $employee->id)->where('type' , 1)->whereBetween('created_at',[$firstDayOfThreeMonthsAgoFromSpecificDate, $firstDayOfMonth])->count();
        $last_q_lead = (($counlastQlead * 15) / 100);
        //dd($app_new_lead,$old_lead,$last_q_lead);
        $total_app = $app_new_lead + $old_lead + $last_q_lead;  
        
        $sales = $total_app * (($sales_cash != null) ? $sales_cash->fees: 2640);
        //dd($employee,$fresh_lead,$countoldlead,$counlastQlead,$app_new_lead,$old_lead,$last_q_lead);
        
        $employees_payment = SubPayment::join('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
            ->where('sub_payments.due_date' , '<=' , date('Y-m-d'))
            ->where('sub_payments.paid',0)
            ->where('sub_payments.employee_id',$employee_id)
            ->where('sub_payments.created_at','>=','2024-09-01')
            ->select('sub_payments.*','lead_payments.lead_type')->get();
            
            
            
        $customer_no = Lead::where('assigned_employee_id' , $employee->id)->where('type',2)->count();
        $customer_activation = $customer_no * 880;
        $customer_unpaid = $employees_payment->sum('amount');
        $customer += $customer_activation + $customer_unpaid;
        // return $operation_cash;
        $client_no = Lead::where('assigned_employee_id' , $employee->id)->where('type',3)->count();
        $client_certi = (($client_no * 10) / 100) * 1300;
        $client_activation = (($client_no * 35) / 100) * ($operation_cash->fees ?? 1980 );
        $client_unpaid = $employees_payment->where('sub_payments.type',2)->sum('amount');
        
        $client += $client_certi + $client_activation + $client_unpaid ; 
    
        $lead_count = new Employee;   
        $lead_count->sales= $sales;
        $lead_count->customer= $customer;
        $lead_count->client= $client;
        $lead_count->total_app= $total_app;
        $lead_count->last_q= $counlastQlead; 
        $lead_count->avg_last_q= $last_q_lead / 3;
        $lead_count->app_new_lead= $app_new_lead;
        $lead_count->no_leads= Lead::where('assigned_employee_id' , $employee->id)->where('type',1)->count();
        $lead_count->no_customer= Lead::where('assigned_employee_id' , $employee->id)->where('type',2)->count();
        $lead_count->no_client= Lead::where('assigned_employee_id' , $employee->id)->where('type',3)->count();
        // $lead_count->name= $employee->first_name;
        $lead_count->employee_id= $employee->id;
        $lead_count->fresh_lead= $fresh_lead;  
        
        $all_lead[$employee->id] = $lead_count;
        //dd($lead_count);
        return $lead_count;
    }
}