<?php
namespace App\Traits;

use App\Models\Setting;
use App\Models\Configuration;
use App\Models\Menu;
use App\Models\Page;
use App\Models\Offer;
use App\Models\TrainingService;
use App\Models\Cart;
use App\Models\CartItem;
use App;
use Auth;
use View;

trait SiteTrait
{
    
    public function getMainData(){
        $pages = Page::where('status',1)->get();
        $footer_menu_noparent = Menu::where('position_type','menu_footer')->whereNull('parent_id')->where('status',1)->orderBy('order_by')->get();
        $header_menu_noparent = Menu::where('position_type','menu_header')->whereNull('parent_id')->where('status',1)->orderBy('order_by')->get();
        //dd($lang);
        
        $cart_count = 0;
        $cart = null;
        //dd(Auth::guard('customer')->check());
        if(Auth::guard('customer')->check()){
            $cart = Cart::where('lead_id',Auth::guard('customer')->user()->id)->orderBy('id','desc')->first();
            //dd($cart,Auth::guard('customer')->user());
            if($cart != null && $cart != ''){
                if(session()->has('session_lead')){
                    $session_cart = Cart::where('session_lead',session()->get('session_lead'))->whereNull('lead_id')->orderBy('id','desc')->first();
                    if($session_cart != null && $session_cart != ''){
                        $cart_items = CartItem::where('cart_id',$session_cart->id)->get();
                        
                        foreach($cart_items as $cart_item){
                            $check_item = null;
                            
                            if($cart_item->item_type == 'offer'){
                                $item = Offer::where('id',$cart_item->item_id)->where('end_date','>=',date('Y-m-d'))->whereIn('show_in',['website','both'])->where('status',1)->first();
                                //$check_item = PackageUser::where('lead_id',Auth::guard('customer')->user()->id)->where('package_id',$item->id)->where('expire_date','>=',date('Y/m/d', strtotime('+3 days')))->first();
                            }
                            elseif($cart_item->item_type == 'training_service'){
                                $item = TrainingService::where('id',$cart_item->item_id)->where('status',1)->first();
                                /*
                                $check_item = CourseRegister::where('course_id',$item->id)->where('lead_id',Auth::guard('customer')->user()->id)->first();
                                if(! $check_item){
                                    $check_item = PackageCourse::where('course_id',$item->id)->where('lead_id',Auth::guard('customer')->user()->id)->where('package_expire_date','>=',date('Y/m/d'))->first();
                                }*/
                            }
                            else{
                                
                            }
                            
                            if(! $item){
                                CartItem::where('id',$cart_item->id)->delete();
                                
                                $cart->coupon = null;
                                $cart->coupon_discount = null;
                                $cart->coupon_cost = null;
                                $cart->net_price = null;
                                $cart->save();
                            }
                        }
                        CartItem::where('cart_id',$session_cart->id)->update(['cart_id' => $cart->id]);
                        Cart::where('session_lead',session()->get('session_lead'))->whereNull('lead_id')->orderBy('id','desc')->delete();
                        
                        $cart->calculateTotalPrice();
                    }else{
                        session()->remove('session_lead');
                    }
                }
                $cart_count = CartItem::where('cart_id',$cart->id)->count();
            }else{
                if(session()->has('session_lead')){
                    $cart = Cart::where('session_lead',session()->get('session_lead'))->orderBy('id','desc')->first();
                    if($cart != null && $cart != ''){
                        
                        $cart_items = CartItem::where('cart_id',$cart->id)->get();
                        
                        foreach($cart_items as $cart_item){
                            $check_item = null;
                            
                            if($cart_item->item_type == 'offer'){
                                $item = Offer::where('id',$cart_item->item_id)->where('end_date','>=',date('Y-m-d'))->whereIn('show_in',['website','both'])->where('status',1)->first();
                                //$check_item = PackageUser::where('lead_id',Auth::guard('customer')->user()->id)->where('package_id',$item->id)->where('expire_date','>=',date('Y/m/d', strtotime('+3 days')))->first();
                            }
                            elseif($cart_item->item_type == 'training_service'){
                                $item = TrainingService::where('id',$cart_item->item_id)->where('status',1)->first();
                                /*
                                $check_item = CourseRegister::where('course_id',$item->id)->where('lead_id',Auth::guard('customer')->user()->id)->first();
                                if(! $check_item){
                                    $check_item = PackageCourse::where('course_id',$item->id)->where('lead_id',Auth::guard('customer')->user()->id)->where('package_expire_date','>=',date('Y/m/d'))->first();
                                }
                                */
                            }
                            else{
                                
                            }
                            
                            if(! $item){
                                CartItem::where('id',$cart_item->id)->delete();
                                
                                $cart->coupon = null;
                                $cart->coupon_discount = null;
                                $cart->coupon_cost = null;
                                $cart->net_price = null;
                                $cart->save();
                            }
                        }
                        
                        $cart -> lead_id = Auth::guard('customer')->user()->id;
                        $cart -> session_lead = null;
                        $cart -> save();
                        
                        $cart->calculateTotalPrice();
                        $cart_count = CartItem::where('cart_id',$cart->id)->count();
                    }else{
                        session()->remove('session_lead');
                    }
                }
            }
        }else{
            if(session()->has('session_lead')){
                $cart = Cart::where('session_lead',session()->get('session_lead'))->orderBy('id','desc')->first();
                if($cart != null && $cart != ''){
                    $cart_count = CartItem::where('cart_id',$cart->id)->count();
                }
            }
        }
        
        View::share('footer_menu_noparent',$footer_menu_noparent);
        View::share('header_menu_noparent',$header_menu_noparent);
        View::share('pages', $pages);
        View::share('cart_count', $cart_count);
        View::share('cart', $cart);
        
    }
}