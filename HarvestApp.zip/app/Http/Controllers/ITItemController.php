<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateITItemRequest;
use App\Http\Requests\UpdateITItemRequest;
use App\Http\Controllers\AppBaseController;
use App\Models\ITItem;
use App\Models\ITItemCategory;
use Illuminate\Http\Request;
use Flash;
use Response;

class ITItemController extends AppBaseController
{
    /**
     * Display a listing of the ITItem.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var ITItem $items */
        $items = ITItem::all();

        return view('it_items.index')->with('items', $items);
    }

    /**
     * Show the form for creating a new ITItem.
     *
     * @return Response
     */
    public function create()
    {
        $categories = ITItemCategory::all()->pluck('name','id');
        
        return view('it_items.create',compact('categories'));
    }

    /**
     * Store a newly created ITItem in storage.
     *
     * @param CreateITItemRequest $request
     *
     * @return Response
     */
    public function store(CreateITItemRequest $request)
    {
        $input = $request->all();

        /** @var ITItem $item */
        $item = ITItem::create($input);

        Flash::success('IT Item saved successfully.');

        return redirect(route('admin.itItems.index'));
    }

    /**
     * Display the specified ITItem.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var ITItem $item */
        $categories = ITItemCategory::all()->pluck('name','id');
        
        $item = ITItem::find($id);

        if (empty($item)) {
            Flash::error('IT Item not found');

            return redirect(route('admin.itItems.index'));
        }

        return view('it_items.show')->with('item', $item)->with('categories',$categories);
    }

    /**
     * Show the form for editing the specified ITItem.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var ITItem $item */
        $categories = ITItemCategory::all()->pluck('name','id');
        
        $item = ITItem::find($id);

        if (empty($item)) {
            Flash::error('IT Item not found');

            return redirect(route('admin.itItems.index'));
        }

        return view('it_items.edit')->with('item', $item)->with('categories',$categories);
    }

    /**
     * Update the specified ITItem in storage.
     *
     * @param int $id
     * @param UpdateITItemRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateITItemRequest $request)
    {
        /** @var ITItem $item */
        $item = ITItem::find($id);

        if (empty($item)) {
            Flash::error('IT Item not found');

            return redirect(route('admin.itItems.index'));
        }

        $item->fill($request->all());
        $item->save();

        Flash::success('IT Item updated successfully.');

        return redirect(route('admin.itItems.index'));
    }

    /**
     * Remove the specified ITItem from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var ITItem $item */
        $item = ITItem::find($id);

        if (empty($item)) {
            Flash::error('IT Item not found');

            return redirect(route('admin.itItems.index'));
        }

        $item->delete();

        Flash::success('IT Item deleted successfully.');

        return redirect(route('admin.itItems.index'));
    }
}
