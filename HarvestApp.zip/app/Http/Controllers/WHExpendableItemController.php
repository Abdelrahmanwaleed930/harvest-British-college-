<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateWHExpendableItemRequest;
use App\Http\Requests\UpdateWHExpendableItemRequest;
use App\Http\Controllers\AppBaseController;
use App\Models\WHItem;
use App\Models\WHUsedItem;
use App\Models\WHExpendableItem;
use App\Models\WHItemCategory;
use App\Models\Place;
use Illuminate\Http\Request;
use Flash;
use Response;

class WHExpendableItemController extends AppBaseController
{
    /**
     * Display a listing of the WHExpendableItem.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var WHExpendableItem $expendable_items */
        $categories = WHItemCategory::all()->pluck('name','id');
        $wh_items = WHItem::select('id','name','item_category_id')->get();
        $wh_items = $wh_items->groupBy('item_category_id');
        
        
        $places = auth()->user()->places->pluck('name', 'id')->toArray();
        
        $expendableItemsQuary = WHExpendableItem::whereIn('place_id',array_keys($places));;
        $per_page = 10;
        
        if($request->per_page && $request->per_page){
            $per_page = $request->per_page;
        }
        if($request->item_category_id && $request->item_category_id){
            $expendableItemsQuary->where('item_category_id',$request->item_category_id);
        }
        if($request->item_id && $request->item_id){
            $expendableItemsQuary->where('item_id',$request->item_id);
        }
        if($request->place_id && $request->place_id){
            $expendableItemsQuary->where('place_id',$request->place_id);
        }
        $countexpendable_items = $expendableItemsQuary->count();
        $expendable_items = $expendableItemsQuary->paginate($per_page);

        return view('wh_expendable_items.index',compact('expendable_items','countexpendable_items','categories','wh_items','places'));
    }

    /**
     * Show the form for creating a new WHExpendableItem.
     *
     * @return Response
     */
    public function create()
    {
        $categories = WHItemCategory::all()->pluck('name','id');
        $wh_items = WHItem::select('id','name','item_category_id')->get();
        $wh_items = $wh_items->groupBy('item_category_id');
        $places = auth()->user()->places->pluck('name', 'id')->toArray();
        
        return view('wh_expendable_items.create',compact('categories','wh_items','places'));
    }

    /**
     * Store a newly created WHItem in storage.
     *
     * @param CreateWHItemRequest $request
     *
     * @return Response
     */
    public function store(CreateWHExpendableItemRequest $request)
    {
        $input = $request->all();
        //dd($input);
        $check_used_items = WHUsedItem::where('item_category_id',$request->item_category_id)
                                      ->where('item_id',$request->item_id)
                                      ->where('place_id',$request->place_id)
                                      ->where('balance','>',0)->first();
        if($check_used_items != null && $check_used_items != ''){
            if($check_used_items->balance >= $request->item_count){
                $check_used_items->balance -= $request->item_count;
                $check_used_items->save();
                
                $input['balance'] = $check_used_items->balance;
                $input['employee_id'] = auth()->user()->id;
                /** @var WHItem $expendable_item */
                $expendable_item = WHExpendableItem::create($input);
        
                Flash::success('Warehouse Item saved successfully.');

            }else{
                Flash::error('Count more than current balance, expected less than '.$check_used_items->balance.'.');
            }
        }else{
            Flash::error('Warehouse Item not fount in current Items.');
        }
        
        return redirect(route('admin.whExpendableItems.index'));
    }

    /**
     * Display the specified WHItem.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var WHItem $expendable_item */
        $expendable_item = WHExpendableItem::find($id);

        if (empty($expendable_item)) {
            Flash::error('Warehouse Item not found');

            return redirect(route('admin.whExpendableItems.index'));
        }

        return view('wh_expendable_items.show')->with('expendable_item', $expendable_item);
    }

    /**
     * Show the form for editing the specified WHItem.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var WHExpendableItem $expendable_item */
        $categories = WHItemCategory::all()->pluck('name','id');
        $wh_items = WHItem::select('id','name','item_category_id')->get();
        $wh_items = $wh_items->groupBy('item_category_id');
        $places = auth()->user()->places->pluck('name', 'id')->toArray();
        
        $expendable_item = WHExpendableItem::find($id);

        if (empty($expendable_item)) {
            Flash::error('Warehouse Item not found');

            return redirect(route('admin.whExpendableItems.index'));
        }

        return view('wh_expendable_items.edit')->with('expendable_item', $expendable_item)->with('categories',$categories)->with('wh_items',$wh_items)->with('places',$places);
    }

    /**
     * Update the specified WHExpendableItem in storage.
     *
     * @param int $id
     * @param UpdateWHItemRequest $request
     *
     * @return Response
     */
    public function update($id, Request $request)
    {
        /** @var WHExpendableItem $expendable_item */
        $expendable_item = WHExpendableItem::find($id);
        $input = $request->all();
        
        if (empty($expendable_item)) {
            Flash::error('Warehouse Item not found');

            return redirect(route('admin.whExpendableItems.index'));
        }
        
        $expendable_item->fill($input);
        $expendable_item->save();

        Flash::success('Warehouse Item updated successfully.');
        
        return redirect(route('admin.whExpendableItems.index'));
    }

    /**
     * Remove the specified WHExpendableItem from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var WHExpendableItem $expendable_item */
        $expendable_item = WHExpendableItem::find($id);

        if (empty($expendable_item)) {
            Flash::error('Warehouse Item not found');

            return redirect(route('admin.whExpendableItems.index'));
        }

        $expendable_item->delete();

        Flash::success('Warehouse Item deleted successfully.');

        return redirect(route('admin.whExpendableItems.index'));
    }
}
