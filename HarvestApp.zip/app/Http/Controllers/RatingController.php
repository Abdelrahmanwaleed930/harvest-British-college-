<?php

namespace App\Http\Controllers;

use App\Http\Controllers\AppBaseController;
use App\Models\InstructorRating;
use Illuminate\Http\Request;
use Flash;
use Response;

class RatingController extends AppBaseController
{
    /**
     * Display a listing of the InstructorRating.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var InstructorRating $ratings */
        $ratings = InstructorRating::all();

        return view('ratings.index')->with('ratings', $ratings);
    }

    /**
     * Show the form for creating a new InstructorRating.
     *
     * @return Response
     */
    public function create()
    {
        return view('ratings.create');
    }

    /**
     * Display the specified InstructorRating.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var InstructorRating $rating */
        $rating = InstructorRating::find($id);

        if (empty($rating)) {
            Flash::error('InstructorRating not found');

            return redirect(route('admin.ratings.index'));
        }

        return view('ratings.show')->with('rating', $rating);
    }

    /**
     * Show the form for editing the specified InstructorRating.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var InstructorRating $rating */
        $rating = InstructorRating::find($id);

        if (empty($rating)) {
            Flash::error('InstructorRating not found');

            return redirect(route('admin.ratings.index'));
        }

        return view('ratings.edit')->with('rating', $rating);
    }

    /**
     * Remove the specified InstructorRating from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var InstructorRating $rating */
        $rating = InstructorRating::find($id);

        if (empty($rating)) {
            Flash::error('InstructorRating not found');

            return redirect(route('admin.ratings.index'));
        }

        $rating->delete();

        Flash::success('InstructorRating deleted successfully.');

        return redirect(route('admin.ratings.index'));
    }
    
    public function ratingsDelete()
    {
        
    }
}
