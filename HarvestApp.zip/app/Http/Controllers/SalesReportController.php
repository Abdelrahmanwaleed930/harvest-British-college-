<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\Employee;
use App\Models\Expense;
use App\Models\Lead;
use App\Models\LeadPayment;
use App\Models\PlacementApplicant;
use App\Models\PlacementKidsApplicant;
use App\Models\Offer;
use App\Models\CustomerTrack;
use App\Models\ExtraItem;
use App\Models\StageLevel;
use App\Models\Safe;
use App\Models\GroupSessionAttendance;
use App\Models\GroupSession;
use App\Models\Group;
use App\Models\GroupStudent;
use App\Models\LeadSource;
use App\Models\LabelType;
use App\Models\LeadCase;
use App\Models\SubPayment;
use App\Models\Timeframe;
use App\Models\Round;
use App\Models\StudentExam;
use App\Models\SubRound;
use App\Models\Track;
use App\Models\TODoListRandom;
use App\Models\GroupWaitingList;
use App\Models\LeadsDutch;
use App\Events\MyEvent;
use Illuminate\Http\Request;
use Auth;
use DB;
use Illuminate\Database\Eloquent\Model;
use App\Traits\TargetCashTrait;

class SalesReportController extends Controller
{
    use TargetCashTrait;
    
    public function showSalesReport(Request $request)
    {
        $view_type = 'employees';
        if($request->has('view_type')){
            $view_type = $request->get('view_type');
        }
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $agents = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            /*->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })*/
                            ->whereIn('current_branch' , $request->get('branches'))->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        $from = null;
        $to = null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $from = date_format(date_create($daterange[0]),'Y-m-d');
            // $to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $to= date_format($reg_to,"Y-m-d");
        }
        $register_from = null;
        $register_to = null;
        if ($request->has('register_daterange') && $request->get('register_daterange') != null && $request->get('register_daterange') != '') {
            $register_daterange = explode(' - ',$request->get('register_daterange'));
            $register_from = date_format(date_create($register_daterange[0]),'Y-m-d');
            // $register_to = date_format(date_create($register_daterange[1]),'Y-m-d');
            $reg_to  = date_create($register_daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $register_to= date_format($reg_to,"Y-m-d");
        }
        
        if($view_type == 'employees'){
            $leadsQuery = Lead::whereNotNull('assigned_employee_id')->whereHas('assignedEmployee',function($quary){
                $quary->where('account_Type', 'Operations Account')->where('status',1);
            });
            
            if (count($agents) > 0){
                $leadsQuery->whereIn('assigned_employee_id', array_keys($agents));
            }
            
            if ($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
                $leadsQuery->where('assigned_employee_id', $request->get('agent'));
            }
            if($register_from && $register_to){
                $leadsQuery->whereBetween('created_at', [$register_from, $register_to]);
            }
            if(! auth()->user()->can('reports show_all_data')){
                $leadsQuery->where('assigned_employee_id', auth()->user()->id);
            }
            $leads = $leadsQuery->select(DB::raw('GROUP_CONCAT(id) as leads_ids'),'assigned_employee_id','type')->groupBy('assigned_employee_id','type')->get()->groupBy('assigned_employee_id');
            //dd($leads);
            foreach($leads as $key => $lead){
                $leads_ids = explode(',',implode(',',$lead->pluck('leads_ids')->toArray()));
                //dd($leads_ids,$lead);
                $assigned_leads = $lead->where('type',1)->first();
                $assigned_customers = $lead->where('type',2)->first();
                $assigned_clients = $lead->where('type',3)->first();
                $leads[$key][0]['assigned_leads_count'] = ($assigned_leads)?count(explode(',',$assigned_leads->leads_ids)): 0;
                $leads[$key][0]['assigned_customers_count'] = ($assigned_customers)?count(explode(',',$assigned_customers->leads_ids)): 0;
                $leads[$key][0]['assigned_clients_count'] = ($assigned_clients)?count(explode(',',$assigned_clients->leads_ids)): 0;
                $leadCasesQuary = LeadCase::whereIn('lead_id', $leads_ids);
                //dd($leads_ids);
                if (count($agents) > 0){
                    $leadCasesQuary->whereIn('employee_id', array_keys($agents));
                }
                if ($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
                    $leadCasesQuary->where('employee_id', $request->get('agent'));
                }
                /*
                if($from && $to){
                    $leadCasesQuary->whereBetween('created_at', [$from, $to]);
                }elseif($register_from && $register_to){
                    $leadCasesQuary->whereBetween('created_at', [$register_from, $register_to]);
                }
                else{
                    $leadCasesQuary->where('created_at','like','%'.date('Y-m-d').'%');
                }
                $followup_count = $leadCasesQuary->count();
                $leads[$key][0]['followup_count'] = $followup_count;
                */ 
                $invoicesQuary = LeadPayment::whereIn('lead_id',$leads_ids)->whereNotNull('paymentable_type');
                /*if($from && $to){
                    $invoicesQuary->whereBetween('created_at', [$from, $to]);
                }elseif($register_from && $register_to){
                    $invoicesQuary->whereBetween('created_at', [$register_from, $register_to]);
                }
                else{
                    $invoicesQuary->where('created_at','like','%'.date('Y-m-d').'%');
                } 
                */
                $invoices = $invoicesQuary->selectRaw('sum(lead_payments.amount) as total_amount , sum(lead_payments.discount) as total_discount, sum(lead_payments.rest) as total_rest, count(*) as total_invoice')->first();
                $leads[$key][0]['bills_count'] = $invoices->total_invoice;
                $leads[$key][0]['bills_amount_paid'] = $invoices->total_amount - $invoices->total_discount;
                $leads[$key][0]['bills_total_amount'] = $leads[$key][0]['bills_amount_paid'] + $invoices->total_rest;
                $leads[$key][0]['reservation'] = (number_format(($leads[$key][0]['bills_count'] / count($leads_ids)),4) * 100);
            }
            //dd($leads[11]);
        }else{
            $leadsQuery = Lead::whereNotNull('branch_id')->whereIn('branch_id',array_keys($employeeBranches))/*->whereHas('assignedEmployee',function($quary){
                $quary->where('account_Type', 'Operations Account')->where('status',1);
            })*/;
            if($register_from && $register_to){
                $leadsQuery->whereBetween('created_at', [$register_from, $register_to]);
            }
            $leadsQuery = $leadsQuery->select('branch_id',DB::raw('count(id) as leads_count'),'type')->groupBy('branch_id','type')->get()->groupBy('branch_id');
            //$leadsQuery = $leadsQuery->groupBy('branch_id');
            //dd($leadsQuery);
            $leads = array();
            foreach($leadsQuery as $key => $lead){
                //$leads_ids = $lead->pluck('id')->toArray();
                //dd($leads_ids);
                $new_lead = [];
                $new_lead[0] = new Lead;
                $new_lead[0]->branch_id = $lead[0]->branch_id;
                $new_lead[0]['assigned_leads_count'] = $lead->where('type',1)->first()->leads_count ?? 0;
                $new_lead[0]['assigned_customers_count'] = $lead->where('type',2)->first()->leads_count ?? 0;
                $new_lead[0]['assigned_clients_count'] = $lead->where('type',3)->first()->leads_count ?? 0;
                
                $leadCasesQuary = LeadCase::leftJoin('leads','leads.id','=','lead_cases.lead_id')->where('leads.branch_id',$lead[0]->branch_id)/*->whereHas('employee',function($quary){
                    $quary->where('account_Type', 'Operations Account')->where('status',1);
                })*/;
                /*
                if($from && $to){
                    $leadCasesQuary->whereBetween('lead_cases.created_at', [$from, $to]);
                }elseif($register_from && $register_to){
                    $leadCasesQuary->whereBetween('leads.created_at', [$register_from, $register_to]);
                }
                else{
                    $leadCasesQuary->where('lead_cases.created_at','like','%'.date('Y-m-d').'%');
                }
                if($register_from && $register_to){
                    $leadCasesQuary->whereBetween('leads.created_at', [$register_from, $register_to]);
                }
                $followup_count = $leadCasesQuary->count();
                $new_lead[0]['followup_count'] = $followup_count;
                */
                $invoicesQuary = LeadPayment::leftJoin('leads','leads.id','=','lead_payments.lead_id')->whereNotNull('paymentable_type')->where('lead_payments.branch_id',$lead[0]->branch_id);
                /*if($from && $to){
                    $invoicesQuary->whereBetween('lead_payments.created_at', [$from, $to]);
                }elseif($register_from && $register_to){
                    $invoicesQuary->whereBetween('leads.created_at', [$register_from, $register_to]);
                }
                else{
                    $invoicesQuary->where('lead_payments.created_at','like','%'.date('Y-m-d').'%');
                } */
                if($register_from && $register_to){
                    $invoicesQuary->whereBetween('leads.created_at', [$register_from, $register_to]);
                }
                $invoices = $invoicesQuary->selectRaw('sum(lead_payments.amount) as total_amount , sum(lead_payments.discount) as total_discount, sum(lead_payments.rest) as total_rest, count(*) as total_invoice')->first();
                
                $new_lead[0]['bills_count'] = $invoices->total_invoice;
                $new_lead[0]['bills_amount_paid'] = $invoices->total_amount - $invoices->total_discount;
                $new_lead[0]['bills_total_amount'] = $new_lead[0]['bills_amount_paid'] + $invoices->total_rest;
                $new_lead[0]['reservation'] = (number_format(($new_lead[0]['bills_count'] / $lead->sum('leads_count')),4) * 100);
                
                $leads[] = $new_lead;
            }
            //dd($leads);
        }
        
        return view('sales_reports.sales_report',compact('view_type','employeeBranches','agents','leads'));
    }
    
    public function sales_target_cash(Request $request)
    {
        // Default view type
        $view_type = 'branches';
        
        // Get view type from request if available
        if ($request->has('view_type')) {
            $view_type = $request->get('view_type');
        }
    
        // Initialize variables
        $totalTargetCash1 = 0;
        $totalTargetCash0 = 0;
        $totalAgentTargetCash = 0;
        $totalAgentCash = 0;
        $branches = [];
        $employees=[];
        $data = [];
        if ($view_type == 'branches') {
            $branches = Branch::where('status', 1)->get();
            foreach($branches as $branch){
                 $data[]= $this->getTargetCashBranch($branch->id);
            }
            
            // $lead_count[$branch_id] = $format_lead;
            // return $data;
        } 
        elseif ($view_type == 'employees') {
            $branchIds = Branch::where('status', 1)->pluck('id');
            $employees = Employee::where('account_Type', 'Operations Account')
                ->where('status', 1)
                ->whereIn('current_branch', $branchIds)
                ->get();
            foreach($employees as $employee){
                 $data[] = $this->getTargetCashEmployee($employee->id);
            }    
    
        }
    
        // Pass data to the view
        return view('sales_reports.sales_target_cash', compact(
            'branches', 
            'view_type', 
            'employees', 
            'data', 
            'totalAgentCash', 
            'totalAgentTargetCash', 
            'totalTargetCash1', 
            'totalTargetCash0'
        ));
    }

    public function showFollowupReport(Request $request)
    {
        //dd($request->all());
        $view_type = 'employees';
        if($request->has('view_type')){
            $view_type = $request->get('view_type');
        }
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $agents = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            /*->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })*/
                            ->whereIn('current_branch' , $request->get('branches'))->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        
        $from = null;
        $to = null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $from = date_format(date_create($daterange[0]),'Y-m-d');
            // $to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $to= date_format($reg_to,"Y-m-d");
        }
        
        $register_from = null;
        $register_to = null;
        if ($request->has('register_daterange') && $request->get('register_daterange') != null && $request->get('register_daterange') != '') {
            $register_daterange = explode(' - ',$request->get('register_daterange'));
            $register_from = date_format(date_create($register_daterange[0]),'Y-m-d');
            // $register_to = date_format(date_create($register_daterange[1]),'Y-m-d');
            $reg_to  = date_create($register_daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $register_to= date_format($reg_to,"Y-m-d");
        }
        
        $targetCall = 0;
        $actualReachable = 0;
        $types = ($request->has('types'))?$request->types:[1];
        $labelTypes = LabelType::select('id','name','type')->where('status',1)->whereIn('category',$types)->get();
        // $include_blade = (count($types) == 1 && $types[0] == 1)?'sales_reports_nav':'operations_reports_nav';
        
        if(count($types) == 1 && $types[0] == 1)
        {
            $include_blade = 'sales_reports_nav';
        }elseif(count($types) == 1 && $types[0] == 2)
        {
             $include_blade = 'customer_report_nav'; 
        }else{
            $include_blade = 'client_report_nav';
        }
        
        if($view_type == 'employees'){
             $leadCasesQuary = LeadCase::whereNotNull('employee_id')->whereHas('employee',function($quary){
                $quary->where('account_Type', 'Operations Account')->where('status',1);
            })->whereIn('label_type_id',$labelTypes->pluck('id'))->with('lead','employee.LeadPayment');
            
            if($register_from && $register_to){
                
                $leadCasesQuary->whereHas('lead',function($quary) use($register_from,$register_to){
                    $quary->whereBetween('created_at',[$register_from,$register_to]);
                });
            }
            
            if ($from && $to) {
                
                $now = strtotime($from); // or your date as well
                $your_date = strtotime($to);
                $datediff = $your_date - $now ;
                $targetCall = 100 * round($datediff / (60 * 60 * 24));
                $actualReachable = 63 * round($datediff / (60 * 60 * 24));
                
                $leadCasesQuary->whereBetween('created_at', [$from, $to]);
            }elseif($register_from && $register_to){
                $now = strtotime($register_from); // or your date as well
                $your_date = strtotime($register_to);
                $datediff = $your_date - $now ;
                $targetCall = 100 * round($datediff / (60 * 60 * 24));
                $actualReachable = 63 * round($datediff / (60 * 60 * 24));
                
                $leadCasesQuary->whereBetween('created_at', [$register_from, $register_to]);
            }
            else{
                $targetCall = 100;
                $actualReachable = 63;
                $leadCasesQuary->where('created_at','like','%'.date('Y-m-d').'%');
            }
            
            if (count($agents) > 0){
                $leadCasesQuary->whereIn('employee_id', array_keys($agents));
            }
            
            if ($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
                $leadCasesQuary->where('employee_id', $request->get('agent'));
            }
            
            if ($request->has('inquiry_type') && $request->get('inquiry_type') != null && $request->get('inquiry_type') != ''){
                if($request->get('inquiry_type') == 'open'){
                    $leadCasesQuary->where('status', 0);
                }else{
                    $leadCasesQuary->where('status', 1);
                }
            }
            
            if(! auth()->user()->can('reports show_all_data')){
                $leadCasesQuary->where('employee_id', auth()->user()->id);
            }
            
            if($types[0] == 4){
                $quary = 'count(case when status = 0 then status end) as open_status , count(case when status = 1 then status end) as close_status , ';
            }else{
                $quary = '';
            }
            
            foreach($labelTypes as $key => $labelType){
                $quary .= 'count(case when label_type_id = '.$labelType->id.' then label_type_id end) as labelTypeCount'.$labelType->id;
                if($key < (count($labelTypes) - 1)){
                    $quary .= ' , ';
                }
            }
            $leadCases = $leadCasesQuary->select('employee_id',DB::raw($quary))->whereIn('employee_id',array_keys($agents))->groupBy('employee_id')->orderBy('employee_id')->get();
            //dd($leadCases);
            $paymentQuery1 = LeadPayment::whereNotNull('paymentable_type')->whereNotNull('paymentable_id')->whereNotNull('employee_id')->where('payment_plan_id',2)->where('rest',0);
            
            $paymentQuery2 = SubPayment::join('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
                ->whereIn('lead_payments.payment_plan_id',[1,3])
                ->whereNotNull('lead_payments.paymentable_type')->whereNotNull('lead_payments.paymentable_id')
                ->where('sub_payments.paid',1);
            
            $oldPaymentQuery = SubPayment::leftJoin('lead_payments', 'lead_payments.id', 'sub_payments.lead_payment_id')
                ->whereIn('lead_payments.payment_plan_id', [1,3])
                ->where('sub_payments.paid', 1)
                ->whereNull('lead_payments.paymentable_type');    

            if($register_from && $register_to){
                // $paymentQuery1->where('created_at','>=',$registration_from)->where('created_at','<',$reg_to);
                $paymentQuery1->whereBetween('created_at',[$register_from, $register_to]);
                $paymentQuery2->whereBetween('sub_payments.due_date',[$register_from, $register_to]);
                $oldPaymentQuery->whereBetween('sub_payments.due_date', [$register_from, $register_to]);
            }
            elseif($from && $to){
                $paymentQuery1->whereBetween('created_at',[$from, $to]);
                $paymentQuery2->whereBetween('sub_payments.due_date',[$from, $to]);
                $oldPaymentQuery->whereBetween('sub_payments.due_date', [$from, $to]);
            }
            else{
                $paymentQuery1->where('created_at','like','%'.date('Y-m-d').'%');
                $paymentQuery2->where('sub_payments.due_date','like','%'.date('Y-m-d').'%');
                $oldPaymentQuery->where('sub_payments.due_date', 'like','%'.date('Y-m-d').'%');
            }

            $employees_payment1 = $paymentQuery1->whereIn('owner_id',array_keys($agents))->orderBy('owner_id')->select('type','lead_type','owner_id','paymentable_type','paymentable_id','amount','lead_id')->get()->groupBy('owner_id');
            $employees_payment2 = $paymentQuery2->whereIn('sub_payments.owner_id',array_keys($agents))->select('sub_payments.type','sub_payments.branch_id','sub_payments.amount','sub_payments.payment_date','sub_payments.created_at','lead_payments.lead_id','lead_payments.lead_type')->orderBy('sub_payments.owner_id')->get()->groupBy('owner_id');
            $employees_old_payment = $oldPaymentQuery->whereIn('sub_payments.employee_id',array_keys($agents))->select('sub_payments.type','sub_payments.employee_id','sub_payments.amount','sub_payments.payment_date','sub_payments.due_date','sub_payments.created_at','lead_payments.lead_type','lead_payments.id')->orderBy('sub_payments.employee_id')->get()->groupBy('employee_id');
            
            foreach ($leadCases as $key => $leadCase){
                $actual_reachable = 0; 
                $total_target_calls = 0;
                foreach($labelTypes as $labelType){
                    $total_target_calls += $leadCase->{'labelTypeCount'.$labelType->id};
                    if(in_array($labelType->id,$labelTypes->where('type','Reachable')->pluck('id')->toArray())){
                        $actual_reachable += $leadCase->{'labelTypeCount'.$labelType->id};
                    }
                }
                $leadCases[$key]['total_target_calls'] = $total_target_calls;
                $leadCases[$key]['actual_reachable'] = $actual_reachable;
                
                $sales = 0;
                $customer = 0;
                $client = 0;
                $sales_no = 0;
                $customer_no = 0;
                $client_no = 0;
                // dd($leadCase->employee_id);
                
                $sales += (isset($employees_payment1[$leadCase->employee_id]))?$employees_payment1[$leadCase->employee_id]->where('type',1)->sum('amount'):0;
                $customer += (isset($employees_payment1[$leadCase->employee_id]))?$employees_payment1[$leadCase->employee_id]->where('type',2)->whereIn('lead_type',[1,2])->sum('amount'):0; 
                $client += (isset($employees_payment1[$leadCase->employee_id]))?$employees_payment1[$leadCase->employee_id]->where('type',2)->where('lead_type',[3])->sum('amount'):0; 
                
                
                $sales += (isset($employees_payment2[$leadCase->employee_id]))?$employees_payment2[$leadCase->employee_id]->where('type',1)->sum('amount'):0;
                $customer += (isset($employees_payment2[$leadCase->employee_id]))?$employees_payment2[$leadCase->employee_id]->where('type',2)->whereIn('lead_type',[1,2])->sum('amount'):0; 
                $client += (isset($employees_payment2[$leadCase->employee_id]))?$employees_payment2[$leadCase->employee_id]->where('type',2)->where('lead_type',3)->sum('amount'):0;    
               
                $sales += (isset($employees_old_payment[$leadCase->employee_id]))?$employees_old_payment[$leadCase->employee_id]->where('type',1)->sum('amount'):0;
                $customer += (isset($employees_old_payment[$leadCase->employee_id]))?$employees_old_payment[$leadCase->employee_id]->where('type',2)->whereIn('lead_type',[1,2])->sum('amount'):0; 
                $client += (isset($employees_old_payment[$leadCase->employee_id]))?$employees_old_payment[$leadCase->employee_id]->where('type',2)->where('lead_type',3)->sum('amount'):0;    
                    
                $employee_data = $this->getTargetCashEmployee($leadCase->employee_id);
                
                // $sales_no += (isset($employees_payment1[$leadCase->employee_id]))?$employees_payment1[$leadCase->employee_id]->where('type',1)->count():0;
                
                
                    
                $sales_no += (isset($employees_payment1[$leadCase->employee_id]))?$employees_payment1[$leadCase->employee_id]->where('type',1)->count():0;
                $customer_no += (isset($employees_payment1[$leadCase->employee_id]))?$employees_payment1[$leadCase->employee_id]->where('type',2)->whereIn('lead_type',[1,2])->count():0; 
                $client_no += (isset($employees_payment1[$leadCase->employee_id]))?$employees_payment1[$leadCase->employee_id]->where('type',2)->where('lead_type',[3])->count():0; 
                 
                
                $leadCases[$key]['sales']=$sales;
                $leadCases[$key]['customer']=$customer;
                $leadCases[$key]['client']=$client;
                $leadCases[$key]['total_cash']=$sales +$customer + $client;
                $leadCases[$key]['target_cash_sales']=$employee_data->sales;
                $leadCases[$key]['target_cash_customer']=$employee_data->customer;
                $leadCases[$key]['target_cash_client']=$employee_data->client;
               
                 $employee= $leadCase->employee_id;
                 
                $leadCases[$key]['sales_no'] =  $employee_data->no_leads;
                $leadCases[$key]['customer_no'] =$employee_data->no_customer;
                $leadCases[$key]['client_no'] = $employee_data->no_client;
                
                $leadCases[$key]['cr_sales_no'] = $sales_no;
                $leadCases[$key]['cr_customer_no'] = $customer_no;
                $leadCases[$key]['cr_client_no'] = $client_no;
                
            }
            
        }else{
            $leadCasesQuary = LeadCase::whereIn('label_type_id',$labelTypes->pluck('id'))
            ->whereNotNull('branch_id')->whereIn('branch_id',array_keys($employeeBranches))
                ->whereHas('employee',function($quary){
                    $quary->where('account_Type', 'Operations Account')->where('status',1);
                });
            
            if($register_from && $register_to){
                $leadCasesQuary->whereHas('lead',function($query) use($register_from,$register_to){
                    $query->whereBetween('created_at',[$register_from,$register_to]);
                });
            }
            
            if ($from && $to) {
                $leadCasesQuary->whereBetween('created_at', [$from, $to]);
            }elseif($register_from && $register_to){
                $leadCasesQuary->whereBetween('created_at', [$register_from,$register_to]);
            }
            else{
                $leadCasesQuary->where('created_at','like','%'.date('Y-m-d').'%');
            }
            
            if ($request->has('inquiry_type') && $request->get('inquiry_type') != null && $request->get('inquiry_type') != ''){
                if($request->get('inquiry_type') == 'open'){
                    $leadCasesQuary->where('status', 0);
                }else{
                    $leadCasesQuary->where('status', 1);
                }
            }
            
            if($types[0] == 4){
                $quary = 'count(case when status = 0 then status end) as open_status , count(case when status = 1 then status end) as close_status , ';
            }else{
                $quary = '';
            }
            
            foreach($labelTypes as $key => $labelType){
                $quary .= 'count(case when label_type_id = '.$labelType->id.' then label_type_id end) as labelTypeCount'.$labelType->id;
                if($key < (count($labelTypes) - 1)){
                    $quary .= ' , ';
                }
            }
            $leadCases = $leadCasesQuary->select('branch_id',DB::raw($quary))->groupBy('branch_id')->orderBy('branch_id')->get();
            
            $paymentQuery1 = LeadPayment::whereNotNull('paymentable_type')->whereNotNull('paymentable_id')->where('payment_plan_id',2)->where('rest',0)->whereNotNull('branch_id')->whereIn('branch_id',array_keys($employeeBranches));
            $paymentQuery2 = SubPayment::leftjoin('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
                ->leftjoin('leads','leads.id','lead_payments.lead_id')
                ->whereNotNull('lead_payments.paymentable_type')
                ->whereIn('lead_payments.payment_plan_id',[1,3])
                ->where('sub_payments.paid',1)
                ->whereNotNull('sub_payments.branch_id')
                ->whereIn('sub_payments.branch_id',array_keys($employeeBranches));
            $oldPaymentQuery = SubPayment::leftjoin('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
                ->leftjoin('leads','leads.id','lead_payments.lead_id')
                ->whereNull('lead_payments.paymentable_type')
                ->whereIn('lead_payments.payment_plan_id',[1,3])
                ->where('sub_payments.paid',1)
                ->whereNotNull('sub_payments.branch_id')->whereIn('sub_payments.branch_id',array_keys($employeeBranches))
                //->whereRaw('sub_payments.due_date != DATE_FORMAT(lead_payments.created_at, "%Y-%m-%d")');
                ->whereRaw('sub_payments.updated_at != sub_payments.created_at');

            if($register_from && $register_to){
                // $paymentQuery1->where('created_at','>=',$registration_from)->where('created_at','<',$reg_to);
                $paymentQuery1->whereBetween('created_at',[$register_from, $register_to]);
                $paymentQuery2->whereBetween('sub_payments.due_date',[$register_from, $register_to]);
                $oldPaymentQuery->whereBetween('sub_payments.due_date', [$register_from, $register_to]);
            }
            elseif($from && $to){
                $paymentQuery1->whereBetween('created_at',[$from, $to]);
                $paymentQuery2->whereBetween('sub_payments.due_date',[$from, $to]);
                $oldPaymentQuery->whereBetween('sub_payments.due_date', [$from, $to]);
            }
            else{
                $paymentQuery1->where('created_at','like','%'.date('Y-m-d').'%');
                $paymentQuery2->where('sub_payments.due_date','like','%'.date('Y-m-d').'%');
                $oldPaymentQuery->where('sub_payments.due_date', 'like','%'.date('Y-m-d').'%');
            }
            $employees_payment1 = $paymentQuery1->orderBy('branch_id')->select('id','lead_type','type','branch_id','paymentable_type','paymentable_id','amount','lead_id')->get()->groupBy('branch_id');
            $employees_payment2 = $paymentQuery2->select('sub_payments.type','sub_payments.branch_id','sub_payments.amount','sub_payments.payment_date','sub_payments.created_at','lead_payments.lead_id','lead_payments.lead_type')->orderBy('sub_payments.branch_id')->with('leadPayment')->get()->groupBy('branch_id');
            $oldPaymentQuery = SubPayment::leftjoin('lead_payments','lead_payments.id','sub_payments.lead_payment_id')
                ->leftjoin('leads','leads.id','lead_payments.lead_id')
                ->whereNull('lead_payments.paymentable_type')
                ->whereIn('lead_payments.payment_plan_id',[1,3])
                ->where('sub_payments.paid',1)
                ->whereNotNull('sub_payments.branch_id')->whereIn('sub_payments.branch_id',array_keys($employeeBranches))
                //->whereRaw('sub_payments.due_date != DATE_FORMAT(lead_payments.created_at, "%Y-%m-%d")');
                ->whereRaw('sub_payments.updated_at != sub_payments.created_at');
            

            //dd($leadCases);
            foreach ($leadCases as $key => $leadCase){
                $actual_reachable = 0; 
                $total_target_calls = 0;
                foreach($labelTypes as $labelType){
                    $total_target_calls += $leadCase->{'labelTypeCount'.$labelType->id};
                    if(in_array($labelType->id,$labelTypes->where('type','Reachable')->pluck('id')->toArray())){
                        $actual_reachable += $leadCase->{'labelTypeCount'.$labelType->id};
                    }
                }
                $leadCases[$key]['total_target_calls'] = $total_target_calls;
                $leadCases[$key]['actual_reachable'] = $actual_reachable;
                
                if ($from && $to) {
                    $now = strtotime($from); // or your date as well
                    $your_date = strtotime($to);
                    $datediff = $your_date - $now ;
                    $targetCall = $leadCase->branch->getEmployeesCount() * 100 * round($datediff / (60 * 60 * 24));
                    $actualReachable = $leadCase->branch->getEmployeesCount() * 63 * round($datediff / (60 * 60 * 24));
                }elseif($register_from && $register_to){
                    $now = strtotime($register_from); // or your date as well
                    $your_date = strtotime($register_to);
                    $datediff = $your_date - $now ;
                    $targetCall = $leadCase->branch->getEmployeesCount() * 100 * round($datediff / (60 * 60 * 24));
                    $actualReachable = $leadCase->branch->getEmployeesCount() * 63 * round($datediff / (60 * 60 * 24));
                }
                else{
                    $targetCall = $leadCase->branch->getEmployeesCount() * 100;
                    $actualReachable = $leadCase->branch->getEmployeesCount() * 63;
                }
                
                
                $sales = 0;
                $customer = 0;
                $client = 0;
                
                $sales_no = 0;
                $customer_no = 0;
                $client_no = 0;
                
                // dd($leadCase->employee_id);
                
                $sales += (isset($employees_payment1[$leadCase->branch_id]))?$employees_payment1[$leadCase->branch_id]->where('type',1)->sum('amount'):0;
                $customer += (isset($employees_payment1[$leadCase->branch_id]))?$employees_payment1[$leadCase->branch_id]->where('type',2)->whereIn('lead_type',[1,2])->sum('amount'):0; 
                $client += (isset($employees_payment1[$leadCase->branch_id]))?$employees_payment1[$leadCase->branch_id]->where('type',2)->where('lead_type',3)->sum('amount'):0; 
                
                
                $sales += (isset($employees_payment2[$leadCase->branch_id]))?$employees_payment2[$leadCase->branch_id]->where('type',1)->sum('amount'):0;
                $customer += (isset($employees_payment2[$leadCase->branch_id]))?$employees_payment2[$leadCase->branch_id]->where('type',2)->whereIn('lead_type',[1,2])->sum('amount'):0; 
                $client += (isset($employees_payment2[$leadCase->branch_id]))?$employees_payment2[$leadCase->branch_id]->where('type',2)->where('lead_type',3)->sum('amount'):0;    
               
                $sales += (isset($employees_old_payment[$leadCase->branch_id]))?$employees_old_payment[$leadCase->branch_id]->where('type',1)->sum('amount'):0;
                $customer += (isset($employees_old_payment[$leadCase->branch_id]))?$employees_old_payment[$leadCase->branch_id]->where('type',2)->whereIn('lead_type',[1,2])->sum('amount'):0; 
                $client += (isset($employees_old_payment[$leadCase->branch_id]))?$employees_old_payment[$leadCase->branch_id]->where('type',2)->where('lead_type',3)->sum('amount'):0;    
                    
                    
                $sales_no += (isset($employees_payment1[$leadCase->branch_id]))?$employees_payment1[$leadCase->branch_id]->where('type',1)->count():0;
                $customer_no += (isset($employees_payment1[$leadCase->branch_id]))?$employees_payment1[$leadCase->branch_id]->where('type',2)->whereIn('lead_type',[1,2])->count():0; 
                $client_no += (isset($employees_payment1[$leadCase->branch_id]))?$employees_payment1[$leadCase->branch_id]->where('type',2)->where('lead_type',3)->count():0; 
                    
                 $Branch_data = $this->getTargetCashBranch($leadCase->branch_id);     
                
                $leadCases[$key]['sales']=$sales;
                $leadCases[$key]['customer']=$customer;
                $leadCases[$key]['client']=$client;
                $leadCases[$key]['total_cash']=$sales +$customer + $client;
                
                $leadCases[$key]['target_cash_sales']=$Branch_data[$leadCase->branch_id]['sales'];
                $leadCases[$key]['target_cash_customer']=$Branch_data[$leadCase->branch_id]['customer'];
                $leadCases[$key]['target_cash_client']=$Branch_data[$leadCase->branch_id]['client'];
               
                $employee= $leadCase->branch_id;
                 
                $leadCases[$key]['sales_no'] =  $Branch_data[$leadCase->branch_id]['no_leads'];
                $leadCases[$key]['customer_no'] =$Branch_data[$leadCase->branch_id]['no_customer'];
                $leadCases[$key]['client_no'] = $Branch_data[$leadCase->branch_id]['no_client'];
                
                
                $leadCases[$key]['cr_sales_no'] = $sales_no;
                $leadCases[$key]['cr_customer_no'] = $customer_no;
                $leadCases[$key]['cr_client_no'] = $client_no;
                
            }
        }
        // return $leadCases;
        
        
        $labelTypes = $labelTypes->groupBy('type');
        return view('operations_reports.followup_report',compact('types','include_blade','view_type','employeeBranches','agents','labelTypes','leadCases','targetCall','actualReachable'));
    }
    
}