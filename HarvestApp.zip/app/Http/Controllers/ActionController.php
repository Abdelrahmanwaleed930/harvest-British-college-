<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateActionRequest;
use App\Http\Requests\UpdateActionRequest;
use App\Http\Controllers\AppBaseController;
use App\Models\Action;
use App\Models\LabelType;
use Illuminate\Http\Request;
use Flash;
use DB;
use Response;

class ActionController extends AppBaseController
{
    /**
     * Display a listing of the Action.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var Action $actions */
        $actions = Action::paginate(10);

        return view('actions.index')
            ->with('actions', $actions);
    }

    /**
     * Show the form for creating a new Action.
     *
     * @return Response
     */
    public function create()
    {
        $Label_types = LabelType::where('status', 1)->select(DB::raw('concat(category,"-",name) as name'), 'id')->get()->pluck('name', 'id');

        return view('actions.create', compact('Label_types'));
    }

    /**
     * Store a newly created Action in storage.
     *
     * @param CreateActionRequest $request
     *
     * @return Response
     */
    public function store(CreateActionRequest $request)
    {
        $input = $request->all();

        /** @var Action $action */
        $action = Action::create($input);

        Flash::success('Action saved successfully.');

        return redirect(route('admin.actions.index'));
    }

    /**
     * Display the specified Action.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var Action $action */
        $action = Action::find($id);

        if (empty($action)) {
            Flash::error('Action not found');

            return redirect(route('admin.actions.index'));
        }

        return view('actions.show')->with('action', $action);
    }

    /**
     * Show the form for editing the specified Action.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var Action $action */
        $action = Action::find($id);

        if (empty($action)) {
            Flash::error('Action not found');

            return redirect(route('admin.actions.index'));
        }
        $Label_types = LabelType::where('status', 1)->select(DB::raw('concat(category,"-",name) as name'), 'id')->get()->pluck('name', 'id');


        return view('actions.edit', compact('action', 'Label_types'));
    }

    /**
     * Update the specified Action in storage.
     *
     * @param int $id
     * @param UpdateActionRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateActionRequest $request)
    {
        /** @var Action $action */
        $action = Action::find($id);

        if (empty($action)) {
            Flash::error('Action not found');

            return redirect(route('admin.actions.index'));
        }

        $action->fill($request->all());
        $action->save();

        Flash::success('Action updated successfully.');

        return redirect(route('admin.actions.index'));
    }

    /**
     * Remove the specified Action from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var Action $action */
        $action = Action::find($id);

        if (empty($action)) {
            Flash::error('Action not found');

            return redirect(route('admin.actions.index'));
        }

        $action->delete();

        Flash::success('Action deleted successfully.');

        return redirect(route('admin.actions.index'));
    }
}
