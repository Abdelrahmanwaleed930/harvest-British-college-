<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Lead;
use App\Models\LeadPayment;
use App\Models\Offer;
use App\Models\Track;
use App\Models\Group;
use App\Models\TrainingService;
use App\Models\CustomerTrack;
use App\Models\StudentQuiz;
use App\Models\GroupWaitingList;
use App\Models\Timeframe;
use App\Models\Round;
use App\Models\Room;
use App\Models\Branch;
use App\Models\SubRound;
use Auth;
use Flash;
use DB;

class QuizAppController extends Controller
{
   public function index(Request $request)
   {
       $employeeBranches = auth()->user()->branches->pluck('name','id')->toArray();
        
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id')->toArray();
        $courses = [];
        $stageLevels = [];
        $groups = [];
        $timeframes = [];
        $rounds = [];
        $daysData = [];
        $intervals = [];
        $subRounds = [];
        
        if($request->has('branch_id') && $request->get('branch_id') != null && $request->get('branch_id') != ''){
            $quizApplicantsQuery = StudentQuiz::whereHas('group',function($query) use ($request){
                $query->where('branch_id', $request->get('branch_id'));
            });
        }else{
            $quizApplicantsQuery = StudentQuiz::with('student')->whereHas('group',function($query) use ($employeeBranches){
                $query->whereIn('branch_id', array_keys($employeeBranches));
            });
        }
        if (request()->filled('search')) {
            $quizApplicantsQuery->whereHas('lead',function ($query) use($request) {
                $query->where('leads.name', 'like', '%' . $request->search . '%')
                    ->orWhere('leads.mobile_1', 'like', '%' . $request->search . '%')
                    ->orWhere('leads.email', 'like', '%' . $request->search . '%');
            });
        }
        if (request()->filled('status')) {
            $quizApplicantsQuery->where('status', request('status'));
        }
        
        if($request->has('track_id') && $request->get('track_id') != null && $request->get('track_id') != ''){
            $courses = Track::where('status',1)->where('parent_id',$request->get('track_id'))->pluck('title','id');
            $quizApplicantsQuery->where('track_id',$request->get('track_id'));
        }
        
        if($request->has('course_id') && $request->get('course_id') != null && $request->get('course_id') != ''){
            $quizApplicantsQuery->where('course_id',$request->get('course_id'));
            $stageLevels = Track::find($request->get('course_id'))->stageLevels->pluck('name', 'id')->toArray();

            $timeframe_ids = DB::table('timeframe_courses')->where('course_id',$request->get('course_id'))->pluck('timeframe_id')->toArray();
            $timeframes = Timeframe::whereIn('id',$timeframe_ids)->where('status',1)->pluck('title','id')->toArray();
        }
        
        if($request->has('level_id') && $request->get('level_id') != null && $request->get('level_id') != ''){
            $quizApplicantsQuery->where('level_id',$request->get('level_id'));
            $groups = Group::where('track_id',$request->get('track_id'))->where('course_id',$request->get('course_id'))->where('level_id',$request->get('level_id'))->pluck('code', 'id')->toArray();
        }
        if($request->has('timeframe_id') && $request->get('timeframe_id') != null && $request->get('timeframe_id') != ''){
            $quizApplicantsQuery->whereHas('group' ,function($q) use ($request){
                $q->where('timeframe_id',$request->get('timeframe_id'));
            });
            $rounds = Round::where('timeframe_id',$request->get('timeframe_id'))->pluck('title', 'id')->toArray();
        }
        
        if($request->has('round_id') && $request->get('round_id') != null && $request->get('round_id') != ''){
            $round = Round::with('timeframe.intervals')->find($request->get('round_id'));
            $quizApplicantsQuery->whereHas('group' ,function($q)use ($request){
                $q->where('round_id',$request->get('round_id'));
            });
            $daysData = $round->timeframe->days;
            $intervals = $round->timeframe->intervals->pluck('name', 'id')->toArray();
            
        }
       
        $quizApplicantCount = $quizApplicantsQuery->count();
        $quizApplicants = $quizApplicantsQuery->latest()->paginate(20);
       
        return view('quizapp.index', compact('employeeBranches','courses','timeframes','rounds','stageLevels','groups','tracks','quizApplicants', 'quizApplicantCount'));
    
       
   }
   public function show($id){
        $applicant = StudentQuiz::find($id);

        if (empty($applicant)) {
            Flash::error('Quiz Applicant not found');

            return redirect(route('admin.QuizApplication.index'));
        }
        //dd(round(microtime(true) * 1000) - $testProcess);
        return view('quizapp.show')->with('applicant', $applicant);
       
   }
   public function edit($id){
         $applicant = StudentQuiz::with('answers')->find($id);
        if (empty($applicant)) {
            Flash::error('quiz not found');
            return redirect(route('admin.QuizApplication.index'));
        }
        return view('quizapp.edit')->with('applicant', $applicant);
   }
   public function update($id , Request $request){
       
       $QuizApplicant = StudentQuiz::find($id);
        
        if (empty($QuizApplicant)) {
            Flash::error('Quiz not found');
            return redirect(route('admin.QuizApplication.index'));
        }

        $QuizApplicant->fill($request->except('_method','_token','exam_status'));
        $QuizApplicant->save();
        $exam_per = ((($QuizApplicant->section1_score + $QuizApplicant->section2_score ) / 25) * 100);
        
        $student = $QuizApplicant->student;
        $updated_data = array();
        $updated_data['exam_status'] = ($exam_per >= 60)?'pass':'fail';
        $updated_data['exam_per'] = number_format($exam_per,2);
        
        $student->update($updated_data);
        
        
         activity('Quiz Student')
           ->causedBy(Auth::user()->id)
           ->performedOn($student)
           ->withProperties(['group_id' =>$student->group_id ])
           ->log('Update Quiz Application');
        
        Flash::success('Quiz Applicant updated successfully.');

        return redirect(route('admin.QuizApplication.index'));
   }
   public function destroy($id)
    {
    
        $quizApplicant = StudentQuiz::find($id);

        if (empty($quizApplicant)) {
            Flash::error('Quiz Applicant not found');

            return redirect(route('admin.QuizApplication.index'));
        }

        $quizApplicant->delete();
        
         activity('Quiz Student')
           ->causedBy(Auth::user()->id)
           ->performedOn($quizApplicant)
           ->withProperties(['group_id' =>$quizApplicant->group_id ])
           ->log('Delete Quiz Application');

        Flash::success('Quiz Applicant deleted successfully.');

        return redirect(route('admin.quizApplicant.index'));
    }
}
