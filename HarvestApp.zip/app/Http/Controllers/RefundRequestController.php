<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateRefundRequest;
use App\Http\Requests\UpdateRefundRequest;
use App\Http\Controllers\AppBaseController;
use App\Models\RefundRequest;
use App\Models\PaymentMethod;
use App\Models\Employee;
use App\Models\Lead;
use App\Models\Expense;
use Illuminate\Http\Request;
use Flash;
use DB;
use Auth;
use Response;

class RefundRequestController extends Controller
{
     public function index(Request $request)
    {
        /** @var RefundRequest $RefundRequests */
        $RefundRequests = RefundRequest::paginate(10);

        return view('RefundRequests.index')
            ->with('RefundRequests', $RefundRequests);
    }

    /**
     * Show the form for creating a new RefundRequest.
     *
     * @return Response
     */
    public function create()
    {
        $paymentMethods = PaymentMethod::where('status', 1)->where('transfer', 1)->pluck('title','id');

        return view('RefundRequests.create',compact('paymentMethods'));
    }

    /**
     * Store a newly created RefundRequest in storage.
     *
     * @param CreateRefundRequestRequest $request
     *
     * @return Response
     */
    public function store(CreateRefundRequest $request)
    {
        $input = $request->all();
        $lead = Lead::find($request->lead_id);
        $input['employee_id'] = auth()->id();
        $input['branch_id'] = $lead->branch_id;
        
        
        $data = [
            'expense_type_id'=> 14 ,
            'employee_id'=> auth()->id(),
            'branch_id'=> $lead->branch_id,
            'method_id'=> $request->method_id ,
            'amount'=> $request->amount ,
            'note'=>  $request->note ,
            'status'=> 'done',
            
            ];
        // return $input;
        /** @var RefundRequest $RefundRequest */
        $RefundRequest = RefundRequest::create($input);
        
        Expense::create($data);
        

        Flash::success('RefundRequest saved successfully.');

        return redirect(route('admin.RefundRequests.index'));
    }

    /**
     * Display the specified RefundRequest.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var RefundRequest $RefundRequest */
        $RefundRequest = RefundRequest::find($id);

        if (empty($RefundRequest)) {
            Flash::error('RefundRequest not found');

            return redirect(route('admin.RefundRequests.index'));
        }

        return view('RefundRequests.show')->with('RefundRequest', $RefundRequest);
    }

    /**
     * Show the form for editing the specified RefundRequest.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var RefundRequest $RefundRequest */
        $RefundRequest = RefundRequest::find($id);

        if (empty($RefundRequest)) {
            Flash::error('RefundRequest not found');

            return redirect(route('admin.RefundRequests.index'));
        }


        return view('RefundRequests.edit', compact('RefundRequest'));
    }

    /**
     * Update the specified RefundRequest in storage.
     *
     * @param int $id
     * @param UpdateRefundRequestRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateRefundRequest $request)
    {
        /** @var RefundRequest $RefundRequest */
        $RefundRequest = RefundRequest::find($id);

        if (empty($RefundRequest)) {
            Flash::error('RefundRequest not found');

            return redirect(route('admin.RefundRequests.index'));
        }

        $RefundRequest->fill($request->all());
        $RefundRequest->save();

        Flash::success('RefundRequest updated successfully.');

        return redirect(route('admin.RefundRequests.index'));
    }

    /**
     * Remove the specified RefundRequest from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var RefundRequest $RefundRequest */
        $RefundRequest = RefundRequest::find($id);

        if (empty($RefundRequest)) {
            Flash::error('RefundRequest not found');

            return redirect(route('admin.RefundRequests.index'));
        }

        $RefundRequest->delete();

        Flash::success('RefundRequest deleted successfully.');

        return redirect(route('admin.RefundRequests.index'));
    }
}
