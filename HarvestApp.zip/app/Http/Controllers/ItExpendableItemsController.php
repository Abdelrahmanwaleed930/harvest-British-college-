<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\ItExpendableItems;
use App\Models\Branch;
use App\Models\ITItemCategory;
use App\Models\ItCurrentItems;
use App\Models\ITItem;
use App\Models\Employee;
use Flash;
use Auth;
class ItExpendableItemsController extends Controller
{
    
    public function index(Request $request){
        $ItExpendableItems = ItExpendableItems::with('ititemCategory','ititem','branch','created_by')->get();
        return view('ItExpendableItems.index',compact('ItExpendableItems'));
    }
    public function show($id){
        $ItExpendableItems = ItExpendableItems::find($id);
        
        return view('ItExpendableItems.show',compact('ItExpendableItems'));
    }
    public function create(Request $request){
        $branches = Branch::where('status',1)->pluck('name','id');
        $ititemcategories =ITItemCategory::pluck('name','id');
        $ititem =[];
       
        
        
        return view('ItExpendableItems.create',compact('branches','ititemcategories','ititem'));
        
    }
    public function store(Request $request){
        
        $data = $request->validate([
            'branch_id' => 'required',
            'it_items_categories_id' => 'required',
            'it_item_id' => 'required',
            
            'item_count' => 'required',
            'details' => 'required',
            'notes' => 'required',
            ]);
        $check_current_items = ItCurrentItems::where('it_items_categories_id',$request->it_items_categories_id)
                                      ->where('it_item_id',$request->it_item_id)
                                      ->where('branch_id',$request->branch_id)
                                      ->where('balance','>',0)->first();
        
        if($check_current_items != null || $check_current_items != '') {
            if($check_current_items->balance >= $request->item_count){
                
                $check_current_items->balance -= $request->item_count;
                $check_current_items->save();
                
                
                $ItExpendableItems = new ItExpendableItems;    
                $ItExpendableItems->branch_id = $request->branch_id;    
                $ItExpendableItems->it_items_categories_id = $request->it_items_categories_id;    
                $ItExpendableItems->it_item_id = $request->it_item_id;    
                $ItExpendableItems->balance = $check_current_items->balance;   
                $ItExpendableItems->item_count = $request->item_count;    
                $ItExpendableItems->details = $request->details;    
                $ItExpendableItems->notes = $request->notes;    
                $ItExpendableItems->created_by_id =auth()->user()->id;    
                $ItExpendableItems->save();  
                Flash::success('It Expendable Items Added successfully.');
            }
            else{
                Flash::error('Count more than current balance, expected less than '.$check_current_items->balance.'.');
            }
         
        }else{
            Flash::error('It Warehouse Item not fount in current Items.');
        }                            
            
        
        return redirect(route('admin.ItExpendableItems.index'));
            
        
    }
    public function edit($id ,Request $request){
        $ItExpendableItems = ItExpendableItems::find($id);
        $branches = Branch::where('status',1)->pluck('name','id');
        $ititemcategories =ITItemCategory::pluck('name','id');
        $ititem =ItItem::find($ItExpendableItems->it_item_id)->pluck('name','id');
       
        
        return view('ItExpendableItems.edit',compact('branches','ItExpendableItems','ititemcategories','ititem'));
    }
    public function update($id ,Request $request){
        
        $data = $request->validate([
             'branch_id' => 'required',
            'it_items_categories_id' => 'required',
            'it_item_id' => 'required',
            
            'item_count' => 'required',
            'details' => 'required',
            'notes' => 'required',
            ]);
            
           
        $ItExpendableItems = ItExpendableItems::find($id);
        $ItExpendableItems->branch_id = $request->branch_id;    
        $ItExpendableItems->it_items_categories_id = $request->it_items_categories_id;    
        $ItExpendableItems->it_item_id = $request->it_item_id;    
    
        $ItExpendableItems->item_count = $request->item_count;    
        $ItExpendableItems->details = $request->details;    
        $ItExpendableItems->notes = $request->notes;    
        $ItExpendableItems->save();
        
        Flash::success('It Expendable Items Updated successfully.');

        return redirect(route('admin.ItExpendableItems.index'));
        
        
    }
    public function destroy($id){
        $ItExpendableItems = ItExpendableItems::find($id);
        $ItExpendableItems->delete();
            
        return redirect(route('admin.ItExpendableItems.index'));    
        
    }
    
}
