<?php

namespace App\Http\Controllers;

use App\Http\Controllers\AppBaseController;
use App\Models\GroupSession;
use App\Models\GroupSessionAttendance;
use App\Models\Group;
use Illuminate\Http\Request;
use Flash;
use Response;

class GroupSessionController extends AppBaseController
{
    /**
     * Display a listing of the GroupSession.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        $groupId = request('group');
        $group = Group::with('students.lead.attendances')->with('students',function($query){
                                    $query->where('Confirmation',1)->where('finance_status',1);
                                })->withCount('students', 'sessions')->find($groupId);
        $pastSessions = GroupSession::where('group_id', $group->id)->where('status', '!=', 1)->count();
        
        /** @var GroupSession $groupSessions */
        $groupSessions = GroupSession::where('group_id', $groupId)
            ->with('makeup' )->withCount('attendances')->orderBy('id')->get();

        return view('group_sessions.index')
            ->with('groupSessions', $groupSessions)
            ->with('group',$group)
            ->with('pastSessions',$pastSessions);
    }

    /**
     * Display the specified GroupSession.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var GroupSession $groupSession */
        $groupSession = GroupSession::with('group','attendances')->find($id);
        $group = $groupSession->group;
        if (empty($groupSession)) {
            Flash::error('Group Session not found');

            return redirect(route('admin.groupSessions.index'));
        }
        
         $groupSessionattendance = $groupSession->attendances;
        //  return $groupSessionattendance;
        return view('group_sessions.show')->with('groupSession', $groupSession)->with('group' ,$group)
        ->with('groupSessionattendance',$groupSessionattendance);
    }

    /**
     * Show the form for editing the specified GroupSession.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var GroupSession $groupSession */
        $groupSession = GroupSession::find($id);

        if (empty($groupSession)) {
            Flash::error('Group Session not found');

            return redirect(route('admin.groupSessions.index'));
        }

        return view('group_sessions.edit')->with('groupSession', $groupSession);
    }
}
