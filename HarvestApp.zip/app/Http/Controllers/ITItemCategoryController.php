<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateITItemCategoryRequest;
use App\Http\Requests\UpdateITItemCategoryRequest;
use App\Http\Controllers\AppBaseController;
use App\Models\ITItemCategory;
use Illuminate\Http\Request;
use Flash;
use Response;

class ITItemCategoryController extends AppBaseController
{
    /**
     * Display a listing of the ITItemCategory.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var ITItemCategory $itemCategories */
        $itemCategories = ITItemCategory::all();

        return view('it_item_categories.index')
            ->with('itemCategories', $itemCategories);
    }

    /**
     * Show the form for creating a new ITItemCategory.
     *
     * @return Response
     */
    public function create()
    {
        return view('it_item_categories.create');
    }

    /**
     * Store a newly created ITItemCategory in storage.
     *
     * @param CreateITItemCategoryRequest $request
     *
     * @return Response
     */
    public function store(CreateITItemCategoryRequest $request)
    {
        $input = $request->all();

        /** @var ITItemCategory $itemCategory */
        $itemCategory = ITItemCategory::create($input);

        Flash::success('IT Item Category saved successfully.');

        return redirect(route('admin.itItemCategories.index'));
    }

    /**
     * Display the specified ITItemCategory.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var ITItemCategory $itemCategory */
        $itemCategory = ITItemCategory::find($id);

        if (empty($itemCategory)) {
            Flash::error('IT Item Category not found');

            return redirect(route('admin.itItemCategories.index'));
        }

        return view('it_item_categories.show')->with('itemCategory', $itemCategory);
    }

    /**
     * Show the form for editing the specified ITItemCategory.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var ITItemCategory $itemCategory */
        $itemCategory = ITItemCategory::find($id);

        if (empty($itemCategory)) {
            Flash::error('IT Item Category not found');

            return redirect(route('admin.itItemCategories.index'));
        }

        return view('it_item_categories.edit')->with('itemCategory', $itemCategory);
    }

    /**
     * Update the specified ITItemCategory in storage.
     *
     * @param int $id
     * @param UpdateITItemCategoryRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateITItemCategoryRequest $request)
    {
        /** @var ITItemCategory $itemCategory */
        $itemCategory = ITItemCategory::find($id);

        if (empty($itemCategory)) {
            Flash::error('IT Item Category not found');

            return redirect(route('admin.itItemCategories.index'));
        }

        $itemCategory->fill($request->all());
        $itemCategory->save();

        Flash::success('IT Item Category updated successfully.');

        return redirect(route('admin.itItemCategories.index'));
    }

    /**
     * Remove the specified ITItemCategory from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var ITItemCategory $itemCategory */
        $itemCategory = ITItemCategory::find($id);

        if (empty($itemCategory)) {
            Flash::error('IT Item Category not found');

            return redirect(route('admin.itItemCategories.index'));
        }

        $itemCategory->delete();

        Flash::success('IT Item Category deleted successfully.');

        return redirect(route('admin.itItemCategories.index'));
    }
}
