<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Branch;
use App\Models\Resignation;
use Flash;

class ResignationController extends Controller
{
    //
    public function index(){

        $resignations = Resignation::latest()->paginate(10);
        $countresignations = $resignations->count();
        

        return view('resignation.index',compact('resignations','countresignations'));
    }

    public function create(){

        $branches = Branch::pluck('name','id')->toArray();
        return view('resignation.create',compact('branches'));
    }
    public function store(Request $request){


        // return $request;
        $user = auth()->user()->id;
        $resignations = new Resignation;
        $resignations->employee_id = $user;
        $resignations->hire_date = $request->hire_date;
        $resignations->date_of_resign = $request->date_of_resign;
        $resignations->Reason = $request->Reason;
        $resignations->branch_id = $request->branch_id;

        $resignations->save();

        Flash::success('Resignation Added successfully.');
        return redirect('/getProfile');


    }
    public function updateStatus($id , Request $request){
        $resignations = Resignation::find($id);
        $resignations->update(['status'=>$request->status]);
        $resignations->save();
        Flash::success('Resignation updated successfully.');

        return redirect(route('admin.Resignation.index'));

    }
}
