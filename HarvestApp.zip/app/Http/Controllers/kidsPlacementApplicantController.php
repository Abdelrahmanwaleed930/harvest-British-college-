<?php

namespace App\Http\Controllers;

use Flash;
use Response;
use DB;
use Illuminate\Http\Request;
use App\Mail\PlacementTestResult;
use App\Models\PlacementKidsApplicant;
use Illuminate\Support\Facades\Mail;
use App\Http\Controllers\AppBaseController;
use App\Models\Lead;
use App\Models\LeadPayment;
use App\Models\Offer;
use App\Models\Employee;
use App\Models\LabelType;
use App\Models\TrainingService;
use App\Models\CustomerTrack;
use App\Models\GroupWaitingList;

class kidsPlacementApplicantController extends AppBaseController
{

    /**
     * Display a listing of the PlacementKidsApplicant.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var PlacementKidsApplicant $placementApplicants */
        //$testProcess = round(microtime(true) * 1000);
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        $employeeBranches = auth()->user()->branches->pluck('name','id')->toArray();
        
        $instructors = Employee::where('account_Type','ESL Account Profile')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->get()->pluck('name','id')->toArray();
        
        $registration_from = null;
        $registration_to = null;
        if ($request->has('registration_daterange') && $request->get('registration_daterange') != null && $request->get('registration_daterange') != '') {
            $daterange = explode(' - ',$request->get('registration_daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            // $registration_to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
        }
        
        $placementApplicantsQuery = PlacementKidsApplicant::whereIn('branch_id', array_keys($employeeBranches));
        //dd($placementApplicantsQuery->count());
        if ($request->has('search') && $request->get('search') != null && $request->get('search') != '') {
            //dd($request->get('search'));
            $placementApplicantsQuery->where('name', 'like', '%' . request('search') . '%')
                ->orWhere('mobile', 'like', '%' . request('search') . '%')
                ->orWhere('email', 'like', '%' . request('search') . '%');
        }
        
        if ($request->has('status') && $request->get('status') != null && $request->get('status') != '') {
            //dd($request->get('status'));
            $placementApplicantsQuery->where('status', request('status'));
        }
        if ($request->has('level') && $request->get('level') !== null && $request->get('level') !== '') {
            //dd($request->get('status'));
            $placementApplicantsQuery->where('level', request('level'));
        }
        
        if($request->has('instructor') && $request->get('instructor') != null && $request->get('instructor') != ''){
            //dd($request->get('instructor'));
            $placementApplicantsQuery->where('instructor_id', $request->get('instructor'));
        }
        if($request->has('select_assigned') && $request->get('select_assigned') != null && $request->get('select_assigned') != ''){
            //dd($request->get('select_assigned'));
            if($request->get('select_assigned') === '0'){
                $placementApplicantsQuery->whereNull('instructor_id');
            }elseif($request->get('select_assigned') === '1'){
                $placementApplicantsQuery->whereNotNull('instructor_id');
            }
        }
        
        if ($request->has('finish') && $request->get('finish') !== null && $request->get('status') !== '') {
            //dd($request->get('status'));
            $placementApplicantsQuery->where('finish', request('finish'));
        }

        
        if($request->has('has_followup') && $request->get('has_followup') != null && $request->get('has_followup') != ''){
            if ($request->get('has_followup') === '0') {
                $placementApplicantsQuery->doesntHave('cases');
            } elseif ($request->get('has_followup') === '1') {
                $placementApplicantsQuery->has('cases');
            }
        }

        if ($request->has('branches') && $request->get('branches') != null && $request->get('branches') != '') {
            //dd($request->get('branches'));
            $placementApplicantsQuery->whereIn('branch_id', $request->get('branches'));
        }
        
        if ($registration_from != null && $registration_to != '') {
            //dd($registration_from,$registration_to);
            $placementApplicantsQuery->whereBetween('created_at', [$registration_from, $registration_to]);
        }
        $labelTypes = LabelType::where('status', 1)->where('category', 6)->pluck('name', 'id')->toArray();

        $ptApplicantCount = $placementApplicantsQuery->count();
        $placementApplicants = $placementApplicantsQuery->withCount('cases')->latest()->paginate($per_page);
        //dd(round(microtime(true) * 1000) - $testProcess);
        return view('kids_placement_applicants.index', compact('placementApplicants','labelTypes', 'ptApplicantCount','instructors','employeeBranches'));
    }

    /**
     * Show the form for creating a new PlacementKidsApplicant.
     *
     * @return Response
     */
    public function create()
    {
        return view('kids_placement_applicants.create');
    }

    /**
     * Store a newly created PlacementKidsApplicant in storage.
     *
     * @param CreatePlacementKidsApplicantRequest $request
     *
     * @return Response
     */
    public function store(Request $request)
    {
        $input = $request->all();

        /** @var PlacementKidsApplicant $placementApplicant */
        $placementApplicant = PlacementKidsApplicant::create($input);

        Flash::success('Placement Applicant saved successfully.');

        return redirect(route('admin.kidsPlacementApplicants.index'));
    }

    /**
     * Display the specified PlacementKidsApplicant.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var PlacementKidsApplicant $placementApplicant */
        //$testProcess = round(microtime(true) * 1000);
        $placementApplicant = PlacementKidsApplicant::find($id);

        if (empty($placementApplicant)) {
            Flash::error('Placement Applicant not found');

            return redirect(route('admin.kidsPlacementApplicants.index'));
        }
        //dd(round(microtime(true) * 1000) - $testProcess);
        return view('kids_placement_applicants.show')->with('placementApplicant', $placementApplicant);
    }

    /**
     * Show the form for editing the specified PlacementKidsApplicant.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var PlacementKidsApplicant $placementApplicant */
        //$testProcess = round(microtime(true) * 1000);
        $placementApplicant = PlacementKidsApplicant::with('answers')->find($id);

        if (empty($placementApplicant)) {
            Flash::error('Placement Applicant not found');

            return redirect(route('admin.kidsPlacementApplicants.index'));
        }
        //dd(round(microtime(true) * 1000) - $testProcess);
        return view('kids_placement_applicants.edit')->with('placementApplicant', $placementApplicant);
    }

    /**
     * Update the specified PlacementKidsApplicant in storage.
     *
     * @param int $id
     * @param UpdatePlacementKidsApplicantRequest $request
     *
     * @return Response
     */
    public function update($id, Request $request)
    {
        /** @var PlacementKidsApplicant $placementApplicant */
        $placementApplicant = PlacementKidsApplicant::find($id);
        
        if (empty($placementApplicant)) {
            Flash::error('Placement Applicant not found');

            return redirect(route('admin.kidsPlacementApplicants.index'));
        }

        $placementApplicant->fill($request->all());
        $placementApplicant->save();

        //Lead::where('mobile_1', $placementApplicant->mobile)->update(['pt_level' => $placementApplicant->level]);
        $lead = Lead::where('id', $placementApplicant->lead_id)->first();
        
        if($lead != null && $lead != ''){
            $customerTrack = CustomerTrack::where('lead_id',$lead->id)->where('track_id',$placementApplicant->track_id)->first();
            $payments = LeadPayment::where('track_id',$placementApplicant->track_id)->where('lead_id',$lead->id)->where('paymentable_type','App\\Models\\Offer')->whereNull('group_id')->get();
            if($payments != null && count($payments) > 0 && ! $customerTrack){
                foreach($payments as $payment){
                    $offer = Offer::with('timeframes', 'intervals')->find($payment->paymentable_id);
                    if($offer->has_levels == 0){
                        $course = $offer->course;
                        $stage_levels = DB::table('stage_levels')->leftJoin('stages','stages.id','=','stage_levels.stage_id')
                                                ->where('stages.track_id',$offer->course_id)
                                                ->where('stage_levels.value','>=',$lead->pt_level)->take($offer->num_levels)->pluck('stage_levels.id')->toArray();
                        //dd($stage_levels,$check_cusTrack);
                        if($stage_levels != null && count($stage_levels) > 0){
                            
                            $customerTrack = CustomerTrack::create([
                                'lead_id' => $lead->id,
                                'track_id' => $offer->track_id,
                                'course_id' => $offer->course_id,
                                'level_id' => $stage_levels[0],
                                'total' => $offer->num_levels,
                                'used' => 0,
                            ]);
                            
                            //dd($stage_levels,$training_service_levels,$total,$training_services->pluck('id'));
                            $timeframesString = implode(',', $offer->timeframes->pluck('id')->toArray());
                            $intervalsString = implode(',', $offer->intervals->pluck('id')->toArray());
                            $disciplinesIds = DB::table('offer_disciplines')->where('offer_id',$offer->id)->pluck('discipline_id')->toArray();
                            GroupWaitingList::where('lead_id',$lead->id)->where('track_id',$placementApplicant->track_id)->delete();
                            GroupWaitingList::create([
                                'lead_id' => $lead->id,
                                'level_id' => $stage_levels[0],
                                'track_id' => $offer->track_id,
                                'course_id' => $offer->course_id,
                                'timeframes' => $timeframesString,
                                'intervals' => $intervalsString,
                                'lead_payment_id' => $payment->id,
                                'discipline_id' => ($disciplinesIds != null && count($disciplinesIds) > 0)?$disciplinesIds[0]:null
                            ]);
                            
                            
                        }
                    }
                }
            }
            
        }
        Flash::success('Placement Applicant updated successfully.');

        return redirect(route('admin.kidsPlacementApplicants.index'));
    }

    /**
     * Remove the specified PlacementKidsApplicant from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var PlacementKidsApplicant $placementApplicant */
        
        $placementApplicant = PlacementKidsApplicant::find($id);

        if (empty($placementApplicant)) {
            Flash::error('Placement Applicant not found');

            return redirect(route('admin.kidsPlacementApplicants.index'));
        }

        $placementApplicant->delete();

        Flash::success('Placement Applicant deleted successfully.');

        return redirect(route('admin.kidsPlacementApplicants.index'));
    }
    
    public function instructorsAssign(Request $request)
    {
        if(! $request->instructor_id) {
            Flash::error('Assigned Instructor is required.');
        }elseif ($request->ids != null && count($request->ids) > 0) {
            PlacementKidsApplicant::whereIn('id', $request->ids)->update(['instructor_id' => $request->instructor_id]);
            Flash::success('Assigned Successfully.');
        }else {
            Flash::error('Selected PT is required.');
        }
        return 0;
    }

    /**
     * Display the specified PlacementKidsApplicant.
     *
     * @param int $id
     *
     * @return Response
     */
    public function sendMail($id)
    {
        /** @var PlacementKidsApplicant $placementApplicant */
        $placementApplicant = PlacementKidsApplicant::find($id);

        if (empty($placementApplicant)) {
            Flash::error('Placement Applicant not found');

            return redirect(route('admin.kidsPlacementApplicants.index'));
        }

        Mail::to($placementApplicant)->send(new PlacementTestResult($placementApplicant));

        Flash::success('Mail sent successfully.');

        return redirect(route('admin.kidsPlacementApplicants.index'));
    }
}
