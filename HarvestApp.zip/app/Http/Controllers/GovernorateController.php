<?php

namespace App\Http\Controllers;

use App\Http\Controllers\AppBaseController;
use App\Models\Country;
use App\Models\Governorate;
use Illuminate\Http\Request;
use Flash;
use Response;

class GovernorateController extends AppBaseController
{
    /**
     * Display a listing of the Country.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var Country $countries */
        $governorates = Governorate::all();
        //dd($countries);
        return view('governorates.index')
            ->with('governorates', $governorates);
    }

    /**
     * Show the form for creating a new Country.
     *
     * @return Response
     */
    public function create()
    {
        $countries = Country::pluck('name','id');
        return view('governorates.create')->with('countries', $countries);
    }

    /**
     * Store a newly created Country in storage.
     *
     * @param CreateCountryRequest $request
     *
     * @return Response
     */
    public function store(Request $request)
    {
        $input = $request->all();

        /** @var Country $country */
        $governorate = Governorate::create($input);

        Flash::success('Governorate saved successfully.');

        return redirect(route('admin.governorates.index'));
    }

    /**
     * Display the specified Country.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var Country $country */
        $governorate = Governorate::find($id);
        
        if (empty($governorate)) {
            Flash::error('governorate not found');

            return redirect(route('admin.governorates.index'));
        }

        return view('governorates.show')->with('governorate', $governorate);
    }

    /**
     * Show the form for editing the specified Country.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var Country $country */
        $governorate = Governorate::find($id);
        $countries = Country::pluck('name','id');
        if (empty($governorate)) {
            Flash::error('governorate not found');

            return redirect(route('admin.governorates.index'));
        }

        return view('governorates.edit')->with('governorate', $governorate)->with('countries',$countries);
    }

    /**
     * Update the specified Country in storage.
     *
     * @param int $id
     * @param UpdateCountryRequest $request
     *
     * @return Response
     */
    public function update($id, Request $request)
    {
        /** @var Country $country */
        $governorate = Governorate::find($id);

        if (empty($governorate)) {
            Flash::error('governorate not found');

            return redirect(route('admin.governorates.index'));
        }

        $governorate->fill($request->all());
        $governorate->save();

        Flash::success('governorate updated successfully.');

        return redirect(route('admin.governorates.index'));
    }

    /**
     * Remove the specified Country from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var Country $country */
        $governorate = Governorate::find($id);

        if (empty($governorate)) {
            Flash::error('governorate not found');

            return redirect(route('admin.governorates.index'));
        }

        $governorate->delete();

        Flash::success('governorate deleted successfully.');

        return redirect(route('admin.governorates.index'));
    }
}
