<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Monitoring;
use App\Models\Branch;
use App\Models\MonitoringSections;
use App\Models\SectionsMonitoring;
use App\Models\Employee;
use App\Models\Group;
use App\Models\GroupSession;
use Flash;

class InstructorMonitoringController extends Controller
{
    public function index(){
        $monitoring = Monitoring::where('instructor_id' ,auth()->user()->id)->get();
        $senior = Employee::where('id' ,auth()->user()->id)->where('job_id',9)->where('status',1)->first();
        $mentor=Employee::where('id' ,auth()->user()->id)->where('job_id',27)->where('status',1)->get();
        
        
        return view('instructor.Monitoring.index',compact('monitoring','senior')); 
    }
    public function seniorindex(){
        $monitoring = Monitoring::where('senior_id' ,auth()->user()->id)->get();
        $senior = Employee::where('id' ,auth()->user()->id)->where('job_id',9)->where('status',1)->get();
        $mentor= Employee::where('id' ,auth()->user()->id)->where('job_id',27)->where('status',1)->get();
        
        
        return view('instructor.Monitoring.seniorindex',compact('monitoring','senior')); 
    }
    public function create(){
        $branches = Branch::pluck('name' ,'id');
        $monitoringsections = MonitoringSections::get();
        $instructors=[];
        $groups =[];
        $sessions =[];
        
        return view('instructor.Monitoring.create',compact('branches' ,'instructors' ,'groups','sessions','monitoringsections')); 
    }
    public function store(Request $request){
        
         $credentials = $request->validate([
            'branch_id' => 'required',
            'instructor_id' => 'required',
            'group_id' => 'required',
            'session_id' => 'required',
        ]);
        
        $monitoringsections = MonitoringSections::select('id','title')->get();
        $monitoring = new Monitoring;
        $monitoring->instructor_id = $request->instructor_id;
        $monitoring->senior_id = auth()->user()->id;
        $monitoring->group_id = $request->group_id;
        $monitoring->branch_id = $request->branch_id;
        $monitoring->session_id = $request->session_id;;
        $monitoring->save();
        
        foreach($monitoringsections as $key => $section){
        $sectionsmonitoring = new SectionsMonitoring;
        $sectionsmonitoring->monitoring_sections_id   = $section->id;
        $sectionsmonitoring->monitoring_id = $monitoring->id;
        $sectionsmonitoring->score = $request->score[$key];
        $sectionsmonitoring->comment = $request->comment[$key];
        $sectionsmonitoring->action = $request->action[$key];
        $sectionsmonitoring->save();
        }
         $sumscore = SectionsMonitoring::where('monitoring_id',$monitoring->id)->sum('score');

        $monitor = Monitoring::find($monitoring->id);
        $monitor->score = $sumscore;
        $monitor->save();
        
        Flash::success(' Monitoring Create successfully.');
        
         return redirect(route('instructor.Monitoring.index'));
    }
    public function edit(Request $request ,$id){
        $monitoring = Monitoring::find($id);
        
        
        $branches = Branch::pluck('name' ,'id');
        $monitoringsections = MonitoringSections::get();
        $instructors=Employee::where('account_Type', 'ESL Account Profile')
        ->where('status',1)->whereHas('branches', function ($query) use ($monitoring) {
                                $query->where('id', $monitoring->branch_id);
                            })->get()->pluck('name','id')->toArray();   
        $groups = Group::where('instructor_id',$monitoring->instructor_id)
        ->pluck('code','id')->toArray();
        $sessions = GroupSession::where('group_id',$monitoring->group_id)
        ->pluck('date','id')->toArray();
         $sectionsmonitoring =  SectionsMonitoring::where('monitoring_id',$monitoring->id)->get();
        return view('instructor.Monitoring.edit',compact('monitoring','sectionsmonitoring','branches' ,'instructors' ,'groups','sessions','monitoringsections')); 

    }
    public function update($id,Request $request){
        //  $credentials = $request->validate([
        //     'branch_id' => 'required',
        //     'instructor_id' => 'required',
        //     'group_id' => 'required',
        //     'session_id' => 'required',
        // ]);
        
        // $monitoringsections = MonitoringSections::select('id','title')->get();
        // $sectionsmonitoring = SectionsMonitoring::where('monitoring_id',$id)->get();
        // $monitoring = Monitoring::find($id);
        // $monitoring->instructor_id = $request->instructor_id;
        // $monitoring->senior_id = auth()->user()->id;
        // $monitoring->group_id = $request->group_id;
        // $monitoring->branch_id = $request->branch_id;
        // $monitoring->session_id = $request->session_id;;
        // $monitoring->save();
        
        // foreach($sectionsmonitoring as $key => $section){
        
        // $sectionsmonitoring[$key]->score = $request->score[$key];
        // $sectionsmonitoring[$key]->comment = $request->comment[$key];
        // $sectionsmonitoring[$key]->action = $request->action[$key];
        // $sectionsmonitoring[$key]->save();
        // }
        //  $sumscore = SectionsMonitoring::where('monitoring_id',$monitoring->id)->sum('score');

        // $monitor = Monitoring::find($monitoring->id);
        // $monitor->score = $sumscore;
        // $monitor->save();
        
        $credentials = $request->validate([
            'branch_id' => 'required',
            'instructor_id' => 'required',
            'group_id' => 'required',
            'session_id' => 'required',
        ]);
        
        $monitoringsections = MonitoringSections::select('id','title')->get();
        $sectionsmonitoring = SectionsMonitoring::where('monitoring_id',$id)->get();
        $monitoring = Monitoring::find($id);
        $monitoring->instructor_id = $request->instructor_id;
        $monitoring->senior_id = auth()->user()->id;
        $monitoring->group_id = $request->group_id;
        $monitoring->branch_id = $request->branch_id;
        $monitoring->session_id = $request->session_id;
        $monitoring->save();
        
        foreach($sectionsmonitoring as $key => $section){
        
        $sectionsmonitoring[$key]->score = $request->score[$key];
        $sectionsmonitoring[$key]->comment = $request->comment[$key];
        $sectionsmonitoring[$key]->action = $request->action[$key];
        $sectionsmonitoring[$key]->save();
        }
        $sumscore = SectionsMonitoring::where('monitoring_id',$monitoring->id)->sum('score');

        $monitor = Monitoring::find($monitoring->id);
        $monitor->score = $sumscore;
        $monitor->save();
        
        return $monitor;
        
        Flash::success('Monitor  updated successfully.');
        return redirect(route('instructor.Monitoring.index'));
        
       
    }
    public function show($id){
        $monitor = Monitoring::find($id); 
        
        return view('instructor.Monitoring.show',compact('monitor')); 
        
    }
    
    public function destroy($id){
        $monitoring = Monitoring::find($id);
        $monitoring->delete();
        Flash::success(' Monitoring delete  successfully.');
        
        return redirect(route('instructor.Monitoring.index'));
    }
    
}
