<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateLeadRequest;
use App\Http\Requests\UpdateLeadRequest;
use App\Http\Controllers\AppBaseController;
use App\Models\Branch;
use App\Models\Employee;
use App\Models\KnowChannel;
use App\Models\Lead;
use App\Models\Country;
use App\Models\Governorate;
use App\Models\Track;
use App\Models\Group;
use App\Models\City;
use App\Models\LeadSource;
use App\Models\LeadCase;
use App\Models\LeadLastCase;
use App\Models\LeadPayment;

use App\Models\CustomerJob;
use App\Models\University;
use App\Models\SMS;
use App\Models\MessageLog;
use App\Models\WhatsApp;
use App\Models\LabelType;
use App\Models\Offer;
use App\Models\Timeframe;
use App\Models\DisciplineCategory;
use App\Models\PlacementApplicant;
use App\Models\TrainingService;
use Illuminate\Http\Request;
use App\Imports\LeadsImport;

use Maatwebsite\Excel\Facades\Excel;
use Flash;
use DB;
use Auth;
use Response;
use Spatie\Activitylog\Contracts\Activity;

class LeadController extends AppBaseController
{
    public function deleteleadsfollowup(Request $request)
    {
        
         $leads = Lead::whereBetween('created_at', ['2022-03-01', '2022-04-01'])->where('type',1)->get(); 
        foreach($leads as $lead)
        {
            LeadCase::where('lead_id',$lead->id)->delete();
            LeadLastCase::where('lead_id',$lead->id)->delete();
        }
        
            
        Lead::whereBetween('created_at', ['2022-01-01', '2022-04-01'])->where('type',1)->update(['created_at' => date('Y-m-d H:i:s'),'assigned_employee_id' => null,'lead_source_id'=>20]);
        
          
    }
    /**
     * Display a listing of the Lead.
     *
     * @param Request $request
     *
     * @return Response
    */
     
    public function notInterestedLeads($label_type_id,Request $request)
    {
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id');
        $testsec = round(microtime(true)*1000);
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $agents = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            /*->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })*/->whereIn('current_branch' , $request->get('branches'))->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->get()->pluck('name', 'id')->toArray();
        }
        $case_from = null;
        $case_to = null;
        if ($request->has('case_daterange') && $request->get('case_daterange') != null && $request->get('case_daterange') != '') {
            $daterange = explode(' - ',$request->get('case_daterange'));
            $case_from = date_format(date_create($daterange[0]),'Y-m-d');
            // $case_to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $case_to= date_format($reg_to,"Y-m-d");
        }
        
        $registration_from = null;
        $registration_to = null;
        if ($request->has('registration_daterange') && $request->get('registration_daterange') != null && $request->get('registration_daterange') != '') {
            $daterange = explode(' - ',$request->get('registration_daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
            
            

        }
        $leadSources = LeadSource::where('status',1)->pluck('name', 'id')->toArray();
        $knowChannels = KnowChannel::pluck('name', 'id')->toArray();
        $services = TrainingService::pluck('title', 'id')->toArray();
        $offers = Offer::pluck('title', 'id')->toArray();
        $labelTypes = LabelType::where('status', 1)->where('category', 1)->pluck('name', 'id')->toArray();
        
        $leadsQuery = Lead::Join('lead_last_cases','leads.id','=','lead_last_cases.lead_id')
                            ->where('leads.type',1)
                            ->where('lead_last_cases.label_type_id',$label_type_id);
                            
        if($request->has('lead_source') && $request->get('lead_source') != null && $request->has('lead_source') != ''){
            $leadsQuery->where('leads.lead_source_id', $request->get('lead_source'));
        }
        
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $leadsQuery->where(function ($query) use ($request){
                $query->where('leads.name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.mobile_1', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('leads.email', 'like', '%' . $request->get('search') . '%');
            });
        }elseif($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
            $leadsQuery->where('leads.assigned_employee_id', $request->get('agent'));
        } elseif (auth()->user()->can('leads leadsAssign')) {
            // show all
            $leadsQuery->whereIn('leads.branch_id', array_keys($employeeBranches));
        } else {
            $leadsQuery->where('leads.assigned_employee_id', auth()->id());
        }
        
        if($request->has('know_channel') && $request->get('know_channel') != null && $request->get('know_channel') != ''){
            $leadsQuery->where('leads.know_channel_id', $request->get('know_channel'));
        }
        if ($request->has('time') && $request->get('time') != null && $request->get('time') != '') {
            $leadsQuery->where('leads.preferred_time', $request->get('time'));
        }
        if ($request->has('service') && $request->get('service') != null && $request->get('service') != '') {
            $leadsQuery->where('leads.training_service_id', $request->get('service'));
        }
        if($request->has('select_assigned') && $request->get('select_assigned') != null && $request->get('select_assigned') != ''){
            if ($request->get('select_assigned') === '0') {
                $leadsQuery->whereNull('leads.assigned_employee_id');
            } elseif ($request->get('select_assigned') === '1') {
                $leadsQuery->whereNotNull('leads.assigned_employee_id');
            }
        }
        if ($request->has('offer') && $request->get('offer') != null && $request->get('offer') != '') {
            $leadsQuery->where('leads.offer_id', $request->get('offer'));
        }
        
        if ($request->has('prefered_track_id') && $request->get('prefered_track_id') != null && $request->get('prefered_track_id') != '') {
            $leadsQuery->where('leads.prefered_track_id', $request->get('prefered_track_id'));
        }
        if ($request->has('branches') && $request->get('branches') != null && $request->get('branches') != '') {
            $leadsQuery->whereIn('leads.branch_id', $request->get('branches'));
        }
        
        if($request->has('has_followup') && $request->get('has_followup') != null && $request->get('has_followup') != ''){
            if ($request->get('has_followup') === '0') {
                $leadsQuery->doesntHave('cases');
            } elseif ($request->get('has_followup') === '1') {
                $leadsQuery->has('cases');
            }
        }
        
        if ($registration_from != null && $registration_to != '') {
            // return $registration_to;
            // dd( $registration_to);
            $leadsQuery->whereBetween('leads.created_at', [$registration_from, $registration_to]);
        }
         if ($case_from != null && $case_to != '') {
            $leadsQuery->whereBetween('lead_last_cases.updated_at', [$case_from, $case_to]);
        }
        $leadsCount = 0;
        
        $leads = $leadsQuery->select('leads.id','leads.created_at','leads.mobile_1','leads.f_name','leads.m_name','leads.l_name',
                'leads.name','leads.name_en','leads.name_ar','leads.type','leads.branch_id','leads.first_branch_id','leads.transfer_branch_id',
                'leads.assigned_employee_id','leads.prefered_track_id','leads.prefer_branch_id','leads.lead_source_id')
            ->groupBy('leads.id')
            ->withCount('cases')
            ->with('lastcase','branch','Track','lead_source','assignedEmployee','prefer_branch')
            ->orderBy('leads.created_at','desc')
            ->paginate($per_page);
            
        return view('leads.not_interested',compact('label_type_id','tracks','leads','leadsCount','employeeBranches','agents','leadSources','knowChannels','services','offers','labelTypes'));
    }
    
    public function index(Request $request)
    {
        
        $testsec = round(microtime(true)*1000);
       
         
       $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        
        
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id');
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $branches = Branch::where('status',1)->pluck('name', 'id');
        $agents = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                           /* ->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })*/->whereIn('current_branch' , $request->get('branches'))->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->get()->pluck('name', 'id')->toArray();
        }
        $case_from = null;
        $case_to = null;
        if ($request->has('case_daterange') && $request->get('case_daterange') != null && $request->get('case_daterange') != '') {
            $daterange = explode(' - ',$request->get('case_daterange'));
            $case_from = date_format(date_create($daterange[0]),'Y-m-d');
            // $case_to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $case_to= date_format($reg_to,"Y-m-d");
        }
        
        $registration_from = null;
        $registration_to = null;
        $reg_to=null;
        if ($request->has('registration_daterange') && $request->get('registration_daterange') != null && $request->get('registration_daterange') != '') {
            $daterange = explode(' - ',$request->get('registration_daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            // $registration_to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
            
        }
        $leadSources = LeadSource::where('id', '!=', 6)->where('status',1)->pluck('name', 'id')->toArray();
        $knowChannels = KnowChannel::pluck('name', 'id')->toArray();
        $services = TrainingService::pluck('title', 'id')->toArray();
        $offers = Offer::pluck('title', 'id')->toArray();
        $labelTypes = LabelType::where('status', 1)->where('category', 1)->pluck('name', 'id')->toArray();
        
        // $leadsQuery = Lead::leftJoin('lead_last_cases','leads.id','=','lead_last_cases.lead_id')
        //                     ->where('leads.type',1)
                            
        //                     ->whereRaw('COALESCE(lead_last_cases.label_type_id,0) in (6,7,8,9,54,64,65,73,74,75,76,77,92,0)')->withCount('cases');
        //                     //->whereRaw('leads.id not in (select lead_cases2.lead_id from lead_cases as lead_cases2 where lead_cases2.label_type_id not in (6,7,8,9,54,64,65,73,74,75,76,77))');


           $leadsQuery = Lead::leftJoin('lead_last_cases','leads.id','=','lead_last_cases.lead_id')
                            ->where('leads.type',1)->whereIn('leads.branch_id', array_keys($employeeBranches))
                                                        ->whereRaw('COALESCE(lead_last_cases.label_type_id,0) in (6,7,8,9,54,64,65,73,74,75,76,77,92,0)')
                                                        ->withCount('cases');
     
        // $q = Lead::where('type',1)->where('branch_id',1)->count();
        // return $q;
       
                            /*
        $leadsQuery = Lead::leftJoin('lead_last_cases',function($query) {
                               $query->on('leads.id','=','lead_last_cases.lead_id')
                               ->whereRaw('lead_last_cases.id IN (select MAX(lead_cases2.id) from lead_cases as lead_cases2 join leads as leads2 on leads2.id = lead_cases2.lead_id group by leads2.id)');
                            })
                            ->where('leads.type',1)
                            ->whereRaw('COALESCE(lead_last_cases.label_type_id,0) in (6,7,8,9,54,64,65,73,74,75,76,77,0)');
        */                   
        if ($request->segment(1) == 'onlineLeads') {
            $leadsQuery->where('leads.lead_source_id', 6);
        }elseif($request->segment(1) == 'corporate_Leads'){
            $leadsQuery->where('leads.lead_source_id', 21);
        }elseif($request->has('lead_source') && $request->get('lead_source') != null && $request->has('lead_source') != ''){
            $leadsQuery->where('leads.lead_source_id', $request->get('lead_source'));
        }else{
            $leadsQuery->where('leads.lead_source_id', '!=', 6)/*->where('leads.lead_source_id', '!=', 21)*/;
        }
        
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $leadsQuery->where(function ($query) use ($request){
                $query->where('name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('mobile_1', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('email', 'like', '%' . $request->get('search') . '%');
            });
        }elseif($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
            $leadsQuery->where('leads.assigned_employee_id', $request->get('agent'));
        } elseif (auth()->user()->can('leads leadsAssign')) {
            // show all
            $leadsQuery->whereIn('leads.branch_id', array_keys($employeeBranches));
        } else {
            $leadsQuery->where('leads.assigned_employee_id', auth()->id());
        }
        
        if($request->has('know_channel') && $request->get('know_channel') != null && $request->get('know_channel') != ''){
            $leadsQuery->where('leads.know_channel_id', $request->get('know_channel'));
        }
        if ($request->has('time') && $request->get('time') != null && $request->get('time') != '') {
            $leadsQuery->where('leads.preferred_time', $request->get('time'));
        }

        if ($request->has('service') && $request->get('service') != null && $request->get('service') != '') {
            $leadsQuery->where('leads.training_service_id', $request->get('service'));
        }
        if($request->has('select_assigned') && $request->get('select_assigned') != null && $request->get('select_assigned') != ''){
            if ($request->get('select_assigned') === '0') {
                $leadsQuery->whereNull('leads.assigned_employee_id');
            } elseif ($request->get('select_assigned') === '1') {
                $leadsQuery->whereNotNull('leads.assigned_employee_id');
            }
        }
        
        if ($request->has('prefered_track_id') && $request->get('prefered_track_id') != null && $request->get('prefered_track_id') != '') {
            $leadsQuery->where('leads.prefered_track_id', $request->get('prefered_track_id'));
        }
        if ($request->has('offer') && $request->get('offer') != null && $request->get('offer') != '') {
            $leadsQuery->where('leads.offer_id', $request->get('offer'));
        }
        if ($request->has('branches') && $request->get('branches') != null && $request->get('branches') != '') {
            $leadsQuery->whereIn('leads.branch_id', $request->get('branches'));
        }
        if (($request->has('label_type_id') && $request->get('label_type_id') != '' && $request->get('label_type_id') != null) || ($case_from != null && $case_to != null)) {
            if ($case_from && $case_to) {
                $leadsQuery->whereBetween('lead_last_cases.date', [$case_from, $case_to]);
            }
            if ($request->get('label_type_id') != '' && $request->get('label_type_id') != null) {
                $leadsQuery->whereIn('lead_last_cases.label_type_id', $request->get('label_type_id'));
            }
            
        }
        if($request->has('has_followup') && $request->get('has_followup') != null && $request->get('has_followup') != ''){
            if ($request->get('has_followup') === '0') {
                $leadsQuery->doesntHave('cases');
            } elseif ($request->get('has_followup') === '1') {
                $leadsQuery->has('cases');
            }
        }
        
        if ($registration_from != null && $registration_to != '') {
            $leadsQuery->whereBetween('leads.created_at', [$registration_from, $registration_to]);
        }
        if ($case_from != null && $case_to != '') {
            $leadsQuery->whereBetween('lead_last_cases.updated_at', [$case_from, $case_to]);
        }

        if($request->get('one_call') === '1')
        {
            $leadsQuery->having('cases_count', 1);
              
        }
        $leadsCount = 0;
        $leads = $leadsQuery->select('leads.id','leads.created_at','leads.mobile_1','leads.f_name','leads.m_name','leads.l_name',
                'leads.name','leads.name_en','leads.name_ar','leads.type','leads.branch_id','leads.first_branch_id','leads.transfer_branch_id',
                'leads.assigned_employee_id','leads.prefered_track_id','leads.prefer_branch_id','leads.lead_source_id')
            ->groupBy('leads.id')
            ->withCount('cases')
            ->with('lastcase','branch','Track','lead_source','assignedEmployee','prefer_branch')
            ->distinct('leads.id')
            ->orderBy('leads.created_at','desc')
            ->paginate($per_page);
        // return $leads;
        //dd(round(microtime(true)*1000)-$testsec);
        
        $sources = LeadSource::whereNotIn('id',[1,6,12])->where('status',1)->pluck('name', 'id');
        $channels = KnowChannel::where('status',1)->pluck('name', 'id');
        //$offers = Offer::pluck('title', 'id');
        $branchess = /*Branch::pluck('name', 'id')*/auth()->user()->branches->pluck('name', 'id')->toArray();
        //$services = TrainingService::pluck('title', 'id');
        $employees = Employee::where('status',1)->where('account_Type','Operations Account')->get()->pluck('name', 'id');
        //$timeframes = Timeframe::pluck('title', 'id');
        $countries = Country::where('status',1)->pluck('name', 'id')->toArray();
        //$jobs = CustomerJob::where('status',1)->pluck('name', 'id')->toArray();
        //$univercities = University::where('status',1)->orderBy('name')->pluck('name', 'id')->toArray();
        //$nationalities = Country::where('status',1)->pluck('nationality', 'id')->toArray();
        //$governorates = Governorate::select('id','name','country_id')->where('status',1)->get();
        //$disciplines = DisciplineCategory::pluck('name', 'id')->toArray();
        $branches = Branch::where('status',1)->pluck('name','id');
        //$governorates = $governorates->groupBy('country_id');
        //dd($governorates);
        //dd($leads[0]);
        //$cities = City::select('id','name','gov_id')->where('status',1)->get();
        //$cities = $cities->groupBy('gov_id');
        return view('leads.index',compact('tracks','branchess','countries','sources', 'channels', 'branches', 'services', 'employees', 'branches','leads','leadsCount','employeeBranches','agents','leadSources','knowChannels','services','offers','labelTypes'));
    }
    
    public function allleads(Request $request)
    {
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id');
        $testsec = round(microtime(true)*1000);
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $branches = Branch::where('status',1)->pluck('name', 'id');
        $agents = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            /*->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })->*/->whereIn('current_branch' , $request->get('branches'))->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($employeeBranches) {
                                $query->whereIn('id', array_keys($employeeBranches));
                            })->get()->pluck('name', 'id')->toArray();
        }
        $case_from = null;
        $case_to = null;
        if ($request->has('case_daterange') && $request->get('case_daterange') != null && $request->get('case_daterange') != '') {
            $daterange = explode(' - ',$request->get('case_daterange'));
            $case_from = date_format(date_create($daterange[0]),'Y-m-d');
            // $case_to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $case_to= date_format($reg_to,"Y-m-d");
        }
        
        $registration_from = null;
        $registration_to = null;
        $reg_to=null;
        if ($request->has('registration_daterange') && $request->get('registration_daterange') != null && $request->get('registration_daterange') != '') {
            $daterange = explode(' - ',$request->get('registration_daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            // $registration_to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
            
        }
        $leadSources = LeadSource::pluck('name', 'id')->toArray();
        $knowChannels = KnowChannel::pluck('name', 'id')->toArray();
        $services = TrainingService::pluck('title', 'id')->toArray();
        $offers = Offer::pluck('title', 'id')->toArray();
        $labelTypes = LabelType::where('status', 1)->where('category', 1)->pluck('name', 'id')->toArray();
        
        $leadsQuery = Lead::leftJoin('lead_last_cases','leads.id','=','lead_last_cases.lead_id')
                            ->where('leads.type',1)
                            ->whereIn('leads.branch_id', array_keys($employeeBranches))->withCount('cases');
     
                          
        if($request->has('lead_source') && $request->get('lead_source') != null && $request->has('lead_source') != ''){
            $leadsQuery->whereIn('leads.lead_source_id', $request->get('lead_source'));
        }
        
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $leadsQuery->where(function ($query) use ($request){
                $query->where('name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('mobile_1', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('email', 'like', '%' . $request->get('search') . '%');
            });
        }elseif($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
            $leadsQuery->where('leads.assigned_employee_id', $request->get('agent'));
        }elseif (auth()->user()->can('leads leadsAssign')) {
            // show all
            $leadsQuery->whereIn('leads.branch_id', array_keys($employeeBranches));
        } else {
            $leadsQuery->where('leads.assigned_employee_id', auth()->id());
            
        }
        
        if($request->has('know_channel') && $request->get('know_channel') != null && $request->get('know_channel') != ''){
            $leadsQuery->whereIn('leads.know_channel_id', $request->get('know_channel'));
        }
        if ($request->has('time') && $request->get('time') != null && $request->get('time') != '') {
            $leadsQuery->whereIn('leads.preferred_time', $request->get('time'));
        }
        
        if ($request->has('prefered_track_id') && $request->get('prefered_track_id') != null && $request->get('prefered_track_id') != '') {
            $leadsQuery->where('leads.prefered_track_id', $request->get('prefered_track_id'));
        }
        if ($request->has('service') && $request->get('service') != null && $request->get('service') != '') {
            $leadsQuery->whereIn('leads.training_service_id', $request->get('service'));
        }
        if($request->has('select_assigned') && $request->get('select_assigned') != null && $request->get('select_assigned') != ''){
            if ($request->get('select_assigned') === '0') {
                $leadsQuery->whereNull('leads.assigned_employee_id');
            } elseif ($request->get('select_assigned') === '1') {
                $leadsQuery->whereNotNull('leads.assigned_employee_id');
            }
        }
        if ($request->has('offer') && $request->get('offer') != null && $request->get('offer') != '') {
            $leadsQuery->whereIn('leads.offer_id', $request->get('offer'));
        }
        if ($request->has('branches') && $request->get('branches') != null && $request->get('branches') != '') {
            $leadsQuery->whereIn('leads.branch_id', $request->get('branches'));
        }
        if (($request->has('label_type_id') && $request->get('label_type_id') != '' && $request->get('label_type_id') != null) || ($case_from != null && $case_to != null)) {
            if ($case_from && $case_to) {
                $leadsQuery->whereBetween('lead_last_cases.date', [$case_from, $case_to]);
            }
            if ($request->get('label_type_id') != '' && $request->get('label_type_id') != null) {
                $leadsQuery->whereIn('lead_last_cases.label_type_id', $request->get('label_type_id'));
            }
            
        }
        if($request->has('has_followup') && $request->get('has_followup') != null && $request->get('has_followup') != ''){
            if ($request->get('has_followup') === '0') {
                $leadsQuery->doesntHave('cases');
            } elseif ($request->get('has_followup') === '1') {
                $leadsQuery->has('cases');
            }
        }
        
        if ($registration_from != null && $registration_to != '') {
            $leadsQuery->whereBetween('leads.created_at', [$registration_from, $registration_to]);
        }
        if($request->get('one_call') === '1')
        {
            $leadsQuery->having('cases_count', 1);
              
        }

        $leadsCount = 0;
        $leads = $leadsQuery->select('leads.id','leads.created_at','leads.mobile_1','leads.f_name','leads.m_name','leads.l_name',
                'leads.name','leads.name_en','leads.name_ar','leads.type','leads.branch_id','leads.first_branch_id','leads.transfer_branch_id',
                'leads.assigned_employee_id','leads.prefered_track_id','leads.prefer_branch_id','leads.lead_source_id')
            ->groupBy('leads.id')
            ->withCount('cases')
            ->with('lastcase','branch','Track','lead_source','assignedEmployee','prefer_branch')
            ->distinct('leads.id')
            ->orderBy('leads.created_at','desc')
            ->paginate($per_page);
        // return $leads;
        //dd(round(microtime(true)*1000)-$testsec);
        
        $sources = LeadSource::whereNotIn('id',[1,6,12])->where('status',1)->pluck('name', 'id');
        $channels = KnowChannel::where('status',1)->pluck('name', 'id');
        //$offers = Offer::pluck('title', 'id');
        $branchess = /*Branch::pluck('name', 'id')*/auth()->user()->branches->pluck('name', 'id')->toArray();
        //$services = TrainingService::pluck('title', 'id');
        $employees = Employee::where('status',1)->where('account_Type','Operations Account')->get()->pluck('name', 'id');
        //$timeframes = Timeframe::pluck('title', 'id');
        $countries = Country::where('status',1)->pluck('name', 'id')->toArray();
        //$jobs = CustomerJob::where('status',1)->pluck('name', 'id')->toArray();
        //$univercities = University::where('status',1)->orderBy('name')->pluck('name', 'id')->toArray();
        //$nationalities = Country::where('status',1)->pluck('nationality', 'id')->toArray();
        //$governorates = Governorate::select('id','name','country_id')->where('status',1)->get();
        //$disciplines = DisciplineCategory::pluck('name', 'id')->toArray();
        $branches = Branch::where('status',1)->pluck('name','id');
        //$governorates = $governorates->groupBy('country_id');
        //dd($governorates);
        
        //$cities = City::select('id','name','gov_id')->where('status',1)->get();
        //$cities = $cities->groupBy('gov_id');
        return view('leads.allleads',compact('tracks','branchess','countries','sources', 'channels', 'branches', 'employees','leads','leadsCount','employeeBranches','agents','leadSources','knowChannels','services','offers','labelTypes'));
    }
    
    public function onlineLeads(Request $request)
    {
        return view('leads.index', ['online' => true]);
    }
    public function corporate_Leads(Request $request)
    {
        return view('leads.index', ['corporate_Leads' => true]);
    }

    /**
     * Show the form for creating a new Lead.
     *
     * @return Response
     */
    public function create()
    {
        //$testsec = round(microtime(true)*1000);
        $sources = LeadSource::whereNotIn('id',[1,6,12])->where('status',1)->pluck('name', 'id');
        $channels = KnowChannel::where('status',1)->pluck('name', 'id');
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id');
        $offers = Offer::pluck('title', 'id');
        $branches = /*Branch::pluck('name', 'id')*/auth()->user()->branches->pluck('name', 'id')->toArray();
        $services = TrainingService::pluck('title', 'id');
        $employees = Employee::where('status',1)->where('account_Type','Operations Account')->get()->pluck('name', 'id');
        $timeframes = Timeframe::pluck('title', 'id');
        $countries = Country::where('status',1)->pluck('name', 'id')->toArray();
        $jobs = CustomerJob::where('status',1)->pluck('name', 'id')->toArray();
        $univercities = University::where('status',1)->orderBy('name')->pluck('name', 'id')->toArray();
        $nationalities = Country::where('status',1)->pluck('nationality', 'id')->toArray();
        $governorates = Governorate::select('id','name','country_id')->where('status',1)->get();
        $disciplines = DisciplineCategory::pluck('name', 'id')->toArray();
        $branches = Branch::where('status',1)->pluck('name','id');
        $governorates = $governorates->groupBy('country_id');
        //dd($governorates);
        $cities = City::select('id','name','gov_id')->where('status',1)->get();
        $cities = $cities->groupBy('gov_id');
        //dd(round(microtime(true)*1000)-$testsec);
        return view('leads.create', compact('governorates','tracks','disciplines','branches','cities','nationalities','univercities','jobs','countries','sources', 'channels', 'offers', 'branches', 'services', 'employees', 'timeframes'));
    }

    /**
     * Store a newly created Lead in storage.
     *
     * @param CreateLeadRequest $request
     *
     * @return Response
     */
    public function store(CreateLeadRequest $request)
    {

        $input = $request->all();
        if ($request->country == 1) {
            $request->validate([
                'mobile_1' => 'required|digits:11|starts_with:0|unique:leads,mobile_1',
            ]);
        }
        else {
            // dd($input);
         $request->validate([
                'mobile_1' => 'required|unique:leads,mobile_1',
            ]);

        }
        // $input['mobile_1'] =$validatedData->mobile_1; 

        $input['assigned_employee_id'] = auth()->id();
        $input['password'] = 'Harvest@123';
        $input['register_from'] = 'admin_panel';
        $input['name_en'] = $request->f_name.' '.$request->m_name.' '.$request->l_name;
        
        // $input['identification'] = $request->identification;
        // dd($input);
        $lead = Lead::create($input);

        Flash::success('Lead saved successfully.');
        $whatsApp = new WhatsApp;

        $msg = 'username : '.$lead->mobile_1.' password : Harvest@123';
        $whatsApp->send($request->mobile_1, $msg);
        $log = MessageLog::create([
            'type' => 2,
            'content' => $msg,
            'employee_id' => auth()->id()
        ]);
        $log->leads()->sync($request->mobile_1);
        
        activity('Leads')
            ->causedBy(Auth::user()->id)
            ->performedOn($lead)
            ->log('create new lead');
        return redirect(route('admin.leadCases.index', ['lead' => $lead->id, 'type' => 1]));
    }

    /**
     * Display the specified Lead.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $lead = Lead::find($id);
        if (empty($lead)) {
            Flash::error('Lead not found');
            return redirect(route('admin.leads.index'));
        }

        $invoices = LeadPayment::where('lead_id', $lead->id)->withCount(['subPayments' => function ($query) {
            $query->where('paid', 0);
        }])->with('subPayments')->get();
        
        
        $groups_ids = DB::table('group_students')->where('lead_id',$lead->id)->pluck('group_id');
        $groups = Group::whereIn('id',$groups_ids)->orderBy('id','desc')->get();
        $msgs_ids = DB::table('lead_message_log')->where('lead_id',$lead->id)->pluck('message_log_id');
        $msgs = MessageLog::whereIn('id',$msgs_ids)->orderBy('id','desc')->get();
        $pt = PlacementApplicant::where('lead_id',$lead->id)->get()->last();
        $labelTypes = LabelType::where('status', 1)->where('category', 4)->pluck('name', 'id')->toArray();
      
        $followupsQuery = LeadCase::leftJoin('leads','leads.id','=','lead_cases.lead_id')
            ->whereIn('lead_cases.label_type_id',array_keys($labelTypes))->where('lead_id', $lead->id);
        
        $followupsCount = $followupsQuery->count();
        $followups = $followupsQuery->select('lead_cases.id','lead_cases.created_at','lead_cases.branch_id','lead_cases.employee_id','lead_cases.lead_id','lead_cases.label_type_id','lead_cases.action_id','lead_cases.date')->with('lead')->orderBy('lead_cases.id','desc')->paginate(20);
        

        $leadCases = LeadCase::where('lead_id', $lead->id)->orderBy('id','desc')->get();
                $leadSources = LeadSource::where('id', '!=', 6)->where('status',1)->pluck('name', 'id')->toArray();
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id')->toArray();

        
        
        // dd($lead , $invoices , $groups , $msgs)
        return view('leads.show',compact('lead','labelTypes', 'followupsQuery','leadCases','followupsCount','followups','invoices' , 'groups' , 'msgs','pt','leadSources','tracks'));
        
    }

    /**
     * Show the form for editing the specified Lead.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit_payment($id)
    {
        $lead = Lead::find($id);


        if (empty($lead)) {
            Flash::error('Lead not found');
            return redirect(route('admin.leads.index'));
        }
        if(! $lead->f_name){
            $lead->f_name = (isset($lead->name['en']))?$lead->name['en']:'';
        }
        
        if(! $lead->name_ar){
            $lead->name_ar = (isset($lead->name['ar']))?$lead->name['ar']:'';
        }
        //dd($lead->name['en']);
        $sources = LeadSource::where('status',1)->pluck('name', 'id');
        $channels = KnowChannel::where('status',1)->pluck('name', 'id');
        
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id');
        $branches = /*Branch::pluck('name', 'id')*/auth()->user()->branches->pluck('name', 'id')->toArray();
 
        $countries = Country::where('status',1)->pluck('name', 'id')->toArray();
        $univercities = University::where('status',1)->orderBy('name')->pluck('name', 'id')->toArray();
        $nationalities = Country::where('status',1)->pluck('nationality', 'id')->toArray();
        $governorates = Governorate::select('id','name','country_id')->where('status',1)->get();
        $governorates = $governorates->groupBy('country_id');
        $branches = Branch::where('status',1)->pluck('name','id');
        
        $cities = City::select('id','name','gov_id')->where('status',1)->get();
        $cities = $cities->groupBy('gov_id');
        return view('leads.edit_payment', compact('governorates','tracks','branches','cities','nationalities','univercities','countries','lead', 'sources', 'channels', 'branches'));
    }
    public function edit($id)
    {
        $lead = Lead::find($id);


        if (empty($lead)) {
            Flash::error('Lead not found');
            return redirect(route('admin.leads.index'));
        }
        if(! $lead->f_name){
            $lead->f_name = (isset($lead->name['en']))?$lead->name['en']:'';
        }
        
        if(! $lead->name_ar){
            $lead->name_ar = (isset($lead->name['ar']))?$lead->name['ar']:'';
        }

        //dd($lead->name['en']);
        $sources = LeadSource::where('status',1)->pluck('name', 'id');
        $channels = KnowChannel::where('status',1)->pluck('name', 'id');
        $offers = Offer::pluck('title', 'id');
        $branches = /*Branch::pluck('name', 'id')*/auth()->user()->branches->pluck('name', 'id')->toArray();
        $services = TrainingService::pluck('title', 'id');
        $employees = Employee::where('status',1)->where('account_Type','Operations Account')->get()->pluck('name', 'id');
        $timeframes = Timeframe::pluck('title', 'id');
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id');
        $countries = Country::where('status',1)->pluck('name', 'id')->toArray();
        $jobs = CustomerJob::where('status',1)->pluck('name', 'id')->toArray();
        $univercities = University::where('status',1)->orderBy('name')->pluck('name', 'id')->toArray();
        $nationalities = Country::where('status',1)->pluck('nationality', 'id')->toArray();
        $governorates = Governorate::select('id','name','country_id')->where('status',1)->get();
        $governorates = $governorates->groupBy('country_id');
        $branches = Branch::where('status',1)->pluck('name','id');
        $disciplines = DisciplineCategory::pluck('name', 'id')->toArray();
        
        $cities = City::select('id','name','gov_id')->where('status',1)->get();
        $cities = $cities->groupBy('gov_id');
        
        return view('leads.edit', compact('governorates','disciplines','tracks','branches','cities','nationalities','univercities','jobs','countries','lead', 'sources', 'channels', 'offers', 'branches', 'services', 'employees', 'timeframes'));
    }

    /**
     * Update the specified Lead in storage.
     *
     * @param int $id
     * @param UpdateLeadRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateLeadRequest $request )
    {
        $lead = Lead::find($id);
        
        $pt_applicants = PlacementApplicant::where('lead_id',$lead->id)->get();
        if($request->country == 1) {
            // dd($input);
            $request->validate([
                'mobile_1' => 'required|digits:11|starts_with:0|unique:leads,mobile_1,'.$request->segment(2),
            ]);

        }

        //dd($pt_applicants);
        /*if($lead->mobile_1 != $request->mobile_1){
            foreach($pt_applicants as $pt_applicant){
                $pt_applicant->mobile = $request->mobile_1;
                $pt_applicant->save();
            }
        }
        if($lead->email != $request->email){
            foreach($pt_applicants as $pt_applicant){
                $pt_applicant->email = $request->email;
                $pt_applicant->save();
            }
        }
        
        if($lead->name['en'] != $request->name['en']){
            foreach($pt_applicants as $pt_applicant){
                $pt_applicant->name = $request->name['en'];
                $pt_applicant->save();
            }
        }
        */
        if(empty($lead)){
            Flash::error('Lead not found');
            return redirect(route('admin.leads.index'));
        }
        $input = $request->all();
        $input['dob'] = date_format(date_create($request->dob),'Y-m-d');
        $input['name_en'] = $request->f_name.' '.$request->m_name.' '.$request->l_name;
        $lead->update($input);
        
        if(request()->has('flag') && request()->get('flag') == 'payment'){
            $url = 'leadPayments/create?customer='.$lead->id.'&convert=true';
            return redirect($url);
        }
        Flash::success('Lead updated successfully.');
          
        activity('Leads')
            ->causedBy(Auth::user()->id)
            ->performedOn($lead)
            ->log('update lead');
        return redirect(route('admin.leads.index'));
    }

    /**
     * Remove the specified Lead from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        $lead = Lead::find($id);

        if (empty($lead)) {
            Flash::error('Lead not found');

            return redirect(route('admin.leads.index'));
        }

        $lead->delete();

        Flash::success('Lead deleted successfully.');
          
        activity('Leads')
            ->causedBy(Auth::user()->id)
            ->performedOn($lead)
            ->log('Delete lead');

        return redirect(route('admin.leads.index'));
    }
    
    public function leadsDelete(Request $request)
    {
        //dd($request->all());
        if ($request->ids != null && count($request->ids) > 0) {
            Lead::whereIn('id', $request->ids)->delete();
            //LeadCase::whereIn('lead_id', $assignLeads)->where('status', 0)->update(['employee_id' => $this->assigned_employee]);
            Flash::success('Deleted Successfully.');
            
            
        activity('Leads')
            ->causedBy(Auth::user()->id)
            ->performedOn($lead)
            ->log('Delete lead');
        }else{
            Flash::error('Selected Leads is required.');
        }
        return 0;
    }
    
    public function leadsAssign(Request $request)
    {
        //dd($request->all());
        if (!$request->employee_id) {
            Flash::error('Assigned Employee is required.');
        } elseif ($request->ids != null && count($request->ids) > 0) {
            $leads = Lead::whereIn('id', $request->ids)->get();
            
            foreach($leads as $lead){
                $assign_from = $lead->assigned_employee_id;
                $lead->update(['assigned_employee_id' => $request->employee_id]);
                $assign_to = $request->employee_id;
                LeadCase::whereIn('lead_id', $request->ids)->where('status', 0)
                       ->update(['action_employee_id' => $request->employee_id]);
                // assigned_btn
                if($request->flag == 'lead_flag')
                {
                   activity('Leads')
                   ->causedBy(Auth::user()->id)
                   ->performedOn($lead)
                   ->withProperties(['assign_from'=>$assign_from , 'assign_to'=>$assign_to])
                   ->log('Assigned lead');
                }
                else{
                    
                   activity('Customer')
                   ->causedBy(Auth::user()->id)
                   ->performedOn($lead)
                   ->withProperties(['assign_from'=>$assign_from , 'assign_to'=>$assign_to])
                   ->log('Assigned customer');
                }
                    
            }
            Flash::success('Assigned Successfully.');
        } else {
            Flash::error('Selected Employees is required.');
        }
        return 0;
    }
    
    public function leadsTransfer(Request $request)
    {
        // dd($request->all());
        if(!$request->transfer_branch_id){
            Flash::error('Transfer Branch is required.');
        }elseif($request->ids != null && count($request->ids) > 0){
            $leads = Lead::whereIn('id', $request->ids)->get();
            foreach($leads as $lead){
                
                $lead->first_branch_id = $lead->branch_id;
                $lead->branch_id = $request->transfer_branch_id;
                //$lead->assigned_employee_id = null;
                $lead->save();
                if($request->flag == 'lead_flag')
                {
                   activity('Leads')
                   ->causedBy(Auth::user()->id)
                   ->performedOn($lead)
                   ->log('Assigned lead');
                }
                else{
                    
                   activity('Customer')
                   ->causedBy(Auth::user()->id)
                   ->performedOn($lead)
                   ->log('Assigned customer');
                }
            }
            //->update(['assigned_employee_id' => $request->employee_id]);
            //LeadCase::whereIn('lead_id', $request->ids)->where('status', 0)->update(['employee_id' => $request->employee_id]);
            
            Flash::success('Assigned Successfully.');
        } else {
            Flash::error('Selected Employees is required.');
        }
        return 0;
    }

    public function LeadsSendmsg(Request $request)
    {
        //dd($request->all());
        if (!$request->message) {
            Flash::error('Message is required.');
        } elseif ($request->ids != null && count($request->ids) > 0) {
            if($request->type == 'sms'){
                $sms = new SMS;
    
                $mobiles = Lead::whereIn('id', $request->ids)->pluck('mobile_1', 'id')->toArray();
                $msg = $request->message;
    
                $sms->send($mobiles, $msg);
    
                $log = MessageLog::create([
                    'type' => 1,
                    'content' => $msg,
                    'employee_id' => auth()->id(),
                ]);
                $log->leads()->sync(array_keys($mobiles));
            }else{
                $whatsApp = new WhatsApp;

                $mobiles = Lead::whereIn('id', $request->ids)->pluck('mobile_1', 'id')->toArray();
                $msg = $request->message;
    
                $whatsApp->send($mobiles, $msg);
    
                $log = MessageLog::create([
                    'type' => 2,
                    'content' => $msg,
                    'employee_id' => auth()->id()
                ]);
                $log->leads()->sync(array_keys($mobiles));

            }
            
            Flash::success('Sent Successfully.');

        } else {
            Flash::error('Selected Employees is required.');
        }
        return 0;
    }
    
    public function uploadExcelLeads(Request $request)
    {
        //dd($request->all());
        if($request->hasFile('excel')){
            $file = $request->file('excel')->store('/');
            Excel::import(new LeadsImport, storage_path('app/' . $file));
            // $lead = Lead::find(Auth::user()->id);
            activity('Leads')
              ->causedBy(Auth::user()->id)
              ->log('upload Excel lead');
            Flash::success('Imported Successfully.');
        }else{
            Flash::success('excel file is required.');
        }
        return redirect()->back();
    }
    
   
}
