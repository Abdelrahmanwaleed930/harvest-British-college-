<?php

namespace App\Http\Controllers;

use App\Models\LeadSourceCategory;
use Illuminate\Http\Request;

class LeadSourceCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $categories = LeadSourceCategory::all();
        return view('lead_source_category.index', compact('categories'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('lead_source_category.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'status' => 'required|boolean',
        ]);

        LeadSourceCategory::create($request->all());
        return redirect()->route('admin.lead_source_categories.index')
            ->with('success', 'Lead Source Category created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(LeadSourceCategory $leadSourceCategory)
    {
        return view('lead_source_category.show', compact('leadSourceCategory'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(LeadSourceCategory $leadSourceCategory)
    {
        return view('lead_source_category.edit', compact('leadSourceCategory'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, LeadSourceCategory $leadSourceCategory)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'status' => 'required|boolean',
        ]);

        $leadSourceCategory->update($request->all());
        return redirect()->route('admin.lead_source_categories.index')
            ->with('success', 'Lead Source Category updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(LeadSourceCategory $leadSourceCategory)
    {
        $leadSourceCategory->delete();
        return redirect()->route('admin.lead_source_categories.index')
            ->with('success', 'Lead Source Category deleted successfully.');
    }
}
