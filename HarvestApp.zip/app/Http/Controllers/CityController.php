<?php

namespace App\Http\Controllers;

use App\Http\Controllers\AppBaseController;
use App\Models\Governorate;
use App\Models\City;
use Illuminate\Http\Request;
use Flash;
use Response;

class CityController extends AppBaseController
{
    /**
     * Display a listing of the Governorate.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var Governorate $governorates */
        $cities = City::all();
        //dd($governorates);
        return view('cities.index')
            ->with('cities', $cities);
    }

    /**
     * Show the form for creating a new Governorate.
     *
     * @return Response
     */
    public function create()
    {
        $governorates = Governorate::pluck('name','id');
        return view('cities.create')->with('governorates', $governorates);
    }

    /**
     * Store a newly created Governorate in storage.
     *
     * @param CreateGovernorateRequest $request
     *
     * @return Response
     */
    public function store(Request $request)
    {
        $input = $request->all();

        /** @var Governorate $country */
        $city = City::create($input);

        Flash::success('City saved successfully.');

        return redirect(route('admin.cities.index'));
    }

    /**
     * Display the specified Governorate.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var Governorate $country */
        $city = City::find($id);
        
        if (empty($city)) {
            Flash::error('city not found');

            return redirect(route('admin.cities.index'));
        }

        return view('cities.show')->with('city', $city);
    }

    /**
     * Show the form for editing the specified Governorate.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var Governorate $country */
        $city = City::find($id);
        $governorates = Governorate::pluck('name','id');
        if (empty($city)) {
            Flash::error('city not found');

            return redirect(route('admin.cities.index'));
        }

        return view('cities.edit')->with('city', $city)->with('governorates',$governorates);
    }

    /**
     * Update the specified Governorate in storage.
     *
     * @param int $id
     * @param UpdateGovernorateRequest $request
     *
     * @return Response
     */
    public function update($id, Request $request)
    {
        /** @var Governorate $country */
        $city = City::find($id);

        if (empty($city)) {
            Flash::error('city not found');

            return redirect(route('admin.cities.index'));
        }

        $city->fill($request->all());
        $city->save();

        Flash::success('city updated successfully.');

        return redirect(route('admin.cities.index'));
    }

    /**
     * Remove the specified Governorate from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var Governorate $country */
        $city = City::find($id);

        if (empty($city)) {
            Flash::error('city not found');

            return redirect(route('admin.cities.index'));
        }

        $city->delete();

        Flash::success('city deleted successfully.');

        return redirect(route('admin.cities.index'));
    }
}
