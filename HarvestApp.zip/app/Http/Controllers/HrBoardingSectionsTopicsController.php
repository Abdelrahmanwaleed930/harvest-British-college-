<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests\CreateHrBoardingSectionsTopicsRequest;
use App\Http\Requests\UpdateHrBoardingSectionsTopicsRequest;

use App\Models\HrBoardingSections;
use App\Models\HrBoardingSectionsTopics;

use Flash;
use Response;
class HrBoardingSectionsTopicsController extends Controller
{
     public function index()
    {
        $HrBoardingSectionsTopics = HrBoardingSectionsTopics::get();
        
        return view('HrBoardingSectionsTopics.index',compact('HrBoardingSectionsTopics'));
    }
    public function create()
    {
        $HrBoardingSections = HrBoardingSections::pluck('title','id');
        return view('HrBoardingSectionsTopics.create',compact('HrBoardingSections'));
    }
    public function store(CreateHrBoardingSectionsTopicsRequest $request)
    {
        $input = $request->all();
        $HrBoardingSectionsTopic = HrBoardingSectionsTopics::create($input);
        
        Flash::success('HrBoardingSectionsTopic saved successfully.');
        return redirect(route('admin.HrBoardingSectionsTopics.index'));
    }
    public function show($id)
    {
        $HrBoardingSectionsTopic = HrBoardingSectionsTopics::find($id);
        if (empty($HrBoardingSectionsTopic)) {
            Flash::error('HrBoardingSectionsTopic not found');

            return redirect(route('admin.HrBoardingSectionsTopics.index'));
        }
        
        return view('HrBoardingSectionsTopics.show',compact('HrBoardingSectionsTopic'));
    }
    public function edit($id)
    {
        $HrBoardingSectionsTopic = HrBoardingSectionsTopics::find($id);
        $HrBoardingSections = HrBoardingSections::pluck('title','id');
        if (empty($HrBoardingSectionsTopic)) {
            Flash::error('HrBoardingSectionsTopic not found');

            return redirect(route('admin.HrBoardingSectionsTopics.index'));
        }
        
        return view('HrBoardingSectionsTopics.edit',compact('HrBoardingSectionsTopic','HrBoardingSections'));
    }
    public function update(UpdateHrBoardingSectionsTopicsRequest $request , $id)
    {
        $HrBoardingSectionsTopic = HrBoardingSectionsTopics::find($id);
        $data =  $request->all();
        if (empty($HrBoardingSectionsTopic)) {
            Flash::error('HrBoardingSectionsTopic not found');

            return redirect(route('admin.HrBoardingSectionsTopics.index'));
        }
        $HrBoardingSectionsTopic->update($data);
        Flash::success('HrBoardingSectionsTopic updated successfully.');
        return redirect(route('admin.HrBoardingSectionsTopics.index'));
    }
    public function destroy($id)
    {
        $HrBoardingSectionsTopic = HrBoardingSectionsTopics::find($id);
        if (empty($HrBoardingSectionsTopic)) {
            Flash::error('HrBoardingSectionsTopic not found');

            return redirect(route('admin.HrBoardingSectionsTopics.index'));
        }
        $HrBoardingSectionsTopic->delete();
        
        Flash::success('HrBoardingSectionsTopic Deleted successfully.');
        return redirect(route('admin.HrBoardingSectionsTopics.index'));
    }
}
