<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\QuizModel;
use App\Models\Question;
use App\Models\Track;
use App\Models\QuizModelQuestion;
use App\Models\QuizModelTimeframe;
use App\Models\Timeframe;
use Flash;

class QuizModelController extends Controller
{
    public function index(Request $request)
    {
        $quizes = QuizModel::orderBy('created_at','desc');
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id');
        $per_page = 10;
        if($request->has('per_page') && $request->get('per_page') != null && $request->get('per_page') != ''){
            $per_page = $request->get('per_page');
        }

        $daterange_from = null;
        $daterange_to = null;
        $reg_to=null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $daterange_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $daterange_to= date_format($reg_to,"Y-m-d");;
            
        }

        if ($daterange_from != null && $daterange_to != '') {
            $quizes->whereBetween('created_at', [$daterange_from, $daterange_to]);
        }
        $courses=[];
        
        if($request->has('track_id') && $request->get('track_id') != null && $request->get('track_id') != ''){
            $courses = Track::where('status',1)->where('parent_id',$request->get('track_id'))->pluck('title','id');
            $quizes->where('track_id',$request->get('track_id'));
        }
        $stageLevels=[];
        
        if($request->has('course_id') && $request->get('course_id') != null && $request->get('course_id') != ''){
            $quizes->where('course_id',$request->get('course_id'));
            $stageLevels = Track::find($request->get('course_id'))->stageLevels->pluck('name', 'id')->toArray();
            }
        
        if($request->has('level_id') && $request->get('level_id') != null && $request->get('level_id') != ''){
            $quizes->where('level_id',$request->get('level_id'));
        }
        

        if ($daterange_from != null && $daterange_to != '') {
            $quizes->whereBetween('created_at', [$daterange_from, $daterange_to]);
        }
        $quizes = $quizes->paginate($per_page);

        return view('quizmodel.index',compact('quizes' ,'tracks' ,'stageLevels' ,'courses'));

    }
    public function create()
    {
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id');    
        $courses=[];
        $stageLevels=[];
        $skills = ['vocab,grammer'=>'vocab,grammer' , 'writing,reading'=>'writing,reading' ,'listening,writing'=>'listening,writing' , 'listening,reading'=>'listening,reading'];
        return view('quizmodel.create',compact('tracks','courses','stageLevels','skills'));
    }
    public function store(Request $request)
    {
        
          $validator = $request->validate([
            'track_id' => 'required',
            'course_id' => 'required',
            'level_id'=>'required',
            'title'=>'required',
            'skills'=>'required',
            
        ]);
         $timeframes= $request->timeframe_id;
         $session_number = $request->session_number;
         
         $skill = $request->skills;
         $skills =explode(",",$skill);
         
        $quiz = new QuizModel;
        $quiz->track_id = $request->track_id;
        $quiz->course_id = $request->course_id;
        $quiz->level_id = $request->level_id;
        $quiz->title = $request->title;
        $quiz->skills = $request->skills;
        $quiz->save();
        foreach($timeframes as $key=>$timeframe){
            $QuizModelTimeframe = new QuizModelTimeframe;
            $QuizModelTimeframe->quiz_model_id = $quiz->id;
            $QuizModelTimeframe->timeframe_id = $timeframes[$key];
            $QuizModelTimeframe->level_id = $quiz->level_id;
            $QuizModelTimeframe->session_number = $session_number[$key];
            $QuizModelTimeframe->save();
        }
        
        if(in_array("vocab", $skills)){
            $question1 = Question::where('track_id',$quiz->track_id)
            ->where('course_id',$quiz->course_id)->where('level_id',$quiz->level_id)
            ->where('skill', 'Vocabulary')->with('answers')->limit(10)->inRandomOrder()->get();
            $array =[];
            
            foreach ($question1 as $key => $question) {
                $quiz_model_question =new QuizModelQuestion ;    
                $quiz_model_question->skill = $question1[$key]->skill;
                $quiz_model_question->question_id = $question1[$key]->id;
                $quiz_model_question->quiz_model_id =$quiz->id;
                $quiz_model_question->save();
            }
        }if(in_array("grammer", $skills)){
        
            $question2 = Question::where('track_id',$quiz->track_id)
            ->where('course_id',$quiz->course_id)->where('level_id',$quiz->level_id)
            ->where('skill', 'Grammar')->with('answers')->limit(10)->inRandomOrder()->get();
    
            foreach ($question2 as $key => $question) {
                $quiz_model_question =new QuizModelQuestion ;    
                $quiz_model_question->skill = $question2[$key]->skill;
                $quiz_model_question->question_id = $question2[$key]->id;
                $quiz_model_question->quiz_model_id = $quiz->id;
                $quiz_model_question->save();
            }

        
        }
        if(in_array("reading", $skills)){
             $paragraphs = Question::where('track_id',$quiz->track_id)
            ->where('course_id',$quiz->course_id)->where('level_id',$quiz->level_id)
            ->where('skill', 'Reading')->whereNull('parent_id')
            ->with('children.answers')
            ->limit(1)->inRandomOrder()->get()->map(function ($para) {
                $para->setRelation('children', $para->children->take(10));
                return $para;
            });
            $questions1 = collect();
            foreach($paragraphs as $paragraph){
                foreach($paragraph->children as $question){
                    $questions1->push($question);
                }
            }
            foreach ($questions1 as $key => $question) {
                $quiz_model_question =new QuizModelQuestion ;    
                $quiz_model_question->skill = $question->skill;
                $quiz_model_question->question_id = $question->id;
                $quiz_model_question->parent_id = $question->parent_id;
                $quiz_model_question->quiz_model_id = $quiz->id;
                $quiz_model_question->save();
            }
        }
        if(in_array("writing", $skills)){
            
            $question3 = Question::where('track_id',$quiz->track_id)
            ->where('course_id',$quiz->course_id)
            ->where('level_id',$quiz->level_id)->where('skill', 'Writing')->whereNull('parent_id')
            ->with('children')
            ->limit(1)->inRandomOrder()->get();
            foreach ($question3 as $key => $question) {
                $quiz_model_question =new QuizModelQuestion ;    
                $quiz_model_question->skill = $question3[$key]->skill;
                $quiz_model_question->question_id = $question3[$key]->id;
                $quiz_model_question->quiz_model_id = $quiz->id;
                $quiz_model_question->save();
            }
        }
        if(in_array("listening", $skills)){
            $paragraphs2 = Question::where('track_id',$quiz->track_id)
            ->where('course_id',$quiz->course_id)->where('level_id',$quiz->level_id)
            ->where('skill', 'Listening')->whereNull('parent_id')
            ->with('children.answers')
            ->limit(1)->inRandomOrder()->get()->map(function ($para) {
                $para->setRelation('children', $para->children->take(10));
                return $para;
            });
            $questions2 = collect();
            foreach($paragraphs2 as $paragraph){
                foreach($paragraph->children as $question){
                    $questions2->push($question);
                }
            }
            foreach ($questions2 as $key => $question) {
                $quiz_model_question =new QuizModelQuestion ;    
                $quiz_model_question->skill = $question->skill;
                $quiz_model_question->question_id = $question->id;
                $quiz_model_question->quiz_model_id = $quiz->id;
                $quiz_model_question->parent_id = $question->parent_id;
                $quiz_model_question->save();
            }

        }

        
        
            
        Flash::success(' Quiz Create successfully.');
        return redirect(route('admin.Quizmodel.index'));
    }
    public function show($id)
    {
         $quiz = QuizModel::with('quiz_model_questions','quiz_model_timeframe')->find($id);
       
        $skills =explode(",",$quiz->skills);
       
         
        $quiz_model_question = QuizModelQuestion::with('question.answers')->with('question.parent')->where('quiz_model_id' , $quiz->id)->get();
        $question = QuizModelQuestion::where('quiz_model_id' , $quiz->id)->pluck('question_id')->toArray();
        $Reading_questions = Question::whereIn('id' , $question)->where('skill','Reading')->with('answers','parent')->get()->groupBy('parent_id');
        $Listening_questions = Question::whereIn('id' , $question)->where('skill','Listening')->with('answers','parent')->get()->groupBy('parent_id');
        return view('quizmodel.show',compact('quiz','skills' ,'quiz_model_question','Reading_questions','Listening_questions'));
    }
    public function edit()
    {
        
    }
    public function update()
    {
        
    }
    public function destroy($id)
    {
        $quiz_model = QuizModel::find($id);
        if (empty($quiz_model)) {
            Flash::error('Quiz Model not found');
            return redirect(route('admin.Quizmodel.index'));
        }
        $quiz_model->delete();
        Flash::success('Quiz Model deleted successfully.');
        return redirect(route('admin.Quizmodel.index'));
    }
    
    public function getsessions(Request $request){
        $timeframe = Timeframe::where('id',$request->timeframe_id)->where('status',1)->first();
        $sessions = $timeframe->total_hours / $timeframe->session_hours;
        return $sessions;

    }
}
