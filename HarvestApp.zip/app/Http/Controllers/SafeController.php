<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\Employee;
use App\Models\Safe;
use App\Models\SafeType;
use App\Models\PaymentMethod;
use App\Models\Lead;
use App\Models\LeadPayment;
use App\Models\Expense;
use App\Models\SubPayment;
use App\Models\SafeOperation;


use App\Models\SafeTrancation;
use Illuminate\Http\Request;
use Flash;
use DB;
use Illuminate\Support\Facades\Auth;
use Spatie\Activitylog\Contracts\Activity;


class SafeController extends Controller
{
    
    
    public function cash(Request $request){
        if (!$request->amount) {
            Flash::error('amount is required.');
        } elseif ($request->ids != null && count($request->ids) > 0) {
            $safes = Safe::whereIn('id', $request->ids)->get();
            $new_balance = 0;
            foreach($safes as $safe){
                
                $safeOperation = new SafeOperation();
                $safeOperation->safe_id = $safe->id; 
                $safeOperation->operation_type = 'income'; 
                $safeOperation->source = 'send-cash'; 
                $safeOperation->amount = $request->amount;
                $safeOperation->save();
                
                $safe->balance +=  $request->amount;
                $safe->save();
            }
            Flash::success('Assigned Successfully.');
        } else {
            Flash::error('Selected Employee is required.');  
        }
        return 0;
    }
    
    public function viewAddSafe()
    {
        $employees = Employee::where('account_Type', 'Operations Account')
        ->orwhere('account_Type', 'H.Q Account')->where('status',1)->get();
        return view('safe.create', compact('employees'));
    }

    public function getAllEmployeeSafe(Request $request)
    {
        $ellEmployees = Employee::where('account_Type', 'Operations Account')
        ->orwhere('account_Type', 'H.Q Account')->where('status',1)->get();
        $user = Auth::user();
        $allBranches = $user->branches;
        $branchesID = [];
        foreach ($allBranches as $branch) {
            array_push($branchesID, $branch->id);
        }
        $Branches = $request->branches;
        $employee = $request->ellEmployee;
        $balance = $request->balance;

        $allEmployeeSafe = Safe::whereNull('is_manager');

        if ($request->has('branches') && count($Branches) != 0 &&  !in_array(0, $Branches)) {
            $allEmployeeSafe = $allEmployeeSafe->whereIn('branch_id', $Branches);
        } else {
            $allEmployeeSafe = $allEmployeeSafe->whereIn('branch_id', $branchesID);
        }

        if ($request->has('ellEmployee') && $employee != '') {
            $allEmployeeSafe = $allEmployeeSafe->where('employee_id', $employee);
        }

        if ($request->has('balance') && $balance != '') {
            if ($balance == 0) {
                $allEmployeeSafe = $allEmployeeSafe->where('balance', 0);
            } else {
                $allEmployeeSafe = $allEmployeeSafe->where('balance', '!=', 0);
            }
        }

        $allEmployeeSafe = $allEmployeeSafe->get();
        
        return view('safe.index')->with('allBranches', $allBranches)->with('ellEmployees', $ellEmployees)
            ->with('allEmployeeSafe', $allEmployeeSafe);
    }













// start new safe


    public function getAllSafe(Request $request)
    {
        $ellEmployees = Employee::whereHas('safe')
        ->where('account_Type', 'Operations Account')
        ->orwhere('account_Type', 'H.Q Account')->where('status',1)->get();
        $user = Auth::user();
        $allBranches = $user->branches;
        $branchesID = [];
        foreach ($allBranches as $branch) {
            array_push($branchesID, $branch->id);
        }
        $Branches = $request->branches;
        $employee = $request->ellEmployee;
        $balance = $request->balance;
        $pym = $request->allPayment;
        $sf=$request->safe_type_id;
    $perPage = $request->get('per_page', 20);  // Get the per_page value, default to 20


        $safe_type = SafeType::WhereNull('parent_id')->get();
        $sub_safe_type = SafeType::WhereNotNull('parent_id')->get();
        $sub_safe_types = $sub_safe_type->groupBy('parent_id');

        $allsafe = Safe::with('branch' , 'employee' , 'payment_method' ,'safe_type');
        $payment_method = PaymentMethod::all();
        // $safe_type = SafeType::all();


        if ($request->has('branches') && count($Branches) != 0 &&  !in_array(0, $Branches)) {
            $allsafe = $allsafe->whereIn('branch_id', $Branches);
        } else {
            $allsafe = $allsafe->whereIn('branch_id', $branchesID);
        }
           if ($request->has('status') && $request->status !== '') {
        $allsafe->where('status', $request->status);
    }
        if ($request->has('ellEmployee') && $employee != '') {
            $allsafe = $allsafe->where('employee_id', $employee);
        }
        if ($request->has('allPayment') && $pym != '') {
            $allsafe = $allsafe->where('payment_method_id', $pym);
        }
        if($request->has('safeType3') && $request->safeType3 != null && $request->safeType3 != ''){
            $allsafe = $allsafe->where('safe_type_id', $request->safeType3);
        }
        elseif($request->has('safeType2') && $request->safeType2 != null && $request->safeType2 != ''){
            $check_safe_type = SafeType::where('parent_id',$request->safeType2)->pluck('id')->toArray();
            
            if($check_safe_type != null && count($check_safe_type) > 0){
                $allsafe = $allsafe->whereIn('safe_type_id', $check_safe_type);
            }else{
                $allsafe = $allsafe->where('safe_type_id', $request->safeType2);
            }
        }
        
        elseif($request->has('safeType1') && $request->safeType1 != null && $request->safeType1 != ''){
            $all_safe_types = array();
            $check_safe_types = SafeType::where('parent_id',$request->safeType1)->pluck('id')->toArray();
                
            if($check_safe_types != null && count($check_safe_types) > 0){
                $all_safe_types = array_merge($all_safe_types,$check_safe_types);
                foreach($check_safe_types as $check_safe_type){
                    $check_safe_sub_types = SafeType::where('parent_id',$check_safe_type)->pluck('id')->toArray();
                    $all_safe_types = array_merge($all_safe_types,$check_safe_sub_types);
                }
                $allsafe = $allsafe->whereIn('safe_type_id', $all_safe_types);
            }else{
                $allsafe = $allsafe->where('safe_type_id', $request->safeType1);
            }
        }
        else{
            
        }
        if ($request->has('balance') && $balance != '') {
            if ($balance == 0) {
                $allsafe = $allsafe->where('balance', 0);
            } else {
                $allsafe = $allsafe->where('balance', '!=', 0);
            }
        }

        $safeallbalance = Safe::get()->sum('balance');

        $safeCount = $allsafe->count();
        $safeTotalBalance = $allsafe->sum('balance');


        
        
        $allsafe = $allsafe->orderBy('status','desc')->orderBy('id','asc')->paginate($perPage);

            return view('safe.index',compact('allsafe','safeallbalance','safeCount','safeTotalBalance','allBranches' , 'ellEmployees' , 'payment_method' , 'safe_type' , 'sub_safe_types'));


    }

    public function showaddsafes(Request $request)
    {
        
        $employees = Employee::where('account_Type', 'Operations Account')
        ->orwhere('account_Type', 'H.Q Account')
        ->where('status',1)->get();
        $branches = Branch::where('status',1)->get();
        $payment_method = PaymentMethod::all();
        $safe_type = SafeType::WhereNull('parent_id')->get();
        $sub_safe_type = SafeType::WhereNotNull('parent_id')->get();
        $sub_safe_types = $sub_safe_type->groupBy('parent_id');

        return view('safe.create', compact('employees', 'branches' ,'payment_method' ,'safe_type' , 'sub_safe_types'));

    }
    public function storeSafe(Request $request)
    {
        // dd($request->all());
        $validator = $request->validate(
            [
                'id_employee' => 'required',
                'id_branche' => 'required',
                'is_hq'=>'required',
                'payment_method_id'=>'required',
                'safe_type_id'=>'required',
                'is_manager'=>'required',
                'status'=>'required'
            ]
        );
        // if ($request->is_hq == 'yes') {
        //     $checkHQSafe = Safe::where('is_hq', 1)->first();
        //     if ($checkHQSafe) {
        //         Flash::error('you actually have HQ safe');
        //         return redirect()->back();
        //     }
        // }
        $safeTypes = array_filter($request->safe_type_id);
        $last_safe_type = end($safeTypes);
        $check_has_sub_types = SafeType::where('parent_id',$last_safe_type)->get();
        
        if($check_has_sub_types != null && count($check_has_sub_types) > 0){
            Flash::error('select safe type.');
            
            return back();
            
        }
        $employee = Employee::where('id',$request->id_employee)->where('status',1)->first();
        $checkSafe = Safe::where('payment_method_id',$request->payment_method_id)->where('employee_id', $request->id_employee)->first();
        if ($checkSafe) {
            Flash::error('Employee actually have safe');
            return redirect(route('admin.safe.view'));
            // return redirect()->back();
        }
        // $payment_method =PaymentMethod::where('title',$request->title)->first();
        // $safe_type =SafeType::where('name',$request->name)->first();
        $newSafe = new Safe();
        $newSafe->employee_id = $request->id_employee;
        $newSafe->branch_id = $request->id_branche;
        if ($request->is_hq == 'yes') {
            $newSafe->is_hq = 1;
        }
        else{
            $newSafe->is_hq = 0;
        }
        if ($request->is_manager == 'yes') {
            $newSafe->is_manager = 1;
        }
        else{
            $newSafe->is_manager = 0;

        }
        if ($request->status == 'Active') {
            $newSafe->status = 1;
        }
        else{
            $newSafe->status = 0;
        }
        
        $newSafe->payment_method_id = $request->payment_method_id;
        $newSafe->safe_type_id = $last_safe_type;
        $newSafe->save();

        
        Flash::success('Employee Safe Added successfully.');
        // return redirect()->back();
        return redirect(route('admin.safe.view'));
    }

    public function editsafe($id){
        $employees = Employee::where('account_Type', 'Operations Account')
        ->orwhere('account_Type', 'H.Q Account')->where('status',1)->get();
        $branches = Branch::where('status',1)->get();
        $safe = Safe::find($id);
        if (!$safe) {
            Flash::error('This branch safe not found');
            return redirect()->back();
        }
        $payment_method = PaymentMethod::all();
        
        $safe_type = SafeType::get();
        $sub_safe_type = SafeType::WhereNotNull('parent_id')->get();
        $sub_safe_types = $sub_safe_type->groupBy('parent_id');


        return view('safe.edit', compact('employees', 'safe' ,'payment_method' ,'safe_type','sub_safe_types','branches'));

    }

    public function updateSafe(Request $request, $id)
    {
        $validator = $request->validate(
            [
                'id_employee' => 'required',
                'id_branche' => 'required',
                'is_hq'=>'required',
                'payment_method_id'=>'required',
                'safe_type_id'=>'required',
                'is_manager'=>'required'
            ]
        );
        // $safe = Safe::->with('')find($id);
        $safe = Safe::with('branch' , 'employee' , 'payment_method' ,'safe_type')->find($id);
        if (!$safe) {
            Flash::error('This safe not found');
            return redirect()->back();
        }
        $employee = Employee::where('id',$request->id_employee)->where('status',1)->first();
        // $checkSafe = Safe::where('employee_id', $request->id_employee)->first();
        // if ($checkSafe) {
        //     Flash::error('Employee actually have safe');
        //     return redirect()->back();
        // }
        // $checkbranchSafe = Safe::where('branch_id', $request->id_branche)->where('is_manager', 1)->first();
        // if ($checkbranchSafe) {
        //     Flash::error('This branch actually have branch safe');
        //     return redirect()->back();
        // }
        // $checkSafe = Safe::where('employee_id', $request->id_employee)->where('branch_id', '!=', $safe->branch_id)->where('is_manager', 1)->first();
        // if ($checkSafe) {
        //     Flash::error('Employee actually have branch safe');
        //     return redirect()->back();
        // }
        // if ($request->is_hq == 'yes') {
        //     $checkHQSafe = Safe::where('is_hq', 1)->where('branch_id', '!=', $safe->branch_id)->first();
        //     if ($checkHQSafe) {
        //         Flash::error('you actually have HQ safe');
        //         return redirect()->back();
        //     }
        // }
        $safeTypes = array_filter($request->safe_type_id);
        $last_safe_type = end($safeTypes);
        $check_has_sub_types = SafeType::where('parent_id',$last_safe_type)->get();
        
        if($check_has_sub_types != null && count($check_has_sub_types) > 0){
            Flash::error('select safe type.');
            
            return back();
            
        }
        $safe->branch_id = $request->id_branche;
        $safe->employee_id = $request->id_employee;
        $safe->payment_method_id = $request->payment_method_id;
        $safe->safe_type_id = $last_safe_type;
        if ($request->is_manager == 'yes') {
            $safe->is_manager = 1;
        }
        else {
            $safe->is_manager = 0;
        }
        if ($request->is_hq == 'yes') {
            $safe->is_hq = 1;
        } else {
            $safe->is_hq = 0;
        }
        if ($request->status == 'Active') {
            $safe->status = 1;
        }
        else{
            $safe->status = 0;
        }
        $safe->save();
        
         activity('Safe')
           ->causedBy(Auth::user()->id)
           ->performedOn($safe)
           ->log('Update Safe');
        Flash::success(' Safe updated successfully.');
        return redirect(route('admin.safe.view'));
    }
    public function deleteSafe($id){
        $safe = Safe::find($id);
        $safe->delete();
        
        
         activity('Safe')
           ->causedBy(Auth::user()->id)
           ->performedOn($safe)
           ->log('Delete Safe');
        Flash::success(' Safe deleted successfully.');
        return redirect(route('admin.safe.view'));

    }



    // end new safe
















    public function getEmployeeBranches(Request $request)
    {
        $id_employee = $request->id_employee;
        $employee = Employee::where('id',$id_employee)->where('status',1)->first();
        $Branches = $employee->branches;
        return $Branches;
    }

    // public function storeSafe(Request $request)
    // {
    //     $validator = $request->validate(
    //         [
    //             'id_employee' => 'required',
    //             'id_branche' => 'required'
    //         ]
    //     );
    //     $employee = Employee::find($request->id_employee);
    //     $checkSafe = Safe::where('employee_id', $request->id_employee)->first();
    //     if ($checkSafe) {
    //         Flash::error('Employee actually have safe');
    //         return redirect()->back();
    //     }
    //     $newSafe = new Safe();
    //     $newSafe->employee_id = $request->id_employee;
    //     $newSafe->branch_id = $request->id_branche;
    //     $newSafe->save();

    //     Flash::success('Employee Safe Added successfully.');
    //     return redirect()->back();
    // }

    public function viewAddBranchSafe()
    {
        $employees = Employee::where('account_Type', 'Operations Account')->where('status',1)->get();
        $branches = Branch::where('status',1)->get();
        return view('safe.branch_create', compact('employees', 'branches'));
    }

    public function storeBranchSafe(Request $request)
    {
        $validator = $request->validate(
            [
                'id_employee' => 'required',
                'id_branche' => 'required'
            ]
        );
        $employee = Employee::where('id',$request->id_employee)->where('status',1)->get();
        $checkbranchSafe = Safe::where('branch_id', $request->id_branche)->where('is_manager', 1)->first();
        if ($checkbranchSafe){
            Flash::error('This branch actually have branch safe');
            return redirect()->back();
        }
        $checkSafe = Safe::where('employee_id', $request->id_employee)->where('is_manager', 1)->first();
        if ($checkSafe) {
            Flash::error('Employee actually have branch safe');
            return redirect()->back();
        }
        if ($request->is_hq == 'yes') {
            $checkHQSafe = Safe::where('is_hq', 1)->first();
            if ($checkHQSafe) {
                Flash::error('you actually have HQ safe');
                return redirect()->back();
            }
        }
        $newSafe = new Safe();
        $newSafe->employee_id = $request->id_employee;
        $newSafe->branch_id = $request->id_branche;
        $newSafe->is_manager = 1;
        if ($request->is_hq == 'yes') {
            $newSafe->is_hq = 1;
        }
        $newSafe->save();
        Flash::success('Branch Safe Added successfully.');
        return redirect(route('admin.safe.getAllBranchSafe'));
    }

    public function getAllBranchSafe()
    {
        $allBranchesSafe = Safe::where('is_manager', 1)->get();
        return view('safe.branch_index', compact('allBranchesSafe'));
    }


    public function editBranchSafe($id)
    {
        $employees = Employee::where('account_Type', 'Operations Account')->where('status',1)->get();
        $safe = Safe::find($id);
        if (!$safe) {
            Flash::error('This branch safe not found');
            return redirect()->back();
        }
        return view('safe.branch_edit', compact('employees', 'safe'));
    }
    
    public function updateBranchSafe(Request $request, $id)
    {
        $validator = $request->validate(
            [
                'id_employee' => 'required'
            ]
        );
        $safe = Safe::find($id);
        if (!$safe) {
            Flash::error('This branch safe not found');
            return redirect()->back();
        }
        $checkbranchSafe = Safe::where('branch_id', $request->id_branche)->where('is_manager', 1)->first();
        if ($checkbranchSafe) {
            Flash::error('This branch actually have branch safe');
            return redirect()->back();
        }
        $checkSafe = Safe::where('employee_id', $request->id_employee)->where('branch_id', '!=', $safe->branch_id)->where('is_manager', 1)->first();
        if ($checkSafe) {
            Flash::error('Employee actually have branch safe');
            return redirect()->back();
        }
        if ($request->is_hq == 'yes') {
            $checkHQSafe = Safe::where('is_hq', 1)->where('branch_id', '!=', $safe->branch_id)->first();
            if ($checkHQSafe) {
                Flash::error('you actually have HQ safe');
                return redirect()->back();
            }
        }
        $safe->employee_id = $request->id_employee;
        $safe->is_manager = 1;
        if ($request->is_hq == 'yes') {
            $safe->is_hq = 1;
        } else {
            $safe->is_hq = 0;
        }
        $safe->save();
        Flash::success('Branch Safe updated successfully.');
        return redirect(route('admin.safe.getAllBranchSafe'));
    }

    public function makeTransaction(Request $request, $idSafe)
    {
        $validator = $request->validate(
            [
                'safe_id' => 'required',
                'amount' => 'required | numeric',
                'type' => 'required',
                'payment_method' => 'required_if:type,1',
                'bank' => 'required_if:type,2',
                'reference_num' => 'required_if:type,2',
            ]
        );
        // dd($request->all());

        $senderSafe = Safe::find($idSafe);
        if (!$senderSafe || $senderSafe->balance < $request->amount) {
            Flash::error('your balance is not enough for this transaction');
            return redirect()->back();
        }

        $receiverSafe = Safe::find($request->safe_id);

        $newSafeTransaction = new SafeTrancation();

        $newSafeTransaction->safe_sender = $senderSafe->id;
        $newSafeTransaction->safe_receiver = $receiverSafe->id;

        $newSafeTransaction->sender = $senderSafe->employee_id;
        $newSafeTransaction->receiver = $receiverSafe->employee_id;
        $newSafeTransaction->amount = $request->amount;
        $newSafeTransaction->description = $request->description;
        $newSafeTransaction->payment_methods_id = $request->type == 1 ? $request->payment_method : $request->bank;
        $newSafeTransaction->reference_num = $request->reference_num;
        $newSafeTransaction->save();

        Flash::success('Your transaction is Added successfully.');

        return redirect()->back();
    }

    public function chengStatusSafeHistory($id, $status)
    {

        $transaction = SafeTrancation::find($id);
        $senderSafe = Safe::find($transaction->safe_sender);
        $receiverSafe = Safe::find($transaction->safe_receiver);
        $transaction->status = $status;
        if ($status != 'refuse') {
            $senderSafe->balance = $senderSafe->balance - $transaction->amount;
            $receiverSafe->balance = $receiverSafe->balance + $transaction->amount;
            $senderSafe->save();
            $receiverSafe->save();

            $safe_operation_receiver = new SafeOperation;
            $safe_operation_receiver->safe_id = $receiverSafe->id;
            $safe_operation_receiver->operation_type = 'income';
            $safe_operation_receiver->amount = $transaction->amount;
            $safe_operation_receiver->source = 'transfer';
            $safe_operation_receiver->save();
    
    
            $safe_operation_sender = new SafeOperation;
            $safe_operation_sender->safe_id = $senderSafe->id;
            $safe_operation_sender->operation_type = 'outcome';
            $safe_operation_sender->amount = $transaction->amount;
            $safe_operation_sender->source = 'transfer';
            $safe_operation_sender->save();
        
        }
        $transaction->save();
        

        Flash::success('Cheng transaction status successfully.');
        return redirect()->back();
    }
    
    
    
    public function updateStatus(Request $request)
    {
        $safe = Safe::find($request->id);
        $message = '';
        if($safe->balance > 0){
            $message .= 'This safe has balance. Please withdraw this balance first.';
        }else{
            $safe->status = ! $safe->status;
            $safe->save();
            
         activity('Safe')
           ->causedBy(Auth::user()->id)
           ->performedOn($safe)
           ->log('Update Safe Status');
        }
        
        
        return response()->json(['safe_status' => $safe->status,'message' => $message]);
    }


    public function accountsStatements(Request $request)
    {
        $safesData = Safe::with('employee', 'branch')->get();
        $safes = [];
        foreach ($safesData as $safe) {
            $safes[$safe->id] = (($safe->employee)?$safe->employee->name:'') . " - " . (($safe->branch)?$safe->branch->name:'') . " - " . $safe->type;
        }
        
        $branches = Branch::where('status',1)->pluck('name', 'id');
        
        $methods = [];
        if($request->has('type') && $request->type != null && $request->type != ''){
            if($request->type == 1){
                $methods = PaymentMethod::where('transfer', 1)->pluck('title', 'id');
            }else{
                $methods = PaymentMethod::where('deposit', 1)->pluck('title', 'id');
            }
        }
        
        $date_from = null;
        $date_to = null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $date_from = date_format(date_create($daterange[0]),'Y-m-d');
            // $date_to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $date_to= date_format($reg_to,"Y-m-d");
        }
        

        $transactionsQuery = SafeTrancation::with('senderEmployee', 'receiverEmployee', 'paymentMethods');

        if ($request->has('branch_id') && $request->branch_id != null && $request->branch_id != '') {
            $transactionsQuery->whereHas('senderSafe', function ( $query) use ($request){
                $query->where('branch_id', $request->branch_id);
            })->orWhereHas('receiverSafe', function ( $query)use ($request) {
                $query->where('branch_id', $request->branch_id);
            });
        }
        if ($request->has('sender_safe') && $request->sender_safe != null && $request->sender_safe != '') {
            $transactionsQuery->where('safe_sender', $request->sender_safe);
        }
        if ($request->has('receiver_safe') && $request->receiver_safe != null && $request->receiver_safe != '') {
            $transactionsQuery->where('safe_receiver', $request->receiver_safe);
        }
        if ($request->has('type') && $request->type != null && $request->type != '') {
            $transactionsQuery->whereHas('paymentMethods', function ( $query)use ($request) {
                $query->where('type', $request->type);
            });
        }
        if ($request->has('payment_methods_id') && $request->payment_methods_id != null && $request->payment_methods_id != '') {
            $transactionsQuery->where('payment_methods_id', $request->payment_methods_id);
        }
        if ($request->has('status') && $request->status != null && $request->status != '') {
            $transactionsQuery->where('status', $request->status);
        }
        
        
        if ($date_from != null && $date_to != '') {
            $transactionsQuery->whereBetween('created_at', [$date_from, $date_to]);
        }
        $total = $transactionsQuery->sum('amount');
        $transactions = $transactionsQuery->paginate(20);

        return view('safe.accounts_statements', compact('transactions', 'total','safes','branches','methods'));
        
    }

    public function safe_report(Request $request)
    {

        $user = Auth::user();
        
        $branches = $user->branches;
        $payment_methods_colors = ['#a4cb88','#88cb8c','#88cbaa','#88cbc5','#88b6cb','#88a5cb','#8889cb','#b188cb','#cb88c0','#cb889e'];
        
        $payment_methods = PaymentMethod::where('status',1)->get();
        // return $payment_methods;
        $dates = [];
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != ''){
            $daterange = explode(' - ',$request->get('daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $registration_to = date_format(date_create($daterange[1]),'Y-m-d');
            
            $period = new \DatePeriod(
                new \DateTime($registration_from),
                new \DateInterval('P1D'),
                new \DateTime($registration_to)
            );
            
            foreach ($period as $key => $value) {
                $dates[$key]['date'] = $value->format('Y-m-d');
            }
        }
        else{
            $dates[0]['date'] = date('Y-m-d');
        }
        
        foreach($dates as $key => $date){
            $expense_amount = Expense::whereNotNull('branch_id')
                ->whereNotNull('method_id')
                ->where('created_at','like',$date['date'].'%')
                ->groupBy('branch_id')
                ->select('branch_id',DB::raw('sum(amount) as expense_amount'))
                ->pluck('expense_amount','branch_id')->toArray();
                
            $dates[$key]['expense'] = $expense_amount;
            
            $cash_amount = LeadPayment::where('payment_plan_id',2)
                ->whereNotNull('branch_id')
                ->whereNotNull('payment_method_id')
                ->where('created_at','like',$date['date'].'%')
                ->groupBy('branch_id','payment_method_id')
                ->select('branch_id','payment_method_id',DB::raw('sum(amount) as cash_amount'))
                ->get()->groupBy('branch_id');
                
            foreach($cash_amount as $branch_id => $cashAmount){
                $dates[$key]['branches'][$branch_id] = $cashAmount->pluck('cash_amount','payment_method_id')->toArray();
            }
            
            $deptor_amount = SubPayment::leftJoin('lead_payments','lead_payments.id','=','sub_payments.lead_payment_id')
                ->whereIn('lead_payments.payment_plan_id',[1,3])
                ->where('sub_payments.paid',1)
                ->whereNotNull('sub_payments.branch_id')
                ->whereNotNull('sub_payments.payment_method_id')
                ->where('due_date','like',$date['date'].'%')
                ->groupBy('sub_payments.branch_id','sub_payments.payment_method_id')
                ->select('sub_payments.branch_id','sub_payments.payment_method_id',DB::raw('sum(sub_payments.amount) as deptor_amount'))
                ->get()->groupBy('branch_id');
            
            foreach($deptor_amount as $branch_id => $deptorAmount){
                if(isset($dates[$key]['branches'][$branch_id])){
                    $branchDeptorAmount = $deptorAmount->pluck('deptor_amount','payment_method_id')->toArray();
                    foreach($branchDeptorAmount as $pay_method_id => $branch_deptor_amount){
                        if(isset($dates[$key]['branches'][$branch_id][$pay_method_id])){
                            $dates[$key]['branches'][$branch_id][$pay_method_id] += $branch_deptor_amount;
                        }else{
                            $dates[$key]['branches'][$branch_id][$pay_method_id] = $branch_deptor_amount;
                        }
                    }
                }else{
                    $dates[$key]['branches'][$branch_id] = $deptorAmount->pluck('deptor_amount','payment_method_id')->toArray();
                }
            }
            
        }
            
        //dd($cash_amount,$deptor_amount,$dates);  
        //dd($dates);
        return view('safe.safe_report',compact('branches','payment_methods','dates','payment_methods_colors'));
    }
    public function safe_operation_report(Request $request)
    {
        $registration_from=null;
        $reg_to=null;
        $dates=[];
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
             $period = new \DatePeriod(
                new \DateTime($registration_from),
                new \DateInterval('P1D'),
                new \DateTime($registration_to)
            );
            
            foreach ($period as $key => $value) {
                $dates[$key]['date'] = $value->format('Y-m-d');
            }
        }
        else{
            $dates[0]['date'] = date('Y-m-d');
            
        }
         
        // return $dates;
        $branches = Branch::where('status',1)->get();
        
        //  $branch=Branch::find(1);
        // return $branch= $branch->whereHas('leads',function($query){
        //     $query->where('type' , 1)->count();
        // })->find(1);
         $lead = Lead::where('branch_id' ,1)->where('type',1)->get()->count();
         $per = ($lead * 40) /100;
         $cash = $per *1350;
          $count =Employee::where('account_Type', 'Operations Account')
            ->where('status',1)->where('current_branch' ,1)->groupBy('id')->get()->count();
          $target = $cash / $count ;   
            
            
         if ($registration_from != null && $registration_to != '') {
             $safes = Safe::where('status',1)->whereHas('safe_operations',function($quary)use ($registration_from , $registration_to){
                         $quary->whereBetween('created_at', [$registration_from, $registration_to]);
                     })->with('safe_operations');
    
         }else{
             $safes = Safe::where('status',1)->whereHas('safe_operations',function($quary) {
                         $quary->where('created_at','like','%'.date('Y-m-d').'%');
                     })->with('safe_operations');
         
         }
        
        $safes = $safes->get();
        
        // return $safes;
       return view('safe.safe_operation_report',compact('safes','branches'));
    }
}
