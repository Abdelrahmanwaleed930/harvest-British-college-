<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\CreateSurveySectionsRequest;
use App\Http\Requests\UpdateSurveySectionsRequest;

use App\Models\SurveySections;
use Flash;
use Response;
class SurveySectionsController extends Controller
{
    public function index()
    {
        $SurveySections = SurveySections::get();
        
        return view('SurveySections.index',compact('SurveySections'));
    }
    public function create()
    {
        return view('SurveySections.create');
    }
    public function store(CreateSurveySectionsRequest $request)
    {
        $input = $request->all();
        $SurveySection = SurveySections::create($input);
        
        Flash::success('SurveySection saved successfully.');
        return redirect(route('admin.SurveySections.index'));
    }
    public function show($id)
    {
        $SurveySection = SurveySections::find($id);
        if (empty($SurveySection)) {
            Flash::error('Event not found');

            return redirect(route('admin.SurveySections.index'));
        }
        
        return view('SurveySections.show',compact('SurveySection'));
    }
    public function edit($id)
    {
        $SurveySection = SurveySections::find($id);
        if (empty($SurveySection)) {
            Flash::error('SurveySections not found');

            return redirect(route('admin.SurveySections.index'));
        }
        
        return view('SurveySections.edit',compact('SurveySection'));
    }
    public function update(UpdateSurveySectionsRequest $request , $id)
    {
        $SurveySection = SurveySections::find($id);
        $data =  $request->all();
        if (empty($SurveySection)) {
            Flash::error('SurveySection not found');

            return redirect(route('admin.SurveySections.index'));
        }
        $SurveySection->update($data);
        Flash::success('SurveySection updated successfully.');
        return redirect(route('admin.SurveySections.index'));
    }
    public function destroy($id)
    {
        $SurveySection = SurveySections::find($id);
        if (empty($SurveySection)) {
            Flash::error('SurveySection not found');

            return redirect(route('admin.SurveySections.index'));
        }
        $SurveySection->delete();
        
        Flash::success('SurveySections Deleted successfully.');
        return redirect(route('admin.SurveySections.index'));
    }
}
