<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ToDoListJobs;
use App\Models\Department;
use App\Models\Job;
use Flash;
class ToDoListJobsController extends Controller
{
    public function index(Request $request ){
        $ToDoListJobs = ToDoListJobs::with('job','department');
        
        $departments = Department::pluck('title','id');
        $jobs= [];
         if($request->has('department_id') && $request->get('department_id') != null && $request->has('department_id') != ''){
            $ToDoListJobs->where('dept_id', $request->get('department_id'));
        }
         if($request->has('job_id') && $request->get('job_id') != null && $request->has('job_id') != ''){
            $ToDoListJobs->where('job_id', $request->get('job_id'));
        }
        $ToDoListJobs = $ToDoListJobs->paginate(20);
        
        return view('ToDoListJobs.index',compact('ToDoListJobs','departments','jobs'));
    }
    public function show(Request $request , $id){
        $ToDoListJobs = ToDoListJobs::find($id);
        
        return view('ToDoListJobs.show',compact('ToDoListJobs'));
    }
    public function create(Request $request){
        $departments = Department::pluck('title','id');
        $jobs= [];
        
        return view('ToDoListJobs.create',compact('departments' ,'jobs'));
    }
    public function store(Request $request){
        $data = $request->validate([
            'department_id',
            'job_id',
            'type',
            'text',
           
        ]);
        $types = $request->type;
        // dd($types);
        foreach($types as $key=>$type){
            
           $ToDoListJob = new ToDoListJobs;
           $ToDoListJob->dept_id = $request->department_id; 
           $ToDoListJob->job_id = $request->job_id; 
           $ToDoListJob->type = $request->type[$key]; 
           $ToDoListJob->text = $request->text[$key]; 
           $ToDoListJob->time = $request->time[$key]; 
           $ToDoListJob->day = $request->day[$key]; 
           $ToDoListJob->save(); 
        }
        
        Flash::success('ToDoListJobs Create successfully.');
        return redirect(route('admin.ToDoListJobs.index'));
  
    }
    public function edit(Request $request , $id){
        $ToDoListJob = ToDoListJobs::find($id);
        $departments = Department::pluck('title','id');
        $jobs = Job::where('id',$ToDoListJob->job_id)->pluck('title','id');
        
        return view('ToDoListJobs.edit',compact('ToDoListJob','jobs','departments'));
        
    }
    public function update(Request $request ,$id){
        $ToDoListJob = ToDoListJobs::find($id);
        $data = $request->validate([
            'department_id',
            'job_id',
            'type',
            'text',
           
        ]);
        $types = $request->type;
        // dd($types);
    
        $ToDoListJob->dept_id = $request->department_id; 
        $ToDoListJob->job_id = $request->job_id; 
        $ToDoListJob->type = $request->type; 
        $ToDoListJob->text = $request->text; 
        $ToDoListJob->time = $request->time; 
        $ToDoListJob->day = $request->day; 
        $ToDoListJob->save(); 
        
        
        Flash::success('ToDoListJobs Updated successfully.');
        return redirect(route('admin.ToDoListJobs.index'));
        
        
        
    }
    public function destroy($id){
        $ToDoListJob = ToDoListJobs::find($id);
        $ToDoListJob->delete();
        Flash::success(' ToDoListJobs delete  successfully.');
        
        return redirect(route('admin.ToDoListJobs.index'));
    }
}
