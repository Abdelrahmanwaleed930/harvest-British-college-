<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\MonitoringSectionTopic;
use App\Models\MonitoringSections;
use App\Http\Requests\CreateMonitoringSectionTopicRequest;
use App\Http\Requests\UpdateMonitoringSectionTopicRequest;
use Flash;

class MonitoringSectionTopicController extends Controller
{
     public function index(){
        $MonitoringSectionTopic = MonitoringSectionTopic::get();
        
        return view('MonitoringSectionTopic.index',compact('MonitoringSectionTopic')); 
    }
    public function create(){
        $MonitoringSectionTopic = MonitoringSectionTopic::get();
        $monitoringsection = MonitoringSections::pluck('title','id');
        // return $monitoringsection;
        return view('MonitoringSectionTopic.create',compact('MonitoringSectionTopic','monitoringsection')); 
    }
    public function store(CreateMonitoringSectionTopicRequest $request ){
        $data = $request->all();
      
        $MonitoringSectionTopic =  MonitoringSectionTopic::create($data);
       
        Flash::success('Monitor Section Topic created successfully.');
        return redirect()->back(); 
    }
    public function edit($id){
        $MonitoringSectionTopic = MonitoringSectionTopic::find($id);
        $monitoringsection = MonitoringSections::where('id',$MonitoringSectionTopic->monitoring_sections_id)->pluck('title','id');
        
        return view('MonitoringSectionTopic.edit',compact('MonitoringSectionTopic','monitoringsection')); 
    }
    public function update($id , UpdateMonitoringSectionTopicRequest $request){
        $MonitoringSectionTopic = MonitoringSectionTopic::find($id);
        $data = $request->all();
        $MonitoringSectionTopic->update($data);
        Flash::success('Monitor Section updated successfully.');
        return redirect()->back(); 
    }
    
    public function destroy($id){
        $MonitoringSectionTopic = MonitoringSectionTopic::find($id);
        $MonitoringSectionTopic->delete();
        Flash::success('Monitor Section deleted successfully.');
        return redirect()->back(); 
        
    }
}
