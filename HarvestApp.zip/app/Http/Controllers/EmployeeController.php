<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateEmployeeRequest;
use App\Http\Requests\UpdateEmployeeRequest;
use Illuminate\Support\Str;
use App\Models\Employee;
use App\Models\PaymentMethod;
use App\Models\Safe;
use App\Models\SafeTrancation;
use App\Models\Vacation;
use App\Models\VacationHistory;
use App\Repositories\EmployeeRepository;
use App\Http\Controllers\AppBaseController;
use App\Models\Branch;
use App\Models\Place;
use App\Models\Department;
use App\Models\Job;
use App\Models\Lead;
use App\Models\ExecuseModel;
use App\Models\Penalties;
use App\Models\MessageLog;
use App\Models\EmployeeFingers;

use App\Models\Interval;
use App\Models\TODoList;
use App\Models\ToDoListJobs;
use App\Models\Resignation;
use App\Models\TODoListRandom;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Flash;
use Illuminate\Support\Facades\Auth;
use App\Models\WhatsApp;
use App\Models\SMS;
use Carbon\Carbon;
use Response;
use DB;
use File;
use Spatie\Permission\Models\Role;


class EmployeeController extends AppBaseController
{
    /** @var  EmployeeRepository */
    private $employeeRepository;

    public function __construct(EmployeeRepository $employeeRepo)
    {
        $this->employeeRepository = $employeeRepo;
    }
    
    
    public function EmployeesSendmsg(Request $request)
    {
        //dd($request->all());
        if (!$request->message) {
            Flash::error('Message is required.');
        } elseif ($request->ids != null && count($request->ids) > 0) {
            if($request->type == 'sms'){
                $sms = new SMS;
    
                $mobiles = Employee::whereIn('id', $request->ids)->pluck('mobile', 'id')->toArray();
                $msg = $request->message;
    
                $sms->send($mobiles, $msg);
    
                
                $log->leads()->sync(array_keys($mobiles));
            }else{
                $whatsApp = new WhatsApp;

                $mobiles = Employee::whereIn('id', $request->ids)->pluck('mobile', 'id')->toArray();
                $msg = $request->message;
    
                $whatsApp->send($mobiles, $msg);
    
                $log->leads()->sync(array_keys($mobiles));

            }
            
            Flash::success('Sent Successfully.');

        } else {
            Flash::error('Selected Employees is required.');
        }
        return 0;
    }
    
    public function updateSystemData(Request $request)
    {
        $employee = $this->employeeRepository->find($request->employee_id);
        $check_email = Employee::where('id','!=',$employee->id)->where('email',$request->email)->first();
        if($check_email != null && $check_email != ''){
            Flash::error('email registered with another employee');
        }else{
                DB::transaction(function() use ($employee, $request) {
                $employee->update($request->except('_token', 'roles'));
                
                // Make sure roles exist before syncing
                $roles = Role::whereIn('id', (array)$request->roles)->pluck('id')->toArray();
                $employee->syncRoles($roles);
                
                Flash::success('Employee saved successfully.');
            });
        }
        
        return redirect()->route('admin.employees.index');
    }
    
    public function instructorsAttendance($id)
    {
        $employee = $this->employeeRepository->find($id);

        if (empty($employee)) {
            Flash::error('Employee not found');

            return redirect(route('admin.employees.index'));
        }
        
        $days = config('system_variables.timeframes.days');
        $intervals = Interval::where('status',1)->orderBy('sort')->pluck('name','id');
        $instructor_attendance = DB::table('employee_attendance')->select('day','interval_id')->where('employee_id',$employee->id)->get();
        $instructor_attendance = $instructor_attendance->groupBy('day');
        foreach($instructor_attendance as $key => $attendance){
            $instructor_attendance[$key] = $attendance->pluck('interval_id')->toArray();
        }
        $instructor_attendance = $instructor_attendance->toArray();
        //dd($instructor_attendance);
        return view('employees.attendance')->with('employee', $employee)->with('days',$days)->with('intervals',$intervals)->with('instructor_attendance',$instructor_attendance);
    }
    
    public function instructorsPostAttendance(Request $request)
    {
        $days = $request->days;
        $employee = $this->employeeRepository->find($request->employee_id);
        if($days != null && count($days) > 0 && $employee != null){
            DB::table('employee_attendance')->where('employee_id',$employee->id)->delete();
            foreach($days as $day){
                if($request->has('intervals_'.$day)){
                    $day_intervals = $request->get('intervals_'.$day);
                    if($day_intervals != null && $day_intervals != '' && count($day_intervals) > 0){
                        foreach($day_intervals as $day_interval){
                            DB::table('employee_attendance')->insert(['employee_id' => $employee->id,'day' => $day,'interval_id' => $day_interval]);
                        }
                    }
                }
            }
            Flash::success('instructor attendance added successfully.');
        }
        return redirect(route('admin.employees.index'));
    }

    /**
     * Display a listing of the Employee.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $employees = Employee::where(function ($query) use ($request){
                $query->where('first_name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('mobile', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('email', 'like', '%' . $request->get('search') . '%');
            });
        }elseif($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $employees = Employee::whereHas('branches')->where('current_branch' ,$request->get('branches'));
            
        }else{
            $employees = Employee::whereHas('branches')->where('current_branch' ,$request->get('branches'));
        }
        if($request->has('account_Type') && $request->get('account_Type') != null && $request->get('account_Type') != ''){
            $employees->where('account_Type',$request->get('account_Type'));
        }
        
        if($request->has('status') && $request->get('status') != null && $request->get('status') != ''){
            $employees->where('status',$request->get('status'));
        }
        $totalemployees = $employees->count();
        $employees = $employees->paginate($per_page);
        
        
        $roles = Role::pluck('name', 'id');
        
        return view('employees.index')->with('employees', $employees)->with('totalemployees', $totalemployees)->with('roles',$roles)->with('employeeBranches',$employeeBranches);
    }

    /**
     * Show the form for creating a new Employee.
     *
     * @return Response
    */
    public function create()
    {
        $branches = Branch::pluck('name', 'id');
        $places = Place::pluck('name', 'id');
        $departments = Department::pluck('title', 'id');
        $roles = Role::pluck('name', 'id');

        return view('employees.create', compact('branches', 'departments', 'roles','places'));
    }

    /**
     * Store a newly created Employee in storage.
     *
     * @param CreateEmployeeRequest $request
     *
     * @return Response
     */
    public function store(CreateEmployeeRequest $request)
    {

        $input = $request->all();
        if ($request->isforeign == 'Egyptian') {
            $input['nationality'] = 'Egyptian';
            if (strlen($request->national_id) != 14) {
                Flash::error('national id must equal 14');
                return redirect()->back();
            }
        }
        $generate_pass =Str::random(10);
        $input['pass'] = $generate_pass;
     
        
        $input['password'] = $generate_pass;
        $employee = $this->employeeRepository->create($input);
        
        $whatsApp = new WhatsApp;
        $mobiles = [$employee->id => $employee->mobile];
        
        $whatsApp->send($mobiles, $generate_pass);
        // $log->leads()->sync(array_keys($mobiles));  
        
        $employee->branches()->sync(request('branches'));
        $employee->places()->sync(request('places'));
        $employee->syncRoles(request('roles'));
        $employee->current_branch = $request->current_branch; 

        if ($request->has('image') && !is_string($request->image) && $request->image != null) {
            $file   = $request->file('image');
            $fileName = $file->getClientOriginalName();
            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->image = $filePath;
        }

        if ($request->has('academic_certificate_image') && !is_string($request->academic_certificate_image) && $request->academic_certificate_image != null) {
            $file   = $request->file('academic_certificate_image');
            $fileName = $file->getClientOriginalName();
            $fileMime = $file->getClientMimeType();

            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->academic_certificate_image = $filePath;
            $employee->academic_certificate_image_mimeType = $fileMime;
        }
        if ($request->has('birth_certificate_image') && !is_string($request->birth_certificate_image) && $request->birth_certificate_image != null) {
            $file   = $request->file('birth_certificate_image');
            $fileName = $file->getClientOriginalName();
            $fileMime = $file->getClientMimeType();

            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->birth_certificate_image = $filePath;
            $employee->birth_certificate_image_mimeType = $fileMime;
        }
        if ($request->has('passport_image') && !is_string($request->passport_image) && $request->passport_image != null) {
            $file   = $request->file('passport_image');
            $fileName = $file->getClientOriginalName();
            $fileMime = $file->getClientMimeType();

            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->passport_image = $filePath;
            $employee->passport_image_mimeType = $fileMime;
        }
        if ($request->has('number_of_insurance') && !is_string($request->number_of_insurance) && $request->number_of_insurance != null) {
            $file   = $request->file('number_of_insurance');
            $fileName = $file->getClientOriginalName();
            $fileMime = $file->getClientMimeType();

            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->number_of_insurance = $filePath;
            $employee->number_of_insurance_mimeType = $fileMime;
        }
        if ($request->has('criminal_status_image') && !is_string($request->criminal_status_image) && $request->criminal_status_image != null) {
            $file   = $request->file('criminal_status_image');
            $fileName = $file->getClientOriginalName();
            $fileMime = $file->getClientMimeType();

            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->criminal_status_image = $filePath;
            $employee->criminal_status_image_mimeType = $fileMime;
        }
        if ($request->has('labor_office_notice') && !is_string($request->labor_office_notice) && $request->labor_office_notice != null) {
            $file   = $request->file('labor_office_notice');
            $fileName = $file->getClientOriginalName();
            $fileMime = $file->getClientMimeType();

            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->labor_office_notice = $filePath;
            $employee->labor_office_notice_mimeType = $fileMime;
        }
        if ($request->has('educational_certificate_image') && !is_string($request->educational_certificate_image) && $request->educational_certificate_image != null) {
            $file   = $request->file('educational_certificate_image');
            $fileName = $file->getClientOriginalName();
            $fileMime = $file->getClientMimeType();

            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->educational_certificate_image = $filePath;
            $employee->educational_certificate_image_mimeType = $fileMime;
        }
        if ($request->has('military_status_image') && !is_string($request->military_status_image) && $request->military_status_image != null) {
            $file   = $request->file('military_status_image');
            $fileName = $file->getClientOriginalName();
            $fileMime = $file->getClientMimeType();

            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->military_status_image = $filePath;
            $employee->military_status_image_mimeType = $fileMime;
        }
        if ($request->has('social_insurance_stamp') && !is_string($request->social_insurance_stamp) && $request->social_insurance_stamp != null) {
            $file   = $request->file('social_insurance_stamp');
            $fileName = $file->getClientOriginalName();
            $fileMime = $file->getClientMimeType();

            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->social_insurance_stamp = $filePath;
            $employee->social_insurance_stamp_mimeType = $fileMime;
        }
        if ($request->has('cv') && !is_string($request->cv) && $request->cv != null) {
            $file   = $request->file('cv');
            $fileName = $file->getClientOriginalName();
            $fileMime = $file->getClientMimeType();

            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->cv = $filePath;
            $employee->cv_mimeType = $fileMime;
        }
        $employee->save();
        $date =Carbon::now()->format('Y');
        $newVacation = Vacation::create([
                'employee_id'=>$employee->id,
                'annual'=>21,
                'casual'=>7,
                'sick'=>7,
                'year'=>$date,
                ]);
        $fingers = $request->employee_finger_id;
        foreach($fingers as $key=>$finger)
        {
            $EmployeeFingers = new EmployeeFingers;
            $EmployeeFingers->employee_finger_id = $request->employee_finger_id[$key];
            $EmployeeFingers->branch_finger_id = $request->branch_finger_id[$key];
            $EmployeeFingers->employee_id = $employee->id;
            $EmployeeFingers->save();
            
        }
              

        Flash::success('Employee saved successfully.');
        if($employee->account_Type == 'ESL Account Profile'){
            return redirect(route('admin.instructors.attendance',$employee->id));
        }else{
            return redirect(route('admin.employees.index'));
        }
        
    }

    /**
     * Display the specified Employee.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $employee = $this->employeeRepository->find($id);

        if (empty($employee)) {
            Flash::error('Employee not found');

            return redirect(route('admin.employees.index'));
        }

        return view('employees.show')->with('employee', $employee);
    }

    /**
     * Show the form for editing the specified Employee.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        //dd('ddd');
        $employee = $this->employeeRepository->find($id);

        if (empty($employee)) {
            Flash::error('Employee not found');

            return redirect(route('admin.employees.index'));
        }
        $branches = Branch::pluck('name', 'id');
        $places = Place::pluck('name', 'id');
        $departments = Department::pluck('title', 'id');
        $roles = Role::pluck('name', 'id');
        
        $EmployeeFingers = EmployeeFingers::where('employee_id',$employee->id)->get();

        return view('employees.edit', compact('employee', 'branches', 'departments', 'roles','places','EmployeeFingers'));
    }

    /**
     * Update the specified Employee in storage.
     *
     * @param int $id
     * @param UpdateEmployeeRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateEmployeeRequest $request)
    {
        $employee = $this->employeeRepository->find($id);

        if (empty($employee)) {
            Flash::error('Employee not found');

            return redirect(route('admin.employees.index'));
        }

        if ($request->isforeign == 'Egyptian') {
            $input['nationality'] = 'Egyptian';
            if (strlen($request->national_id) != 14) {
                Flash::error('national id must equal 14');
                return redirect()->back();
            }
            $request->nationality = 'Egyptian';
        }
        if ($request->hiring_date == null) {
            $request->hiring_date = $employee->hiring_date;
        }
        if ($request->gradute_year == null) {
            $request->gradute_year = $employee->gradute_year;
        }
        if ($request->birth_date == null) {
            $request->birth_date = $employee->birth_date;
        }
        $employee = $this->employeeRepository->update($request->all(), $id);

        $employee->branches()->sync(request('branches'));
        $employee->places()->sync(request('places'));
        //$employee->syncRoles(request('roles'));
        $employee->current_branch = $request->current_branch; 

        $employee->nationality = $request->nationality;
        if ($request->has('image') && !is_string($request->image) && $request->image != null) {
            $file   = $request->file('image');
            $fileName = $file->getClientOriginalName();
            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->image = $filePath;
        }



        if ($request->has('academic_certificate_image') && !is_string($request->academic_certificate_image) && $request->academic_certificate_image != null) {
            $file   = $request->file('academic_certificate_image');
            $fileName = $file->getClientOriginalName();
            $fileMime = $file->getClientMimeType();

            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->academic_certificate_image = $filePath;
            $employee->academic_certificate_image_mimeType = $fileMime;
        }
        if ($request->has('birth_certificate_image') && !is_string($request->birth_certificate_image) && $request->birth_certificate_image != null) {
            $file   = $request->file('birth_certificate_image');
            $fileName = $file->getClientOriginalName();
            $fileMime = $file->getClientMimeType();

            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->birth_certificate_image = $filePath;
            $employee->birth_certificate_image_mimeType = $fileMime;
        }
        if ($request->has('passport_image') && !is_string($request->passport_image) && $request->passport_image != null) {
            $file   = $request->file('passport_image');
            $fileName = $file->getClientOriginalName();
            $fileMime = $file->getClientMimeType();

            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->passport_image = $filePath;
            $employee->passport_image_mimeType = $fileMime;
        }
        if ($request->has('number_of_insurance') && !is_string($request->number_of_insurance) && $request->number_of_insurance != null) {
            $file   = $request->file('number_of_insurance');
            $fileName = $file->getClientOriginalName();
            $fileMime = $file->getClientMimeType();

            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->number_of_insurance = $filePath;
            $employee->number_of_insurance_mimeType = $fileMime;
        }
        if ($request->has('criminal_status_image') && !is_string($request->criminal_status_image) && $request->criminal_status_image != null) {
            $file   = $request->file('criminal_status_image');
            $fileName = $file->getClientOriginalName();
            $fileMime = $file->getClientMimeType();

            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->criminal_status_image = $filePath;
            $employee->criminal_status_image_mimeType = $fileMime;
        }
        if ($request->has('labor_office_notice') && !is_string($request->labor_office_notice) && $request->labor_office_notice != null) {
            $file   = $request->file('labor_office_notice');
            $fileName = $file->getClientOriginalName();
            $fileMime = $file->getClientMimeType();

            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->labor_office_notice = $filePath;
            $employee->labor_office_notice_mimeType = $fileMime;
        }
        if ($request->has('educational_certificate_image') && !is_string($request->educational_certificate_image) && $request->educational_certificate_image != null) {
            $file   = $request->file('educational_certificate_image');
            $fileName = $file->getClientOriginalName();
            $fileMime = $file->getClientMimeType();

            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->educational_certificate_image = $filePath;
            $employee->educational_certificate_image_mimeType = $fileMime;
        }
        if ($request->has('military_status_image') && !is_string($request->military_status_image) && $request->military_status_image != null) {
            $file   = $request->file('military_status_image');
            $fileName = $file->getClientOriginalName();
            $fileMime = $file->getClientMimeType();

            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->military_status_image = $filePath;
            $employee->military_status_image_mimeType = $fileMime;
        }
        if ($request->has('social_insurance_stamp') && !is_string($request->social_insurance_stamp) && $request->social_insurance_stamp != null) {
            $file   = $request->file('social_insurance_stamp');
            $fileName = $file->getClientOriginalName();
            $fileMime = $file->getClientMimeType();

            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->social_insurance_stamp = $filePath;
            $employee->social_insurance_stamp_mimeType = $fileMime;
        }
        if ($request->has('cv') && !is_string($request->cv) && $request->cv != null) {
            $file   = $request->file('cv');
            $fileName = $file->getClientOriginalName();
            $fileMime = $file->getClientMimeType();

            $new_name = rand() . $fileName;
            $filePath = 'profile/' . $new_name;
            $file->move('profile/', $new_name);
            $employee->cv = $filePath;
            $employee->cv_mimeType = $fileMime;
        }


        $employee->save();
        
        $fingers = $request->employee_finger_id;
        $fingers_count = count($fingers);
        if($fingers_count >= 1){
            EmployeeFingers::where('employee_id',$employee->id)->delete();
            foreach($fingers as $key=>$finger)
            {
                $EmployeeFingers = new EmployeeFingers;
                $EmployeeFingers->branch_finger_id = $request->branch_finger_id[$key];
                $EmployeeFingers->employee_finger_id = $request->employee_finger_id[$key];
                $EmployeeFingers->employee_id = $employee->id;
                $EmployeeFingers->save();
                
            }
        }
        
        Flash::success('Employee updated successfully.');

        return redirect(route('admin.employees.index'));
    }

    /**
     * Remove the specified Employee from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        $employee = $this->employeeRepository->find($id);

        if (empty($employee)) {
            Flash::error('Employee not found');

            return redirect(route('admin.employees.index'));
        }

        $this->employeeRepository->delete($id);

        Flash::success('Employee deleted successfully.');

        return redirect(route('admin.employees.index'));
    }

    /**
     * Get Jobs depending on department id.
     *
     * @return void
     */
    public function getJobs()
    {
        if (request()->filled('department_id')) {
            $jobs = Job::where('department_id', request('department_id'))->get();

            return $jobs;
        }
    }
     public function getDayInRange($dateFromString, $dateToString,$day)
    {
        $dateFrom = new \DateTime($dateFromString);
        $dateTo = new \DateTime($dateToString);
        $dates = [];
        $dayNum = date_format(date_create($day),'N');
        if ($dateFrom > $dateTo) {
            return $dates;
        }
        
        if ($dayNum != $dateFrom->format('N')) {
            $dateFrom->modify(('next '.$day));
        }
    
        while ($dateFrom <= $dateTo) {
            $dates[] = $dateFrom->format('Y-m-d');
            $dateFrom->modify('+1 week');
        }
    
        return $dates;
    }

    public function getProfile()
    {
        $employee = Auth::user();
        $branches = Branch::pluck('name','id')->toArray();

        //        dd($employee->safe()->first());
        $transferPaymentMethods = PaymentMethod::where('status', 1)->where('transfer', 1)->get();
        $depositPaymentMethods = PaymentMethod::where('status', 1)->where('deposit', 1)->get();

        $normalSafe = Safe::where('status',1)->where('employee_id', $employee->id)->where('is_manager',0)->first();
        if ($normalSafe) {
            $allSafes = Safe::where('status',1)
                        ->whereHas('employee',function($query){
                            $query->where('status',1);
                        })
                        ->where('is_manager', 1)->where('branch_id', $normalSafe->branch_id)->get();
            //dd($allSafes);
            $sefeHistories = SafeTrancation::where(function ($query) use ($normalSafe) {
                $query->where('safe_sender', '=', $normalSafe->id)
                    ->orWhere('safe_receiver', '=', $normalSafe->id);
            })->orderBy('id', 'DESC')->get();
        } else {
            $allSafes = null;
            $sefeHistories = null;
        }
        
        $branchSafe = Safe::where('status',1)->where('employee_id', $employee->id)->where('is_manager', 1)->first();

        if ($branchSafe) {
            $allBranchesSafes = Safe::where('status',1)->where('branch_id', '!=', $branchSafe->branch_id)->where('is_hq', 1)->where('is_manager', 1)->get();
            $branchSefeHistories = SafeTrancation::where(function ($query) use ($branchSafe) {
                $query->where('safe_sender', '=', $branchSafe->id)
                    ->orWhere('safe_receiver', '=', $branchSafe->id);
            })->orderBy('id', 'DESC')->get();
        } else {
            $allBranchesSafes = null;
            $branchSefeHistories = null;
        }

         $excuses = ExecuseModel::where('employee_id' ,$employee->id)->get();
        
        $employeeVacation = Vacation::where('employee_id', $employee->id)->orderBy('id', 'DESC')->get();
        $employeeVacationHistory = VacationHistory::where('employee_id', $employee->id)->orderBy('id', 'DESC')->get();
        $todolist = TODoList::with('job','TODoListRandom','employee','created_by','department')
                              ->where('employee_id',$employee->id)->first();
        $Penalties = Penalties::where('employee_id',$employee->id)->get();  
        
        $Resignations = Resignation::where('employee_id' , $employee->id)->get();
        $static_tasks = [];
      /*  $static_tasks = ToDoListJobs::where('job_id',$employee->job_id)->select('type','text','time','day')
        ->orderByRaw('LENGTH(type)', 'asc')->orderBy('type', 'ASC')->get();
        */
        $eloquentEvents = TODoListRandom::where('employee_id',$employee->id)->get(); //EventModel implements LaravelFullcalendar\Event
        $events=[];
        $dateFromString = date('Y-m-01');
        $dateToString = date('Y-m-t');
        
       
        foreach($static_tasks as $task){
            if($task->type == 'Weekly')
            {
                $tks= $this->getDayInRange($dateFromString, $dateToString,$task->day);
                foreach($tks as $tk)
                {
                    $events[] = [
                        'title' => $task->text. ' '.$task->type,
                        'start' => $tk,
                        'end' => $tk,
                    ];
                }
            }
            if($task->type == 'Monthly')
            {
                
                    $events[] = [
                        'title' => $task->text. ' '.$task->type,
                        'start' => $dateToString,
                        'end' => $dateToString,
                    ];
        
            }
            
            
             
        }
        //dd($this->getDayInRange($dateFromString, $dateToString,'sunday'));
       

 
        foreach ($eloquentEvents as $event) {
        
            $events[] = [
                'title' => $event->name,
                'start' => $event->start_date,
                'end' => $event->end_date,
            ];
        }

       

        return view('employees.profile', compact('employee','Resignations','events','Penalties','static_tasks','todolist','excuses','branches', 'employeeVacation', 'employeeVacationHistory', 'allSafes', 'transferPaymentMethods', 'depositPaymentMethods', 'sefeHistories', 'allBranchesSafes', 'branchSefeHistories'));
    }
    
    public function resetPassword(Request $request)
    {
        $employee = Employee::find($request->empid);
        $generate_pass =Str::random(10);
        $employee->update([
            'password' => $generate_pass,
            'pass'=>$generate_pass,
        ]);
        $whatsApp = new WhatsApp;
        $mobiles = [$employee->id => $employee->mobile];
        $msg = 'Your Password is '.$generate_pass;
        $whatsApp->send($mobiles, $msg);
        // $log->leads()->sync(array_keys($mobiles));
            
        
        return response()->json(['message' => 'Password reset successfully ']);
    }
    
    public function updateStatus(Request $request)
    {
        $employee = Employee::find($request->id);
        $message = '';
        $safes = Safe::where('employee_id',$employee->id)->where('status',1)->where('balance','>',0)->get();
        //$leads = Lead::where('assigned_employee_id',$employee->id)->get();
        //dd(count($leads));
        if($safes != null && count($safes) > 0){
            //$message .= ($leads != null && count($leads) > 0)?'This employee has data assigned to him. Please withdraw this data first.':'';
            $message .= ($safes != null && count($safes) > 0)?'This employee has safe assigned to him. Please withdraw this safe first.':'';
        }else{
            $employee->status = ! $employee->status;
            $employee->save();
            
            Lead::where('assigned_employee_id',$employee->id)->update(['assigned_employee_id' => null]);
        }
        return response()->json(['employee_status' => $employee->status,'message' => $message]);
    }

    public function updateProfile(Request $request, $id)
    {
        $validator = $request->validate(
            [
                'phone' => 'required',
                'address' => 'required',
                'emergency_name' => 'required',
                'emergency_relation' => 'required',
                'emergency_phone' => 'required',
                'image'=>'nullable|image',

            ]
        );

        $employee = Employee::find($id);
        $employee->phone = $request->phone;
        $employee->address = $request->address;
        $employee->emergency_name = $request->emergency_name;
        $employee->emergency_relation = $request->emergency_relation;
        $employee->emergency_phone = $request->emergency_phone;
        
        if($request->hasFile('image')){
            $file = $request->file('image');
            
            $file_name = rand(11111,99999).'-'.$file->getClientOriginalName();
            $file->storeAs('/uploads/profile_picture', $file_name);
            $employee->image = $file_name;
            
            File::move(storage_path('app/uploads/profile_picture/'.$file_name), '/home/harvestc/public_html/testsys/uploads/profile_picture/'.$file_name);
        }
        $employee->save();
        return redirect()->back();
    }

    public function updatePassword(Request $request, $id)
    {
        $validator = $request->validate(
            [
                'password' => 'required|confirmed'
            ]
        );
        //        $pass=bcrypt($request->password);
        $pass = $request->password;
        $employee = Employee::find($id);
        $employee->password = $pass;
        $employee->save();
        return redirect()->back();
    }


    public function downloadFile($id, $fileName, $fileMime)
    {
        $employee = Employee::find($id);
        $name = '/' . $employee[$fileName];
        $namArrey = explode(".", $name);
        $mime = $employee[$fileMime];
        //        $filePath = public_path().$name;
        $filePath = "/home/harvestc/public_html/testsys" . $name;

        $headers = array(
            'Content-Type: ' . $mime,
        );
        return \Illuminate\Support\Facades\Response::download($filePath, $fileName . '.' . $namArrey[count($namArrey) - 1], $headers);
    }


    public function requestVacation(Request $request, $id)
    {
        $validator = $request->validate(
            [
                'startdate' => 'required',
                'enddate' => 'required|after_or_equal:startdate',
                'type' => 'required'
            ]
        );
        $startdateArrey = explode("-", $request->startdate);

        $vacation = Vacation::where('year', $startdateArrey[0])->where('employee_id', $id)->first();
        $start = strtotime($request->startdate);
        // dd($start);
        $end = strtotime($request->enddate);
        $datediff = $end - $start;
        
        $type = $request->type;
        $days = round($datediff / (60 * 60 * 24));
        $days = $days + 1;
        // if (!$vacation || $days > $vacation[$request->type]) {
        //     Flash::error('you not have vacation in this year');
        //     return redirect()->back();
        // }
    //   return  $count = VacationHistory::where('employee_id',$id)->with(['vacation' => function ($query) use ($startdateArrey) {
    //     $query->where('year',  $startdateArrey[0]);
    //      }])->where('status','refuse')->get();
        $number = VacationHistory::select('type',DB::raw ('sum(days) as day_count'))
        ->where('employee_id',$id)->where('status','approve')->with(['vacation' => function ($query) use ($startdateArrey) {
        $query->where('year',  $startdateArrey[0]);
         }])->groupBy('type')->pluck('day_count','type');
         
       
        if($type == 'annual'){
          
           if(isset($number['annual'])){
               
                if ($vacation->annual < ($number['annual'] +$days)) {
                Flash::error('you have no annual vacation in this year');
                }
                else{
                    $newVacationHistory = new VacationHistory();
                    $newVacationHistory->employee_id = $id;
                    $newVacationHistory->vacations_id = $vacation->id;
                    $newVacationHistory->type = $request->type;
                    $newVacationHistory->start = $request->startdate;
                    $newVacationHistory->end = $request->enddate;
                    $newVacationHistory->days = $days;
                    $newVacationHistory->confirmed_by_id = auth()->user()->id;
                    $newVacationHistory->department_id = auth()->user()->department_id;
                    $newVacationHistory->save();
                    Flash::success('your vacation requested successfully.');
                }
           }
           else{
                    $newVacationHistory = new VacationHistory();
                    $newVacationHistory->employee_id = $id;
                    $newVacationHistory->vacations_id = $vacation->id;
                    $newVacationHistory->type = $request->type;
                    $newVacationHistory->start = $request->startdate;
                    $newVacationHistory->end = $request->enddate;
                    $newVacationHistory->days = $days;
                    $newVacationHistory->confirmed_by_id = auth()->user()->id;
                    $newVacationHistory->department_id = auth()->user()->department_id;
                    $newVacationHistory->save();
                    Flash::success('your vacation requested successfully.');
           }
       
       }elseif($type == 'casual'){
        if(isset($number['casual'])){
                if ($vacation->casual < ($number['casual'] +$days)) {
                Flash::error('you have no casual vacation in this year');
                }
                else{
                    $newVacationHistory = new VacationHistory();
                    $newVacationHistory->employee_id = $id;
                    $newVacationHistory->vacations_id = $vacation->id;
                    $newVacationHistory->type = $request->type;
                    $newVacationHistory->start = $request->startdate;
                    $newVacationHistory->end = $request->enddate;
                    $newVacationHistory->days = $days;
                    $newVacationHistory->confirmed_by_id = auth()->user()->id;
                    $newVacationHistory->department_id = auth()->user()->department_id;
                    $newVacationHistory->save();
                    Flash::success('your vacation requested successfully.');
                }
           }
           else{
                    $newVacationHistory = new VacationHistory();
                    $newVacationHistory->employee_id = $id;
                    $newVacationHistory->vacations_id = $vacation->id;
                    $newVacationHistory->type = $request->type;
                    $newVacationHistory->start = $request->startdate;
                    $newVacationHistory->end = $request->enddate;
                    $newVacationHistory->days = $days;
                    $newVacationHistory->confirmed_by_id = auth()->user()->id;
                    $newVacationHistory->department_id = auth()->user()->department_id;
                    $newVacationHistory->save();
                    Flash::success('your vacation requested successfully.');
           }
       }elseif($type == 'sick'){
        if(isset($number['sick'])){
                if ($vacation->sick < ($number['sick'] +$days)) {
                Flash::error('you have no sick vacation in this year');
                }
                else{
                    $newVacationHistory = new VacationHistory();
                    $newVacationHistory->employee_id = $id;
                    $newVacationHistory->vacations_id = $vacation->id;
                    $newVacationHistory->type = $request->type;
                    $newVacationHistory->start = $request->startdate;
                    $newVacationHistory->end = $request->enddate;
                    $newVacationHistory->days = $days;
                    $newVacationHistory->confirmed_by_id = auth()->user()->id;
                    $newVacationHistory->department_id = auth()->user()->department_id;
                    $newVacationHistory->save();
                    Flash::success('your vacation requested successfully.');
                }
           }
           else{
                    $newVacationHistory = new VacationHistory();
                    $newVacationHistory->employee_id = $id;
                    $newVacationHistory->vacations_id = $vacation->id;
                    $newVacationHistory->type = $request->type;
                    $newVacationHistory->start = $request->startdate;
                    $newVacationHistory->end = $request->enddate;
                    $newVacationHistory->days = $days;
                    $newVacationHistory->confirmed_by_id = auth()->user()->id;
                    $newVacationHistory->department_id = auth()->user()->department_id;
                    $newVacationHistory->save();
                    Flash::success('your vacation requested successfully.');
           }
       }
    
        return redirect()->back();
    }
        
}
