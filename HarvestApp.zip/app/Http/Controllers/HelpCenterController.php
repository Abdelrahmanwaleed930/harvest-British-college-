<?php
namespace App\Http\Controllers;

use App\Models\HelpCenter;
use App\Models\Department;

use Illuminate\Http\Request;

class HelpCenterController extends Controller
{
    public function index()
    {
            $helpCenters = HelpCenter::with('parent')->get();

        return view('help_centers.index', compact('helpCenters'));
    }

 public function view()
{
    // Get all help centers and categories with their children
    $helpCenters = HelpCenter::all(); // Retrieve all help centers
    $categories = HelpCenter::whereNull('parent_id')->with('children')->get(); // Get top-level categories with children

    // Pass both categories and helpCenters to the view
    return view('help_centers.view', compact('helpCenters', 'categories'));
}

public function create()
{
    // Retrieve all help centers for the parent dropdown, if needed
    $helpCenters = HelpCenter::all();

    // Return the view with help centers for the dropdown and any other needed data
    return view('help_centers.create', compact('helpCenters'));
}


    public function store(Request $request)
{
    $request->validate([
        'title' => 'required|string|max:255',
        'video_url' => 'nullable|url',
        'description' => 'nullable',
        'parent_id' => 'nullable|exists:help_center,id', // Update to help_center
    ]);

    HelpCenter::create($request->all());

    return redirect()->route('admin.help_centers.index');
}


    public function show(HelpCenter $helpCenter)
    {
        return view('help_centers.show', compact('helpCenter'));
    }

     public function edit(HelpCenter $helpCenter)
    {
        // Retrieve all departments for the parent dropdown
            $helpCenters = HelpCenter::all();
        return view('help_centers.edit', compact('helpCenter', 'helpCenters'));
    }

    public function update(Request $request, HelpCenter $helpCenter)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'video_url' => 'nullable|url',
            'description' => 'nullable',
            'parent_id' => 'nullable|exists:departments,id', // Validate against departments table
        ]);

        $helpCenter->update($request->all());

        return redirect()->route('admin.help_centers.index');
    }


    public function destroy(HelpCenter $helpCenter)
    {
        $helpCenter->delete();

        return redirect()->route('admin.help_centers.index');
    }
}