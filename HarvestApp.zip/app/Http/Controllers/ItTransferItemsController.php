<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ItTransferItems;
use App\Models\Branch;
use App\Models\ITItemCategory;
use App\Models\ItCurrentItems;
use App\Models\ITItem;
use App\Models\Employee;
use Flash;
use Auth;

class ItTransferItemsController extends Controller
{
     public function index(Request $request){
        $ItTransferItems = ItTransferItems::with('ititemCategory','ititem','from_branch','to_branch','created_by')->get();
        
        return view('ItTransferItems.index',compact('ItTransferItems'));
    }
    public function show($id){
        $ItTransferItems = ItTransferItems::find($id);
        
        return view('ItTransferItems.show',compact('ItTransferItems'));
    }
    public function create(Request $request){
    
        $branches = Branch::pluck('name','id');
        $ititemcategories =ITItemCategory::pluck('name','id');
        $ititem =[];
       
        
        
        return view('ItTransferItems.create',compact('branches','ititemcategories','ititem'));
        
    }
    public function store(Request $request){
        
        $data = $request->validate([
            'from_branch_id' => 'required',
            'to_branch_id' => 'required',
            'it_items_categories_id' => 'required',
            'it_item_id' => 'required',
            
            'item_count' => 'required',
            'details' => 'required',
            'notes' => 'required',
            ]);
            $check_from_items = ItCurrentItems::where('it_items_categories_id',$request->it_items_categories_id)
                                      ->where('it_item_id',$request->it_item_id)
                                      ->where('branch_id',$request->from_branch_id)
                                      ->where('balance','>',0)->first();
        
        if($check_from_items != null || $check_from_items != '') {
            if($check_from_items->balance >= $request->item_count){
                
                $check_from_items->balance -= $request->item_count;
                $check_from_items->save();
                
                $balance_from = $check_from_items->balance;
                
                
                 $check_to_items = ItCurrentItems::where('it_items_categories_id',$request->it_items_categories_id)
                                      ->where('it_item_id',$request->it_item_id)
                                      ->where('balance',$request->balance_to)->first();
                if($check_to_items != null && $check_to_items != ''){
                    $check_to_items->balance += $request->item_count;
                    $check_to_items->save();
                    
                    $balance_to = $check_to_items->balance;
                    
                    
                }else{
                    ItCurrentItems::create([
                        'it_items_categories_id' => $request->it_items_categories_id,
                        'it_item_id' => $request->it_item_id,
                        'branch_id' => $request->to_branch_id,
                        'balance' => $request->item_count,
                        'created_by_id' => auth()->user()->id
                    ]);
                    $balance_to = $request->item_count;
                    
                    
                }      
                
                $ItTransferItems = new ItTransferItems;    
                $ItTransferItems->from_branch_id = $request->from_branch_id;    
                $ItTransferItems->to_branch_id = $request->to_branch_id;    
                $ItTransferItems->it_items_categories_id = $request->it_items_categories_id;    
                $ItTransferItems->it_item_id = $request->it_item_id;    
                $ItTransferItems->balance_from = $balance_from;    
                $ItTransferItems->balance_to = $balance_to;    
                $ItTransferItems->item_count = $request->item_count;    
                $ItTransferItems->details = $request->details;    
                $ItTransferItems->notes = $request->notes;    
                $ItTransferItems->created_by_id =auth()->user()->id;    
                $ItTransferItems->save();  
                 Flash::success('It Transfer Items Added successfully.');
            }
            else{
                Flash::error('Count more than current balance, expected less than '.$check_from_items->balance.'.');
            }
        }else{
            Flash::error('It Warehouse Item not fount in current Items.');
        }
            
        
        
           
        

        return redirect(route('admin.ItTransferItems.index'));
            
        
    }
    public function edit($id ,Request $request){
        $ItTransferItems = ItTransferItems::find($id);
        $branches = Branch::pluck('name','id');
        $ititemcategories =ITItemCategory::pluck('name','id');
        $ititem =ItItem::find($ItTransferItems->it_item_id)->pluck('name','id');
       
        return $ItTransferItems->created_by->first_name;
        return view('ItTransferItems.edit',compact('branches','ItTransferItems','ititemcategories','ititem'));
    }
    public function update($id ,Request $request){
        
        $data = $request->validate([
            'from_branch_id' => 'required',
            'to_branch_id' => 'required',
            'it_items_categories_id' => 'required',
            'it_item_id' => 'required',
           
            'item_count' => 'required',
            'details' => 'required',
            'notes' => 'required',
            ]);
            
           
        $ItTransferItems = ItTransferItems::find($id);
        
        $ItTransferItems->from_branch_id = $request->from_branch_id;    
        $ItTransferItems->to_branch_id = $request->to_branch_id;    
        $ItTransferItems->it_items_categories_id = $request->it_items_categories_id;    
        $ItTransferItems->it_item_id = $request->it_item_id;    
        $ItTransferItems->balance_from = $request->balance_from;    
        $ItTransferItems->balance_to = $request->balance_to;    
        $ItTransferItems->item_count = $request->item_count;    
        $ItTransferItems->details = $request->details;    
        $ItTransferItems->notes = $request->notes;   
        $ItTransferItems->save();
        
        Flash::success('It Expendable Items Updated successfully.');

        return redirect(route('admin.ItTransferItems.index'));
        
        
    }
    public function destroy($id){
        $ItTransferItems = ItTransferItems::find($id);
        $ItTransferItems->delete();
            
        return redirect(route('admin.ItTransferItems.index'));    
        
    }
    
    
}
