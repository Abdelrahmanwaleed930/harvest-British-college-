<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\CreateSurvayRequest;
use App\Http\Requests\UpdateSurvayRequest;

use App\Models\Employee;
use App\Models\Branch;
use App\Models\Lead;
use App\Models\Track;
use App\Models\Stage;
use App\Models\StageLevel;
use App\Models\Interval;
use App\Models\Timeframe;
use App\Models\Survey;
use App\Models\SurveySectionsStudent;
use App\Models\SurveySectionTopicAnswer;
use App\Models\SurveySections;
use App\Models\SurveySectionsTopic;
use Flash;
use DB;
class SurveyController extends Controller
{
    public function index(Request $request){
        $Survey = Survey::with('course','lead','branch','instructor','interval','level');
        $SurveyCount = $Survey->count();
        $Surveys = $Survey->paginate(20);
        return view('Survey.index',compact('Surveys','SurveyCount')); 
    }
    
    public function create()
    {
        $lead = Lead::find(588540);
        $SurveySections = SurveySections::where('type',$lead->type)->get();
        $branches = Branch::where('status',1)->pluck('name','id');
        $sub_tracks = Track::whereNotNull('parent_id')->groupBy('parent_id')->pluck('title','id');
        $levels = StageLevel::pluck('name','id');
        
        $instructors = Employee::where('status',1)->where('account_Type', 'ESL Account Profile')
            ->select('id','first_name','middle_name','last_name')->get()->pluck('name','id');
        $intervals = Interval::join('interval_timeframe','intervals.id','=','interval_timeframe.interval_id')->where('intervals.status',1)->orderBy('intervals.sort')->pluck('intervals.name','intervals.id');
        
        $timeframes = Timeframe::join('timeframe_courses','timeframe_courses.timeframe_id','=','timeframes.id')
            ->where('timeframes.status',1)->pluck('timeframes.title','timeframes.id');
        $daysData = Timeframe::whereNotIn('id',['3','6'])->pluck('days','id'); 
        
        // dd($daysData);
        //  dd(config('system_variables.timeframes.days')[]);
        //dd($sub_tracks,$levels,$instructors,$intervals,$daysData);
        return view('Survey.create',compact('SurveySections','lead','intervals','instructors','levels','sub_tracks','branches','daysData')); 
    }
    
    public function store(CreateSurvayRequest $request){
        $data = $request->all();
        // return $data;
        $data['student_id']=10;
        $Survey = Survey::create($data);
        $lead = Lead::find(588540);
        
        foreach($request->survey_sections_topic_id as $key => $topic){
            
            $SurveySectionsStudent = new SurveySectionsStudent;
            $SurveySectionsStudent->survey_sections_id = $request->survey_sections_id[$topic];
            $SurveySectionsStudent->survey_sections_topic_id = $topic;
            $SurveySectionsStudent->survey_section_topic_answer_id =$request->survey_section_topic_answer_id[$topic];
            $SurveySectionsStudent->survey_id = $Survey->id;
            $SurveySectionsStudent->comment = $request->comment[$topic];       
            $SurveySectionsStudent->save();
            
            
        }
        
        Flash::success(' Survey Create successfully.');
        
         return redirect()->back();
    }
    public function edit($id){
        
        $Survey = Survey::find($id);
        $SurveySections = SurveySections::where('type',$Survey->hr_type)->get();
        
        return view('Survey.edit',compact('Survey','SurveySections')); 

    }
    public function update($id,UpdateSurvayRequest $request){
      
        $Survey =Survey::find($id);
        $data = $request->all();
        dd($data);
        $Survey->update($data); 
     
        if($request->survey_sections_topic_id != null && count($request->survey_sections_topic_id) > 0)
        {
             SurveySectionsStudent::where('survey_id',$Survey->id)->delete();
            
            foreach($request->survey_sections_topic_id as $key => $topic){
                $SurveySectionsStudent = new SurveySectionsStudent;
                $SurveySectionsStudent->survey_sections_id   = $request->survey_sections_id[$topic];
                $SurveySectionsStudent->survey_sections_topic_id = $topic;
                $SurveySectionsStudent->survey_id = $Survey->id;
                $SurveySectionsStudent->score = $request->score[$topic];
                $SurveySectionsStudent->comment = $request->comment[$topic];          
                $SurveySectionsStudent->save();
            }
        }
      
        
        
        
        Flash::success('Survey  updated successfully.');
         return redirect(route('admin.Survey.index'));
        
       
    }
    public function show($id){
        $Survey = Survey::find($id); 
        $SurveySectionsStudent =  SurveySectionsStudent::where('survey_id',$Survey->id)->get();
        $SurveySections = SurveySections::get();
        return view('Survey.show',compact('Survey','SurveySections','SurveySectionsStudent')); 
        
    }
    public function destroy($id){
        $Survey = Survey::find($id);
        $Survey->delete();
        Flash::success(' Survey delete  successfully.');
        
        return redirect(route('admin.Survey.index'));
    }
}
