<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\EmployeeAttendances;
use App\Models\EmployeeFingerPrint;
use App\Models\Employee;

use Flash;
use Response;
use Carbon\Carbon;
use DB;
use Auth;
use App\Imports\Finger;
use Maatwebsite\Excel\Facades\Excel;
use Spatie\Activitylog\Contracts\Activity;


class EmployeeFingerPrintController extends Controller
{
    public function index(Request $request){
        $Employees = Employee::where('status',1)->get()->pluck('name','id');
        
        $registration_from = null;
        $registration_to = null;
        $today = date('Y-m-d');
         $firstDayOfMonth = date('Y-m-01');
        $lastDayOfMonth = date('Y-m-t');
    
        if ($request->has('register_daterange') && $request->get('register_daterange') != null && $request->get('register_daterange') != '') {
            $daterange = explode(' - ', $request->get('register_daterange'));
            $registration_from = date_format(date_create($daterange[0]), 'Y-m-d');
            $reg_to = date_create($daterange[1]);
            date_add($reg_to, date_interval_create_from_date_string("1 days"));
            $registration_to = date_format($reg_to, "Y-m-d");
        }
        // return $registration_from;
        $EmployeeFingerPrint = EmployeeFingerPrint::with('employee');
        if ($registration_from != null && $registration_to != '') {
            
            // $EmployeeAttendance->whereBetween('date', [$registration_from, $registration_to])->get();
            $EmployeeFingerPrint->whereBetween('date',[$registration_from , $registration_to]);
        }
        if($request->has('employee_id') && $request->get('employee_id') != null && $request->get('employee_id') != ''){
            $EmployeeFingerPrint->where('employee_id',$request->get('employee_id'));
        }
        $EmployeeFingerPrints = $EmployeeFingerPrint->paginate(10);
        
        return view('EmployeeFingerPrint.index',compact('EmployeeFingerPrints','Employees'));
        
    }
    
    public function ReportFingerPrint(Request $request){
        
          
          
        $Employees = EmployeeFingerPrint::distinct()->pluck('employee_id');
        $Employee = Employee::where('status',1)->get()->pluck('name','id');
        
        $EmployeeAttendance = EmployeeAttendances::with('employee');
        $registration_from = null;
        $registration_to = null;
        $today = date('Y-m-d');
         $firstDayOfMonth = date('Y-m-01');
        $lastDayOfMonth = date('Y-m-t');
    
        if ($request->has('register_daterange') && $request->get('register_daterange') != null && $request->get('register_daterange') != '') {
            $daterange = explode(' - ', $request->get('register_daterange'));
            $registration_from = date_format(date_create($daterange[0]), 'Y-m-d');
            $reg_to = date_create($daterange[1]);
            date_add($reg_to, date_interval_create_from_date_string("1 days"));
            $registration_to = date_format($reg_to, "Y-m-d");
        }
        // return $registration_from;
        if ($registration_from != null && $registration_to != '') {
            
            // $EmployeeAttendance->whereBetween('date', [$registration_from, $registration_to])->get();
            $EmployeeAttendance->whereBetween('date',[$registration_from , $registration_to]);
        }
        if($request->has('employee_id') && $request->get('employee_id') != null && $request->get('employee_id') != ''){
            $EmployeeAttendance->where('employee_id',$request->get('employee_id'));
        }
    
         $EmployeeAttendances = $EmployeeAttendance->get()->groupBy('employee_id');
        
        
        $attendances = [];
        
        foreach($EmployeeAttendances as $key =>$attend){
            $att = new EmployeeAttendances;
            $att->employee_id = $key;
            $att->alldays = $attend->count();
            $att->done = $attend->where('status',1)->count();
            $att->quartday = $attend->where('status',2)->count();
            $att->halfday = $attend->where('status',3)->count();
            $att->oneday = $attend->where('status',4)->count();
            $att->pending = $attend->where('status',0)->count();
            $attendances[$key] = $att;
        }
        // return $attendances;
    
        
        return view('EmployeeAttendances.Report',compact('attendances','Employees','Employee'));
        
    }
    
     public function uploadfingerprint(Request $request)
    {
        if($request->hasFile('excel')){
            $file = $request->file('excel')->store('/');
            Excel::import(new Finger, storage_path('app/' . $file));
            // $lead = Lead::find(Auth::user()->id);
            
            $this->EmployeeAttendances();
            activity('Finger Print')
              ->causedBy(Auth::user()->id)
              ->log('upload Excel lead');
            Flash::success('Imported Successfully.');
        }else{
            Flash::success('excel file is required.');
        }
        return redirect()->back();
    }
    public function EmployeeAttendances(){
         $firstDayOfMonth = date('Y-m-01 h:m:s');
         $lastDayOfMonth = date('Y-m-t h:m:s');
         $results = EmployeeFingerPrint::
            select('*', 
            DB::raw('MAX(time) as max_time'),
            DB::raw('MIN(time) as min_time'))
            ->whereBetween('created_at',[$firstDayOfMonth , $lastDayOfMonth])
            ->groupBy('employee_id','date')->get();
        
          
          
        foreach ($results as $key=> $result){
            
            $diff= strtotime($result->max_time) - strtotime($result->min_time);

            EmployeeAttendances::updateOrCreate([
                'employee_id'=>$result->employee_id,
                'date'=>$result->date,
                ],[
                  'time_in'=>$result->min_time,
                  'time_out'=>$result->max_time,
                  'attendance_hours'=> date('H:i:s', $diff),
                  'status'=>1,
                  ]);
            
        }
        
    }
    
}
