<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ItCurrentItems;
use App\Models\Branch;
use App\Models\ITItemCategory;
use App\Models\ITItem;
use App\Models\Employee;
use Flash;
use Auth;
class ItCurrentItemsController extends Controller
{
    public function index(){
        $ItCurrentItems = ItCurrentItems::with('ititemCategory','ititem','branch','created_by')->get();
        
        return view('ItCurrentItems.index',compact('ItCurrentItems'));
    }
    public function create(){
        
        $branches = Branch::where('status',1)->pluck('name','id');
        $ititemcategories =ITItemCategory::pluck('name','id');
        $ititem =[];
        $employee= [];
        
        
        return view('ItCurrentItems.create',compact('branches','employee','ititemcategories','ititem'));
    }
    public function store(Request $request){
        $data = $request->validate([
            'branch_id' => 'required',
            'it_items_categories_id' => 'required',
            'it_item_id' => 'required',
            'balance' => 'required',
            'employee_id' => 'required|array',
            
        ]);
        
        $ItCurrentItems = new ItCurrentItems;
        $ItCurrentItems->it_items_categories_id = $request->it_items_categories_id;
        $ItCurrentItems->it_item_id = $request->it_item_id;
        $ItCurrentItems->balance = $request->balance;
        $ItCurrentItems->branch_id = $request->branch_id;
        $ItCurrentItems->employee_id =  json_encode($request->employee_id);
        $ItCurrentItems->created_by_id = auth()->user()->id;
        $ItCurrentItems->save();
            
       
        
         Flash::success('Used It Items Added successfully.');

        return redirect(route('admin.ItCurrentItems.index'));
        
        
        
    }
    public function edit($id , Request $request){
        $ItCurrentItems = ItCurrentItems::find($id);
        $branches = Branch::where('status',1)->pluck('name','id');
        $ititemcategories =ITItemCategory::pluck('name','id');
        $ititem =ItItem::find($ItCurrentItems->it_item_id)->pluck('name','id');
        $employee = Employee::where('current_branch',$ItCurrentItems->branch_id)->where('status',1)->select('first_name','middle_name','last_name','id')->get()->pluck('name','id');
       
        
        
        return view('ItCurrentItems.edit',compact('branches','ItCurrentItems','employee','ititemcategories','ititem'));
    }
    public function update($id ,Request $request){
         $data = $request->validate([
            'branch_id' => 'required',
            'it_items_categories_id' => 'required',
            'it_item_id' => 'required',
            'balance' => 'required',
            'employee_id' => 'required',
            
        ]);
        
        $ItCurrentItems =  ItCurrentItems::find($id);
        $ItCurrentItems->it_items_categories_id = $request->it_items_categories_id;
        $ItCurrentItems->it_item_id = $request->it_item_id;
        $ItCurrentItems->balance = $request->balance;
        $ItCurrentItems->branch_id = $request->branch_id;
        $ItCurrentItems->employee_id = $request->employee_id;
        $ItCurrentItems->save();
        
         Flash::success('Used It Items Added successfully.');

        return redirect(route('admin.ItCurrentItems.index'));
        
    }
    public function destroy($id){
        $ItCurrentItems = ItCurrentItems::find($id);
        $ItCurrentItems->delete();
        return redirect(route('admin.ItCurrentItems.index'));
    }
    
    public function getitemployee(Request $request){
        
        $employee = Employee::where('current_branch',$request->branch_id)->select('first_name','last_name','middle_name','id')->where('status',1)->get();
        return $employee;
    }
    
}
