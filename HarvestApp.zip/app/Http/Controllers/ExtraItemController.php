<?php

namespace App\Http\Controllers;

use Flash;
use Response;
use File;
use App\Models\ExtraItem;
use App\Models\Installment;
use App\Models\ItemCategory;
use App\Models\PaymentPlan;
use App\Models\LabelType;
use App\Models\Track;
use Illuminate\Http\Request;
use App\Http\Controllers\AppBaseController;
use App\Traits\StoreImageTrait;


class ExtraItemController extends AppBaseController
{
         use StoreImageTrait;

    public function extraItems_editWeb($id)
    {
        $extraItem = ExtraItem::find($id);

        if (empty($extraItem)) {
            Flash::error('Extra Item not found');

            return redirect(route('admin.extraItems.index'));
        }

        return view('extra_items.editWeb')->with('extraItem', $extraItem);
    }
    
    public function extraItems_updateWeb($id,Request $request)
    {
        $extraItem = ExtraItem::find($id);

        if (empty($extraItem)) {
            Flash::error('Extra Item not found');

            return redirect(route('admin.extraItems.index'));
        }
        $data = $request->except('image','_token');
        
                 $data['image'] = $this->verifyAndUpdateImageSource($extraItem->image,$request,'image','uploads/extraItems');

        $extraItem->fill($data);
        $extraItem->save();

        Flash::success('Extra Item updated successfully.');

        return redirect(route('admin.extraItems.index'));
    }
    /**
     * Display a listing of the ExtraItem.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var ExtraItem $extraItems */
        $extraItems = ExtraItem::all();

        return view('extra_items.index')
            ->with('extraItems', $extraItems);
    }

    /**
     * Show the form for creating a new ExtraItem.
     *
     * @return Response
     */
    public function create()
    {
        
        $categories = ItemCategory::pluck('name', 'id');
        $paymentPlans = PaymentPlan::where('status', 1)->pluck('title', 'id');
        $labelTypes = LabelType::where('status', 1)->where('category', 4)->pluck('name', 'id');
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id');
        return view('extra_items.create', compact('categories' ,'paymentPlans','labelTypes','tracks'));
    }
    public function storee(Request $request)
    {
        
        // $input = $request->all();
        $extraItem = new ExtraItem;
        $extraItem->track_id = $request->track_id;
        $extraItem->item_category_id = $request->item_category_id;
        $extraItem->price = $request->price;
        $extraItem->send_operation_inquiry = $request->send_operation_inquiry;
        $extraItem->payment_plan_id = $request->payment_plan_id;
        $extraItem->name = $request->name;
        $extraItem->save();
        
        if($request->payment_plan_id == 1 )
        {
            $installment = new Installment;
            $installment->installmentable_type = 'App\\Models\\ExtraItem';
            $installment->installmentable_id =$extraItem->id;
            $installment->deposit = $request->deposit;
            $installment->first_payment =   $request->first_payment;
            $installment->first_due_date =  $request->first_due_date;
            $installment->second_payment =  $request->second_payment;
            $installment->second_due_date = $request->second_due_date;
            $installment->third_payment =   $request->third_payment;
            $installment->third_due_date =  $request->third_due_date;
            $installment->fourth_payment =   $request->fourth_payment;
            $installment->fourth_due_date =  $request->fourth_due_date;
            $installment->save();
        }
        
         Flash::success('ExtraItem saved successfully.');

        return redirect(route('admin.extraItems.index'));
        
    }

    /**
     * Display the specified ExtraItem.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var ExtraItem $extraItem */
        $extraItem = ExtraItem::find($id);
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id');
        if (empty($extraItem)) {
            Flash::error('Extra Item not found');

            return redirect(route('admin.extraItems.index'));
        }

        return view('extra_items.show')->with('extraItem', $extraItem)->with('tracks',$tracks);
    }
    
    //store update

    /**
     * Show the form for editing the specified ExtraItem.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var ExtraItem $extraItem */
        $extraItem = ExtraItem::find($id);

        if (empty($extraItem)) {
            Flash::error('Extra Item not found');

            return redirect(route('admin.extraItems.index'));
        }
        $installment = Installment::where('installmentable_id' , $extraItem->id)
                                  ->where('installmentable_type','App\Models\ExtraItem')->first();
            
        $categories = ItemCategory::pluck('name', 'id');
        $paymentPlans = PaymentPlan::where('status', 1)->pluck('title', 'id');
        $labelTypes = LabelType::where('status', 1)->where('category', 4)->pluck('name', 'id');
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id');
        return view('extra_items.edit', compact('extraItem','installment' ,'categories','paymentPlans','labelTypes','tracks'));
    }
    public function updatee($id , Request $request )
    {
        $extraItem = ExtraItem::find($id);
        $extraItem->track_id = $request->track_id;
        $extraItem->item_category_id = $request->item_category_id;
        $extraItem->price = $request->price;
        $extraItem->send_operation_inquiry = $request->send_operation_inquiry;
        $extraItem->payment_plan_id = $request->payment_plan_id;
        $extraItem->name = $request->name;
        $extraItem->save();
        
        if($extraItem->payment_plan_id == 1 )
        {
            
            $installment = Installment::where('installmentable_id' , $extraItem->id)
                                      ->where('installmentable_type','App\Models\ExtraItem')->first();
           
            $installment->deposit = $request->deposit;
            $installment->first_payment =   $request->first_payment;
            $installment->first_due_date =  $request->first_due_date;
            $installment->second_payment =  $request->second_payment;
            $installment->second_due_date = $request->second_due_date;
            $installment->third_payment =   $request->third_payment;
            $installment->third_due_date =  $request->third_due_date;
            $installment->fourth_payment =   $request->fourth_payment;
            $installment->fourth_due_date =  $request->fourth_due_date;
            $installment->save();
        }
        
         Flash::success('ExtraItem updated successfully.');

        return redirect(route('admin.extraItems.index'));
        
    }

    /**
     * Remove the specified ExtraItem from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var ExtraItem $extraItem */
        $extraItem = ExtraItem::find($id);

        if (empty($extraItem)) {
            Flash::error('Extra Item not found');

            return redirect(route('admin.extraItems.index'));
        }

        $extraItem->delete();

        Flash::success('Extra Item deleted successfully.');

        return redirect(route('admin.extraItems.index'));
    }
}
