<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CertificateSerial;
use Flash;
use Auth;
use DB;
use File;
use App\Traits\StoreImageTrait;

class CertificateSerialController extends Controller
{
     use StoreImageTrait;
    public function index(Request $request){
        $CertificateSerials = CertificateSerial::get();
        
        return view('CertificateSerial.index',compact('CertificateSerials')); 
    }
    public function create(){
        $CertificateSerial = CertificateSerial::get();
        
        return view('CertificateSerial.create',compact('CertificateSerial'));
    }
    public function store(Request $request){
        
         $credentials = $request->validate([
            'name' => 'required',
            'level' => 'required',
            'grade' => 'required',
            'email' => 'required',
            'phone' => 'required',
            'issued_on' => 'required',
            // 'photo' => 'required'
            'type' => 'required'
            
        ]);
       
        $CertificateSerial = new CertificateSerial;
        $CertificateSerial->name = $request->name;
        $CertificateSerial->level = $request->level;
        $CertificateSerial->grade = $request->grade;
        $CertificateSerial->email = $request->email;
        $CertificateSerial->phone = $request->phone;
        $CertificateSerial->type = $request->type;
        $CertificateSerial->issued_on = $request->issued_on;
                $CertificateSerial['photo'] = $this->verifyAndStoreImageSource($request,'photo','uploads/certificate');

        
        $first_number = rand(111,555);
        $second_number = rand(666,999);
       
        if($request->type == 'harvest'){
          $CertificateSerial->serial_number = 'H'.'-'.$first_number.'-'.$second_number;
        }
        elseif($request->type == 'cambiragde'){
            $CertificateSerial->serial_number = $request->serial_number;
        }
        //  dd($CertificateSerial->serial_number);
        $CertificateSerial->save();
        Flash::success('CertificateSerial created successfully.');
      
        
        
         return redirect(route('admin.CertificateSerial.index'));
         
    }
    public function edit($id , Request $request){
        $CertificateSerial = CertificateSerial::find($id);
        // return $CertificateSerial;
        return view('CertificateSerial.edit',compact('CertificateSerial')); 
    }
    public function update($id , Request $request){
        $CertificateSerial = CertificateSerial::find($id);
         $credentials = $request->validate([
            'name' => 'required',
            'level' => 'required',
            'grade' => 'required',
            'email' => 'required',
            'phone' => 'required',
            'issued_on' => 'required',
            
            
            
        ]);
        $CertificateSerial->name = $request->name;
        $CertificateSerial->level = $request->level;
        $CertificateSerial->grade = $request->grade;
        $CertificateSerial->email = $request->email;
        $CertificateSerial->phone = $request->phone;
        $CertificateSerial->issued_on = $request->issued_on;
        if($CertificateSerial->type == 'cambiragde'){
         $CertificateSerial->serial_number = $request->serial_number;
        }
        // $CertificateSerial->photo = $request->photo;
  
                 $CertificateSerial['photo'] = $this->verifyAndUpdateImageSource($CertificateSerial->photo,$request,'photo','uploads/certificate');

        $CertificateSerial->save();
        Flash::success('CertificateSerial updated successfully.');
          return redirect(route('admin.CertificateSerial.index')); 
    }
    public function destroy($id){
        $CertificateSerial = CertificateSerial::find($id);
        $CertificateSerial->delete();
        Flash::success('CertificateSerial deleted successfully.');
        
          return redirect(route('admin.CertificateSerial.index'));
    }
    
    public function show($id)
    {
        $CertificateSerial = CertificateSerial::find($id);
        return view('CertificateSerial.show',compact('CertificateSerial')); 
    }
    
}
