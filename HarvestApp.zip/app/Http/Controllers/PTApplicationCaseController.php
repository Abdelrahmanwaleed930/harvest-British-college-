<?php

namespace App\Http\Controllers;

use App\Repositories\PTApplicationCaseRepository;
use App\Http\Controllers\AppBaseController;
use App\Models\Action;
use App\Models\Branch;
use App\Models\SMS;
use App\Models\WhatsApp;
use App\Models\Feedback;
use App\Models\Label;
use App\Models\Lead;
use App\Models\LabelType;
use App\Models\PTApplicationCase;
use App\Models\PTApplicationLaseCase;
use App\Models\kids_pt_application_case;
// use App\Models\kids_pt_applications_last_case;
use App\Models\kids_pt_application_last_case;
use App\Models\PlacementKidsApplicant;
use App\Models\Group;
use App\Models\PlacementApplicant;
use App\Models\PTApplicationLastCase;
use App\Models\Employee;
use App\Models\MessageLog;
use Illuminate\Http\Request;
use Flash;
use Response;
use DB;
use Auth;

class PTApplicationCaseController extends AppBaseController
{
    /** @var  PTApplicationCaseRepository */
    private $ptApplicationCaseRepository;

    public function __construct(PTApplicationCaseRepository $ptApplicationCaseRepo)
    {
        $this->ptApplicationCaseRepository = $ptApplicationCaseRepo;
    }
    
    public function followUpDelete(Request $request)
    {
        if ($request->ids != null && count($request->ids) > 0) {
            PTApplicationCase::whereIn('id', $request->ids)->delete();

            Flash::success('Deleted Successfully.');

            $this->show_delete = false;
            $this->selected = [];
        } else {
            Flash::error('Selected PTs Applications is required.');
        }
        return 0;
    }
    
    public function followUpSendmsg(Request $request)
    {
        if (!$request->message) {
            Flash::error('Message is required.');
        } elseif ($request->ids != null && count($request->ids) > 0) {
            if($request->type == 'sms'){
                $sms = new SMS;

                $ptApplicationsMobile = PTApplicationCase::whereIn('id', $request->ids)->with('pt_application')->get()->pluck('pt_application.mobile', 'pt_application_id')->toArray();
                $mobiles = array_unique($ptApplicationsMobile);
    
                $msg = $request->message;

                $sms->send($mobiles, $msg);

                $log = MessageLog::create([
                    'type' => 1,
                    'content' => $msg,
                    'employee_id' => auth()->id()
                ]);
                $log->PTsApplications()->sync(array_keys($mobiles));

            }else{
                $whatsApp = new WhatsApp;

                $ptApplicationsMobile = PTApplicationCase::whereIn('id', $request->ids)->with('pt_application')->get()->pluck('pt_application.mobile', 'pt_application_id')->toArray();
                $mobiles = array_unique($ptApplicationsMobile);
    
                $msg = $request->message;

                $whatsApp->send($mobiles, $msg);

                $log = MessageLog::create([
                    'type' => 2,
                    'content' => $msg,
                    'employee_id' => auth()->id()
                ]);
                $log->PTsApplications()->sync(array_keys($mobiles));

            }
            Flash::success('Sent Successfully.');

        } else {
            Flash::error('Selected Employees is required.');
        }
        return 0;
    }
    
    /**
     * Display a listing of the PTApplicationCase.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        //dd($request->all());
        //$testsec = round(microtime(true)*1000);
        $pt = PlacementApplicant::find(request('pt_application'));
        $lead = $pt->getLead();
           
        $labelTypes = LabelType::where('status', 1)->where('category', $request->type)->get();
        $feedbacks = Feedback::where('status', 1)->whereIn('label_type_id', $labelTypes->pluck('id'))->get();
        $actions = Action::where('status', 1)->whereIn('label_type_id', $labelTypes->pluck('id'))->get();
        $feedbacks = $feedbacks->groupBy('label_type_id');
        $actions = $actions->groupBy('label_type_id');
        
        $ptApplicationCases = PTApplicationCase::where('pt_application_id', $pt->id)->orderBy('id','desc')->get();

        $msgs_ids = DB::table('pt_application_message_log')->where('pt_application_id',$pt->id)->pluck('message_log_id');
        $msgs = MessageLog::whereIn('id',$msgs_ids)->orderBy('id','desc')->get();
        //dd(round(microtime(true)*1000)-$testsec);
        return view('pt_application_cases.index', compact('ptApplicationCases', 'pt','msgs','lead','labelTypes','feedbacks','actions'));
    }
    public function index_kids(Request $request)
    {
        $labelTypes = LabelType::where('status', 1)->where('category', $request->type)->get();
         $feedbacks = Feedback::where('status', 1)->whereIn('label_type_id', $labelTypes->pluck('id'))->get();
        $actions = Action::where('status', 1)->whereIn('label_type_id', $labelTypes->pluck('id'))->get();
        $feedbacks = $feedbacks->groupBy('label_type_id');
        $actions = $actions->groupBy('label_type_id');
        $pt = PlacementKidsApplicant::find(request('pt_application'));
        // $lead = $pt->getLead();
        
        
        $ptApplicationCases = kids_pt_application_case::where('kids_pt_application_id', $pt->id)->orderBy('id','desc')->get();

        // $msgs_ids = DB::table('pt_application_message_log')->where('pt_application_id',$pt->id)->pluck('message_log_id');
        // $msgs = MessageLog::whereIn('id',$msgs_ids)->orderBy('id','desc')->get();
        $msgs=[];
        return view('pt_application_cases.kids_index', compact('ptApplicationCases','feedbacks','actions', 'pt','msgs','labelTypes'));
    }
      public function destroy_kids($id)
    {
    
       $followup= kids_pt_application_case::find($id);
       $followup->delete();
       Flash::success('Kids Deleted Successfully.');
       return redirect(route('admin.ptApplications.kidsfollowup'));
        
        
        
    }
    
    public function show_kids($id)
    {
         $ptApplicationCase = kids_pt_application_case::find($id);

        if (empty($ptApplicationCase)) {
            Flash::error('Kids Placement Applicant Case not found');

            return redirect(route('admin.ptApplicationCases.index_kids'));
        }

        return view('pt_application_cases.kids_show')->with('ptApplicationCase', $ptApplicationCase);
    }

    /**
     * Show the form for creating a new PTApplicationCase.
     *
     * @return Response
     */
    public function create()
    {
        //dd(request('lead'));
        $ptApplication = PlacementApplicant::find(request('pt_application'));
        

        return view('pt_application_cases.create', compact('ptApplication'));
    }
    public function store(Request $request){
        // return $request;
        $data = $request->validate([
            'pt_application_id' => 'required',
            'branch_id' => 'required',
            'label_type_id' => 'required',
            'follow_up_type' => 'required',
            'call_type' => 'nullable',
            'feedback_id' => 'nullable',
            
            'action_id' => 'nullable',
            'notes' => 'nullable',
            'date' => 'nullable',
        ]);
       
        // $ptApplicationCase = $pt->ptApplicationCase;
        // if($ptApplicationCase){
        //     $ptApplicationCase->update($data);
        // }else{
        $data['employee_id'] = Auth::user()->id;
        $data['serial'] = time();
        $ptApplication = PlacementApplicant::find($request->pt_application_id);
        $ptApplicationCase = PTApplicationCase::create($data);

        if($request->has('old') && $request->get('old') != '' && $request->get('old') != null) {
            $followup = PTApplicationCase::find($request->get('old'));
            $followup->update(['status' => 1]);
        }
        
        $lastcase = $ptApplication->lastcase;
        $last_case_date = array_merge(['pt_application_case_id' => $ptApplicationCase->id ],$data);
        if($lastcase){
            $lastcase->update($last_case_date);
        }else{
            $lastcase = PTApplicationLastCase::create($last_case_date);
        }
        $query = ['pt_application' => $ptApplicationCase->pt_application_id,'type' => $ptApplicationCase->type];
    
        return redirect(route('admin.ptApplicationCases.index', $query));
    }

    /**
     * Display the specified PTApplicationCase.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $ptApplicationCase = $this->ptApplicationCaseRepository->find($id);

        if (empty($ptApplicationCase)) {
            Flash::error('Placement Applicant Case not found');

            return redirect(route('admin.ptApplicationCases.index'));
        }

        return view('pt_application_cases.show')->with('ptApplicationCase', $ptApplicationCase);
    }

    /**
     * Show the form for editing the specified PTApplicationCase.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $ptApplicationCase = $this->ptApplicationCaseRepository->find($id);
        //dd($ptApplicationCase);
        if (empty($ptApplicationCase)) {
            Flash::error('Placement Applicant Case not found');

            return redirect(route('admin.ptApplicationCases.index'));
        }
        $labelTypes = LabelType::where('status', 1)->where('category', 6)->get();
        $feedbacks = Feedback::where('status', 1)->whereIn('label_type_id', $labelTypes->pluck('id'))->get();
        $actions = Action::where('status', 1)->whereIn('label_type_id', $labelTypes->pluck('id'))->get();
        $feedbacks = $feedbacks->groupBy('label_type_id');
        $actions = $actions->groupBy('label_type_id');
        
        $ptApplication = PlacementApplicant::find($ptApplicationCase->pt_application_id);

        return view('pt_application_cases.edit', compact('ptApplication', 'ptApplicationCase','labelTypes','feedbacks','actions'));
    }
    
    public function update($id ,Request $request){
        //  $data =$request->all();
         $data = $request->validate([
            'label_type_id' => 'required',
            'follow_up_type' => 'required',
            'call_type' => 'nullable',
            'feedback_id' => 'nullable',
            'action_id' => 'nullable',
            'notes' => 'nullable',
            'date' => 'nullable',
        ]);
       
         $ptApplicationCase = PTApplicationCase::find($id);
         if(isset($data['action_id']) && $data['action_id'] != null && $data['action_id'] != ''){
            $action = Action::findOrFail($data['action_id']);
            //dd($action);
            if(strtolower($action->name) == 'open'){
                $data['status'] = 0;
            }
            if(strtolower($action->name) == 'close' || strtolower($action->name) == 'closed'){
                $data['status'] = 1;
            }
        }
        
        if(isset($data['label_type_id']) && $data['label_type_id'] != null && $data['label_type_id'] != ''){
            $label_type = LabelType::findOrFail($data['label_type_id']);
            //dd($action);
            if(strtolower($label_type->name) == 'reserved'){
                $data['status'] = 1;
            }
        }
        //dd($leadCase);
        if (empty($ptApplicationCase)) {
            Flash::error('Adult PT Case not found');

            return redirect(route('admin.ptApplications.followup'));
        }
        
        $ptApplicationCase->update($data);

        Flash::success('Adult PT Case updated successfully.');

        return redirect()->back();
        // $data =$request->all();
        //  $pt = PTApplicationCase::find($id);
        //  if(isset($data['action_id']) && $data['action_id'] != null && $data['action_id'] != ''){
        //     $action = Action::findOrFail($data['action_id']);
        //     //dd($action);
        //     if(strtolower($action->name) == 'open'){
        //         $data['status'] = 0;
        //     }
        //     if(strtolower($action->name) == 'close' || strtolower($action->name) == 'closed'){
        //         $data['status'] = 1;
        //     }
        // }
        
        // if(isset($data['label_type_id']) && $data['label_type_id'] != null && $data['label_type_id'] != ''){
        //     $label_type = LabelType::findOrFail($data['label_type_id']);
        //     //dd($action);
        //     if(strtolower($label_type->name) == 'reserved'){
        //         $data['status'] = 1;
        //     }
        // }
        // //dd($leadCase);
        // if (empty($pt)) {
        //     Flash::error('Adult PT Case not found');

        //     return redirect(route('admin.ptApplications.followup'));
        // }
        
        
        // $pt->update($data);

        // Flash::success('Adult PT Case updated successfully.');

        // return redirect()->back();
    }

    /**
     * Remove the specified PTApplicationCase from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        $ptApplicationCase = $this->ptApplicationCaseRepository->find($id);

        if (empty($ptApplicationCase)) {
            Flash::error('PT Application Case not found');

            return redirect(route('admin.ptApplicationCases.index'));
        }
        PTApplicationLastCase::where('pt_application_case_id',$ptApplicationCase->id)->delete();
        $ptApplication = $ptApplicationCase->pt_application_id;

        $this->ptApplicationCaseRepository->delete($id);

        Flash::success('PT Application Case deleted successfully.');

        return redirect(route('admin.ptApplicationCases.index', ['pt_application' => $ptApplication]));
    }

    /**
     * Show the follow up page.
     *
     * @return Response
     */
    public function followup(Request $request)
    {
        //dd('dddd');
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        $branches = Branch::pluck('name', 'id')->toArray();
        /*
        $agents = Employee::where('account_Type', 'H.Q Account')->where('status',1)
                            ->whereIn('job_id',[32,33,34])->get()->pluck('name', 'id')->toArray();
        */
        $labelTypes = LabelType::where('status', 1)->where('category', 6)->pluck('name', 'id')->toArray();
        
        $followupsQuery = PTApplicationCase::leftJoin('placement_applicants','placement_applicants.id','=','pt_application_cases.pt_application_id')
            ->where('pt_application_cases.status', 0)
            ->whereNotNull('pt_application_cases.date')
            ->where('pt_application_cases.date', '<=', now());
        //dd($followupsQuery->count());
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $followupsQuery->where(function ($query) use ($request){
                $query->where('placement_applicants.name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('placement_applicants.mobile', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('placement_applicants.email', 'like', '%' . $request->get('search') . '%');
            });
        }
        
        if ($request->has('branches') && $request->get('branches') != null && $request->get('branches') != '') {
            $followupsQuery->whereIn('placement_applicants.branch_id', $request->get('branches'));
        }else {
            $followupsQuery->whereIn('placement_applicants.branch_id', array_keys($branches));
        }
        /*
        if($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
            $followupsQuery->where('pt_application_cases.employee_id', $request->get('agent'));
        }
        */
        if(!auth()->user()->can('followup manager')){
            //dd('ddd');
            $followupsQuery->where('pt_application_cases.employee_id', auth()->id());
        }
        if($request->has('label_type_id') && $request->get('label_type_id') != null && $request->get('label_type_id') != ''){
            $followupsQuery->where('pt_application_cases.label_type_id', $request->get('label_type_id'));
        }
        $followupsCount = $followupsQuery->count();
        //dd($followupsCount);
        $followups = $followupsQuery->select('pt_application_cases.id','pt_application_cases.created_at','pt_application_cases.branch_id','pt_application_cases.label_type_id','pt_application_cases.employee_id','pt_application_cases.pt_application_id','pt_application_cases.feedback_id','pt_application_cases.action_id','pt_application_cases.date')->with('pt_application')->orderBy('pt_application_cases.date','desc')->paginate($per_page);

        return view('pt_application_cases.followup',compact('followupsCount','followups','branches','labelTypes'));
    }
    public function kidsfollowup(Request $request)
    {
        //dd('dddd');
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        $branches = Branch::pluck('name', 'id')->toArray();
        
        $labelTypes = LabelType::where('status', 1)->where('category', 6)->pluck('name', 'id')->toArray();
        
        // $followupsQuery = kids_pt_application_case::leftJoin('placement_kids_applicants','placement_kids_applicants.id','=','kids_pt_applications_case.kids_pt_application_id')
        //     ->where('kids_pt_applications_case.status', 0)
        //     ->whereNotNull('kids_pt_applications_case.date')
        //     ->where('kids_pt_applications_case.date', '<=', now());
        $followupsQuery = kids_pt_application_case::where('status', 0)
            ->whereNotNull('date')
            ->where('date', '<=', now());
        
        // if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
        //     $followupsQuery->where(function ($query) use ($request){
        //         $query->where('placement_kids_applicants.name', 'like', '%' . $request->get('search') . '%')
        //             ->orWhere('placement_kids_applicants.mobile', 'like', '%' . $request->get('search') . '%')
        //             ->orWhere('placement_kids_applicants.email', 'like', '%' . $request->get('search') . '%');
        //     });
        // }
        
        // if ($request->has('branches') && $request->get('branches') != null && $request->get('branches') != '') {
        //     $followupsQuery->whereIn('placement_kids_applicants.branch_id', $request->get('branches'));
        // }else {
        //     $followupsQuery->whereIn('placement_kids_applicants.branch_id', array_keys($branches));
        // }
        
        // if(!auth()->user()->can('followup manager')){
        //     //dd('ddd');
        //     $followupsQuery->where('kids_pt_applications_case.employee_id', auth()->id());
        // }
        // if($request->has('label_type_id') && $request->get('label_type_id') != null && $request->get('label_type_id') != ''){
        //     $followupsQuery->where('kids_pt_applications_case.label_type_id', $request->get('label_type_id'));
        // }
        $followupsCount = $followupsQuery->count();
        
        // $followups = $followupsQuery->select('kids_pt_applications_case.id','kids_pt_applications_case.created_at','kids_pt_applications_case.branch_id','kids_pt_applications_case.label_type_id','kids_pt_applications_case.employee_id','kids_pt_applications_case.pt_application_id','kids_pt_applications_case.feedback_id','kids_pt_applications_case.action_id','kids_pt_applications_case.date')->with('pt_application')->orderBy('kids_pt_applications_case.date','desc')->paginate($per_page);
        $followups = $followupsQuery->with('pt_application')->orderBy('date','desc')->paginate($per_page);

        return view('pt_application_cases.kids_followup',compact('followupsCount','followups','branches','labelTypes'));
    }
    public function storekidsfollowup(Request $request){
        
        $data = $request->validate([
            'kids_pt_application_id' => 'required',
            'branch_id' => 'required',
            'label_type_id' => 'required',
            'follow_up_type' => 'required',
            'call_type' => 'nullable',
            'feedback_id' => 'nullable',
            
            'action_id' => 'nullable',
            'note' => 'nullable',
            'date' => 'nullable',
        ]);
       
        // $ptApplicationCase = $pt->ptApplicationCase;
        // if($ptApplicationCase){
        //     $ptApplicationCase->update($data);
        // }else{
        $data['employee_id'] = Auth::user()->id;
        $data['serial'] = time();
        $kidsptApplication = PlacementKidsApplicant::find($request->kids_pt_application_id);
        $ptApplicationCase = kids_pt_application_case::create($data);

        if($request->has('old') && $request->get('old') != '' && $request->get('old') != null) {
            $followup = kids_pt_application_case::find($request->get('old'));
            $followup->update(['status' => 1]);
        }
        $lastcase = $kidsptApplication->lastcase;
        $last_case_date = array_merge(['kids_pt_application_case_id' => $ptApplicationCase->id ],$data);
        if($lastcase){
            $lastcase->update($last_case_date);
        }else{
            $lastcase = kids_pt_application_last_case::create($last_case_date);
        }
        $query = ['pt_application' => $ptApplicationCase->kids_pt_application_id,'type' => $ptApplicationCase->type];
    
        return redirect(route('admin.ptApplicationCases.index_kids', $query));
    }
    
    public function kids_edit($id , Request $request)
    {
        // $leadCase = LeadCase::find($id);
        $ptApplicationCase = kids_pt_application_case::find($id);
        //dd($leadCase);
        if (empty($ptApplicationCase)) {
            Flash::error('Kids PT Case not found');

            return redirect(route('admin.ptApplications.kidsfollowup'));
        }
        $labelTypes = LabelType::where('status', 1)->where('category', 6)->get();
        $feedbacks = Feedback::where('status', 1)->whereIn('label_type_id', $labelTypes->pluck('id'))->get();
        $actions = Action::where('status', 1)->whereIn('label_type_id', $labelTypes->pluck('id'))->get();
        $feedbacks = $feedbacks->groupBy('label_type_id');
        $actions = $actions->groupBy('label_type_id');
        
        // $lead = Lead::find($ptApplicationCase->lead_id);

        return view('pt_application_cases.kids_edit', compact('ptApplicationCase','labelTypes','feedbacks','actions'));
    }

    
    public function kids_update($id, Request $request)
    {
        $data =$request->all();
         $ptApplicationCase = kids_pt_application_case::find($id);
         if(isset($data['action_id']) && $data['action_id'] != null && $data['action_id'] != ''){
            $action = Action::findOrFail($data['action_id']);
            //dd($action);
            if(strtolower($action->name) == 'open'){
                $data['status'] = 0;
            }
            if(strtolower($action->name) == 'close' || strtolower($action->name) == 'closed'){
                $data['status'] = 1;
            }
        }
        
        if(isset($data['label_type_id']) && $data['label_type_id'] != null && $data['label_type_id'] != ''){
            $label_type = LabelType::findOrFail($data['label_type_id']);
            //dd($action);
            if(strtolower($label_type->name) == 'reserved'){
                $data['status'] = 1;
            }
        }
        //dd($leadCase);
        if (empty($ptApplicationCase)) {
            Flash::error('Kids PT Case not found');

            return redirect(route('admin.ptApplications.kidsfollowup'));
        }
        
        $ptApplicationCase->update($data);

        Flash::success('Kids PT Case updated successfully.');

        return redirect()->back();
    }
    public function showRecentFollowupReport(Request $request)
    {
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        $branches = Branch::pluck('name', 'id')->toArray();
        /*
        $agents = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($branches) {
                                $query->whereIn('id', array_keys($branches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        */
        $from = null;
        $to = null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $from = date_format(date_create($daterange[0]),'Y-m-d');
            // $to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $to= date_format($reg_to,"Y-m-d");
        }
        
        $register_from = null;
        $register_to = null;
        if ($request->has('register_daterange') && $request->get('register_daterange') != null && $request->get('register_daterange') != '') {
            $register_daterange = explode(' - ',$request->get('register_daterange'));
            $register_from = date_format(date_create($register_daterange[0]),'Y-m-d');
            // $register_to = date_format(date_create($register_daterange[1]),'Y-m-d');
            $reg_to  = date_create($register_daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $register_to= date_format($reg_to,"Y-m-d");
        }
        $labelTypes = LabelType::where('status',1)->where('category',6)->pluck('name','id')->toArray();
        
        $ptApplicationCasesQuary = PTApplicationCase::whereIn('label_type_id',array_keys($labelTypes))->with('pt_application')->whereHas('employee',function($quary){
            $quary->where('status',1);
        });
        
        if($register_from && $register_to){
            $ptApplicationCasesQuary->whereHas('pt_application',function($query) use ($register_from,$register_to){
                $query->whereBetween('created_at',[$register_from,$register_to]);
            });
        }
        
        if($from && $to){
            $ptApplicationCasesQuary->whereBetween('created_at', [$from, $to]);
        }elseif($register_from && $register_to){
            $ptApplicationCasesQuary->whereBetween('created_at', [$register_from,$register_to]);
        }
        else{
            $ptApplicationCasesQuary->where('created_at','like','%'.date('Y-m-d').'%');
        }
        /*
        if(count($agents) > 0){
            $ptApplicationCasesQuary->whereIn('employee_id', array_keys($agents));
        }
        
        if($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
            $ptApplicationCasesQuary->where('employee_id', $request->get('agent'));
        }
        
        if(! auth()->user()->can('reports show_all_data')){
            $ptApplicationCasesQuary->where('employee_id', auth()->user()->id);
        }
        */
        $followupsCount = $ptApplicationCasesQuary->count();
        $ptApplicationCases = $ptApplicationCasesQuary->orderBy('id','desc')->paginate($per_page);
        
        return view('pt_reports.recent_followup_report',compact('per_page','branches','ptApplicationCases','followupsCount'));
    }
    
    public function showFollowupReport(Request $request)
    {
        //dd($request->all());
        $view_type = 'employees';
        if($request->has('view_type')){
            $view_type = $request->get('view_type');
        }
        $branches = Branch::pluck('name', 'id')->toArray();
        
        $from = null;
        $to = null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $from = date_format(date_create($daterange[0]),'Y-m-d');
            // $to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $to= date_format($reg_to,"Y-m-d");
        }
        
        $register_from = null;
        $register_to = null;
        if ($request->has('register_daterange') && $request->get('register_daterange') != null && $request->get('register_daterange') != '') {
            $register_daterange = explode(' - ',$request->get('register_daterange'));
            $register_from = date_format(date_create($register_daterange[0]),'Y-m-d');
            // $register_to = date_format(date_create($register_daterange[1]),'Y-m-d');
            $reg_to  = date_create($register_daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $register_to= date_format($reg_to,"Y-m-d");
        }
        
        $targetCall = 0;
        $actualReachable = 0;
        
        $labelTypes = LabelType::select('id','name')->where('status',1)->where('category',6)->orderBy('id')->get();
        $feedbacks = Feedback::whereIn('label_type_id',$labelTypes->pluck('id'))->orderBy('label_type_id')->get();
        
        //if($view_type == 'employees'){
            $ptApplicationCasesQuary = PTApplicationCase::whereNotNull('employee_id')->whereHas('employee',function($quary){
                $quary->where('status',1);
            })->whereIn('label_type_id',$labelTypes->pluck('id'))->with('pt_application');
            
            $employees_ids = $ptApplicationCasesQuary->pluck('employee_id');
            if($employees_ids != null && count($employees_ids) > 0){
                if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
                    $agents = Employee::whereIn('id', $employees_ids)->where('status',1)
                                    ->whereHas('branches', function ($query) use ($request) {
                                        $query->whereIn('id', $request->get('branches'));
                                    })->groupBy('id')->get()->pluck('name', 'id')->toArray();
                }else{
                    $agents = Employee::whereIn('id', $employees_ids)->where('status',1)
                                    ->whereHas('branches', function ($query) use ($branches) {
                                        $query->whereIn('id', array_keys($branches));
                                    })->groupBy('id')->get()->pluck('name', 'id')->toArray();
                }
            }
            if($register_from && $register_to){
                
                $ptApplicationCasesQuary->whereHas('pt_application',function($quary) use($register_from,$register_to){
                    $quary->whereBetween('created_at',[$register_from,$register_to]);
                });
            }
            
            if ($from && $to) {
                
                $now = strtotime($from); // or your date as well
                $your_date = strtotime($to);
                $datediff = $your_date - $now ;
                
                $targetCall = 100 * round($datediff / (60 * 60 * 24));
                $actualReachable = 63 * round($datediff / (60 * 60 * 24));
                
                $ptApplicationCasesQuary->whereBetween('created_at', [$from, $to]);
            }elseif($register_from && $register_to){
                $now = strtotime($register_from); // or your date as well
                $your_date = strtotime($register_to);
                $datediff = $your_date - $now ;
                
                $targetCall = 100 * round($datediff / (60 * 60 * 24));
                $actualReachable = 63 * round($datediff / (60 * 60 * 24));
                
                $ptApplicationCasesQuary->whereBetween('created_at', [$register_from, $register_to]);
            }
            else{
                $targetCall = 100;
                $actualReachable = 63;
                $ptApplicationCasesQuary->where('created_at','like','%'.date('Y-m-d').'%');
            }
            
            if (count($agents) > 0){
                $ptApplicationCasesQuary->whereIn('employee_id', array_keys($agents));
            }
            
            if ($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
                $ptApplicationCasesQuary->where('employee_id', $request->get('agent'));
            }
            /*
            if(! auth()->user()->can('reports show_all_data')){
                $ptApplicationCasesQuary->where('employee_id', auth()->user()->id);
            }
            */
            $quary = '';
            foreach($feedbacks as $key => $feedback){
                $quary .= 'count(case when feedback_id = '.$feedback->id.' then feedback_id end) as feedbackCount'.$feedback->id;
                if($key < (count($feedbacks) - 1)){
                    $quary .= ' , ';
                }
            }
            $ptApplicationCases = $ptApplicationCasesQuary->select('employee_id',DB::raw($quary))->groupBy('employee_id')->orderBy('employee_id')->get();
            //dd($ptApplicationCases);
            foreach ($ptApplicationCases as $key => $leadCase){
                $actual_reachable = 0; 
                $total_target_calls = 0;
                foreach($feedbacks as $feedback){
                    $total_target_calls += $leadCase->{'feedbackCount'.$feedback->id};
                    if(in_array($feedback->id,[30,31,32,33])){
                        $actual_reachable += $leadCase->{'feedbackCount'.$feedback->id};
                    }
                }
                $ptApplicationCases[$key]['total_target_calls'] = $total_target_calls;
                $ptApplicationCases[$key]['actual_reachable'] = $actual_reachable;
            }
            
            //dd($targetCall,$actualReachable);
        /*}else{
            $ptApplicationCasesQuary = PTApplicationCase::whereIn('feedback_id',$feedbacks->pluck('id'))->whereNotNull('branch_id')->whereIn('branch_id',array_keys($branches))
                ->whereHas('employee',function($quary){
                    $quary->where('status',1);
                });
            
            if($register_from && $register_to){
                $ptApplicationCasesQuary->whereHas('pt_application',function($query) use($register_from,$register_to){
                    $query->whereBetween('created_at',[$register_from,$register_to]);
                });
            }
            
            if ($from && $to) {
                $ptApplicationCasesQuary->whereBetween('created_at', [$from, $to]);
            }elseif($register_from && $register_to){
                $ptApplicationCasesQuary->whereBetween('created_at', [$register_from,$register_to]);
            }
            else{
                $ptApplicationCasesQuary->where('created_at','like','%'.date('Y-m-d').'%');
            }
            
            $quary = '';
            foreach($feedbacks as $key => $feedback){
                $quary .= 'count(case when feedback_id = '.$feedback->id.' then feedback_id end) as feedbackCount'.$feedback->id;
                if($key < (count($feedbacks) - 1)){
                    $quary .= ' , ';
                }
            }
            $ptApplicationCases = $ptApplicationCasesQuary->select('branch_id',DB::raw($quary))->groupBy('branch_id')->orderBy('branch_id')->get();
            //dd($ptApplicationCases);
            foreach ($ptApplicationCases as $key => $leadCase){
                $actual_reachable = 0; 
                $total_target_calls = 0;
                foreach($feedbacks as $feedback){
                    $total_target_calls += $leadCase->{'feedbackCount'.$feedback->id};
                    if(in_array($feedback->id,[30,31,32,33])){
                        $actual_reachable += $leadCase->{'feedbackCount'.$feedback->id};
                    }
                }
                if ($from && $to) {
                    $now = strtotime($from); // or your date as well
                    $your_date = strtotime($to);
                    $datediff = $your_date - $now ;
                    
                    $ptApplicationCases[$key]['targetCall'] = $leadCase->branch->getEmployeesCount() * 100 * round($datediff / (60 * 60 * 24));
                    $ptApplicationCases[$key]['actualReachable'] = $leadCase->branch->getEmployeesCount() * 63 * round($datediff / (60 * 60 * 24));
                }elseif($register_from && $register_to){
                    $now = strtotime($register_from); // or your date as well
                    $your_date = strtotime($register_to);
                    $datediff = $your_date - $now ;
                    
                    $ptApplicationCases[$key]['targetCall'] = $leadCase->branch->getEmployeesCount() * 100 * round($datediff / (60 * 60 * 24));
                    $ptApplicationCases[$key]['actualReachable'] = $leadCase->branch->getEmployeesCount() * 63 * round($datediff / (60 * 60 * 24));
                }
                else{
                    $ptApplicationCases[$key]['targetCall'] = $leadCase->branch->getEmployeesCount() * 100;
                    $ptApplicationCases[$key]['actualReachable'] = $leadCase->branch->getEmployeesCount() * 63;
                }
                $ptApplicationCases[$key]['employeesCount'] = $leadCase->branch->getEmployeesCount();
                $ptApplicationCases[$key]['total_target_calls'] = $total_target_calls;
                $ptApplicationCases[$key]['actual_reachable'] = $actual_reachable;
            }
            
        }*/
        
        return view('pt_reports.followup_report',compact('view_type','feedbacks','agents','branches','labelTypes','ptApplicationCases','targetCall','actualReachable'));
    }
    
    public function showTotalFollowupReport(Request $request)
    {
        $view_type = 'employees';
        if($request->has('view_type')){
            $view_type = $request->get('view_type');
        }
        $branches = Branch::pluck('name', 'id')->toArray();
        /*
        $agents = [];
        if($request->has('branches') && $request->get('branches') != '' && $request->get('branches') != null){
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($request) {
                                $query->whereIn('id', $request->get('branches'));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }else{
            $agents = Employee::where('account_Type', 'Operations Account')->where('status',1)
                            ->whereHas('branches', function ($query) use ($branches) {
                                $query->whereIn('id', array_keys($branches));
                            })->groupBy('id')->get()->pluck('name', 'id')->toArray();
        }
        */
        $labelTypes = LabelType::select('id','name')->where('category',1)->where('status',1)->get();
        $from = null;
        $to = null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));
            $from = date_format(date_create($daterange[0]),'Y-m-d');
            // $to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $to= date_format($reg_to,"Y-m-d");
        }
        
        if($view_type == 'employees'){
            if (count($agents) > 0){
                $ptApplicationCasesQuary = PTApplicationCase::whereIn('employee_id', array_keys($agents))
                                            ->whereRaw('id in (select max(id) as last_follow_up_id from lead_cases group by employee_id,lead_id)');
            }else{
                $ptApplicationCasesQuary = PTApplicationCase::whereHas('employee',function($quary){
                    $quary->where('account_Type', 'Operations Account')->where('status',1);
                })
                ->whereRaw('id in (select max(id) as last_follow_up_id from lead_cases group by employee_id,lead_id)');
            }
            $ptApplicationCasesQuary->whereIn('label_type_id',$labelTypes->pluck('id'));
            
            if ($from && $to) {
                $ptApplicationCasesQuary->whereHas('pt_application',function($quary) use ($from,$to){
                    $quary->whereBetween('created_at', [$from, $to]);
                });
            }
            /*
            if ($this->case_from && $this->case_to) {
                $ptApplicationCasesQuary->whereBetween('created_at', [$this->case_from, $this->case_to]);
            }
            */
            if ($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
                $ptApplicationCasesQuary->where('employee_id', $request->get('agent'));
            }
            
            if(! auth()->user()->can('reports show_all_data')){
                $ptApplicationCasesQuary->where('employee_id', auth()->user()->id);
            }
            $quary = '';
            foreach($labelTypes as $key => $labelType){
                $quary .= 'count(case when label_type_id = '.$labelType->id.' then label_type_id end) as labelTypeCount'.$labelType->id;
                if($key < (count($labelTypes) - 1)){
                    $quary .= ' , ';
                }
            }
            $ptApplicationCases = $ptApplicationCasesQuary->select('employee_id',DB::raw($quary))->groupBy('employee_id')->orderBy('employee_id')->get();
        }else{
            $ptApplicationCasesQuary = PTApplicationCase::whereIn('branch_id',array_keys($branches))
                    ->whereHas('employee',function($quary){
                        $quary->where('account_Type', 'Operations Account')->where('status',1);
                    })
                    ->whereRaw('id in (select max(id) as last_follow_up_id from lead_cases group by lead_id)');
                    //->select('branch_id','employee_id','lead_id',DB::raw('max(id) as last_follow_up_id'))->groupBy('employee_id')->groupBy('lead_id')->orderBy('branch_id')->get();
        
            //$ptApplicationCasesQuary2 = PTApplicationCase::whereIn('id',$ptApplicationCasesQuary1->pluck('last_follow_up_id'));
            
            if ($from && $to) {
                $ptApplicationCasesQuary->whereHas('pt_application',function($quary) use ($from,$to){
                    $quary->whereBetween('created_at', [$from, $to]);
                });
            }
            
            $quary = '';
            foreach($labelTypes as $key => $labelType){
                $quary .= 'count(case when label_type_id = '.$labelType->id.' then label_type_id end) as labelTypeCount'.$labelType->id;
                if($key < (count($labelTypes) - 1)){
                    $quary .= ' , ';
                }
            }
            $ptApplicationCases = $ptApplicationCasesQuary->select('branch_id',DB::raw($quary))->groupBy('branch_id')->orderBy('branch_id')->get();
            
        }
        return view('sales_reports.total_followup_report',compact('view_type','agents','employeeBranches','labelTypes','ptApplicationCases'));
    }
    
}
