<?php

namespace App\Http\Controllers;

use Flash;
use Response;
use DB;
use Illuminate\Http\Request;
use App\Models\StudentExam;
use Illuminate\Support\Facades\Mail;
use App\Http\Controllers\AppBaseController;
use App\Models\Lead;
use App\Models\LeadPayment;
use App\Models\Offer;
use App\Models\Track;
use App\Models\Group;
use App\Models\TrainingService;
use App\Models\CustomerTrack;
use App\Models\GroupWaitingList;
use App\Models\GroupSession;
use App\Models\GroupStudent;

use App\Models\Timeframe;
use App\Models\Round;
use App\Models\StageLevel;
use App\Models\Room;
use App\Models\Branch;
use App\Models\SubRound;
use Auth;
use Spatie\Activitylog\Contracts\Activity;


// use DB;

class ExamApplicantController extends AppBaseController
{
    /**
     * Display a listing of the StudentExam.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var StudentExam $examsApplicants */
        //$testProcess = round(microtime(true) * 1000);
        $employeeBranches = auth()->user()->branches->pluck('name','id')->toArray();
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id')->toArray();
        $courses = [];
        $stageLevels = [];
        $groups = [];
        // $courses = [];
        // $stageLevels = [];
        $timeframes = [];
        $rounds = [];
        $daysData = [];
        $intervals = [];
        $subRounds = [];
        $examsApplicantsQuery = StudentExam::with('student');
        if($request->has('branch_id') && $request->get('branch_id') != null && $request->get('branch_id') != ''){
            $examsApplicantsQuery = $examsApplicantsQuery->whereHas('group',function($query) use ($request){
                $query->where('branch_id', $request->get('branch_id'));
            });
        }
        
        
        if (request()->filled('search')) {
            $examsApplicantsQuery->whereHas('lead',function ($query) use($request) {
                $query->where('leads.name', 'like', '%' . $request->search . '%')
                    ->orWhere('leads.mobile_1', 'like', '%' . $request->search . '%')
                    ->orWhere('leads.email', 'like', '%' . $request->search . '%');
            });
        }
        if (request()->filled('status')) {
            $examsApplicantsQuery->where('status', request('status'));
        }
        if (request()->filled('exam_status')) {
              $examsApplicantsQuery->whereHas('student',function($query) use ($request){
                $query->where('exam_status', $request->get('exam_status'));
            });        }
        
        if($request->has('track_id') && $request->get('track_id') != null && $request->get('track_id') != ''){
            $courses = Track::where('status',1)->where('parent_id',$request->get('track_id'))->pluck('title','id');
            $examsApplicantsQuery->where('track_id',$request->get('track_id'));
        }
        
        if($request->has('course_id') && $request->get('course_id') != null && $request->get('course_id') != ''){
            $examsApplicantsQuery->where('course_id',$request->get('course_id'));
            $stageLevels = Track::find($request->get('course_id'))->stageLevels->pluck('name', 'id')->toArray();

            $timeframe_ids = DB::table('timeframe_courses')->where('course_id',$request->get('course_id'))->pluck('timeframe_id')->toArray();
            $timeframes = Timeframe::whereIn('id',$timeframe_ids)->where('status',1)->pluck('title','id')->toArray();
        }
        
        if($request->has('level_id') && $request->get('level_id') != null && $request->get('level_id') != ''){
            $examsApplicantsQuery->where('level_id',$request->get('level_id'));
            $groups = Group::where('track_id',$request->get('track_id'))->where('course_id',$request->get('course_id'))->where('level_id',$request->get('level_id'))->pluck('code', 'id')->toArray();
        }
        if($request->has('timeframe_id') && $request->get('timeframe_id') != null && $request->get('timeframe_id') != ''){
            // $groupsQuery->where('timeframe_id',$request->get('timeframe_id'));
            $examsApplicantsQuery->whereHas('group' ,function($q) use ($request){
                $q->where('timeframe_id',$request->get('timeframe_id'));
            });
            $rounds = Round::where('timeframe_id',$request->get('timeframe_id'))->pluck('title', 'id')->toArray();
        }
        
        if($request->has('round_id') && $request->get('round_id') != null && $request->get('round_id') != ''){
            // $groupsQuery->where('round_id',$request->get('round_id'));
            $round = Round::with('timeframe.intervals')->find($request->get('round_id'));
            $examsApplicantsQuery->whereHas('group' ,function($q)use ($request){
                $q->where('round_id',$request->get('round_id'));
            });
            $daysData = $round->timeframe->days;
            $intervals = $round->timeframe->intervals->pluck('name', 'id')->toArray();
            
        }
        if($request->has('sub_round_id') && $request->get('sub_round_id') != null && $request->get('sub_round_id') != ''){
            $examsApplicantsQuery->whereHas('group' ,function($q) use ($request){
                $q->where('sub_round_id',$request->get('sub_round_id'));
            });
        }
        // if($groups != null && count($groups) > 0 && $request->has('branch_id') && $request->get('branch_id') != null && $request->get('branch_id') != ''){
        //     $groups->where('branch_id',$request->get('branch_id'));
        // }
        $examsApplicantCount = $examsApplicantsQuery->count();
        $examsApplicants = $examsApplicantsQuery->latest()->paginate($per_page);
        // return $examsApplicants;
        //dd(round(microtime(true) * 1000) - $testProcess);
        return view('exams_applicants.index', compact('employeeBranches','subRounds','courses','timeframes','rounds','stageLevels','groups','tracks','examsApplicants', 'examsApplicantCount'));
    }

    /**
     * Show the form for creating a new StudentExam.
     *
     * @return Response
     */
    public function create()
    {
        return view('exams_applicants.create');
    }

    /**
     * Store a newly created StudentExam in storage.
     *
     * @param CreateStudentExamRequest $request
     *
     * @return Response
     */
    public function store(CreateStudentExamRequest $request)
    {
        $input = $request->all();

        /** @var StudentExam $examsApplicant */
        $examsApplicant = StudentExam::create($input);

        Flash::success('Placement Applicant saved successfully.');

        return redirect(route('admin.examApplicants.index'));
    }

    /**
     * Display the specified StudentExam.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var StudentExam $examsApplicant */
        //$testProcess = round(microtime(true) * 1000);
        $applicant = StudentExam::find($id);

        if (empty($applicant)) {
            Flash::error('Exam Applicant not found');

            return redirect(route('admin.examApplicants.index'));
        }
        //dd(round(microtime(true) * 1000) - $testProcess);
        return view('exams_applicants.show')->with('applicant', $applicant);
    }

    /**
     * Show the form for editing the specified StudentExam.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var StudentExam $applicant */
        //$testProcess = round(microtime(true) * 1000);
        $applicant = StudentExam::with('answers','student')->find($id);

        if (empty($applicant)) {
            Flash::error('Placement Applicant not found');

            return redirect(route('admin.examApplicants.index'));
        }
        //dd(round(microtime(true) * 1000) - $testProcess);
        return view('exams_applicants.edit')->with('applicant', $applicant);
    }

    /**
     * Update the specified StudentExam in storage.
     *
     * @param int $id
     * @param Request $request
     *
     * @return Response
     */
    public function update($id, Request $request)
    {
        //dd($request->all());
        /** @var StudentExam $examsApplicant */
        $examsApplicant = StudentExam::find($id);
        
        if (empty($examsApplicant)) {
            Flash::error('Placement Applicant not found');
            return redirect(route('admin.examApplicants.index'));
        }

        $examsApplicant->fill($request->except('_method','_token','exam_status'));
        $examsApplicant->save();
        if($examsApplicant->course_id == 13 && $examsApplicant->level_id >= 112){
           $exam_per = ((( $examsApplicant->speaking_score + $examsApplicant->listening_score+$examsApplicant->evaluation_score) / 100) * 100);
           $student = $examsApplicant->student;
           $updated_data = array();
           $updated_data['exam_status'] = ($exam_per >= 70)?'pass':'fail';
        }else{
           $exam_per = ((($examsApplicant->vocabulary_score + $examsApplicant->grammar_score + $examsApplicant->reading_score + $examsApplicant->listening_score + $examsApplicant->speaking_score + $examsApplicant->writing_score+$examsApplicant->evaluation_score) / 100) * 100);
           $student = $examsApplicant->student;
           $updated_data = array();
           $updated_data['exam_status'] = ($exam_per >= 60)?'pass':'fail'; 
        }
        
      
        $updated_data['exam_per'] = number_format($exam_per,2);
        $customer_track = CustomerTrack::where('lead_id',$examsApplicant->lead_id)->first();
        $student->update($updated_data);
        
        
        $next_level=null;
        if($examsApplicant->course_id == 2 && $examsApplicant->level_id == 111)
        {
           $next_level = StageLevel::join('stages','stages.id','=','stage_levels.stage_id')
                   ->where('stages.track_id',13)->where('stage_levels.id','>',$student->group->level_id)
                   ->orderBy('stage_levels.id')->select('stage_levels.*','stages.track_id as level_course_id')->first();
        }else{
           $next_level = StageLevel::join('stages','stages.id','=','stage_levels.stage_id')
                            ->where('stages.track_id',$student->group->course_id)->where('stage_levels.id','>',$student->group->level_id)
                            ->orderBy('stage_levels.id')->select('stage_levels.*')->first();
        }
                
        $lead = Lead::find($examsApplicant->lead_id);
        if($student->exam_status != null && $student->exam_status != '' && $student->exam_status == "fail"){
            $lead->type = 2;
            $lead->customer_type = "fail";
            $lead->save();
            
            $waiting_list = new GroupWaitingList;
            $waiting_list->create([
                'lead_id' => $lead->id,
                'level_id' => $student->level_id,
                'track_id' => $student->group->track_id,
                'course_id' => $student->group->course_id,
                'timeframes' =>  $student->group->timeframe_id,
                'discipline_id' => $student->group->discipline_id,
            ]);
            // $lead = Lead::where('id',$lead->id)->first();
            $customer_track->last_group_id = null;
            $customer_track->last_level_id = $student->level_id;
            $customer_track->save();
            // transfer to customer and customer_type="fail" and add to waitinglist 
            // disabled save button and hidden edit button
            
        }else if($student->exam_status != null && $student->exam_status != '' && $student->exam_status == "pass"){
            if($customer_track->total > $customer_track->used){
                // transfer to next level and change the customer_type == "current"
                
                $lead->customer_type = "current";
                $lead->save();
                if($next_level != null){
                    $upgrade_group = Group::leftJoin('sub_rounds','sub_rounds.id','=','groups.sub_round_id')
                        ->where('groups.track_id',$student->group->track_id)
                        ->where('groups.course_id',$next_level->level_course_id)
                        ->where('groups.discipline_id',$student->group->discipline_id)
                        ->where('groups.timeframe_id',$student->group->timeframe_id)
                        ->where('groups.round_id',$student->group->round_id)
                        ->where('groups.level_id',$next_level->id)
                        ->where('groups.branch_id',$student->group->branch_id)
                        ->where('sub_rounds.end_date','>=',date('Y-m-d'))
                        ->where('parent_id',($student->group->parent_id != null && $student->group->parent_id != '')?$student->group->parent_id:$student->group->id)
                        ->orderBy('sub_rounds.start_date')->select('groups.*')->first();
                    
                    //dd($upgrade_group);
                    // return $student->group;
                    if(! ($upgrade_group != null && $upgrade_group != '')){
                            
                        $upgrade_group = Group::leftJoin('sub_rounds','sub_rounds.id','=','groups.sub_round_id')
                            ->where('groups.track_id',$student->group->track_id)
                            ->where('groups.course_id',$next_level->level_course_id)
                            ->where('groups.timeframe_id',$student->group->timeframe_id)
                            ->where('groups.round_id',$student->group->round_id)
                            ->where('groups.level_id',$next_level->id)
                            //->where('groups.days',$student->group->days)
                            ->where('sub_rounds.end_date','>=',date('Y-m-d'))
                            ->where('groups.discipline_id',$student->group->discipline_id)
                            ->where('groups.branch_id',$student->group->branch_id)
                            //->where('instructor_id',$student->group->instructor_id)
                            //->where('interval_id',$student->group->interval_id)
                            //->where('parent_id',($student->group->parent_id != null && $student->group->parent_id != '')?$student->group->parent_id:$student->group->id)
                            
                            ->orderBy('sub_rounds.start_date')->select('groups.*')->first();
                    }
                    //dd($upgrade_group);
                    $check_group_student = GroupStudent::where('level_id',$next_level->id)->where('lead_id',$lead->id)->first();
                    $current_group_student = GroupStudent::where('group_id',$student->group->id)->where('lead_id',$lead->id)->first();
                    if($upgrade_group != null && $upgrade_group != ''){
                        if($examsApplicant->course_id == 2 && $examsApplicant->level_id == 111)
                        {
                            $customer_track->course_id = 13;
                            $customer_track->level_id = 112;
                            $customer_track->save();
                        }
                      $sessions = GroupSession::with('level')->where('group_id', $upgrade_group->id)->get();
                        if(! $check_group_student){
                            $group_student = GroupStudent::create([
                                'group_id' => $upgrade_group->id,
                                'lead_id' => $lead->id,
                                'level_id' => $next_level->id,
                                'payment' => $current_group_student->payment,
                                'lead_payment_id' => $current_group_student->lead_payment_id,
                                'Confirmation'=>1,
                                'finance_status'=>1,
                            ]);
                           
                            foreach ($sessions as $session) {
                                $session->attendances()->create([
                                    'lead_id' => $lead->id,
                                    'group_id' => $session->group_id,
                                    'level_id' => $session->level_id,
                                ]);
                                
                            }
                            
                            if($upgrade_group->course_id == 13)
                            {
                                // create student exam
                                $student_exam = StudentExam::create([
                                    'group_id' => $upgrade_group->id,
                                    'lead_id' => $lead->id,
                                    'track_id' => $upgrade_group->track_id,
                                    'course_id' => $upgrade_group->course_id,
                                    'level_id' => $next_level->id,
                                    'student_id' => $group_student->id,
                                    'finish'=>1,
                                ]);
                                
                            }
                            // $lead = Lead::where('id',$lead->id)->first();
                            $customer_track->last_group_id = $upgrade_group->id;
                            $customer_track->last_level_id = $next_level->id;
                            $customer_track->used += 1;
                            $customer_track->save();
                            // $customer_track->save();
                        }
                        
                    }
                }
        
            }
            else{
                // transfer to customer and customer_type="activation" and add to waitinglist in a next level
                $lead->type = 2;
                $lead->customer_type = "activation";
                $lead->save(); 
                
                $customer_track->last_group_id = null;
                $customer_track->last_level_id = $student->level_id;
                $customer_track->save(); 
                
                $waiting_list = new GroupWaitingList;
                $waiting_list->create([
                    'lead_id' => $lead->id,
                    'level_id' => $next_level->id,
                    'track_id' => $student->group->track_id,
                    'course_id' => $student->group->course_id,
                    'timeframes' =>  $student->group->timeframe_id,
                    'discipline_id' => $student->group->discipline_id,
                ]);
            }
        }
        
         activity('Exam Student')
           ->causedBy(Auth::user()->id)
           ->performedOn($student)
           ->withProperties(['group_id' =>$student->group_id ])
           ->log('Update Exam Application');
        
        Flash::success('Exam Applicant updated successfully.');

        return redirect(route('admin.examApplicants.index'));
    }

    /**
     * Remove the specified StudentExam from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var StudentExam $examsApplicant */
        $examsApplicant = StudentExam::find($id);

        if (empty($examsApplicant)) {
            Flash::error('Exam Applicant not found');

            return redirect(route('admin.examApplicants.index'));
        }

        
        
         activity('Exam Student')
           ->causedBy(Auth::user()->id)
           ->performedOn($examsApplicant)
           ->withProperties(['group_id' =>$examsApplicant->group_id ])
           ->log('Delete Exam Application');

        Flash::success('Exam Applicant deleted successfully.');
        $examsApplicant->delete();
        return redirect(route('admin.examApplicants.index'));
    }

    /**
     * Display the specified StudentExam.
     *
     * @param int $id
     *
     * @return Response
     */
    
}
