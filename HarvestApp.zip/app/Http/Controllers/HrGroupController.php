<?php

namespace App\Http\Controllers;
use App\Models\HrGroups;
use App\Models\HrGroupSession;
use App\Models\Department;
use App\Models\Employee;
use App\Models\JobApplication;
use App\Models\HrGroupTrainee;
use Flash;
use Illuminate\Http\Request;

class HrGroupController extends Controller
{
    //
    public function index(Request $request)
    {
         $Groups = HrGroups::withcount('hr_group_trainee')->orderBy('created_at','desc');
         $departments= Department::pluck('title','id')->toArray();
         $trainer=[];
         $daterange_from = null;
         $daterange_to = null;
         $reg_to=null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            
            $daterange = explode(' - ',$request->get('daterange'));
            $daterange_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $daterange_to= date_format($reg_to,"Y-m-d");
            
        }
        
        if($request->has('department_id') && $request->get('department_id') != '' && $request->get('department_id') != null){
            $Groups = $Groups->where('department_id',$request->get('department_id'));
            
        }
        if($request->has('trainer_id') && $request->get('trainer_id') != '' && $request->get('trainer_id') != null){
            $Groups = $Groups->where('trainer_id',$request->get('trainer_id'));
            $trainer = Employee::find($request->get('trainer_id'));
        }
          if ($daterange_from != null && $daterange_to != '') {
            $Groups->whereBetween('created_at', [$daterange_from, $daterange_to]);
        }
         $Groups = $Groups->get();
        return view('HrGroup.index',compact('Groups','departments','trainer'));
    }
    public function show($id){
        $groups = HrGroups::with('hr_group_session')->find($id);
       
        return view('HrGroup.show',compact('groups'));
    }
    public function create(Request $request){
        $departments = Department::pluck('title','id')->toArray();
        $trainer=[];
        return view('HrGroup.create',compact('departments','trainer'));
    }
    public function store(Request $request){
        // dd($request->all());
        $groups = new HrGroups;
        $groups->department_id = $request->department_id;
        $groups->trainer_id =  $request->trainer_id;
        $groups->start_date = $request->start_date;
        $groups->end_date = $request->end_date;
        $groups->time_from = $request->time_from;
        $groups->time_to = $request->time_to;
        $groups->session_count = $request->session_count;
        $groups->status = $request->status;
        $groups->save();
        
        for($i =0 ;$i < $groups->session_count ; $i++){
        $hr_group_session = new HrGroupSession;
        $hr_group_session->hr_group_id   = $groups->id;
        $hr_group_session->trainer_id = $groups->trainer_id;
        $hr_group_session->date = $request->sessions_dates[$i];
        $hr_group_session->save();
        }
        Flash::success(' Group Create successfully.');
        
         return redirect(route('admin.HrGroup.index'));
        
    }
    public function edit($id,Request $request){
         $group = HrGroups::with('hr_group_session')->find($id);
        //  $group_session = HrGroupSession::where('hr_group_id',$group->id)->get();
        $departments = Department::pluck('title','id')->toArray();
        $trainer = Employee::where('status',1)->where('department_id',$group->department_id)->get()->pluck('name','id')->toArray();  
        return view('HrGroup.edit',compact('group','trainer','departments'));
    }
    public function update($id , Request $request){
         $groups = HrGroups::find($id);      
         $hr_group_session = HrGroupSession::where('hr_group_id',$groups->id)->get();
     
        $groups->department_id = $request->department_id;
        $groups->trainer_id =  $request->trainer_id;
        $groups->start_date = $request->start_date;
        $groups->end_date = $request->end_date;
        $groups->time_from = $request->time_from;
        $groups->time_to = $request->time_to;
        $groups->session_count = $request->session_count;
        $groups->status = $request->status;
        $groups->save();
        
        foreach($hr_group_session as $key => $session){
        
        $hr_group_session[$key]->date = $request->sessions_dates[$key];
        $hr_group_session[$key]->save();
        }
        Flash::success('Group  updated successfully.');
         return redirect(route('admin.HrGroup.index'));
           
    }
    public function destroy($id){
        $group = HrGroups::find($id);
        $group->delete();
        Flash::success(' Group Deleted successfully.');
    
        return redirect(route('admin.HrGroup.index'));
        
        
    }
    
    public function gettrainer(Request $request)
    {
       
        $trainers=[];
        $trainers = Employee::where('status',1)->where('department_id',$request->department_id)->select('first_name', 'last_name','id')->get();       
        
        return $trainers;
    
    }
     public function gettrainee(Request $request)
    {
        $group = HrGroups::with('hr_group_session')->find($request->group_id);
        $tarinees = JobApplication::where('status',1)->get();
        $html = '<option></option>';
        foreach($tarinees as $tarinee){
            $html .= '<option value="'.$tarinee->id.'">'.$tarinee->full_name.' / '.$tarinee->phone.' / '.$tarinee->phone2.' / '.$tarinee->email.'</option>';
        }
        
        return response()->json(['html' => $html]);
    }
     public function addtrainee(Request $request)
    {
        
        $group = HrGroups::with('hr_group_session')->find($request->group_id);
        
        $trainee_ids = $request->trainee;
        if (count($trainee_ids) == 0) {
            Flash::error("The trainees field is required.");
            return redirect()->back();
        }
       
        $lists = JobApplication::where('status',1)->whereIn('id', $trainee_ids)->get();
        $mobiles = [];
        foreach ($lists as $list) {
            $sessions = HrGroupSession::where('hr_group_id', $group->id)->get();
            foreach ($sessions as $key=>$session) {
                $session->hr_group_session_attendance()->create([
                    'hr_group_id' => $group->id,
                    'hr_group_session_id' => $session->id,
                    'job_application_id' => $list->id,
                ]);
            }
             $list->update(['status' => 2]);
            $grouptrainee = new HrGroupTrainee;
            $grouptrainee->hr_group_id = $group->id;
            $grouptrainee->job_application_id = $list->id;
            $grouptrainee->save();
        }
        
        Flash::success('Added trainee to group Successfully.');
        return redirect()->back();

    }
    
    
}
