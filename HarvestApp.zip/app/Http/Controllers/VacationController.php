<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\Vacation;
use App\Models\VacationHistory;
use Illuminate\Http\Request;
use Flash;
use Auth;
use DB;
use Carbon\Carbon;
class VacationController extends Controller
{
    public function viewEmployeeVacation($id){
        $vacations=Vacation::where('employee_id',$id)->orderBy('id', 'DESC')->latest()->paginate(10);
        $vacationsCount = $vacations->count();
         
        return view('vacation.index')
            ->with('vacations', $vacations)->with('employee_id',$id)->with('vacationsCount',$vacationsCount);
    }
    public function sendEmployeeVacation(Request $request){
        $id = $request->id;
        $vacations=Vacation::where('employee_id',$id)->orderBy('id', 'DESC')->get();
        echo json_encode($vacations);
    }
    public function addvacation(){
        // return Carbon::now()->format('Y');
        return view('vacation.create');
    }
    public function storeVacation(Request $request){

        $validator = $request->validate([
                'annual' => 'required | numeric | min:0',
                'casual' => 'required | numeric | min:0',
                'sick' => 'required | numeric | min:0',
                'year' => 'required | numeric | min:2021'
            ]
        );
        
        $allEmployee=Employee::where('status',1)->get();
        
        foreach ($allEmployee as $employee){
            
            $newVacation = Vacation::updateOrCreate([
                'employee_id'=>$employee->id,
                'annual'=>$request->annual,
                'casual'=>$request->casual,
                'sick'=>$request->sick,
                'year'=>$request->year,
                ],[
                    'year'=>$request->year,
                ]);
        }

        Flash::success('Employee Vacation saved successfully.');
        return redirect(route('admin.vacation.getRequested'));
    }
    public function edit($id){
        $vacation=Vacation::find($id);
        return view('vacation.edit')->with('vacation',$vacation);
    }


    public function updateVacation(Request $request,$id){

        $validator = $request->validate([
                'annual' => 'required | numeric | min:0',
                'casual' => 'required | numeric | min:0',
                'sick' => 'required | numeric | min:0'
            ]
        );
        $isOldVacation=Vacation::where('employee_id',$id)->where('year',$request->year)->first();

        $newVacation=Vacation::find($id);
        if (! $newVacation){
            Flash::error('Vacation not found');
            return redirect()->back();
        }
        $newVacation->annual =$request->annual ;
        $newVacation->casual =$request->casual;
        $newVacation->sick =$request->sick ;
        $newVacation->save();
        Flash::success('Employee vacation updated successfully.');
        return redirect(route('admin.employees.index'));
        // return redirect(route('admin.vacation.view',$newVacation->employee_id));
    }


    public function getVacationHistory(){
        
          $employeedepartment =auth()->user();
         $department_manager = DB::table('department_managers')->where('department_id',$employeedepartment->department_id)->first();
         $allVacationHistory = VacationHistory::with('employee','department'); 
        
        // show all agents and esl to BM
        if($employeedepartment->job_id == 20)
        {
           $allVacationHistory->whereHas('employee', function ($query) use($employeedepartment) {
                                $query->whereIn('job_id',[8,22,21])->where('current_branch', $employeedepartment->current_branch); 
                            });
        }
        // Show all Bm and esl to Area Manager
        elseif($employeedepartment->job_id == 19){
            $allVacationHistory->whereHas('employee', function ($query)use($employeedepartment)  {
                                $query->whereIn('job_id',[20,8]);
                            });
        }
        // show all cc cs to cc supervisior
        elseif($employeedepartment->job_id == 6){
            $allVacationHistory->whereHas('employee', function ($query)use($employeedepartment)  {
                                $query->where('job_id',7);
                            });
        }
        // show all marketing agents to Marketing Manager
        elseif($employeedepartment->job_id == 35){
            $allVacationHistory->whereHas('employee', function ($query)use($employeedepartment)  {
                                $query->whereIn('job_id',[37,38,46,47]);
                            });
        }
        // show all Hr Agents To Hr Manager
        elseif($employeedepartment->job_id == 43){
            $allVacationHistory->whereHas('employee', function ($query)use($employeedepartment)  {
                                $query->whereIn('job_id',[41,32,33,34]);
                            });
        }
        // Show all finance agents to finance manager
        elseif($employeedepartment->job_id == 49){
            $allVacationHistory->whereHas('employee', function ($query)use($employeedepartment)  {
                                $query->whereIn('job_id',[30,31]);
                            });
        }
        // show all it to it manager
        elseif($employeedepartment->job_id == 48){
            $allVacationHistory->whereHas('employee', function ($query)use($employeedepartment)  {
                                $query->where('job_id',42);
                            });
        }
        // show all Esl to Technical Head
        elseif($employeedepartment->job_id == 45){
            $allVacationHistory->whereHas('employee', function ($query)use($employeedepartment)  {
                                $query->whereIn('job_id',[8,10,9,27]);
                            });
        }
        // show all employees to ceo , office manger and hr manager 
        elseif($employeedepartment->job_id == 15 ||$employeedepartment->job_id == 16 || $employeedepartment->job_id == 43 || $employeedepartment->job_id == 40 ){
            
            $allVacationHistory->whereNotNull('status'); 
        }else{
            $allVacationHistory->where('employee_id' ,$employeedepartment->id); 
        }
         $allVacationHistorys = $allVacationHistory->orderBy('created_at' , 'DESC')->get();
        // $allVacationHistory=VacationHistory::with('employee')->orderBy('id', 'DESC')->get();
        return view('vacation.history',compact('allVacationHistorys'));
    }
    public function chengStatusVacationHistory($id,$status){

        $vacationHistory=VacationHistory::find($id);
        $vacation=Vacation::find($vacationHistory->vacations_id);
        $vacationHistory->status=$status;
        if ($status != 'refuse'){
            $vacation[$vacationHistory->type]=$vacation[$vacationHistory->type] - $vacationHistory->days;
            $vacation->save();
        }
        $vacationHistory->save();
        Flash::success('Cheng vacation status successfully.');
        return redirect()->back();
    }
    public function confirmmanger($id,$confirm){

        $vacationHistory=VacationHistory::find($id);
        $vacationHistory->confirm_mang = $confirm;
        $vacationHistory->confirmed_by_id = auth()->user()->id;
        
        $vacationHistory->save();
        Flash::success('Confirm Manager vacation status successfully.');
        return redirect()->back();
    }
    
}
