<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Flash;

class AuthInstructorController extends Controller
{
    public function login()
    {
        return view('auth.instructor_login');
    }

    public function postLogin(Request $request)
    {
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        if(auth()->attempt($credentials)){
            return redirect(route('instructor.home'));
        }

        Flash::error(__('auth.failed'));
        return back();
    }

    public function logout()
    {
        auth()->logout();

        return redirect(route('instructor.login'));
    }
}
