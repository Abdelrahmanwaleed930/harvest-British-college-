<?php

namespace App\Http\Controllers;

use App\Models\SafeType;
use App\Models\PaymentMethod;
use Illuminate\Http\Request;
use Flash;
use Illuminate\Support\Facades\Auth;
use \DateTime;
use File;

class SafeTypeController extends Controller
{
    public function index()
    {
        $allSafeType = SafeType::get();
        return view('safes_types.index')->with('allSafeType', $allSafeType);
    }
    public function create()
    {
        $allSafeType = SafeType::pluck('name','id');
        return view('safes_types.create')->with('allSafeType', $allSafeType);
    }

    public function store(Request $request)
    {

        $validator = $request->validate(
            [
                'name' => 'required',
                'parent_id' => 'nullable',
            ]
        );

        $newSafeType = new SafeType();
        $newSafeType->name = $request->name;
        $newSafeType->parent_id = $request->parent_id;
        $newSafeType->save();
        Flash::success('Safe Type saved successfully.');

        return redirect(route('admin.safes_types.index'));
    }
    public function edit($id)
    {
        $safetype = SafeType::find($id);
        $allSafeType = SafeType::pluck('name','id');
        return view('safes_types.edit')->with('allSafeType', $allSafeType)->with('safetype', $safetype);
    }


    public function update(Request $request, $id)
    {

        $validator = $request->validate(
            [
                'name' => 'required',
                'parent_id' => 'nullable',
            ]
        );

        $SafeType = SafeType::find($id);
        if (!$SafeType) {
            Flash::error('SafeType not found');
            return redirect()->back();
        }
        $SafeType->name = $request->name;
        $SafeType->parent_id = $request->parent_id;
        $SafeType->save();
        Flash::success('SafeType Type updated successfully.');
        return redirect(route('admin.safes_types.index'));
    }
}