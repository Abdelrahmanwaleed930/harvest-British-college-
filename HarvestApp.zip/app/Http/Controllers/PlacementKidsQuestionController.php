<?php

namespace App\Http\Controllers;

use App\Http\Controllers\AppBaseController;
use App\Models\PlacementKidsQuestion;
use App\Models\PlacementKidsAnswer;
use App\Models\Track;
use Illuminate\Http\Request;
use Flash;
use Response;

class PlacementKidsQuestionController extends AppBaseController
{
    /**
     * Display a listing of the PlacementKidsQuestion.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        $per_page = 10;
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id');
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        /** @var PlacementKidsQuestion $placementQuestions */
        $placementQuestionsQuery = PlacementKidsQuestion::whereNotIn('id', function ($query) {
            $query->select('id')->from('placement_kids_questions')
                ->where('skill', 'Writing')->whereNotNull('parent_id');
        });
        
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $placementQuestionsQuery->where('question','like','%'.$request->get('search').'%');
        }
        if($request->has('skill') && $request->get('skill') != null && $request->get('skill') != ''){
            $placementQuestionsQuery->where('skill', $request->get('skill'));
        }
        if($request->has('track_id') && $request->get('track_id') != null && $request->get('track_id') != ''){
            $placementQuestionsQuery->where('track_id', $request->get('track_id'));
        }
        $placementQuestionsCount = $placementQuestionsQuery->count();
        $placementQuestions = $placementQuestionsQuery->orderBy('id','desc')->paginate($per_page);
        return view('placement_kids_questions.index')
            ->with('placementQuestions', $placementQuestions)
            ->with('placementQuestionsCount',$placementQuestionsCount)
            ->with('tracks',$tracks);
    }

    /**
     * Show the form for creating a new PlacementKidsQuestion.
     *
     * @return Response
     */
    public function create()
    {
        $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id');
        $readingparagraphs = PlacementKidsQuestion::whereNull('parent_id')->where('skill', 'Reading')->get()->pluck('paragraph', 'id');
    
        $listeningparagraphs = PlacementKidsQuestion::whereNull('parent_id')->where('skill', 'Listening')->get()->pluck('paragraph', 'id');
        
        return view('placement_kids_questions.create',compact('readingparagraphs','listeningparagraphs','tracks'));
    }
    
    public function store(Request $request){
        
         $credentials = $request->validate([
            'skill' => 'required',
            'track_id' => 'required',
            'question' => 'required',
            'photo'=>'nullable|image',
            'parent_id' => 'nullable',
            
        ]);
        if($request->skill == 'Vocabulary' || $request->skill == 'Grammar')
        {
            $request->validate([
                'answers' => 'required|array',
                'is_correct'=>'required'
            ]);
        }
        if(($request->skill == 'Reading' || $request->skill == 'Listening') && $request->parent_id != null)
        {
            $request->validate([
                'answers' => 'required|array|between:2,4',
                'is_correct'=>'required'
            ]);
        }
        
        
        if( $request->skill == 'Listening' && $request->photo != null)
        {
            $request->validate([
                'mp3' => 'mimes:mp3',
            ]);
        }
         
        if ($request->photo != null) {
            $file = $request->photo->store('/');
            $request->photo = $file;
            if (env('APP_ENV') == 'production') {
                rename(storage_path('app/' . $file), '/home/harvestc/public_html/testsys/uploads/' . $file);
            } else {
                rename(storage_path('app/' . $file), public_path('uploads/' . $file));
            }
        }
        if ($request->mp3 != null) {
            $file = $request->mp3->store('/');
            $request->mp3 = $file;
            if (env('APP_ENV') == 'production') {
                rename(storage_path('app/' . $file), '/home/harvestc/public_html/testsys/uploads/' . $file);
            } else {
                rename(storage_path('app/' . $file), public_path('uploads/' . $file));
            }
        }
        $placementQuestion =new  PlacementKidsQuestion;
        $placementQuestion->skill = $request->skill;
        $placementQuestion->track_id = $request->track_id;
        $placementQuestion->question = $request->question;
        $placementQuestion->photo = $request->photo;
        if($request->skill == 'Reading'){
           $placementQuestion->parent_id = $request->parent_idr;
        }elseif($request->skill == 'Listening'){
           $placementQuestion->parent_id = $request->parent_idl;
            
        }
        $placementQuestion->save();
        

        // if ($request->skill == 'Writing') {
        //     foreach ($request->ideas as $idea) {
        //         PlacementQuestion::create([
        //             'skill' => 'Writing',
        //             'parent_id' => $placementQuestion->id,
        //             'question' => $idea
        //         ]);
        //     }
        // }
        if (isset($request->answers)) {
            foreach ($request->answers as $key => $answer) {
                if($answer !='' && $answer != null){
                PlacementKidsAnswer::create([
                    'placement_question_id' => $placementQuestion->id,
                    'answer' => $answer,
                    'is_correct' => $request->is_correct == $key,
                ]);
                    
                }
            }
        }

        Flash::success('Kids Placement Question saved successfully.');
        
        return redirect(route('admin.kidsPlacementQuestions.index'));
        
    }

    /**
     * Display the specified PlacementKidsQuestion.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var PlacementKidsQuestion $placementQuestion */
        $placementQuestion = PlacementKidsQuestion::find($id);

        if (empty($placementQuestion)) {
            Flash::error('Placement Question not found');

            return redirect(route('admin.kidsPlacementQuestions.index'));
        }

        return view('placement_kids_questions.show')->with('placementQuestion', $placementQuestion);
    }

    /**
     * Show the form for editing the specified PlacementKidsQuestion.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var PlacementKidsQuestion $placementQuestion */
        $placementQuestion = PlacementKidsQuestion::with('answers')->find($id);
        $readingparagraphs = PlacementKidsQuestion::whereNull('parent_id')->where('skill', 'Reading')->get()->pluck('paragraph', 'id');
        $listeningparagraphs = PlacementKidsQuestion::whereNull('parent_id')->where('skill', 'Listening')->get()->pluck('paragraph', 'id');
         $tracks = Track::where('status',1)->whereNull('parent_id')->pluck('title', 'id');

        if (empty($placementQuestion)) {
            Flash::error('Placement Question not found');

            return redirect(route('admin.kidsPlacementQuestions.index'));
        }

        return view('placement_kids_questions.edit', compact('placementQuestion','readingparagraphs','listeningparagraphs'));
    }
    public function update(Request $request , $id)
    {
        $placementQuestion = PlacementKidsQuestion::find($id);
         $credentials = $request->validate([
            'question' => 'required',
            'track_id' => 'required',
            'photo'=>'nullable|image',
            'parent_id' => 'nullable',
            
        ]);
        if($request->skill == 'Vocabulary' || $request->skill == 'Grammar')
        {
            $request->validate([
                'answers' => 'required|array',
                'is_correct'=>'required'
            ]);
        }
        if(($request->skill == 'Reading' || $request->skill == 'Listening') && $request->parent_id != null)
        {
            $request->validate([
                'answers' => 'required|array|between:2,4',
                'is_correct'=>'required'
            ]);
        }
        
        
        if( $request->skill == 'Listening' && $request->photo != null)
        {
            $request->validate([
                'mp3' => 'mimes:mp3',
            ]);
        }
         
        if ($request->photo != null) {
            $file = $request->photo->store('/');
            $request->photo = $file;
            if (env('APP_ENV') == 'production') {
                rename(storage_path('app/' . $file), '/home/harvestc/public_html/testsys/uploads/' . $file);
            } else {
                rename(storage_path('app/' . $file), public_path('uploads/' . $file));
            }
        }
        else{
           $request->photo = $placementQuestion->photo;
        }
        if ($request->mp3 != null) {
            $file = $request->mp3->store('/');
            $request->mp3 = $file;
            if (env('APP_ENV') == 'production') {
                rename(storage_path('app/' . $file), '/home/harvestc/public_html/testsys/uploads/' . $file);
            } else {
                rename(storage_path('app/' . $file), public_path('uploads/' . $file));
            }
        }else{
            $request->mp3 = $placementQuestion->mp3;
        }
        

        $placementQuestion->question = $request->question;
        $placementQuestion->photo = $request->photo;
        $placementQuestion->parent_id = $request->parent_id;
        $placementQuestion->track_id = $request->track_id;
        $placementQuestion->save();
        

        
         $ptanswers = PlacementKidsAnswer::where('placement_question_id' ,$placementQuestion->id)->get();

        // if ($request->skill == 'Writing') {
        //     foreach ($ptanswers as $key => $answer) {
        //         $ptanswers[$key]->answer = $request->ideas[$key];
        //         $ptanswers[$key]->save();
        //     }
            
        // }
        // dd( $request->is_correct);
            foreach($ptanswers as $key => $answer){
             $ptanswers[$key]->answer = $request->answers[$key];
             $ptanswers[$key]->is_correct = $request->is_correct == $key;
             $ptanswers[$key]->save();
            }
            


        Flash::success('Kids Placement Question Updated successfully.');
        
        return redirect(route('admin.kidsPlacementQuestions.index'));
    }

    /**
     * Remove the specified PlacementKidsQuestion from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var PlacementKidsQuestion $placementQuestion */
        $placementQuestion = PlacementKidsQuestion::find($id);

        if (empty($placementQuestion)) {
            Flash::error('Placement Question not found');

            return redirect(route('admin.kidsPlacementQuestions.index'));
        }

        $placementQuestion->delete();

        Flash::success('Placement Question deleted successfully.');

        return redirect(route('admin.kidsPlacementQuestions.index'));
    }
}
