<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateWHItemCategoryRequest;
use App\Http\Requests\UpdateWHItemCategoryRequest;
use App\Http\Controllers\AppBaseController;
use App\Models\WHItemCategory;
use Illuminate\Http\Request;
use Flash;
use Response;

class WHItemCategoryController extends AppBaseController
{
    /**
     * Display a listing of the WHItemCategory.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var WHItemCategory $itemCategories */
        $itemCategories = WHItemCategory::all();

        return view('wh_item_categories.index')
            ->with('itemCategories', $itemCategories);
    }

    /**
     * Show the form for creating a new WHItemCategory.
     *
     * @return Response
     */
    public function create()
    {
        return view('wh_item_categories.create');
    }

    /**
     * Store a newly created WHItemCategory in storage.
     *
     * @param CreateWHItemCategoryRequest $request
     *
     * @return Response
     */
    public function store(CreateWHItemCategoryRequest $request)
    {
        $input = $request->all();

        /** @var WHItemCategory $itemCategory */
        $itemCategory = WHItemCategory::create($input);

        Flash::success('Warehouse Item Category saved successfully.');

        return redirect(route('admin.whItemCategories.index'));
    }

    /**
     * Display the specified WHItemCategory.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var WHItemCategory $itemCategory */
        $itemCategory = WHItemCategory::find($id);

        if (empty($itemCategory)) {
            Flash::error('Warehouse Item Category not found');

            return redirect(route('admin.whItemCategories.index'));
        }

        return view('wh_item_categories.show')->with('itemCategory', $itemCategory);
    }

    /**
     * Show the form for editing the specified WHItemCategory.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var WHItemCategory $itemCategory */
        $itemCategory = WHItemCategory::find($id);

        if (empty($itemCategory)) {
            Flash::error('Warehouse Item Category not found');

            return redirect(route('admin.whItemCategories.index'));
        }

        return view('wh_item_categories.edit')->with('itemCategory', $itemCategory);
    }

    /**
     * Update the specified WHItemCategory in storage.
     *
     * @param int $id
     * @param UpdateWHItemCategoryRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateWHItemCategoryRequest $request)
    {
        /** @var WHItemCategory $itemCategory */
        $itemCategory = WHItemCategory::find($id);

        if (empty($itemCategory)) {
            Flash::error('Warehouse Item Category not found');

            return redirect(route('admin.whItemCategories.index'));
        }

        $itemCategory->fill($request->all());
        $itemCategory->save();

        Flash::success('Warehouse Item Category updated successfully.');

        return redirect(route('admin.whItemCategories.index'));
    }

    /**
     * Remove the specified WHItemCategory from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var WHItemCategory $itemCategory */
        $itemCategory = WHItemCategory::find($id);

        if (empty($itemCategory)) {
            Flash::error('Warehouse Item Category not found');

            return redirect(route('admin.whItemCategories.index'));
        }

        $itemCategory->delete();

        Flash::success('Warehouse Item Category deleted successfully.');

        return redirect(route('admin.whItemCategories.index'));
    }
}
