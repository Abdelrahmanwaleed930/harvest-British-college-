<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\MonitoringSections;
use Flash;

class MonitoringSectionsController extends Controller
{
    //
    public function index(){
        $monitoringsections = MonitoringSections::get();
        
        return view('MonitoringSections.index',compact('monitoringsections')); 
    }
    public function create(){
        $monitoringsections = MonitoringSections::get();
        
        return view('MonitoringSections.create',compact('monitoringsections')); 
    }
    public function store(Request $request ){
        
          $credentials = $request->validate([
            'title' => 'required',
            'description' => 'required',
        ]);
        $monitoringsections = new MonitoringSections;
        $monitoringsections->title = $request->title;
        $monitoringsections->description = $request->description;
        $monitoringsections->save();
        
        Flash::success('Monitor Section created successfully.');
        return redirect()->back(); 
    }
    public function edit($id){
        $monitoringsections = MonitoringSections::find($id);
        
        return view('MonitoringSections.update',compact('monitoringsections')); 
    }
    public function update($id , Request $request){
        $monitoringsections = MonitoringSections::find($id);
        $credentials = $request->validate([
            'title' => 'required',
            'description' => 'required',
        ]);
        $monitoringsections->title = $request->title;
        $monitoringsections->description = $request->description;
        
        $monitoringsections->save();
        
        Flash::success('Monitor Section updated successfully.');
        return redirect()->back(); 
    }
    
    public function destroy($id){
        $monitoringsections = MonitoringSections::find($id);
        $monitoringsections->delete();
        Flash::success('Monitor Section deleted successfully.');
        return redirect()->back(); 
        
    }
    
}
