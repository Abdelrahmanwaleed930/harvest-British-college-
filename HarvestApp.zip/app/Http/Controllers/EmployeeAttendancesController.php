<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\EmployeeAttendances;
use App\Models\EmployeeFingerPrint;
use App\Models\Employee;

use Flash;
use Response;
use Carbon\Carbon;
use DB;
use Auth;
use App\Imports\Finger;
use Maatwebsite\Excel\Facades\Excel;
use Spatie\Activitylog\Contracts\Activity;

class EmployeeAttendancesController extends Controller
{
    public function index(Request $request){
        // $max_time = '14:05:00';
        // $min_time = '9:01:00';
        // $diff= strtotime($max_time) - strtotime($min_time);
        // return $all= date('H:i:s', $diff);

        
        $EmployeeAttendance = EmployeeAttendances::with('employee');
        $Employees = Employee::where('status',1)->get()->pluck('name','id');
        
        $registration_from = null;
        $registration_to = null;
        $today = date('Y-m-d');
         $firstDayOfMonth = date('Y-m-01');
        $lastDayOfMonth = date('Y-m-t');
    
        if ($request->has('register_daterange') && $request->get('register_daterange') != null && $request->get('register_daterange') != '') {
            $daterange = explode(' - ', $request->get('register_daterange'));
            $registration_from = date_format(date_create($daterange[0]), 'Y-m-d');
            $reg_to = date_create($daterange[1]);
            date_add($reg_to, date_interval_create_from_date_string("1 days"));
            $registration_to = date_format($reg_to, "Y-m-d");
        }
        // return $registration_from;
        if ($registration_from != null && $registration_to != '') {
            
            // $EmployeeAttendance->whereBetween('date', [$registration_from, $registration_to])->get();
            $EmployeeAttendance->whereBetween('date',[$registration_from , $registration_to]);
        }
        if($request->has('employee_id') && $request->get('employee_id') != null && $request->get('employee_id') != ''){
            $EmployeeAttendance->where('employee_id',$request->get('employee_id'));
        }
           $EmployeeAttendances = $EmployeeAttendance->paginate(10);
        return view('EmployeeAttendances.index',compact('EmployeeAttendances','Employees'));
        
    }  
    public function attendaction(Request $request){
        // dd($request->action , $request->ids);
        if (!$request->action) {
            Flash::error('Select Data is required.');
        } elseif ($request->ids != null && count($request->ids) > 0) {
            $EmployeeAttendances = EmployeeAttendances::whereIn('id', $request->ids)->get();
            foreach($EmployeeAttendances as $attend){
                $attend->update(['status' => $request->action]);
                    
            }
            Flash::success('Assigned Successfully.');
        } else {
            Flash::error('Selected Employees is required.');
        }
        return 0;
    }
}
