<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateWHTransferedItemRequest;
use App\Http\Requests\UpdateWHTransferedItemRequest;
use App\Http\Controllers\AppBaseController;
use App\Models\WHItem;
use App\Models\WHUsedItem;
use App\Models\WHTransferedItem;
use App\Models\WHItemCategory;
use App\Models\Place;
use Illuminate\Http\Request;
use Flash;
use Response;

class WHTransferedItemController extends AppBaseController
{
    /**
     * Display a listing of the WHTransferedItem.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var WHTransferedItem $transfered_items */
        $categories = WHItemCategory::all()->pluck('name','id');
        $wh_items = WHItem::select('id','name','item_category_id')->get();
        $wh_items = $wh_items->groupBy('item_category_id');
        $places = auth()->user()->places->pluck('name', 'id')->toArray();
        
        $transferedItemsQuary = new WHTransferedItem;
        $per_page = 10;
        
        if($request->per_page && $request->per_page){
            $per_page = $request->per_page;
        }
        if($request->item_category_id && $request->item_category_id){
            $transferedItemsQuary->where('item_category_id',$request->item_category_id);
        }
        if($request->item_id && $request->item_id){
            $transferedItemsQuary->where('item_id',$request->item_id);
        }
        if($request->from_place_id && $request->from_place_id){
            $transferedItemsQuary->where('from_place_id',$request->from_place_id);
        }
        if($request->to_place_id && $request->to_place_id){
            $transferedItemsQuary->where('to_place_id',$request->to_place_id);
        }
        $counttransfered_items = $transferedItemsQuary->count();
        $transfered_items = $transferedItemsQuary->paginate($per_page);

        return view('wh_transfered_items.index',compact('transfered_items','counttransfered_items','categories','wh_items','places'));
    }

    /**
     * Show the form for creating a new WHTransferedItem.
     *
     * @return Response
     */
    public function create()
    {
        $categories = WHItemCategory::all()->pluck('name','id');
        $wh_items = WHItem::select('id','name','item_category_id')->get();
        $wh_items = $wh_items->groupBy('item_category_id');
        $places = auth()->user()->places->pluck('name', 'id')->toArray();
        
        return view('wh_transfered_items.create',compact('categories','wh_items','places'));
    }

    /**
     * Store a newly created WHItem in storage.
     *
     * @param CreateWHItemRequest $request
     *
     * @return Response
     */
    public function store(CreateWHTransferedItemRequest $request)
    {
        $input = $request->all();
        //dd($input);
        $check_from_items = WHUsedItem::where('item_category_id',$request->item_category_id)
                                      ->where('item_id',$request->item_id)
                                      ->where('place_id',$request->from_place_id)
                                      ->where('balance','>',0)->first();
        if($check_from_items != null && $check_from_items != ''){
            if($check_from_items->balance >= $request->item_count){
                $check_from_items->balance -= $request->item_count;
                $check_from_items->save();
                
                $input['balance_from'] = $check_from_items->balance;
                $input['employee_id'] = auth()->user()->id;
                
                $check_to_items = WHUsedItem::where('item_category_id',$request->item_category_id)
                                      ->where('item_id',$request->item_id)
                                      ->where('place_id',$request->to_place_id)->first();
                if($check_to_items != null && $check_to_items != ''){
                    $check_to_items->balance += $request->item_count;
                    $check_to_items->save();
                    
                    $input['balance_to'] = $check_to_items->balance;
                    
                }else{
                    WHUsedItem::create([
                        'item_category_id' => $request->item_category_id,
                        'item_id' => $request->item_id,
                        'place_id' => $request->to_place_id,
                        'balance' => $request->item_count,
                        'employee_id' => auth()->user()->id
                    ]);
                    
                    $input['balance_to'] = $request->item_count;
                }
        
                /** @var WHItem $transfered_item */
                $transfered_item = WHTransferedItem::create($input);
        
                Flash::success('Warehouse Item saved successfully.');

            }else{
                Flash::error('Count more than current balance, expected less than '.$check_from_items->balance.'.');
            }
        }else{
            Flash::error('Warehouse Item not fount in current Items.');
        }
        
        return redirect(route('admin.whTransferedItems.index'));
    }

    /**
     * Display the specified WHItem.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var WHItem $transfered_item */
        $transfered_item = WHTransferedItem::find($id);

        if (empty($transfered_item)) {
            Flash::error('Warehouse Item not found');

            return redirect(route('admin.whTransferedItems.index'));
        }

        return view('wh_transfered_items.show')->with('transfered_item', $transfered_item);
    }

    /**
     * Show the form for editing the specified WHItem.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var WHTransferedItem $transfered_item */
        $categories = WHItemCategory::all()->pluck('name','id');
        $wh_items = WHItem::select('id','name','item_category_id')->get();
        $wh_items = $wh_items->groupBy('item_category_id');
        $places = auth()->user()->places->pluck('name', 'id')->toArray();
        
        $transfered_item = WHTransferedItem::find($id);

        if (empty($transfered_item)) {
            Flash::error('Warehouse Item not found');

            return redirect(route('admin.whTransferedItems.index'));
        }

        return view('wh_transfered_items.edit')->with('transfered_item', $transfered_item)->with('categories',$categories)->with('wh_items',$wh_items)->with('places',$places);
    }

    /**
     * Update the specified WHTransferedItem in storage.
     *
     * @param int $id
     * @param UpdateWHItemRequest $request
     *
     * @return Response
     */
    public function update($id, Request $request)
    {
        /** @var WHTransferedItem $transfered_item */
        $transfered_item = WHTransferedItem::find($id);
        $input = $request->all();
        
        if (empty($transfered_item)) {
            Flash::error('Warehouse Item not found');

            return redirect(route('admin.whTransferedItems.index'));
        }
        
        $transfered_item->fill($input);
        $transfered_item->save();

        Flash::success('Warehouse Item updated successfully.');

        return redirect(route('admin.whTransferedItems.index'));
    }

    /**
     * Remove the specified WHTransferedItem from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        /** @var WHTransferedItem $transfered_item */
        $transfered_item = WHTransferedItem::find($id);

        if (empty($transfered_item)) {
            Flash::error('Warehouse Item not found');

            return redirect(route('admin.whTransferedItems.index'));
        }

        $transfered_item->delete();

        Flash::success('Warehouse Item deleted successfully.');

        return redirect(route('admin.whTransferedItems.index'));
    }
}
