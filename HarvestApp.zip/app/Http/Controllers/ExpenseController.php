<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\Expense;
use App\Models\Safe;
use App\Models\SafeOperation;
use App\Models\ExpenseType;
use App\Models\PaymentMethod;
use Illuminate\Http\Request;
use Flash;
use Illuminate\Support\Facades\Auth;
use App\Traits\StoreImageTrait;

use \DateTime;
use File;


use Spatie\Activitylog\Contracts\Activity;


class ExpenseController extends Controller
{
         use StoreImageTrait;

    public function indexExpenseType()
    {
        $allExpense = ExpenseType::get();
        return view('expense.index')->with('allExpense', $allExpense);
    }
    public function addExpenseType()
    {
        $allExpense = ExpenseType::pluck('name','id');
        return view('expense.create')->with('allExpense', $allExpense);
    }

    public function storeExpenseType(Request $request)
    {
        

        $validator = $request->validate(
            [
                'name' => 'required',
                'parent_id' => 'nullable',
            ]
        );

        $newExpenseType = new ExpenseType();
        $newExpenseType->name = $request->name;
        $newExpenseType->parent_id = $request->parent_id;
        $newExpenseType->save();
        Flash::success('Expense Type saved successfully.');

        return redirect(route('admin.expenseType.index'));
    }
    public function editExpenseType($id)
    {
        $expensetype = ExpenseType::find($id);
        $allExpense = ExpenseType::pluck('name','id');
        return view('expense.edit')->with('allExpense', $allExpense)->with('expensetype', $expensetype);
    }


    public function updateExpenseType(Request $request, $id)
    {

        $validator = $request->validate(
            [
                'name' => 'required',
                'parent_id' => 'nullable',
            ]
        );

        $ExpenseType = ExpenseType::find($id);
        if (!$ExpenseType) {
            Flash::error('ExpenseType not found');
            return redirect()->back();
        }
        $ExpenseType->name = $request->name;
        $ExpenseType->parent_id = $request->parent_id;
        $ExpenseType->save();
        Flash::success('Expense Type updated successfully.');
        return redirect(route('admin.expenseType.index'));
    }


    public function indexExpense(Request $request)
    {
        //dd($request->all());
        $allBranches = Branch::all();
        $branchesID = $allBranches->pluck('id')->toArray();
        $user = Auth::user();
        $allBranches = $user->branches;
        $Branches = $request->branches;


        $allpayment_methods = PaymentMethod::where('status' , 1)->get();
        $paymentMethodsid = $allpayment_methods->pluck('id')->toArray();
        $paymentMethods= $request->payment_method;

        $reference_number = $request->reference_number;


        $expenseTypes = ExpenseType::WhereNull('parent_id')->get();
        $sub_expense_types = ExpenseType::WhereNotNull('parent_id')->get();
        $sub_expense_types = $sub_expense_types->groupBy('parent_id');

        
        $registration_from = null;
        $registration_to = null;
        if ($request->has('daterange') && $request->get('daterange') != null && $request->get('daterange') != '') {
            $daterange = explode(' - ',$request->get('daterange'));

            // return $request->daterange ;
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            // $registration_to = date_format(date_create($daterange[1]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
        }
        $ellExpense = Expense::orderBy('id', 'DESC');
        
        if ($request->has('status') && $request->status !=' ' && $request->status != null ){
            $ellExpense = $ellExpense->where('status' , $request->status);
        }
        if ($request->has('branches') && count($Branches) != 0 &&  !in_array(0, $Branches)) {
            $ellExpense = $ellExpense->whereIn('branch_id', $Branches);
        } else {
            $ellExpense = $ellExpense->whereIn('branch_id', $branchesID);
        }
        if ($request->has('payment_method_id') && count($paymentMethods) != 0 &&  !in_array(0, $paymentMethods)) {
            $ellExpense = $ellExpense->whereIn('payment_method_id', $paymentMethods);
        } 
        if($request->has('reference_number') && $request->reference_number != null && $request->reference_number !='' )
        {
            // dd($reference_number);
            $ellExpense = $ellExpense->where('reference_number' , $reference_number);
        }
        if($request->has('expenseType3') && $request->expenseType3 != null && $request->expenseType3 != ''){
            $ellExpense = $ellExpense->where('expense_type_id', $request->expenseType3);
        }
        elseif($request->has('expenseType2') && $request->expenseType2 != null && $request->expenseType2 != ''){
            $check_expense_type = ExpenseType::where('parent_id',$request->expenseType2)->pluck('id')->toArray();
            
            if($check_expense_type != null && count($check_expense_type) > 0){
                $ellExpense = $ellExpense->whereIn('expense_type_id', $check_expense_type);
            }else{
                $ellExpense = $ellExpense->where('expense_type_id', $request->expenseType2);
            }
        }
        elseif($request->has('expenseType1') && $request->expenseType1 != null && $request->expenseType1 != ''){
            $all_expenses_types = array();
            $check_expense_types = ExpenseType::where('parent_id',$request->expenseType1)->pluck('id')->toArray();
                
            if($check_expense_types != null && count($check_expense_types) > 0){
                $all_expenses_types = array_merge($all_expenses_types,$check_expense_types);
                foreach($check_expense_types as $check_expense_type){
                    $check_expense_sub_types = ExpenseType::where('parent_id',$check_expense_type)->pluck('id')->toArray();
                    $all_expenses_types = array_merge($all_expenses_types,$check_expense_sub_types);
                }
                $ellExpense = $ellExpense->whereIn('expense_type_id', $all_expenses_types);
            }else{
                $ellExpense = $ellExpense->where('expense_type_id', $request->expenseType1);
            }
        }else{
            
        }
        if ($registration_from != null && $registration_to != '') {
            $ellExpense = $ellExpense->whereBetween('created_at', [$registration_from, $registration_to]);
        }else{
            // dd(date('Y-m-d'));
            $ellExpense = $ellExpense->where('created_at','like','%'.date('Y-m-d').'%');
        }
        //dd($branchesID,$ellExpense->toSql());
        $expenseCount = $ellExpense->count();
        $expenseTotalAmount = $ellExpense->sum('amount');
        $expenseallAmount = Expense::get()->sum('amount');



        $ellExpense = $ellExpense->get();
        return view('expense.expenseindex')
            ->with('allBranches', $allBranches)
            ->with('ellExpense', $ellExpense)
            ->with('expenseTotalAmount', $expenseTotalAmount)
            ->with('expenseCount', $expenseCount)
            ->with('expenseTypes',$expenseTypes)
            ->with('sub_expense_types',$sub_expense_types)
            ->with('allpayment_methods',$allpayment_methods)
            ->with('expenseallAmount',$expenseallAmount);
    }
    
    public function addExpense()
    {
        $employee = Auth::user();
        $paymentMethods = PaymentMethod::where('status', 1)->where('transfer', 1)->get();
        $expenseTypes = ExpenseType::WhereNull('parent_id')->get();
        $employeeBranches = $employee->branches;
        
        $sub_expense_types = ExpenseType::WhereNotNull('parent_id')->get();
        $sub_expense_types = $sub_expense_types->groupBy('parent_id');
        // dd($sub_expense_types);
        
        return view('expense.expensecreate', compact('employee', 'paymentMethods', 'expenseTypes', 'employeeBranches','sub_expense_types'));
    }

    public function storeExpense(Request $request)
    {
        $data = $request->all();
        //dd($request->all());
        // $validator = $request->validate(
        //     [
        //         'branch' => 'required ',
        //         'expenseType' => 'required|array',
        //         'amount' => 'required|numeric',
        //         'payment_method_id' => 'required',
        //         'reference_number' => 'required_unless:payment_method_id,1',
        //         'upload_bill' => 'required|image',
                
        //     ]
        // );
        
        $expenseTypes = array_filter($request->expenseType);
        $last_expense_type = end($expenseTypes);
         $check_has_sub_types = ExpenseType::where('parent_id',$last_expense_type)->get();
        
        if($check_has_sub_types != null && count($check_has_sub_types) > 0){
            Flash::error('select Expense type.');
            
            return back();
            
        }
        if($request->branch == 19)
        {
            $data['employee_id']= Auth::user()->id;
            $data['method_id']= $request->payment_method;
            $data['expense_type_id']= $last_expense_type;
            $data['branch_id']= $request->branch;
            $data['note']= $request->note;
            $data['status']= "pending";
           
                    $data['upload_bill'] = $this->verifyAndStoreImageSource($request,'upload_bill','uploads/expense_bills');



             $newExpense = Expense::create($data);
             return redirect()->back();
        }
        
        
        
        $employee = Auth::user();
        $employee_safe = Safe::where('employee_id' , $employee->id)->where('payment_method_id' , 1)
        ->where('is_manager',0)->where('is_hq', 0)->where('status',1)->first();
        if(!$employee_safe){
            Flash::error('you do not any cash safe');
            return redirect()->back();
        }
        
        
        // return $employee_safe;
        if($employee_safe->balance > $request->amount){
            $data['employee_id']= Auth::user()->id;
           $data['method_id']= $request->payment_method;
           $data['branch_id']= $request->branch;
           $data['note']= $request->note;
           $data['expense_type_id']= $last_expense_type;
           $data['status']= "pending";
                               $data['upload_bill'] = $this->verifyAndStoreImageSource($request,'upload_bill','uploads/expense_bills');


            $newExpense = Expense::create($data);
           
           $employee_safe->balance -= $request->amount;
           $employee_safe->save();
           
           $safeOperation = new SafeOperation();
           $safeOperation->safe_id = $employee_safe->id; 
           $safeOperation->operation_type = 'outcome'; 
           $safeOperation->source = 'expenses'; 
           $safeOperation->amount = $request->amount;
           $safeOperation->save();
           
          
           Flash::success('Expense saved successfully.');
        }
        else
        {
            Flash::error('amount is greater than your balance.');
            return back();
            
        }
           return redirect(route('admin.expense.index'));
    }



    public function updateStatus($id,Request $request)
    {
        
        $expense = Expense::find($id);
        $expense->status = $request->status;
        $expense->save();
        
        $employee = Auth::user();
        $employee_safe = Safe::where('employee_id' , $employee->id)->where('payment_method_id' , 1)->first();
        
        if($expense->status == 'disapprove')
        {
           $employee_safe->balance += $expense->amount;
           $employee_safe->save();
           
           $operation_safe = SafeOperation::where('operation_type','outcome')->where('safe_id',$employee_safe->id)
                                          ->where('source','expenses')->where('amount',$expense->amount)
                                          ->where('created_at','like',date_format(date_create($expense->created_at),'Y-m-d H:i').'%');
           $operation_safe->delete();                                
        }
                    
         activity('Expenses')
           ->causedBy(Auth::user()->id)
           ->performedOn($expense)
           
           ->log('Update Expenses Type');

        return redirect(route('admin.expense.index'));
    }

    public function delete($id)
    {
        $expense = Expense::find($id);
        $expense->delete();
        
                    
         activity('Expenses')
           ->causedBy(Auth::user()->id)
           ->performedOn($expense)
           ->log('Delete Expenses');

        Flash::success('Expense deleted successfully.');

        return redirect(route('admin.expense.index'));
    }
    
    
    
}
