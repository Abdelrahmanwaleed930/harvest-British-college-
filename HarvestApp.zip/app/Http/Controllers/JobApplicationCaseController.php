<?php

namespace App\Http\Controllers;

use App\Repositories\JobApplicationCaseRepository;
use App\Http\Controllers\AppBaseController;
use App\Models\Action;
use App\Models\Branch;
use App\Models\SMS;
use App\Models\WhatsApp;
use App\Models\Feedback;
use App\Models\Label;
use App\Models\LabelType;
use App\Models\JobApplication;
use App\Models\JobApplicationCase;
use App\Models\Group;
use App\Models\PlacementApplicant;
use App\Models\JobApplicationLastCase;
use App\Models\Job;
use App\Models\Employee;
use App\Models\MessageLog;
use Illuminate\Http\Request;
use Flash;
use Response;
use Auth;
use DB;


class JobApplicationCaseController extends AppBaseController
{
    /** @var  JobApplicationCaseRepository */
    private $jobApplicationCaseRepository;

    public function __construct(JobApplicationCaseRepository $jobApplicationCaseRepo)
    {
        $this->jobApplicationCaseRepository = $jobApplicationCaseRepo;
    }
    
    public function followUpDelete(Request $request)
    {
        if ($request->ids != null && count($request->ids) > 0) {
            JobApplicationCase::whereIn('id', $request->ids)->delete();

            Flash::success('Deleted Successfully.');

            $this->show_delete = false;
            $this->selected = [];
        } else {
            Flash::error('Selected Jobs Applications is required.');
        }
        return 0;
    }
    
    public function followUpSendmsg(Request $request)
    {
        if (!$request->message) {
            Flash::error('Message is required.');
        } elseif ($request->ids != null && count($request->ids) > 0) {
            if($request->type == 'sms'){
                $sms = new SMS;

                $jobApplicationsMobile = JobApplicationCase::whereIn('id', $request->ids)
                    ->with('job_application')
                    ->get()->pluck('job_application.phone', 'job_application_id')->toArray();
                $mobiles = array_unique($jobApplicationsMobile);
    
                $msg = $request->message;

                $sms->send($mobiles, $msg);

                $log = MessageLog::create([
                    'type' => 1,
                    'content' => $msg,
                    'employee_id' => auth()->id()
                ]);
                $log->jobsApplications()->sync(array_keys($mobiles));

            }else{
                $whatsApp = new WhatsApp;

                $jobApplicationsMobile = JobApplicationCase::whereIn('id', $request->ids)
                    ->with('job_application')
                    ->get()->pluck('job_application.phone', 'job_application_id')->toArray();
                $mobiles = array_unique($jobApplicationsMobile);
    
                $msg = $request->message;

                $whatsApp->send($mobiles, $msg);

                $log = MessageLog::create([
                    'type' => 2,
                    'content' => $msg,
                    'employee_id' => auth()->id()
                ]);
                $log->jobsApplications()->sync(array_keys($mobiles));

            }
            Flash::success('Sent Successfully.');

        } else {
            Flash::error('Selected Employees is required.');
        }
        return 0;
    }
    
    /**
     * Display a listing of the JobApplicationCase.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        //dd($request->all());
        //$testsec = round(microtime(true)*1000);
        $jobApplication = JobApplication::find(request('job_application'));

        $jobApplicationCases = JobApplicationCase::where('job_application_id', $jobApplication->id)->orderBy('id','desc')->get();
        $labelTypes = LabelType::where('status', 1)->where('category', $request->type)->get();
        $feedbacks = Feedback::where('status', 1)->whereIn('label_type_id', $labelTypes->pluck('id'))->get();
        $actions = Action::where('status', 1)->whereIn('label_type_id', $labelTypes->pluck('id'))->get();
        $feedbacks = $feedbacks->groupBy('label_type_id');
        $actions = $actions->groupBy('label_type_id');
        

        $msgs_ids = DB::table('job_application_message_log')->where('job_application_id',$jobApplication->id)->pluck('message_log_id');
        $msgs = MessageLog::whereIn('id',$msgs_ids)->orderBy('id','desc')->get();
        //dd(round(microtime(true)*1000)-$testsec);
        return view('job_application_cases.index', compact('jobApplicationCases', 'jobApplication','msgs','labelTypes','feedbacks','actions'));
    }

    /**
     * Show the form for creating a new JobApplicationCase.
     *
     * @return Response
     */
    public function create()
    {
        //dd(request('lead'));
        $jobApplication = JobApplication::find(request('job_application'));

        return view('job_application_cases.create', compact('jobApplication'));
    }
    public function store(Request $request)
    {
        $data = $request->validate([
            'job_application_id' => 'nullable',
            'label_type_id' => 'required',
            'follow_up_type' => 'required',
            'call_type' => 'nullable',
            'feedback_id' => 'nullable',
            'feedback_date' => 'nullable',
            'action_id' => 'nullable',
            'notes' => 'required',
            'date' => 'nullable',
        ]);
        
        if(isset($data['action_id']) && $data['action_id'] != null && $data['action_id'] != ''){
            $action = Action::findOrFail($data['action_id']);
            if(strtolower($action->name) == 'open'){
                $data['status'] = 0;
            }
            if(strtolower($action->name) == 'close' || strtolower($action->name) == 'closed'){
                $data['status'] = 1;
            }
        }
        
        if(isset($data['label_type_id']) && $data['label_type_id'] != null && $data['label_type_id'] != ''){
            $label_type = LabelType::findOrFail($data['label_type_id']);
            if(strtolower($label_type->name) == 'reserved'){
                $data['status'] = 1;
            }
        }



        //dd($data);
        $jobApplicationCase = $request->jobApplicationCase;
        if($jobApplicationCase){
            $jobApplicationCase->update($data);
        }else{
            $data['employee_id'] = Auth::user()->id;
            $data['serial'] = time();
            
            $jobApplicationCase = JobApplicationCase::create($data);

            if($request->oldUpdate) {
                $followup = JobApplicationCase::find($request->oldUpdate);
                $followup->update(['status' => 1]);
            }
       
            $lastcase = $jobApplicationCase->lastcase;
            $last_case_date = array_merge(['job_application_case_id' => $jobApplicationCase->id ],$data);
            if($lastcase){
                $lastcase->update($last_case_date);
            }else{
                $lastcase = JobApplicationLastCase::create($last_case_date);
            }
        }
        $job_application = JobApplication::where('id',$data['job_application_id']);

        $job_application = $job_application->update([
            'status'=>$request->statuss,

        ]);

        


        

        Flash::success('JobApplicationCase saved successfully.');
        if(!auth()->user()->can('followup manager')){
            $branches = Branch::pluck('id')->toArray();
            $jobsApplicationsId = JobApplication::pluck('id')->toArray();
            
            $next_followup = JobApplicationCase::whereIn('job_application_id', $jobsApplicationsId)
                ->where('status', 0)
                ->where('employee_id', auth()->id())
                ->whereDate('date', '<=', now())
                ->orderBy('id','desc')
                ->first();
            if($next_followup != null){
                $quary = '?job_application='.$next_followup->job_application_id.'&type=5&old='.$next_followup->id;
                return redirect('jobApplicationCases'.$quary);
            }else{
                return redirect('followup');
            }
            
        }else{
            $query = ['job_application' => $jobApplicationCase->job_application_id];
            return redirect(route('admin.jobApplicationCases.index', $query));
        }

        
    }

    /**
     * Display the specified JobApplicationCase.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $jobApplicationCase = $this->jobApplicationCaseRepository->find($id);

        if (empty($jobApplicationCase)) {
            Flash::error('JobApplication Case not found');

            return redirect(route('admin.jobApplicationCases.index'));
        }

        return view('job_application_cases.show')->with('jobApplicationCase', $jobApplicationCase);
    }

    /**
     * Show the form for editing the specified JobApplicationCase.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        
         $jobApplicationCase = $this->jobApplicationCaseRepository->find($id);
        $labelTypes = LabelType::where('status', 1)->where('category', 5)->get();
        $feedbacks = Feedback::where('status', 1)->whereIn('label_type_id', $labelTypes->pluck('id'))->get();
        $actions = Action::where('status', 1)->whereIn('label_type_id', $labelTypes->pluck('id'))->get();
        $feedbacks = $feedbacks->groupBy('label_type_id');
        $actions = $actions->groupBy('label_type_id');
        
        //dd($jobApplicationCase);
        if (empty($jobApplicationCase)) {
            Flash::error('JobApplication Case not found');

            return redirect(route('admin.jobApplicationCases.index'));
        }
        $jobApplication = JobApplication::find($jobApplicationCase->job_application_id);

        return view('job_application_cases.edit', compact('jobApplicationCase', 'jobApplication','labelTypes','feedbacks','actions'));
    }
    public function update(Request $request , $id){
       
        $data = $request->validate([
            'label_type_id' => 'required',
            'follow_up_type' => 'required',
            'call_type' => 'nullable',
            'feedback_id' => 'nullable',
            'action_id' => 'nullable',
            'notes' => 'nullable',
            'date' => 'nullable',
        ]);
       
          $jobApplicationCase = JobApplicationCase::find($id);
         if(isset($data['action_id']) && $data['action_id'] != null && $data['action_id'] != ''){
            $action = Action::findOrFail($data['action_id']);
            //dd($action);
            if(strtolower($action->name) == 'open'){
                $data['status'] = 0;
            }
            if(strtolower($action->name) == 'close' || strtolower($action->name) == 'closed'){
                $data['status'] = 1;
            }
        }
        
        if(isset($data['label_type_id']) && $data['label_type_id'] != null && $data['label_type_id'] != ''){
            $label_type = LabelType::findOrFail($data['label_type_id']);
            //dd($action);
            if(strtolower($label_type->name) == 'reserved'){
                $data['status'] = 1;
            }
        }
        //dd($leadCase);
        // if (empty($ptApplicationCase)) {
        //     Flash::error('Job Application Case not found');

        //     return redirect(route('admin.jobApplicationCases.index'));
        // }
        
        $jobApplicationCase->update($data);

        Flash::success('Job Application Case updated successfully.');
        return redirect()->back();
   
    }
    /**
     * Remove the specified JobApplicationCase from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        $jobApplicationCase = $this->jobApplicationCaseRepository->find($id);

        if (empty($jobApplicationCase)) {
            Flash::error('Job Application Case not found');

            return redirect(route('admin.jobApplicationCases.index'));
        }
        JobApplicationLastCase::where('job_application_case_id',$jobApplicationCase->id)->delete();
        $jobApplication = $jobApplicationCase->job_application_id;

        $this->jobApplicationCaseRepository->delete($id);

        Flash::success('Job Application Case deleted successfully.');

        return redirect(route('admin.jobApplicationCases.index', ['job_application' => $jobApplication]));
    }

    /**
     * Show the follow up page.
     *
     * @return Response
     */
    public function followup(Request $request)
    {
        //dd('dddd');
        $per_page = 10;
        if($request->has('per_page')){
            $per_page = $request->get('per_page');
        }
        $branches = Branch::pluck('name', 'id')->toArray();
        $jobs = Job::pluck('title', 'id')->toArray();
        
        $agents = Employee::where('account_Type', 'H.Q Account')->where('status',1)
                            ->whereIn('job_id',[32,33,34])->get()->pluck('name', 'id')->toArray();
        
        $labelTypes = LabelType::where('status', 1)->where('category', 5)->pluck('name', 'id')->toArray();
        
        $followupsQuery = JobApplicationCase::leftJoin('jobs_applications','jobs_applications.id','=','job_application_cases.job_application_id')
            ->where('job_application_cases.status', 0)
            ->whereNotNull('job_application_cases.date')
            ->where('job_application_cases.date', '<=', now());
        //dd($followupsQuery->count());
        if($request->has('search') && $request->get('search') != null && $request->get('search') != ''){
            $followupsQuery->where(function ($query) use ($request){
                $query->where('jobs_applications.full_name', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('jobs_applications.phone', 'like', '%' . $request->get('search') . '%')
                    ->orWhere('jobs_applications.email', 'like', '%' . $request->get('search') . '%');
            });
        }
        
        if ($request->has('branches') && $request->get('branches') != null && $request->get('branches') != '') {
            $followupsQuery->whereIn('jobs_applications.branch_id', $request->get('branches'));
        }else {
            $followupsQuery->whereIn('jobs_applications.branch_id', array_keys($branches));
        }
        if($request->has('agent') && $request->get('agent') != null && $request->get('agent') != ''){
            $followupsQuery->where('job_application_cases.employee_id', $request->get('agent'));
        }
        if(!auth()->user()->can('followup manager')){
            //dd('ddd');
            $followupsQuery->where('job_application_cases.employee_id', auth()->id());
        }
        if($request->has('label_type_id') && $request->get('label_type_id') != null && $request->get('label_type_id') != ''){
            $followupsQuery->where('job_application_cases.label_type_id', $request->get('label_type_id'));
        }
        if($request->has('job_id') && $request->get('job_id') != null && $request->get('job_id') != ''){
            $followupsQuery->where('jobs_applications.job_id', $request->get('job_id'));
        }
        
        $followupsCount = $followupsQuery->count();
        //dd($followupsCount);
        $followups = $followupsQuery->select(
                'job_application_cases.id',
                'job_application_cases.created_at',
                'job_application_cases.label_type_id',
                'job_application_cases.employee_id',
                'job_application_cases.job_application_id',
                'job_application_cases.feedback_id',
                'job_application_cases.action_id',
                'job_application_cases.date'
            )
            ->with('job_application')
            ->orderBy('job_application_cases.date','desc')
            ->paginate($per_page);

        return view('job_application_cases.followup',compact('followupsCount','followups','agents','branches','jobs','labelTypes'));
    }
}
