<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreatePlaceRequest;
use App\Http\Requests\UpdatePlaceRequest;
use App\Repositories\PlaceRepository;
use App\Http\Controllers\AppBaseController;
use Illuminate\Http\Request;
use App\Models\Employee;
use Flash;
use DB;
use Response;

class PlaceController extends AppBaseController
{
    /** @var  PlaceRepository */
    private $placeRepository;

    public function __construct(PlaceRepository $placeRepo)
    {
        $this->placeRepository = $placeRepo;
    }

    /**
     * Display a listing of the Place.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        $places = $this->placeRepository->all();

        return view('places.index')
            ->with('places', $places);
    }

    /**
     * Show the form for creating a new Place.
     *
     * @return Response
     */
    public function create()
    {
        $managers = Employee::select('id',DB::raw('concat(COALESCE(first_name,"")," ",COALESCE(middle_name,"")," ",COALESCE(last_name,"")) as full_name'))->where('status',1)->pluck('full_name','id')->toArray();
        return view('places.create')->with('managers',$managers);;
    }

    /**
     * Store a newly created Place in storage.
     *
     * @param CreatePlaceRequest $request
     *
     * @return Response
     */
    public function store(CreatePlaceRequest $request)
    {
        $input = $request->all();

        $place = $this->placeRepository->create($input);

        Flash::success('Place saved successfully.');

        return redirect(route('admin.places.index'));
    }

    /**
     * Display the specified Place.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $place = $this->placeRepository->find($id);

        if (empty($place)) {
            Flash::error('Place not found');

            return redirect(route('admin.places.index'));
        }

        return view('places.show')->with('place', $place);
    }

    /**
     * Show the form for editing the specified Place.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $place = $this->placeRepository->find($id);
        $managers = Employee::select('id',DB::raw('concat(COALESCE(first_name,"")," ",COALESCE(middle_name,"")," ",COALESCE(last_name,"")) as full_name'))->where('status',1)->pluck('full_name','id')->toArray();
        if (empty($place)) {
            Flash::error('Place not found');

            return redirect(route('admin.places.index'));
        }

        return view('places.edit')->with('place', $place)->with('managers',$managers);
    }

    /**
     * Update the specified Place in storage.
     *
     * @param int $id
     * @param UpdatePlaceRequest $request
     *
     * @return Response
     */
    public function update($id, UpdatePlaceRequest $request)
    {
        $place = $this->placeRepository->find($id);

        if (empty($place)) {
            Flash::error('Place not found');

            return redirect(route('admin.places.index'));
        }

        $place = $this->placeRepository->update($request->all(), $id);

        Flash::success('Place updated successfully.');

        return redirect(route('admin.places.index'));
    }

    /**
     * Remove the specified Place from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        $place = $this->placeRepository->find($id);

        if (empty($place)) {
            Flash::error('Place not found');

            return redirect(route('admin.places.index'));
        }

        $this->placeRepository->delete($id);

        Flash::success('Place deleted successfully.');

        return redirect(route('admin.places.index'));
    }
}
