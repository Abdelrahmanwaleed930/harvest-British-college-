<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\Lead;

class UpdateCustomerRequest extends FormRequest
{

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        if($this->segment(1) == 'oldPayment'){
            $lead_id = $this->segment(3);
        }else{
            $lead_id = $this->segment(2);
        }
        //dd($this->segment(3));
        
        $lead_data = Lead::$rules;
        $lead_data['mobile_1'] = 'required|unique:leads,mobile_1,' . $lead_id;
        $lead_data['email'] = 'email|unique:leads,email,' . $lead_id;

        $payment_data = [
            'track_id' => 'required',    
            'sub_track_id' => 'required',    
            'num_of_levels' => 'required',
            'discipline_id' => 'required',
            'harvest_certificate' => 'required',
            'cambridge_certificate' => 'required',
            'books' => 'required',
            'total_amount' => 'required',
            'paid' => 'required'
        ];
        
        return array_merge($lead_data,$payment_data);
    }
}
