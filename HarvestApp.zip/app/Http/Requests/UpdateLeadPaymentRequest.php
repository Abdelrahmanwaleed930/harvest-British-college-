<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\LeadPayment;

class UpdateLeadPaymentRequest extends FormRequest
{

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $leadPayment = LeadPayment::find($this->payment_id);
        
        if($leadPayment->payment_status != null && $leadPayment->payment_status != '' && 
          $leadPayment->merchantRefNumber != null && $leadPayment->merchantRefNumber != ''){
            
            $rules = [
                'subPayments' => 'required|array',
                'subPayments.*.amount' => 'required',
                'subPayments.*.payment_method_id' => 'required',
                'subPayments.*.reference_num' => 'nullable',
                'subPayments.*.upload_bill' => 'nullable',
                'subPayments.*.payment_status' => 'nullable'
            ];
            
        }else{
            $rules = [
                'subPayments' => 'required|array',
                'subPayments.*.amount' => 'required_unless:subPayments.*.payment_method_id,null',
                
                'subPayments.*.payment_method_id' => 'required_unless:subPayments.*.payment_method_id,null',
                'subPayments.*.branch_id' => 'required_unless:subPayments.*.payment_method_id,null',
                
                'subPayments.*.reference_num' => 'required_unless:subPayments.*.payment_method_id,null,1',
                'subPayments.*.upload_bill' => 'required_unless:subPayments.*.payment_method_id,null,1|image',
                'subPayments.*.payment_status' => 'nullable'
            ];
        }
        
        return $rules;
    }
}
