<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\Lead;

class CreateCustomerRequest extends FormRequest
{

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        // $lead_data = Lead::$rules;
         $lead_data = [
        'f_name' => 'required|regex:/(^([a-zA-Z\s]+)(\d+)?$)/u',
        'l_name' => 'required|regex:/(^([a-zA-Z\s]+)(\d+)?$)/u',
        'm_name' => 'required|regex:/(^([a-zA-Z\s]+)(\d+)?$)/u',
        'name_ar' => 'required',
        'gender' => 'required',
        'preferred_type' => 'nullable',
        'mobile_1' => 'required|string',
        'mobile_2' => 'nullable|string|unique:leads,mobile_1',
        'email' => 'required|email',
        'lead_source_id' => 'required',
        'know_channel_id' => 'required',
        'preferred_time' => 'required',
        'offer_id' => 'nullable',
        'branch_id' => 'required',
        'training_service_id' => 'nullable',
        'timeframe_id' => 'required',
        'prefer_branch_id'=>'required',
        'prefer_discipline_id'=>'nullable',
        //'pt_level' => 'nullable|numeric',
        'identification_type' => 'nullable|string',
        'identification' => 'nullable|string',
    ];

        // $lead_data['mobile_1'] = 'required|digits:11|starts_with:0|unique:leads,mobile_1' ;

        $payment_data = [
            'track_id' => 'required',    
            'sub_track_id' => 'required',    
            'num_of_levels' => 'required',
            'discipline_id' => 'required',
            'harvest_certificate' => 'required',
            'cambridge_certificate' => 'required',
            'books' => 'required',
            'total_amount' => 'required',
            'paid' => 'required'
        ];
        
        return array_merge($lead_data,$payment_data);
    }
}
