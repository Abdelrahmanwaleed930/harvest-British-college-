<?php

namespace App\Http\Livewire\PTApplicationCases;

use App\Models\PlacementApplicant;
use App\Models\Label;
use App\Models\Action;
use App\Models\Branch;
use Livewire\Component;
use App\Models\Feedback;
use App\Models\kids_pt_application_case;
use App\Models\kids_pt_application_last_case;
use App\Models\LabelType;
use Illuminate\Http\Request;
use Laracasts\Flash\Flash;
use App\Models\SMS;
use App\Models\WhatsApp;
use App\Models\MessageLog;
use Auth;

class Kids_Form extends Component
{
    public $ptApplication,
        $ptApplicationCase,
        $kids_pt_application_id,
        $branch_id,
        $employee_id,
        $label_type_id,
        $follow_up_type,
        $serial,
        $call_type,
        $feedback_id,
        $feedback_date,
        $action_id,
        $notes,
        $status,
        $date,
        $labelType = null,
        $labelTypes = [],
        $feedbacks = [],
        $actions = [],
        $oldUpdate = null;

    public function mount(Request $request, $ptApplication, $ptApplicationCase = null)
    {
        if ($ptApplicationCase) {
            $this->fill([
                'kids_pt_application_id' => $ptApplicationCase->kids_pt_application_id,
                'branch_id' => $ptApplicationCase->branch_id,
                'employee_id' => $ptApplicationCase->employee_id,
                'label_type_id' => $ptApplicationCase->label_type_id,
                'follow_up_type' => $ptApplicationCase->follow_up_type,
                'serial' => $ptApplicationCase->serial,
                'call_type' => $ptApplicationCase->call_type,
                'feedback_id' => $ptApplicationCase->feedback_id,
                'feedback_date' => $ptApplicationCase->feedback_date,
                'action_id' => $ptApplicationCase->action_id,
                'notes' => $ptApplicationCase->notes,
                'status' => $ptApplicationCase->status,
                'date' => $ptApplicationCase->date,
            ]);
            $this->labelType = LabelType::find($ptApplicationCase->label_type_id);
            $this->feedbacks = Feedback::where('status', 1)->where('label_type_id', $ptApplicationCase->label_type_id)->pluck('name', 'id');
            $this->actions = Action::where('status', 1)->where('label_type_id', $ptApplicationCase->label_type_id)->pluck('name', 'id');
        } else {
            $this->fill([
                'pt_application_id' => $ptApplication->id,
                'branch_id' => $ptApplication->branch_id,
            ]);

            if ($request->filled('old')) {
                $this->oldUpdate = $request->get('old');
            }
        }
        
        $labelTypesQuery = LabelType::where('status', 1)->where('category', 6);
        if($this->call_type != null && $this->call_type != '' && $this->call_type == 1){
            $labelTypesQuery->where('name','not like','%back%');
        }
        $this->labelTypes = $labelTypesQuery->pluck('name', 'id');
    }

    protected function rules()
    {
        $rules = [
            'kids_pt_application_id' => 'nullable',
            'branch_id' => 'required',
            'label_type_id' => 'required',
            'follow_up_type' => 'required',
            'call_type' => 'nullable',
            'feedback_id' => 'nullable',
            'feedback_date' => 'nullable',
            'action_id' => 'nullable',
            'notes' => 'required',
            'date' => 'nullable',
        ];

        return $rules;
    }

    public function updated($name)
    {
        $this->validateOnly($name);
    }
    
    public function updatedCallType($value)
    {
        $labelTypesQuery = LabelType::where('status', 1)->where('category', 6);
        if($this->call_type != null && $this->call_type != '' && $this->call_type == 1){
            $labelTypesQuery->where('name','not like','%back%');
        }
        $this->labelTypes = $labelTypesQuery->pluck('name', 'id');
    }
    
    public function updatedLabelTypeId($value)
    {
        $this->labelType = LabelType::find($value);
        $this->feedbacks = Feedback::where('status', 1)->where('label_type_id', $value)->pluck('name', 'id');
        $this->actions = Action::where('status', 1)->where('label_type_id', $value)->pluck('name', 'id');
        $this->feedback_id = '';
        $this->action_id = '';
        //$this->actions = [];
    }
    
    public function save()
    {
        $data = $this->validate();
        
        if(isset($data['action_id']) && $data['action_id'] != null && $data['action_id'] != ''){
            $action = Action::findOrFail($data['action_id']);
            
            if(strtolower($action->name) == 'open'){
                $data['status'] = 0;
            }
            if(strtolower($action->name) == 'close' || strtolower($action->name) == 'closed'){
                $data['status'] = 1;
            }
        }
        
        if(isset($data['label_type_id']) && $data['label_type_id'] != null && $data['label_type_id'] != ''){
            $label_type = LabelType::findOrFail($data['label_type_id']);
           
            if(strtolower($label_type->name) == 'reserved'){
                $data['status'] = 1;
            }
        }
        
        $ptApplicationCase = $this->ptApplicationCase;
        if($ptApplicationCase){
            $ptApplicationCase->update($data);
        }else{
            $data['employee_id'] = Auth::user()->id;
            $data['serial'] = time();
            
            $ptApplicationCase = kids_pt_application_case::create($data);

            if($this->oldUpdate) {
                $followup = kids_pt_application_case::find($this->oldUpdate);
                $followup->update(['status' => 1]);
            }
            /*
            //whatsup
            if(in_array($ptApplicationCase->action_id,[6,38,39,40]) && $this->ptApplication->mobile_1 != null && $this->ptApplication->mobile_1 != ''){
                $whatsApp = new WhatsApp;
                $mobiles = [$this->ptApplication->id => $this->ptApplication->mobile_1];
                $msg = 'test whatsup msg from follow up';
    
                $whatsApp->send($mobiles, $msg);
    
                $log = MessageLog::create([
                    'type' => 2,
                    'content' => $msg,
                    'employee_id' => auth()->id(),
                ]);
                $log->ptsApplications()->sync(array_keys($mobiles));
    
                Flash::success('Sent Successfully.');
            }
            //sms
            if(in_array($ptApplicationCase->action_id,[44,45,46,47]) && $this->ptApplication->mobile_1 != null && $this->ptApplication->mobile_1 != ''){
                $sms = new SMS;
                $mobiles = [$this->ptApplication->id => $this->ptApplication->mobile_1];
                $msg = 'test sms msg from follow up';
    
                $sms->send($mobiles, $msg);
    
                $log = MessageLog::create([
                    'type' => 1,
                    'content' => $msg,
                    'employee_id' => auth()->id(),
                ]);
                $log->ptsApplications()->sync(array_keys($mobiles));
    
                Flash::success('Sent Successfully.');

            }
            */
            $lastcase = $this->ptApplication->lastcase;
            //dd($lastcase);
            $last_case_date = array_merge(['kids_pt_application_case_id' => $ptApplicationCase->id ],$data);
            if($lastcase){
                $lastcase->update($last_case_date);
            }else{
                $lastcase = kids_pt_application_last_case::create($last_case_date);
            }
        }

        Flash::success('PTKidsApplicationCase saved successfully.');
        if(!auth()->user()->can('followup manager')){
            $branches = Branch::pluck('id')->toArray();
            $ptsApplicationsId = PlacementKidsApplicant::pluck('id')->toArray();
            
            $next_followup = kids_pt_application_case::whereIn('kids_pt_application_id', $ptsApplicationsId)
                ->where('status', 0)
                ->where('employee_id', auth()->id())
                ->whereDate('date', '<=', now())
                ->orderBy('id','desc')
                ->first();
            if($next_followup != null){
                $quary = '?pt_application='.$next_followup->pt_application_id.'&type=7&old='.$next_followup->id;
                return redirect('ptApplicationCases'.$quary);
            }else{
                return redirect('followup');
            }
            
        }else{
            $query = ['pt_application' => $ptApplicationCase->pt_application_id];
            return redirect(route('admin.ptApplicationCases.kids_index', $query));
        }
    }

    public function render()
    {
        return view('livewire.p-t-application-cases.kids_form');
    }
}
