<?php

namespace App\Http\Livewire\StudentExam;

use App\Models\GroupStudent;
use Livewire\Component;
use Auth;
use App\Models\StudentExam;

class Index extends Component
{
    public $applicant, $studentId,$groupId,$leadId,$trackId,$courseId,$levelId, $type = 1,$timer = 3600,$hours,$minutes;

    protected $listeners = ['registered', 'next'];

    public function mount($studentId)
    {
        
        //dd($this->type);
        if(Auth::guard('customer')->check()){
            $user = Auth::guard('customer')->user();
            
            $student = GroupStudent::findOrFail($studentId);
            
            $this->studentId = $student->id;
            $this->groupId = $student->group_id;
            $this->leadId = $student->lead_id;
            $this->trackId = $student->group->track_id;
            $this->courseId = $student->group->course_id;
            $this->levelId = $student->group->level_id;
            
            //$this->type = 2;
            $applicant = StudentExam::updateOrCreate([
                'group_id' => $this->groupId,'lead_id' => $this->leadId,'track_id' => $this->trackId,
                'course_id' => $this->courseId,'level_id' => $this->levelId,'student_id' => $this->studentId
            ], []);
            
            if($applicant->step != null && $applicant->step != '' && $applicant->step > 0){
                $this->type = $applicant->step;
            }
            $this->applicant = $applicant;

            session()->remove('redirectToStudentExam');
            session()->remove('contactBranchId');
            
            //$this->hours = (int)($this->timer / 60);
            //$this->minutes = (int)($this->timer - ($this->hours * 60));
            
        }
        
    }
    /*
    public function countDownTimer()
    {
        if($this->timer > 0){
            $this->timer -= 1;
            $this->hours = (int)($this->timer / 60);
            $this->minutes = (int)($this->timer - ($this->hours * 60));
        }
    }
*/
    public function registered()
    {
        //$this->applicant = StudentExam::find($id);
        $this->next();
    }

    public function next()
    {
        //$this->type = 5;
        $this->type += 1;
    }

    public function render()
    {
        return view('livewire.student-exam.index')->layout('layouts.customer_app');
    }
}
