<?php

namespace App\Http\Livewire\StudentExam;

use App\Models\Answer;
use App\Models\Question;
use Livewire\Component;

class Reading extends Component
{
    public $applicant,$questions,$limit = 10, $answers = [],$shown_ques,$show_next_msg = false;

    private $paragraphLimit = 1, $point = 1;

    public function mount($applicant)
    {
        $this->applicant = $applicant;

        $paragraphs = Question::where('track_id',$applicant->track_id)
        ->where('course_id',$applicant->course_id)->where('level_id',$applicant->level_id)
        ->where('skill', 'Reading')->whereNull('parent_id')
            ->with('children.answers')
            ->limit($this->paragraphLimit)->inRandomOrder()->get()->map(function ($para) {
                $para->setRelation('children', $para->children->take(10));
                return $para;
            });
        $questions = collect();
        foreach($paragraphs as $paragraph){
            foreach($paragraph->children as $question){
                $questions->push($question);
            }
        }
        $this->questions = $questions;
        //dd($this->questions);
        $this->shown_ques = $questions[0]->id;
        //$this->paragraphs = $paragraphs;
    }
    
    public function previosBtn($key)
    {
        $this->shown_ques = $this->questions[($key - 1)]['id'];
        $this->show_next_msg = false;
    }
    
    public function updatedAnswers()
    {
        $key = count(array_keys($this->answers));
        if($key < count($this->questions)){
            $this->shown_ques = $this->questions[$key]['id'];
        }
        $this->show_next_msg = false;
    }
    
    public function nextBtn($key)
    {
        if(array_key_exists($this->questions[$key]['id'],$this->answers)){
            $this->shown_ques = $this->questions[($key + 1)]['id'];
        }else{
            $this->show_next_msg = true;
        }
    }
    
    protected function rules()
    {
        return [
            'answers' => 'array|size:' . $this->limit
        ];
    }

    protected $messages = [
        'array' => 'يجب إجابة كل الاسئلة',
        'size' => 'يجب إجابة كل الاسئلة',
    ];

    public function save()
    {
        //$this->validate();
        if(count($this->answers) == $this->limit){
            $correctCount = Answer::whereIn('id', array_values($this->answers))->sum('is_correct', 1);
    
            $score = $correctCount * $this->point;
    
            $this->applicant->update(['reading_score' => $score,'step' => 5]);
    
            $this->emitUp('next');
        }else{
            $this->show_next_msg = true;
        }
    }

    public function render()
    {
        return view('livewire.student-exam.reading');
    }
}
