<?php

namespace App\Http\Livewire\FollowUp;

use App\Models\SMS;
use App\Models\Lead;
use App\Models\Offer;
use Livewire\Component;
use App\Models\Employee;
use App\Models\LeadCase;
use App\Models\WhatsApp;
use App\Models\LabelType;
use App\Models\LeadSource;
use App\Models\MessageLog;
use Laracasts\Flash\Flash;
use App\Models\KnowChannel;
use Livewire\WithPagination;
use App\Models\TrainingService;
use Illuminate\Database\Eloquent\Builder;

class Index extends Component
{
    use WithPagination;

    protected $paginationTheme = 'bootstrap';

    public $leadSources,
        $knowChannels,
        $services,
        $offers,
        $labelTypes,
        $label_type_id,
        $per_page = 10,
        $branchesData,
        $employeeBranches,
        $agents,
        $show_filter = false,
        $show_delete = false,
        $show_sms = false,
        $selectAll = false,
        $selected = [],
        $shown_followups = [],
        $sms_message,
        $search,
        $feedback,
        $lead_source,
        $know_channel,
        $time,
        $service,
        $offer,
        $branches,
        $agent;

    public function mount()
    {
        $this->leadSources = LeadSource::pluck('name', 'id')->toArray();
        $this->knowChannels = KnowChannel::pluck('name', 'id')->toArray();
        $this->services = TrainingService::pluck('title', 'id')->toArray();
        $this->offers = Offer::pluck('title', 'id')->toArray();
        $this->labelTypes = LabelType::where('status', 1)->where('category', 1)->pluck('name', 'id')->toArray();
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $this->branchesData = $employeeBranches;
        $this->employeeBranches = $employeeBranches;
        $this->agents = Employee::where('account_Type', 'Operations Account')->whereHas('branches', function (Builder $query) use ($employeeBranches) {
            $query->whereIn('id', array_keys($employeeBranches));
        })->get()->pluck('name', 'id')->toArray();
    }

    public function updatedSelectAll()
    {
        if(! $this->selectAll){
            foreach($this->shown_followups as $key => $show_followup){
                unset($this->selected[$show_followup]);
            }
        }else{
            foreach($this->shown_followups as $key => $show_followup){
                $this->selected[$show_followup] = $show_followup;
            }
        }
    }
    
    public function updating($field_name)
    {
        if(!str_starts_with($field_name,'selected') && $field_name != 'selectAll'){
            $this->resetPage();
        }else{
        }
    }
    public function toggleFilter()
    {
        $this->show_filter = !$this->show_filter;
        $this->show_delete = false;
        $this->show_sms = false;
    }
    
    public function toggleDelete()
    {
        $this->show_delete = !$this->show_delete;
        $this->show_filter = false;
        $this->show_sms = false;
    }

    public function toggleSms()
    {
        $this->show_sms = !$this->show_sms;
        $this->show_delete = false;
        $this->show_filter = false;
    }

    public function selectShownFollowups()
    {
        $this->selected = $this->shown_followups;
    }
    
    public function submitDelete()
    {
        $assignFollowups = array_filter($this->selected);
        if (count($assignFollowups) > 0) {
            LeadCase::whereIn('id', $assignFollowups)->delete();
            //LeadCase::whereIn('lead_id', $assignFollowups)->where('status', 0)->update(['employee_id' => $this->assigned_employee]);

            Flash::success('Deleted Successfully.');

            $this->show_delete = false;
            $this->selected = [];
        } else {
            Flash::error('Selected Leads is required.');
        }
    }
    
    public function submitSms()
    {
        $selectedFollowups = array_filter($this->selected);
        if (!$this->sms_message) {
            Flash::error('Message is required.');
        } elseif (count($selectedFollowups) > 0) {
            $sms = new SMS;

            $leadsMobile = LeadCase::whereIn('id', $selectedFollowups)->with('lead')->get()->pluck('lead.mobile_1', 'lead_id')->toArray();
            $mobiles = array_unique($leadsMobile);

            if (count($selectedFollowups) > 0) {
                $msg = $this->sms_message;

                $sms->send($mobiles, $msg);

                $log = MessageLog::create([
                    'type' => 1,
                    'content' => $msg,
                    'employee_id' => auth()->id()
                ]);
                $log->leads()->sync(array_keys($mobiles));

                Flash::success('Sent Successfully.');

                $this->show_sms = false;
                $this->selected = [];
                $this->sms_message = null;
            } else {
                Flash::error('Followups doesn\'t have students.');
            }
        } else {
            Flash::error('Selected Followups is required.');
        }
    }

    public function submitWhatsApp()
    {
        $selectedFollowups = array_filter($this->selected);
        if (!$this->sms_message) {
            Flash::error('Message is required.');
        } elseif (count($selectedFollowups) > 0) {
            $whatsApp = new WhatsApp;

            $leadsMobile = LeadCase::whereIn('id', $selectedFollowups)->with('lead')->get()->pluck('lead.mobile_1', 'lead_id')->toArray();
            $mobiles = array_unique($leadsMobile);

            if (count($selectedFollowups) > 0) {
                $msg = $this->sms_message;

                $whatsApp->send($mobiles, $msg);

                $log = MessageLog::create([
                    'type' => 2,
                    'content' => $msg,
                    'employee_id' => auth()->id()
                ]);
                $log->leads()->sync(array_keys($mobiles));

                Flash::success('Sent Successfully.');

                $this->show_sms = false;
                $this->selected = [];
                $this->sms_message = null;
            } else {
                Flash::error('Followups doesn\'t have students.');
            }
        } else {
            Flash::error('Selected Followups is required.');
        }
    }

    public function updatedBranches($val)
    {
        $this->agents = Employee::where('account_Type', 'Operations Account')->whereHas('branches', function (Builder $query) use ($val) {
            $query->whereIn('id', $val);
        })->get()->pluck('name', 'id')->toArray();
    }

    public function render()
    {
        //$leadsQuery = Lead::where('type', 1);

        
        //$leadsId = $leadsQuery->pluck('id')->toArray();
        //$testsec = round(microtime(true)*1000);
        $followupsQuery = LeadCase::leftJoin('leads','leads.id','=','lead_cases.lead_id')
            ->where('lead_cases.status', 0)
            ->where('lead_cases.label_type_id','!=',12)
            ->whereDate('lead_cases.date', '<=', now());
            
        if ($this->search) {
            $followupsQuery->where(function ($query) {
                $query->where('leads.name', 'like', '%' . $this->search . '%')
                    ->orWhere('leads.mobile_1', 'like', '%' . $this->search . '%')
                    ->orWhere('leads.email', 'like', '%' . $this->search . '%');
            });
        }
        if ($this->lead_source) {
            $followupsQuery->where('leads.lead_source_id', $this->lead_source);
        }
        if ($this->know_channel) {
            $followupsQuery->where('leads.know_channel_id', $this->know_channel);
        }
        if ($this->time) {
            $followupsQuery->where('leads.preferred_time', $this->time);
        }
        if ($this->service) {
            $followupsQuery->where('leads.training_service_id', $this->service);
        }
        if ($this->offer) {
            $followupsQuery->where('leads.offer_id', $this->offer);
        }
        if ($this->branches) {
            $followupsQuery->whereIn('leads.branch_id', $this->branches);
        } else {
            $followupsQuery->whereIn('leads.branch_id', array_keys($this->employeeBranches));
        }
        if ($this->agent) {
            $followupsQuery->where('leads.assigned_employee_id', $this->agent);
        }

        if(!auth()->user()->can('followup manager')){
            $followupsQuery->where('lead_cases.employee_id', auth()->id());
        }
        if($this->label_type_id){
            $followupsQuery->where('lead_cases.label_type_id', $this->label_type_id);
        }

        $followupsCount = $followupsQuery->count();
        $followups = $followupsQuery->select('lead_cases.id','lead_cases.created_at','lead_cases.branch_id','lead_cases.employee_id','lead_cases.lead_id','lead_cases.feedback_id','lead_cases.action_id','lead_cases.date')->with('lead')->orderBy('lead_cases.id','desc')->paginate($this->per_page);

        $this->shown_followups = $followups->pluck('id')->toArray();
        
        if(! $this->selectAll){
            $all_checked = array_values($this->selected);
            if(in_array(false,$all_checked)){
                $this->selectAll = false;
            }else{
                if (count(array_intersect_key(array_flip($this->shown_followups), $this->selected)) === count($this->shown_followups)) {
                    $this->selectAll = 1;
                }
            }
        }else{
            
            $all_checked = array_values($this->selected);
            if(in_array(false,$all_checked)){
                $this->selectAll = false;
            }else{
                foreach($this->shown_followups as $key => $show_followup){
                    $this->selected[$show_followup] = $show_followup;
                }
            }
        }
        //dd(round(microtime(true)*1000)-$testsec);
        return view('livewire.follow-up.index', compact('followups', 'followupsCount'));
    }
}
