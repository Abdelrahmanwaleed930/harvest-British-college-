<?php

namespace App\Http\Livewire\Offers;

use App\Models\Branch;
use App\Models\Offer;
use App\Models\Track;
use Livewire\Component;
use App\Models\ExtraItem;
use App\Models\Timeframe;
use App\Models\ServiceFee;
use Laracasts\Flash\Flash;
use App\Models\Installment;
use App\Models\PaymentPlan;
use App\Models\DisciplineCategory;
use App\Models\Interval;
use File;
use Illuminate\Database\Eloquent\Builder;
use Livewire\WithFileUploads;

class Form extends Component
{
    use WithFileUploads;
    
    public $offer,
        $paymentPlans,
        $disciplines_data,
        $items_data,
        $tracks,
        $courses = [],
        $timeframes_data,
        $intervals_data = [],
        $services_data = [],
        $branches_data,
        $title,
        $fees,
        $show_in,
        $include_books = 0,
        $has_levels = 1,
        $num_levels = 0,
        $start_date,
        $end_date,
        //$image,
        $track_id,
        $course_id,
        $payment_plan_id,
        $timeframes = [],
        $intervals = [],
        $branches,
        $disciplines,
        $items,
        //$full_desc = null,
        $services,
        $installment,
        $total_amount;

    public function mount($offer = null)
    {
        if ($offer) {
            $total = 0;
            $items = $offer->items->pluck('id');
            $services = $offer->services->pluck('id');
            $services_data = ServiceFee::whereHas('trainingService', function (Builder $query) use ($offer) {
                                            $query->where('course_id', $offer->course_id);
                                        })->with('trainingService')->get()->pluck('trainingService.title', 'id');
            
            if ($items) {
                $total += ExtraItem::whereIn('id', $items)->sum('price');
            }
            if($offer->has_levels == 1){
                if ($services) {
                    $total += ServiceFee::whereIn('id', $services)->sum('fees');
                }
            }else{
                if($services_data != null && count($services_data) > 0){
                    $service = ServiceFee::find(array_key_first($services_data->toArray()));
                    $total += $offer->num_levels * $service->fees;
                }
            }
            $this->fill([
                'title' => $offer->title,
                'fees' => $offer->fees,
                'start_date' => $offer->start_date,
                'show_in' => $offer->show_in,
                'include_books' => ($offer->include_books != null && $offer->include_books != '')?$offer->include_books:0,
                'has_levels' => $offer->has_levels,
                'num_levels' => $offer->num_levels,
                'end_date' => $offer->end_date,
                'track_id' => $offer->track_id,
                'course_id' => $offer->course_id,
                'payment_plan_id' => $offer->payment_plan_id,
                'timeframes' => $offer->timeframes->pluck('id')->toArray(),
                'intervals' => $offer->intervals->pluck('id')->toArray(),
                'branches' => $offer->branches->pluck('id'),
                'disciplines' => $offer->disciplines->pluck('id'),
                'items' => $items,
                //'full_desc' => $offer->full_desc,
                //'image' => $offer->image,
                'courses' => Track::where('parent_id', $offer->track_id)->pluck('title', 'id'),
                'services_data' => $services_data,
                'services' => $services,
                'installment' => $offer->installment,
                'total_amount' => $total,
            ]);
            $this->timeframesUpdated($this->timeframes);
        }
        $this->tracks = Track::whereNull('parent_id')->where('status', 1)->pluck('title', 'id');
        $this->timeframes_data = Timeframe::where('status', 1)->pluck('title', 'id');
        $this->branches_data = Branch::pluck('name', 'id');
        $this->paymentPlans = PaymentPlan::where('status', 1)->pluck('title', 'id');
        $this->disciplines_data = DisciplineCategory::pluck('name', 'id');
        $this->items_data = ExtraItem::pluck('name', 'id');
        // $this->services_data = ServiceFee::with('trainingService')->get()->pluck('trainingService.title', 'id');
    }

    protected function rules()
    {
        $rules = [
            'title' => 'required',
            'fees' => 'required|integer',
            'start_date' => 'required',
            'end_date' => 'required',
            'track_id' => 'required',
            'course_id' => 'required',
            'show_in' => 'nullable',
            'include_books' => 'nullable',
            'has_levels' => 'required',
            'payment_plan_id' => 'required',
            'timeframes' => 'required|array',
            'intervals' => 'required|array',
            'branches' => 'required|array',
            'disciplines' => 'required|array',
            'items' => 'nullable|array',
            'num_levels' => 'nullable|integer',
            'services' => 'nullable|array',
            //'image' => 'nullable',
            //'full_desc' => 'nullable',
        ];

        if ($this->payment_plan_id == 1) {
            $rules += [
                'installment.deposit' => 'required|integer',
                'installment.first_payment' => 'required|integer',
                'installment.first_due_date' => 'required',
                'installment.second_payment' => 'nullable|integer',
                'installment.second_due_date' => 'nullable',
                'installment.third_payment' => 'nullable|integer',
                'installment.third_due_date' => 'nullable',
                'installment.fourth_payment' => 'nullable|integer',
                'installment.fourth_due_date' => 'nullable',
            ];
        }elseif($this->payment_plan_id == 3){
            $rules += [
                'installment.deposit' => 'required|integer',
            ];
        }

        return $rules;
    }

    public function updated($name)
    {
        
        $this->validateOnly($name);
        //dd($name);
        
        if (in_array($name, ['items', 'services','num_levels','include_books'])) {
            $this->calcAmount();
        }
        
    }

    public function updatedTrackId($value)
    {
        $this->courses = Track::where('parent_id', $value)->pluck('title', 'id');
        $this->course_id = '';
    }

    public function updatedCourseId($value)
    {
        $this->services_data = ServiceFee::whereHas('trainingService', function (Builder $query) use ($value) {
            $query->where('course_id', $value);
        })->with('trainingService')->get()->pluck('trainingService.title', 'id');
    }

    public function updatedTimeframes($val)
    {
        //dd('ddd');
        $this->timeframesUpdated($val);
    }

    public function timeframesUpdated($ids)
    {
        //dd('ddd');
        $this->intervals_data = Interval::whereHas('timeframes', function (Builder $query) use ($ids) {
            $query->whereIn('id', $ids);
        })->pluck('name', 'id');
    }

    public function calcAmount()
    {
        //dd('ddd');
        $items = $this->items;
        $services = $this->services;
        //dd($items,$services);
        $total_amount = 0;
        if($items){
            $total_amount += ExtraItem::whereIn('id', $items)->sum('price');
        }
        if($this->has_levels == 1){
            if($services){
                $total_amount += ServiceFee::whereIn('id', $services)->sum('fees');
            }
        }else{
            if($this->services_data != null && count($this->services_data) > 0){
                //dd(array_key_first($this->services_data->toArray()));
                $service = ServiceFee::find(array_key_first($this->services_data->toArray()));
                $book = ExtraItem::where('item_category_id',1)->first();
                if($this->include_books == 1){
                    $total_amount += $this->num_levels * ($service->fees + $book->price);
                }else{
                    //dd($this->num_levels,$service);
                    $total_amount += $this->num_levels * $service->fees;
                }
                
            }
        }
        
        $this->total_amount = $total_amount;
    }

    public function save()
    {
        $data = $this->validate();
        //dd($data);
        /*if($this->image != null && $this->image != '' && gettype($this->image) != 'string'){
            $this->image->getClientOriginalName();
            $file_name = rand(11111,99999).'-'.$this->image->getClientOriginalName();
            $this->image->storeAs('/uploads/offers', $file_name);
            $data['image'] = $file_name;
            File::move(storage_path('app/uploads/offers/'.$file_name), '/home/harvestc/public_html/testsys/uploads/offers/'.$file_name);
            
        }else{
            unset($data['image']);
        }*/
        $offer = $this->offer;
        if ($offer) {
            $offer->update($data);
            if($offer->installment() != null && $offer->installment() != ''){
                $offer->installment()->delete();
            }
            if ($this->payment_plan_id == 1) {
                $data['installment']['installmentable_type'] = 'App\\Models\\Offer';
                $data['installment']['installmentable_id'] = $offer->id;
                Installment::create($data['installment']);
            }elseif($this->payment_plan_id == 3){
                $data['installment']['installmentable_type'] = 'App\\Models\\Offer';
                $data['installment']['installmentable_id'] = $offer->id;
                $data['installment']['first_payment'] = $offer->fees - $data['installment']['deposit'];
                $data['installment']['first_due_date'] = 13;
                Installment::create($data['installment']);
            }
            
        }else{
            $data['title_ar'] = $data['title'];
            $offer = Offer::create($data);
            if ($this->payment_plan_id == 1) {
                $data['installment']['installmentable_type'] = 'App\\Models\\Offer';
                $data['installment']['installmentable_id'] = $offer->id;
                Installment::create($data['installment']);
            }elseif($this->payment_plan_id == 3){
                $data['installment']['installmentable_type'] = 'App\\Models\\Offer';
                $data['installment']['installmentable_id'] = $offer->id;
                $data['installment']['first_payment'] = $offer->fees - $data['installment']['deposit'];
                $data['installment']['first_due_date'] = 13;
                Installment::create($data['installment']);
            }
        }

        $offer->timeframes()->sync($data['timeframes']);
        $offer->intervals()->sync($data['intervals']);
        $offer->branches()->sync($data['branches']);
        $offer->disciplines()->sync($data['disciplines']);
        $offer->items()->sync($data['items']);
        if($offer->has_levels == 1){
            $offer->services()->sync($data['services']);
        }
        Flash::success('Extra Item saved successfully.');

        redirect(route('admin.offers.index'));
    }

    public function render()
    {
        return view('livewire.offers.form');
    }
}
