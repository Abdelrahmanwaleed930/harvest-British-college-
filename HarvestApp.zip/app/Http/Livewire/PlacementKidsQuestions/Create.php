<?php

namespace App\Http\Livewire\PlacementKidsQuestions;

use App\Models\PlacementKidsAnswer;
use Livewire\Component;
use Livewire\WithFileUploads;
use App\Models\PlacementKidsQuestion;
use Flash;

class Create extends Component
{
    use WithFileUploads;

    public $skill, $question, $parent_id, $photo,$mp3, /*$ideas,*/ $paragraphs, $answers, $is_correct;

    protected function rules()
    {
        $rules = [
            'skill' => 'required',
            'question' => 'required',
            'photo' => 'nullable|image',
            //'ideas' => 'nullable|required_if:skill,Writing|array|between:2,4',
            'parent_id' => 'nullable',
        ];

        if (in_array($this->skill, ['Vocabulary', 'Grammar'])) {
            $rules['answers'] = 'required|array|between:2,4';
            $rules['is_correct'] = 'required';
        }

        if (in_array($this->skill, ['Reading', 'Listening']) && $this->parent_id) {
            $rules['answers'] = 'required|array|between:2,4';
            $rules['is_correct'] = 'required';
        }
        /*
        if ($this->photo && $this->skill == 'Writing') {
            $rules['photo'] = 'image';
        }
        */
        if ($this->photo && $this->skill == 'Listening') {
            $rules['mp3'] = 'mimes:mp3';
        }

        return $rules;
    }

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
    }

    public function updatedSkill($value)
    {
        if($value == 'Reading'){
            $this->paragraphs = PlacementKidsQuestion::whereNull('parent_id')->where('skill', 'Reading')->get()->pluck('paragraph', 'id');
        }
        if($value == 'Listening'){
            $this->paragraphs = PlacementKidsQuestion::whereNull('parent_id')->where('skill', 'Listening')->get()->pluck('paragraph', 'id');
        }
    }

    public function save()
    {
        $data = $this->validate();

        if ($this->photo){
            $file = $this->photo->store('/');
            $data['photo'] = $file;
            if(env('APP_ENV') == 'production'){
                rename(storage_path('app/' . $file), '/home/harvestc/public_html/testsys/uploads/' . $file);
            }else{
                rename(storage_path('app/' . $file), public_path('uploads/' . $file));
            }
        }
        if ($this->mp3) {
            $file = $this->mp3->store('/');
            $data['mp3'] = $file;
            if (env('APP_ENV') == 'production') {
                rename(storage_path('app/' . $file), '/home/harvestc/public_html/testsys/uploads/' . $file);
            } else {
                rename(storage_path('app/' . $file), public_path('uploads/' . $file));
            }
        }
        $placementQuestion = PlacementKidsQuestion::create($data);
        /*
        if ($data['skill'] == 'Writing') {
            foreach ($data['ideas'] as $idea) {
                PlacementKidsQuestion::create([
                    'skill' => 'Writing',
                    'parent_id' => $placementQuestion->id,
                    'question' => $idea
                ]);
            }
        }
        */
        if (isset($data['answers'])) {
            foreach ($data['answers'] as $key => $answer) {
                PlacementKidsAnswer::create([
                    'placement_question_id' => $placementQuestion->id,
                    'answer' => $answer,
                    'is_correct' => $data['is_correct'] == $key
                ]);
            }
        }

        Flash::success('kids Placement Question saved successfully.');

        redirect(route('admin.kidsPlacementQuestions.index'));
    }

    public function render()
    {
        return view('livewire.placement-kids-questions.create');
    }
}
