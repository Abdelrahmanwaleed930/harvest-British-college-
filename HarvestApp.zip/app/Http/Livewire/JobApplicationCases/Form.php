<?php

namespace App\Http\Livewire\JobApplicationCases;

use App\Models\JobApplication;
use App\Models\Label;
use App\Models\Action;
use App\Models\Branch;
use Livewire\Component;
use App\Models\Feedback;
use App\Models\JobApplicationLastCase;
use App\Models\JobApplicationCase;
use App\Models\LabelType;
use Illuminate\Http\Request;
use Laracasts\Flash\Flash;
use App\Models\SMS;
use App\Models\WhatsApp;
use App\Models\MessageLog;
use Auth;

class Form extends Component
{
    public $jobApplication,
        $jobApplicationCase,
        $job_application_id,
        $employee_id,
        $label_type_id,
        $follow_up_type,
        $serial,
        $call_type,
        $feedback_id,
        $feedback_date,
        $action_id,
        $notes,
        $status,
        $statuss,
        $date,
        $labelType = null,
        $labelTypes = [],
        $feedbacks = [],
        $actions = [],
        $oldUpdate = null;

    public function mount(Request $request, $jobApplication, $jobApplicationCase = null)
    {
        if ($jobApplicationCase) {
            $this->fill([
                'job_application_id' => $jobApplicationCase->job_application_id,
                'employee_id' => $jobApplicationCase->employee_id,
                'label_type_id' => $jobApplicationCase->label_type_id,
                'follow_up_type' => $jobApplicationCase->follow_up_type,
                'serial' => $jobApplicationCase->serial,
                'call_type' => $jobApplicationCase->call_type,
                'feedback_id' => $jobApplicationCase->feedback_id,
                'feedback_date' => $jobApplicationCase->feedback_date,
                'action_id' => $jobApplicationCase->action_id,
                'notes' => $jobApplicationCase->notes,
                'status' => $jobApplicationCase->status,
                'statuss' => [0 => 'Candidate', 1 => 'Done Interview', 2 => 'Trainning'],
                'date' => $jobApplicationCase->date,
            ]);
            $this->labelType = LabelType::find($jobApplicationCase->label_type_id);
            $this->feedbacks = Feedback::where('status', 1)->where('label_type_id', $jobApplicationCase->label_type_id)->pluck('name', 'id');
            $this->actions = Action::where('status', 1)->where('label_type_id', $jobApplicationCase->label_type_id)->pluck('name', 'id');
        } else {
            $this->fill([
                'job_application_id' => $jobApplication->id,
                'type' => 5,
            ]);

            if ($request->filled('old')) {
                $this->oldUpdate = $request->get('old');
            }
        }
        
        $labelTypesQuery = LabelType::where('status', 1)->where('category', 5);
        if($this->call_type != null && $this->call_type != '' && $this->call_type == 1){
            $labelTypesQuery->where('name','not like','%back%');
        }
        $this->labelTypes = $labelTypesQuery->pluck('name', 'id');
    }

    protected function rules()
    {
        $rules = [
            'job_application_id' => 'nullable',
            'label_type_id' => 'required',
            'follow_up_type' => 'required',
            'call_type' => 'nullable',
            'feedback_id' => 'nullable',
            'feedback_date' => 'nullable',
            'action_id' => 'nullable',
            'notes' => 'required',
            'date' => 'nullable',
        ];

        return $rules;
    }

    public function updated($name)
    {
        $this->validateOnly($name);
    }
    
    public function updatedCallType($value)
    {
        $labelTypesQuery = LabelType::where('status', 1)->where('category', 5);
        if($this->call_type != null && $this->call_type != '' && $this->call_type == 1){
            $labelTypesQuery->where('name','not like','%back%');
        }
        $this->labelTypes = $labelTypesQuery->pluck('name', 'id');
    }
    
    public function updatedLabelTypeId($value)
    {
        $this->labelType = LabelType::find($value);
        $this->feedbacks = Feedback::where('status', 1)->where('label_type_id', $value)->pluck('name', 'id');
        $this->actions = Action::where('status', 1)->where('label_type_id', $value)->pluck('name', 'id');
        $this->feedback_id = '';
        $this->action_id = '';
        //$this->actions = [];
    }
    
    public function save()
    {
        // dd($this->statuss);
        $data = $this->validate();
        
        if(isset($data['action_id']) && $data['action_id'] != null && $data['action_id'] != ''){
            $action = Action::findOrFail($data['action_id']);
            //dd($action);
            if(strtolower($action->name) == 'open'){
                $data['status'] = 0;
            }
            if(strtolower($action->name) == 'close' || strtolower($action->name) == 'closed'){
                $data['status'] = 1;
            }
        }
        
        if(isset($data['label_type_id']) && $data['label_type_id'] != null && $data['label_type_id'] != ''){
            $label_type = LabelType::findOrFail($data['label_type_id']);
            //dd($action);
            if(strtolower($label_type->name) == 'reserved'){
                $data['status'] = 1;
            }
        }



        //dd($data);
        $jobApplicationCase = $this->jobApplicationCase;
        if($jobApplicationCase){
            $jobApplicationCase->update($data);
        }else{
            $data['employee_id'] = Auth::user()->id;
            $data['serial'] = time();
            
            $jobApplicationCase = JobApplicationCase::create($data);

            if($this->oldUpdate) {
                $followup = JobApplicationCase::find($this->oldUpdate);
                $followup->update(['status' => 1]);
            }
            /*
            //whatsup
            if(in_array($jobApplicationCase->action_id,[6,38,39,40]) && $this->jobApplication->mobile_1 != null && $this->jobApplication->mobile_1 != ''){
                $whatsApp = new WhatsApp;
                $mobiles = [$this->jobApplication->id => $this->jobApplication->mobile_1];
                $msg = 'test whatsup msg from follow up';
    
                $whatsApp->send($mobiles, $msg);
    
                $log = MessageLog::create([
                    'type' => 2,
                    'content' => $msg,
                    'employee_id' => auth()->id(),
                ]);
                $log->jobsApplications()->sync(array_keys($mobiles));
    
                Flash::success('Sent Successfully.');
            }
            //sms
            if(in_array($jobApplicationCase->action_id,[44,45,46,47]) && $this->jobApplication->mobile_1 != null && $this->jobApplication->mobile_1 != ''){
                $sms = new SMS;
                $mobiles = [$this->jobApplication->id => $this->jobApplication->mobile_1];
                $msg = 'test sms msg from follow up';
    
                $sms->send($mobiles, $msg);
    
                $log = MessageLog::create([
                    'type' => 1,
                    'content' => $msg,
                    'employee_id' => auth()->id(),
                ]);
                $log->jobsApplications()->sync(array_keys($mobiles));
    
                Flash::success('Sent Successfully.');

            }
            */
            $lastcase = $this->jobApplication->lastcase;
            $last_case_date = array_merge(['job_application_case_id' => $jobApplicationCase->id ],$data);
            if($lastcase){
                $lastcase->update($last_case_date);
            }else{
                $lastcase = JobApplicationLastCase::create($last_case_date);
            }
        }
        $job_application = JobApplication::where('id',$data['job_application_id']);

        $job_application = $job_application->update([
            'status'=>$this->statuss,

        ]);

        


        

        Flash::success('JobApplicationCase saved successfully.');
        if(!auth()->user()->can('followup manager')){
            $branches = Branch::pluck('id')->toArray();
            $jobsApplicationsId = JobApplication::pluck('id')->toArray();
            
            $next_followup = JobApplicationCase::whereIn('job_application_id', $jobsApplicationsId)
                ->where('status', 0)
                ->where('employee_id', auth()->id())
                ->whereDate('date', '<=', now())
                ->orderBy('id','desc')
                ->first();
            if($next_followup != null){
                $quary = '?job_application='.$next_followup->job_application_id.'&type=5&old='.$next_followup->id;
                return redirect('jobApplicationCases'.$quary);
            }else{
                return redirect('followup');
            }
            
        }else{
            $query = ['job_application' => $jobApplicationCase->job_application_id];
            return redirect(route('admin.jobApplicationCases.index', $query));
        }
    }

    public function render()
    {
        return view('livewire.job-application-cases.form');
    }
}
