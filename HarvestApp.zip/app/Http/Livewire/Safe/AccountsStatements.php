<?php

namespace App\Http\Livewire\Safe;

use App\Models\Safe;
use App\Models\Branch;
use Livewire\Component;
use Livewire\WithPagination;
use App\Models\PaymentMethod;
use App\Models\SafeTrancation;
use Illuminate\Database\Eloquent\Builder;

class AccountsStatements extends Component
{
    use WithPagination;

    protected $paginationTheme = 'bootstrap';

    public $branches,
        $safes,
        $methods = [],
        $branch_id,
        $sender_safe,
        $receiver_safe,
        $type,
        $payment_methods_id,
        $status,
        $from,
        $to;

    public function mount()
    {
        $safesData = Safe::with('employee', 'branch')->get();
        $safes = [];
        foreach ($safesData as $safe) {
            $safes[$safe->id] = (($safe->employee)?$safe->employee->name:'') . " - " . (($safe->branch)?$safe->branch->name:'') . " - " . $safe->type;
        }

        $this->fill([
            'branches' => Branch::pluck('name', 'id'),
            'safes' => $safes,
        ]);
    }

    public function updatedType($val)
    {
        if($val == 1){
            $this->methods = PaymentMethod::where('transfer', 1)->pluck('title', 'id');
        }else{
            $this->methods = PaymentMethod::where('deposit', 1)->pluck('title', 'id');
        }
        
        $this->payment_methods_id = '';
    }

    public function render()
    {
        $transactionsQuery = SafeTrancation::with('senderEmployee', 'receiverEmployee', 'paymentMethods');

        if ($this->branch_id) {
            $transactionsQuery->whereHas('senderSafe', function (Builder $query) {
                $query->where('branch_id', $this->branch_id);
            })->orWhereHas('receiverSafe', function (Builder $query) {
                $query->where('branch_id', $this->branch_id);
            });
        }
        if ($this->sender_safe) {
            $transactionsQuery->where('safe_sender', $this->sender_safe);
        }
        if ($this->receiver_safe) {
            $transactionsQuery->where('safe_receiver', $this->receiver_safe);
        }
        if ($this->type) {
            $transactionsQuery->whereHas('paymentMethods', function (Builder $query) {
                $query->where('type', $this->type);
            });
        }
        if ($this->payment_methods_id) {
            $transactionsQuery->where('payment_methods_id', $this->payment_methods_id);
        }
        if ($this->status) {
            $transactionsQuery->where('status', $this->status);
        }
        if ($this->from && $this->to) {
            $transactionsQuery->whereBetween('created_at', [$this->from, $this->to]);
        }

        $total = $transactionsQuery->sum('amount');
        $transactions = $transactionsQuery->paginate(20);

        return view('livewire.safe.accounts-statements', compact('transactions', 'total'));
    }
}
