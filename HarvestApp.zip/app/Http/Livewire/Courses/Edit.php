<?php

namespace App\Http\Livewire\Courses;

use App\Models\Track;
use App\Models\Stage;
use App\Models\StageLevel;
use App\Models\ExtraItem;
use Livewire\Component;
use Laracasts\Flash\Flash;
use DB;

class Edit extends Component
{
    public $course,
        $tracks,
        $parent_id,
        $certificates = [],
        $certificates_ids = [],
        $items = [],
        $title,
        $levels = 0,
        $stages = [],
        $old_stages = [];

    public function mount($course)
    {
        //dd($course->stages->toArray());
        $this->certificates = ExtraItem::where('item_category_id',2)->pluck('name','id');
        $this->items = ExtraItem::pluck('name','id');
        $this->fill([
            'tracks' => Track::whereNull('parent_id')->pluck('title', 'id'),
            'parent_id' => $course->parent_id,
            'title' => $course->title,
            'levels' => $course->levels,
            'certificates_ids' => DB::table('track_items')->where('track_id',$course->id)->pluck('item_id')->toArray(),
            'old_stages' => $course->stages->toArray(),
        ]);
        //dd($this->old_stages);
    }

    protected function rules()
    {
        $rules = [
            'parent_id' => 'required',
            'title' => 'required',
            'certificates_ids' => 'nullable',
            'levels' => '',
            
            'old_stages' => 'required|array',
            'old_stages.*.id' => 'required',
            'old_stages.*.name' => 'required',
            'old_stages.*.levels.*.id' => 'required',
            'old_stages.*.levels.*.name' => 'required',
            'old_stages.*.levels.*.value' => 'required|integer',
            'old_stages.*.levels.*.items' => 'nullable',
            
            'stages' => 'nullable|array',
            'stages.*.name' => 'nullable',
            'stages.*.levels.*.name' => 'nullable',
            'stages.*.levels.*.value' => 'nullable|integer',
            'stages.*.levels.*.items' => 'nullable',
        ];

        return $rules;
    }

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
    }

    public function addStage()
    {
        $this->stages[]['levels'][] = ['name' => '', 'value' => '','items' => []];
        $this->levels += 1;
    }
    
    public function addOldStageLevel($idx)
    {
        $this->old_stages[$idx]['levels'][] = ['id' => 0,'name' => '', 'value' => '','items' => []];
        $this->levels += 1;
    }

    public function deleteStage($idx)
    {
        $stages = $this->stages;
        $levels_count = count($stages[$idx]['levels']);
        $this->levels -= $levels_count;
        unset($stages[$idx]);
        $this->stages = $stages;
    }

    public function addStageLevel($idx)
    {
        $this->stages[$idx]['levels'][] = ['name' => '', 'value' => '','items' => []];
        $this->levels += 1;
    }

    public function save()
    {
        $data = $this->validate();

        $course = $this->course;
        $course->update($data);
        // dd($course->stages());
        // DB::table('stage_level_items')->whereIn('level_id',$data->levels->toArray())->delete();
        // DB::table('stage_level')->whereIn('level_id',$level->id)->delete();
        // $course->stages()->
        
        //$course->stages()->delete();
        
        foreach ($data['old_stages'] as $oldStageData){
            $oldStage = Stage::find($oldStageData['id']);
            $oldStage->name = $oldStageData['name'];
            $oldStage->save();
            
            foreach ($oldStageData['levels'] as $levelData){
                if(isset($levelData['id']) && $levelData['id'] !== '' && $levelData['id'] !== null && $levelData['id'] !== 0){
                    $level = StageLevel::find($levelData['id']);
                    $level->name = $levelData['name'];
                    $level->value = $levelData['value'];
                    $level->save();
                }else{
                    $level = $stage->levels()->create($levelData);
                }
                DB::table('stage_level_items')->where('level_id',level_id)->delete();
                if(isset($levelData['items']) && $levelData['items'] != null && count($levelData['items']) > 0){
                    foreach($levelData['items'] as $item_id){
                        DB::table('stage_level_items')->insert(['level_id' => c,'item_id' => $item_id]);
                    }
                }
                
            }
        }
        
        foreach ($data['stages'] as $stageData){
            $stage = $course->stages()->create($stageData);
            foreach ($stageData['levels'] as $levelData){
                $level = $stage->levels()->create($levelData);
                
                if(isset($levelData['items']) && $levelData['items'] != null && count($levelData['items']) > 0){
                    foreach($levelData['items'] as $item_id){
                        DB::table('stage_level_items')->insert(['level_id' => $level->id,'item_id' => $item_id]);
                    }
                }
                
            }
        }
        
        DB::table('track_items')->where('track_id',$course->id)->delete();
        if($data['certificates_ids'] != null && count($data['certificates_ids']) > 0){
            foreach($data['certificates_ids'] as $certificate_id){
                DB::table('track_items')->insert(['track_id' => $course->id,'item_id' => $certificate_id]);
            }
        }
        Flash::success('Sub Track saved successfully.');

        redirect(route('admin.courses.index'));
    }

    public function render()
    {
        //dd('ssss');
        return view('livewire.courses.edit');
    }
}
