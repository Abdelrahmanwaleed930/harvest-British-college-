<?php

namespace App\Http\Livewire\LeadPayments;

use App\Models\Safe;
use Livewire\Component;
use App\Models\SubPayment;
use Laracasts\Flash\Flash;
use App\Models\PaymentMethod;
use App\Models\SafeTrancation;
use App\Models\SafeOperation;
use Livewire\WithFileUploads;

class Edit extends Component
{
    use WithFileUploads;
    
    public $lead, $leadPayment,
        $paymentable_type,
        $service,
        $installments,
        $subPayments,
        $employee_id,
        $paymentMethods;

    public function mount($lead, $leadPayment = null)
    {
        //dd($leadPayment->paymentable);
        $this->fill([
            'paymentable_type' => ($leadPayment->paymentable_type)?$leadPayment->paymentable_type:null,
            'service' => ($leadPayment->paymentable_type && $leadPayment->paymentable_id)?$leadPayment->paymentable:null,
            'installments' => $leadPayment->subPayments()->with('payment_method')->get(),
            'paymentMethods' => PaymentMethod::where('status', 1)->where('transfer', 1)->pluck('title', 'id'),
        ]);
        $this->employee_id = auth()->id();
        if($leadPayment->payment_plan_id == 3 || $leadPayment->payment_plan_id == 1){
            
            $subPayments = $leadPayment->subPayments()->select('id','amount','payment_method_id','reference_num','upload_bill','payment_status','merchantRefNumber')->where('paid',0)->get();
            $array = [];
            foreach($subPayments as $subPayment){
                if($subPayment->merchantRefNumber != null && $subPayment->merchantRefNumber != ''){
                    $array[$subPayment->id] = [
                        'payment_status' => $subPayment->payment_status,
                        'amount' => $subPayment->amount,
                        'payment_method_id' => $subPayment->payment_method_id,
                        'reference_num' => $subPayment->reference_num,
                        'upload_bill' => $subPayment->upload_bill.'',
                    ];
                }else{
                    $array[$subPayment->id] = ['amount' => $subPayment->amount];
                }
                break;
            }
            $this->subPayments = $array;
        }
        //dd($this->subPayments);
    }

    protected function rules()
    {
        if($this->leadPayment->payment_status != null && $this->leadPayment->payment_status != '' && 
          $this->leadPayment->merchantRefNumber != null && $this->leadPayment->merchantRefNumber != ''){
            
            $rules = [
                'subPayments' => 'required|array',
                'subPayments.*.amount' => 'required',
                'subPayments.*.payment_method_id' => 'required',
                'subPayments.*.reference_num' => 'nullable',
                'subPayments.*.upload_bill' => 'nullable',
                'subPayments.*.payment_status' => 'nullable'
            ];
            
        }else{
            $rules = [
                'subPayments' => 'required|array',
                'subPayments.*.amount' => 'required',
                'subPayments.*.payment_method_id' => 'required',
                'subPayments.*.reference_num' => 'required_unless:subPayments.*.payment_method_id,1',
                'subPayments.*.upload_bill' => 'required_unless:subPayments.*.payment_method_id,1|image',
                'subPayments.*.payment_status' => 'nullable'
            ];
        }
        
        return $rules;
    }

    public function updated($name)
    {
        $this->validateOnly($name);
    }

    public function save()
    {
        //dd($this->leadPayment);
        $data = $this->validate();
        $lead = $this->lead;
        $subPayments = $data['subPayments'];
        //dd($subPayments);
        foreach ($subPayments as $id => $subPayment) {

            if ($subPayment['payment_method_id'] == 1) {
                $safe = Safe::where('employee_id', $this->employee_id)->where('payment_method_id',1)
                    ->where('is_manager',0)->where('is_hq', 0)->where('status',1)->first();
                if (!$safe) {
                    Flash::error('Employee doesn\'t have safe.');
                    return null;
                }/*else{
                    if($safe->branch_id != $lead->branch_id){
                        Flash::error('customer in another branch, transfer it first.');
                        return null;
                    }
                }*/
            } else {
                $safe = Safe::where('payment_method_id',$subPayment['payment_method_id'])->where('status',1)->first();
                if (!$safe) {
                    Flash::error('No safe found for this payment method.');
                    return null;
                }
            }
            if(isset($subPayment['payment_status']) && $subPayment['payment_status'] != null && $subPayment['payment_status'] != ''){
                if($subPayment['payment_status'] == 'ACCEPTED'){
                    $subPayment['paid'] = 1;
                }else{
                    $subPayment['paid'] = 0;
                }
            }else{
                $subPayment['paid'] = 1;
            }
            
            $subPayment['branch_id'] = $this->lead->branch_id;
            $subPayment['employee_id'] = auth()->id();
            $subPayment['payment_date'] = date('Y-m-d');
            $subPayment['due_date'] = date('Y-m-d');
            $sub = SubPayment::find($id);
            if($sub->amount > $subPayment['amount']){
                
                $new_amount = $sub->amount - $subPayment['amount'];
                //dd($new_amount);
                $new_subPayment = [
                    'lead_payment_id' => $sub->lead_payment_id,
                    'amount' => $new_amount,
                    'due_date' => date('Y-m-d',strtotime('+ 7 days')),
                    'paid' => 0
                ];
                
                SubPayment::create($new_subPayment);
            }
            
            if(isset($subPayments[$id]['upload_bill']) && $subPayments[$id]['upload_bill'] != null && $subPayments[$id]['upload_bill'] != ''){
                $file = $subPayments[$id]['upload_bill']->store('/');
                $subPayment['upload_bill'] = $file;
                if (env('APP_ENV') == 'production') {
                    rename(storage_path('app/' . $file), '/home/harvestc/public_html/testsys/uploads/lead_payments_bills/' . $file);
                } else {
                    rename(storage_path('app/' . $file), public_path('uploads/' . $file));
                }
            }
            
            $sub->update($subPayment);
            
            // add to safe
            $safe->increment('balance', $sub->amount);

            // add safe operation
            $safe_operation = new SafeOperation;
            $safe_operation->safe_id = $safe->id;
            $safe_operation->operation_type = 'income';
            $safe_operation->amount = $paid;
            $safe_operation->source = 'old_payment';
            $safe_operation->save();

            /*
            if($safe->is_hq){
                $senderSafe = Safe::where('employee_id', auth()->id())->where('branch_id', $this->lead->branch_id)
                    ->whereNull('is_manager')->where('is_hq', 0)->first();
                SafeTrancation::create([
                    'sender' => auth()->id(),
                    'receiver' => $safe->employee_id,
                    'safe_sender' => $senderSafe->id,
                    'safe_receiver' => $safe->id,
                    'amount' => $sub->amount,
                    // 'description' => ,
                    'payment_methods_id' => $subPayment['payment_method_id'],
                    'status' => 'approve',
                ]);
            }
            */
        }

        $leadPayment = $this->leadPayment;
        $paid = $leadPayment->subPayments()->where('paid', 1)->sum('amount');
        $discount = $leadPayment->discount ?? 0;
        $rest = $leadPayment->amount - $discount - $paid;
        $rest = $rest < 0 ? 0 : $rest;
        $leadPayment->update(['rest' => $rest]);

        Flash::success('Lead Payment saved successfully.');

        redirect(route('admin.leadPayments.index', ['customer' => $this->lead->id]));
    }

    public function render()
    {
        return view('livewire.lead-payments.edit');
    }
}
