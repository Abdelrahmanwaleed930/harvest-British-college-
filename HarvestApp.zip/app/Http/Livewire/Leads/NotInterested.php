<?php

namespace App\Http\Livewire\Leads;

use App\Models\SMS;
use DB;
use App\Models\Lead;
use App\Models\Offer;
use Livewire\Component;
use App\Models\Employee;
use App\Models\WhatsApp;
use App\Models\LeadSource;
use App\Models\MessageLog;
use Laracasts\Flash\Flash;
use App\Models\KnowChannel;
use App\Imports\LeadsImport;
use App\Models\LabelType;
use App\Models\LeadCase;
use Livewire\WithPagination;
use Livewire\WithFileUploads;
use App\Models\TrainingService;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Database\Eloquent\Builder;

class NotInterested extends Component
{
    use WithPagination, WithFileUploads;

    protected $paginationTheme = 'bootstrap';

    public $search,
        $leadSources,
        $mobile_1,
        $name,
        $case_from,
        $case_to,
        $registration_from,
        $registration_to,
        $knowChannels,
        $services,
        $offers,
        $per_page = 10,
        $branchesData,
        $employeeBranches,
        $selectAll = false,
        $agents,
        //$labelTypes,
        //$label_type_id,
        $has_followup,
        $show_filter = false,
        $show_delete = false,
        //$show_assign = false,
        //$show_sms = false,
        $shown_leads = [],
        $assign_leads = [],
        //$assigned_employee,
        $select_assigned,
        //$sms_message,
        $lead_source,
        $know_channel,
        $time,
        $service,
        $offer,
        $branches,
        $agent;
        //$excel;

    public function mount()
    {
        $this->leadSources = LeadSource::where('id', '!=', 6)->pluck('name', 'id')->toArray();
        $this->knowChannels = KnowChannel::pluck('name', 'id')->toArray();
        $this->services = TrainingService::pluck('title', 'id')->toArray();
        $this->offers = Offer::pluck('title', 'id')->toArray();
        $this->labelTypes = LabelType::where('status', 1)->where('category', 1)->pluck('name', 'id')->toArray();
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $this->branchesData = $employeeBranches;
        $this->employeeBranches = $employeeBranches;
        $this->agents = Employee::where('account_Type', 'Operations Account')->whereHas('branches', function (Builder $query) use ($employeeBranches) {
            $query->whereIn('id', array_keys($employeeBranches));
        })->get()->pluck('name', 'id')->toArray();
    }

    public function updatedSelectAll()
    {
        if(! $this->selectAll){
            foreach($this->shown_leads as $key => $show_lead){
                unset($this->assign_leads[$show_lead]);
            }
        }else{
            foreach($this->shown_leads as $key => $show_lead){
                $this->assign_leads[$show_lead] = $show_lead;
            }
        }
    }
    

    public function toggleFilter()
    {
        $this->show_filter = !$this->show_filter;
        $this->show_delete = false;
    }
    
    public function toggleDelete()
    {
        $this->show_delete = !$this->show_delete;
        $this->show_filter = false;
    }
    
    public function submitDelete()
    {
        $assignLeads = array_filter($this->assign_leads);
        if (count($assignLeads) > 0) {
            Lead::whereIn('id', $assignLeads)->delete();
            //LeadCase::whereIn('lead_id', $assignLeads)->where('status', 0)->update(['employee_id' => $this->assigned_employee]);

            Flash::success('Deleted Successfully.');

            $this->show_delete = false;
            $this->assign_leads = [];
        } else {
            Flash::error('Selected Leads is required.');
        }
    }
    
    public function updating($field_name)
    {
        if(!str_starts_with($field_name,'assign_leads') && $field_name != 'selectAll'){
            $this->resetPage();
        }else{
        }
    }


    public function updatedBranches($val)
    {
        $this->agents = Employee::where('account_Type', 'Operations Account')->whereHas('branches', function (Builder $query) use ($val) {
            $query->whereIn('id', $val);
        })->get()->pluck('name', 'id')->toArray();
    }

    public function render()
    {
        //dd('dddd');
        //$leadCasesQuary = LeadCase::select('lead_id',DB::raw('max(id) as last_follow_up_id'))->groupBy('lead_id')->pluck('last_follow_up_id')->toArray();
        //$testsec = round(microtime(true)*1000);
        /*
        $leadsQuery = Lead::join('lead_cases',function($query) {
                               $query->on('leads.id','=','lead_cases.lead_id')
                               ->whereRaw('lead_cases.id IN (select MAX(lead_cases2.id) from lead_cases as lead_cases2 join leads as leads2 on leads2.id = lead_cases2.lead_id group by leads2.id)');
                            })
                            ->where('leads.type',1)
                            ->where('lead_cases.label_type_id',12);
        */
        
        $leadsQuery = Lead::leftJoin('lead_cases','leads.id','=','lead_cases.lead_id')
                            ->where('leads.type',1)
                            ->where('lead_cases.label_type_id',12);
        
        if ($this->lead_source) {
            $leadsQuery->where('leads.lead_source_id', $this->lead_source);
        }
        if ($this->search) {
            $leadsQuery->where(function ($query) {
                $query->where('leads.name', 'like', '%' . $this->search . '%')
                    ->orWhere('leads.mobile_1', 'like', '%' . $this->search . '%')
                    ->orWhere('leads.email', 'like', '%' . $this->search . '%');
            });
        } else {
            $leadsQuery->whereIn('leads.branch_id', array_keys($this->employeeBranches));
        }
        if ($this->agent) {
            $leadsQuery->where('leads.assigned_employee_id', $this->agent);
        } elseif (auth()->user()->can('leads leadsAssign')) {
            // show all
        } else {
            $leadsQuery->where('leads.assigned_employee_id', auth()->id());
        }
        if ($this->know_channel) {
            $leadsQuery->where('leads.know_channel_id', $this->know_channel);
        }
        if ($this->time) {
            $leadsQuery->where('leads.preferred_time', $this->time);
        }
        if ($this->service) {
            $leadsQuery->where('leads.training_service_id', $this->service);
        }
        
        if ($this->offer) {
            $leadsQuery->where('leads.offer_id', $this->offer);
        }
        if ($this->branches) {
            $leadsQuery->whereIn('leads.branch_id', $this->branches);
        }
        
        if ($this->registration_from && $this->registration_to) {
            $leadsQuery->whereBetween('leads.created_at', [$this->registration_from, $this->registration_to]);
        }

        $leadsCount = $leadsQuery->distinct('leads.id')->count();
        //dd($leadsCount);
        $leads = $leadsQuery->select('leads.f_name','leads.m_name','leads.l_name','leads.name','leads.name_ar','leads.created_at','leads.mobile_1','leads.mobile_2','leads.branch_id','leads.lead_source_id','leads.assigned_employee_id','leads.id')->groupBy('leads.id')->withCount('cases')->with('lastcase')->latest()->paginate($this->per_page);

        $this->shown_leads = $leads->pluck('id')->toArray();
        
        if(! $this->selectAll){
            $all_checked = array_values($this->assign_leads);
            if(in_array(false,$all_checked)){
                $this->selectAll = false;
            }else{
                if (count(array_intersect_key(array_flip($this->shown_leads), $this->assign_leads)) === count($this->shown_leads)) {
                    $this->selectAll = 1;
                }
            }
        }else{
            $all_checked = array_values($this->assign_leads);
            if(in_array(false,$all_checked)){
                $this->selectAll = false;
            }else{
                foreach($this->shown_leads as $key => $show_lead){
                    $this->assign_leads[$show_lead] = $show_lead;
                }
            }
        }
        
        //dd(round(microtime(true)*1000)-$testsec);
        return view('livewire.leads.not-interested', compact('leads', 'leadsCount'));
    }
}
