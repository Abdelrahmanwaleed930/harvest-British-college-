<?php

namespace App\Http\Livewire\Groups;

use App\Models\SMS;
use App\Models\Lead;
use App\Models\Track;
use App\Models\Room;
use App\Models\Group;
use App\Models\Round;
use App\Models\Branch;
use Livewire\Component;
use App\Models\Employee;
use App\Models\SubRound;
use App\Models\WhatsApp;
use App\Models\Timeframe;
use App\Models\MessageLog;
use App\Models\StageLevel;
use Laracasts\Flash\Flash;
use App\Models\GroupSession;
use App\Models\GroupStudent;
use Livewire\WithPagination;
use App\Models\SubRoundSession;
use App\Models\GroupWaitingList;
use App\Models\DisciplineCategory;
use Illuminate\Database\Eloquent\Builder;
use DB;
use Auth;
// use Response;
use Spatie\Activitylog\Contracts\Activity;


class Index extends Component
{
    use WithPagination;

    protected $paginationTheme = 'bootstrap';

    public $per_page = 10,
        $show_filter = false,
        $show_sms = false,
        $sms_message,
        $selected = [],
        $shown_groups = [],
        $employeeBranches,
        //$levels,
        $tracks,
        $courses = [],
        $rounds = [],
        $subRounds = [],
        $daysData = [],
        $disciplines,
        $timeframes = [],
        $branches,
        $rooms = [],
        $instructors = [],
        $admins = [],
        $intervals = [],
        $stageLevels = [],
        
        $discipline_id,
        $track_id,
        $course_id,
        $timeframe_id,
        $round_id,
        $sub_round_id,
        $days,
        $from_sub_round,
        $to_sub_round,
        $interval_id,
        $branch_id,
        $room_id,
        $instructor_id,
        $admin_id,
        $level_id,
        $status,
        $selectedGroups = [],
        $showModal = false,
        $assignedGroup = null,
        $waitingLists = [],
        $students = [];

    public function mount()
    {
        $this->tracks = Track::whereNull('parent_id')->pluck('title', 'id')->toArray();
        //$this->rounds = Round::pluck('title', 'id')->toArray();
        $this->disciplines = DisciplineCategory::pluck('name', 'id')->toArray();
        $employeeBranches = auth()->user()->branches->pluck('name', 'id')->toArray();
        $this->employeeBranches = $employeeBranches;
        $this->branches = $employeeBranches;
        $this->admins = Employee::where('status',1)->where('account_Type', 'Operations Account')->whereHas('branches', function (Builder $query) use ($employeeBranches) {
            $query->whereIn('id', array_keys($employeeBranches));
        })->get()->pluck('name', 'id')->toArray();
        //$this->admins = Employee::where('account_Type', 'Operations Account')->get()->pluck('name', 'id')->toArray();
        //dd($this->rounds);
        $this->getInstructors(false);
        
    }

    public function toggleFilter()
    {
        $this->show_filter = !$this->show_filter;
        $this->reset([
            // 'show_upgrade',
            'timeframe_id',
            'round_id',
            'sub_round_id',
            'days',
            'from_sub_round',
            'to_sub_round',
            'interval_id',
            'room_id',
            'instructor_id',
            'admin_id',
            'level_id',
        ]);
    }

    public function toggleUpgrade()
    {
        $this->show_upgrade = !$this->show_upgrade;
        // $this->show_filter = false;
    }

    public function toggleSms()
    {
        $this->show_sms = !$this->show_sms;
    }

    public function selectedShownGroups()
    {
        $this->selected = $this->shown_groups;
    }

    public function submitSms()
    {
        $selectedGroups = array_filter($this->selected);
        if (!$this->sms_message) {
            Flash::error('Message is required.');
        } elseif (count($selectedGroups) > 0) {
            $sms = new SMS;

            $groupStudentsMobile = GroupStudent::whereIn('group_id', $selectedGroups)->with('lead')->get()->pluck('lead.mobile_1', 'lead_id')->toArray();
            $mobiles = array_unique($groupStudentsMobile);

            if (count($selectedGroups) > 0) {
                $msg = $this->sms_message;

                $sms->send($mobiles, $msg);

                $log = MessageLog::create([
                    'type' => 1,
                    'content' => $msg,
                    'employee_id' => auth()->id()
                ]);
                $log->leads()->sync(array_keys($mobiles));

                Flash::success('Sent Successfully.');

                $this->show_sms = false;
                $this->selected = [];
                $this->sms_message = null;
            } else {
                Flash::error('Groups doesn\'t have students.');
            }
        } else {
            Flash::error('Selected Groups is required.');
        }
    }

    public function submitWhatsApp()
    {
        $selectedGroups = array_filter($this->selected);
        if (!$this->sms_message) {
            Flash::error('Message is required.');
        } elseif (count($selectedGroups) > 0) {
            $whatsApp = new WhatsApp;

            $groupStudentsMobile = GroupStudent::whereIn('group_id', $selectedGroups)->with('lead')->get()->pluck('lead.mobile_1', 'lead_id')->toArray();
            $mobiles = array_unique($groupStudentsMobile);

            if (count($selectedGroups) > 0) {
                $msg = $this->sms_message;

                $whatsApp->send($mobiles, $msg);

                $log = MessageLog::create([
                    'type' => 2,
                    'content' => $msg,
                    'employee_id' => auth()->id()
                ]);
                $log->leads()->sync(array_keys($mobiles));

                Flash::success('Sent Successfully.');

                $this->show_sms = false;
                $this->selected = [];
                $this->sms_message = null;
            } else {
                Flash::error('Groups doesn\'t have students.');
            }
        } else {
            Flash::error('Selected Groups is required.');
        }
    }

    public function getWaitingList($groupId)
    {
        $group = Group::with('level', 'students', 'discipline')->find($groupId);
        $level_id = $group->level->id;
        $oldStudents = $group->students->pluck('lead_id')->toArray();

        $waitingLists = GroupWaitingList::where('level_id', $level_id)->whereNotIn('lead_id', $oldStudents)
            ->with('lead')->get();
        //dd($level_id,$oldStudents,$waitingLists);
        $this->waitingLists = $waitingLists;
        $this->assignedGroup = $group;
        $this->showModal = true;
    }

    public function doClose()
    {
        $this->waitingLists = [];
        $this->students = [];
        $this->assignedGroup = null;
        $this->showModal = false;
    }

    public function addStudents()
    {
        $this->resetErrorBag();

        $group = $this->assignedGroup;
        $maxStudent = $group->discipline->max_student;
        $students = array_filter($this->students);
        if (count($students) == 0) {
            $this->addError('students', "The students field is required.");
            return null;
        }
        if (count($students) > $maxStudent) {
            $this->addError('students', "The students may not have more than $maxStudent items.");
            return null;
        }

        $lists = GroupWaitingList::with('lead', 'level')->whereIn('id', $students)->get();
        $mobiles = [];
        foreach ($lists as $list) {
            $lead = $list->lead;
            $lead->groups()->attach($group->id, [
                'level_id' => $list->level_id,
                //'payment' => $payment->payment_plan_id == 1 ? 0 : 1
            ]);

            $lead->update(['type' => 3]);

            $sessions = GroupSession::with('level')->where('group_id', $group->id)->get();
            foreach ($sessions as $session) {
                if (!$session->level || $session->level->value >= $list->level->value) {
                    $session->attendances()->create([
                        'lead_id' => $lead->id,
                        'group_id' => $session->group_id,
                        'level_id' => $session->level_id,
                    ]);
                }
            }

            $mobiles[$lead->id] = $lead->mobile_1;
            $list->delete();
            
            activity('Groups')
              ->causedBy(Auth::user()->id)
              ->performedOn($lead)
              ->withProperties(['group_id' =>$group->id ])
              ->log('Add Student');
        }
        
        $whatsApp = new WhatsApp;
        $buttons = [
            
            'templateButtons' => [
                ['index' => 1, 'urlButton' => ['displayText' => 'Visit your profile', 'url' => 'https://testsys.harvestcollege.co.uk/customerPortal/courses']],
            ],
             
        ];
         
        $msg = 'جاهزين نبدأ رحلتنا؟😎
        معاك Harvest  هنكون بنتابع معاك دايما من 11صباحا ل9 مساءا ماعدا الجمعة

        حابين حابين نأكد مع حضرتك ان بداية موعدك الدراسى يوم'. config('system_variables.timeframes.days')[$group->days]  .  
        'من الساعة '. $group->interval->name .'
        فى دبلومة '. $group->course->title .' 
        فى الفترة '. $group->subRound->start_date  .'-'.  $group->subRound->end_date .'
        فى فرع '. $group->branch->name  .'
        تعليمات خاصة بالحضور:
        1-يرجى العلم أنك تستطيع التغيب لمحاضرة واحدة فقط وفي حالة الغياب لمدة محاضرتين متتاليتين كانوا يجب حجز محاضرة تعويضية قبل المحاضرة الثالثة لإستكمال المستوى
        2-يرجى العلم في حالة التغيب لمحاضرتين منقطعين يجب حجز محاضرة تعويضية قبل يوم إمتحان نهاية المستوى
        يرجى الإفادة في النقطة السابقة
        3-يرجى العلم في حالة التأكيد على تلك الرسالة ذلك يعنى موافقتك على الموعد و تأكدك من حضورك لذلك المستوى وأنه سيتم خصمه من رصيد المستويات
        4- إذا قمت بالتأجيل أكثر من فترة ثلاثة أشهر توجب عليك صنع إختبار تحديد مستوى جديد
        بنأكد إننا هنكون المتابعين معاك في حالة وجود أي إستفسار أو إزاي نقدر نوصل لأقصى إستفادة خلال الدبلومة🤍
        وبكده نقدر نهتم بدراستنا بس و نحقق أقصى إستفادة 😎💪
        بنتمنالك يوم سعيد و وقت مميز تقضيه معانا🌸
        Have a nice day🌸
        لتأكيد الحجز ';

        $whatsApp->send($mobiles, $msg,$buttons);

        $log = MessageLog::create([
            'type' => 2,
            'content' => $msg
        ]);
        $log->leads()->sync(array_keys($mobiles));
     Flash::success('Sent Successfully.');

        // $sms = new SMS;
        // $msg = "You had been assigned to new group. Group Number:" . $group->id;
        // $sms->send($mobiles, $msg);

        // $log = MessageLog::create([
        //     'type' => 1,
        //     'content' => $msg
        // ]);
        // $log->leads()->sync(array_keys($mobiles));

        Flash::success('Added Students Successfully.');

        $this->doClose();
    }

    
    public function updatedTrackId($value)
    {
        $this->courses = Track::where('parent_id', $value)->pluck('title', 'id')->toArray();
        //dd($this->courses);
        $this->course_id = '';
    }

    public function updatedCourseId($value)
    {
        $this->stageLevels = Track::find($value)->stageLevels->pluck('name', 'id')->toArray();
        $timeframe_ids = DB::table('timeframe_courses')->where('course_id',$value)->pluck('timeframe_id')->toArray();
        $this->timeframes = Timeframe::whereIn('id',$timeframe_ids)->where('status',1)->pluck('title','id')->toArray();
        $this->level_id = '';
        $this->timeframe_id = '';
    }
    
    public function updatedTimeframeId($value)
    {
        $this->rounds = Round::where('timeframe_id',$value)->pluck('title', 'id')->toArray();
        $this->round_id = '';
    }

    public function updatedRoundId($val)
    {
        $this->round_idUpdated($val);
        
        $this->interval_id = '';
        //$this->levels = [];
        //$this->level_id = '';
        $this->getInstructors();
    }
    
    public function updatedDays($day)
    {
        $this->subRounds = SubRound::where('days', $day)->where('round_id', $this->round_id)
            ->whereDate('start_date', '>=', now())->orderBy('start_date')->pluck('start_date', 'id');

        $this->sub_round_id = '';
    }

    public function updatedBranchId($val)
    {
        $this->branchIdUpdated($val);
        
        $this->admin_id = '';
        $this->room_id = '';

        $this->getInstructors();
    }


    public function updatedIntervalId($val)
    {
        $this->getInstructors();
    }

    public function getInstructors($reset = true)
    {
        $instructorsQuery = Employee::where('status',1)->where('account_Type', 'ESL Account Profile');

        if ($this->branch_id) {
            $instructorsQuery->whereHas('branches', function (Builder $query) {
                $query->where('id', $this->branch_id);
            });
        }else{
            $employeeBranches = $this->employeeBranches;
            $instructorsQuery->whereHas('branches', function (Builder $query) use ($employeeBranches){
                $query->whereIn('id', array_keys($employeeBranches));
            });
        }
        
        $this->instructors = $instructorsQuery->get()->pluck('name', 'id')->toArray();

        if ($reset) {
            $this->instructor_id = '';
        }
    }

    public function setRoundFrom()
    {
        if ($this->round_id && $this->days) {
            $this->subRoundFrom = SubRound::where('round_id', $this->round_id)->where('days', $this->days)->get();
        }
    }

    public function updatedFromSubRound($val)
    {
        $this->to_sub_round = SubRound::where('round_id', $this->round_id)->where('days', $this->days)->where('id', '>', $val)->first();

        $this->selectGroups();
    }

    public function selectGroups()
    {
        if ($this->from_sub_round && $this->discipline_id) {
            $this->selectedGroups = Group::where([
                'sub_round_id' => $this->from_sub_round, 'discipline_id' => $this->discipline_id, 'is_upgraded' => 0, 'is_last' => 0
            ])->with('course.stageLevels', 'levels')->get();
        }
    }
    public function branchIdUpdated($branchId)
    {
        $this->rooms = Room::where('branch_id', $branchId)->pluck('name', 'id');
        $this->admins = Employee::whereHas('branches', function (Builder $query) use ($branchId){
                                    $query->where('branch_id', $branchId)->where('status',1);
                                })->where('account_Type', 'Operations Account')->get()->pluck('name', 'id')->toArray();
    }
    
    public function round_idUpdated($round_id)
    {
        $round = Round::with('timeframe.intervals')->find($round_id);

        $this->daysData = $round->timeframe->days;
        $this->intervals = $round->timeframe->intervals->pluck('name', 'id')->toArray();
    }

    public function resetData()
    {
        $this->reset([
            'show_upgrade',
            'roundsData',
            'daysData',
            'subRoundFrom',
            'timeframe_id',
            'round_id',
            'days',
            'from_sub_round',
            'to_sub_round',
            'selectedGroups',
        ]);
    }

    public function upgradeGroups()
    {
        if (count($this->selectedGroups) == 0) {
            Flash::error('No Groups Found.');
            return null;
        }

        if (!$this->to_sub_round) {
            Flash::error('No Sub Round To Found.');
            return null;
        }

        foreach ($this->selectedGroups as $group) {
            $stageLevels = $group->course->stageLevels->pluck('id')->toArray();
            $levels = $group->levels->pluck('id')->toArray();

            $levelsCount = count($levels);
            $end = end($levels);

            $lastKey = array_search($end, $stageLevels);

            $newLevels = [];
            for ($i = 1; $i <= $levelsCount; $i++) {
                $lastKey += $i;
                if (isset($stageLevels[$lastKey])) {
                    $newLevels[] = $stageLevels[$lastKey];
                }
            }

            $data = [
                'parent_id' => $group->id,
                'sub_round_id' => $this->to_sub_round->id,
            ];

            if (!isset($stageLevels[$lastKey + 1])) {
                $data['is_last'] = 1;
            }

            $upgradedGroup = $group->replicate()->fill($data);
            $upgradedGroup->save();

            $upgradedGroup->levels()->sync($newLevels);

            $group->update(['is_upgraded' => 1]);



            $dates = SubRoundSession::where('sub_round_id', $upgradedGroup->sub_round_id)->pluck('date')->toArray();

            $newLevelsCount = count($newLevels);
            $perSession = (count($dates) - 1) / $newLevelsCount;
            $end = end($dates);

            $key = 0;
            $i = 1;
            foreach ($dates as $date) {
                $sessionData = [
                    'group_id' => $upgradedGroup->id,
                    'date' => $date,
                    'room_id' => $upgradedGroup->room_id,
                    'instructor_id' => $upgradedGroup->instructor_id,
                    'interval_id' => $upgradedGroup->interval_id,
                ];

                if ($date != $end) {
                    $sessionData['level_id'] = $newLevels[$key];
                }

                GroupSession::create($sessionData);

                if (($i % $perSession) == 0) {
                    $key++;
                }
                $i++;
            }
        }

        $this->resetData();

        Flash::success('Groups Upgraded.');
    }

    public function render()
    {
        $groupsQuery = Group::withCount('students', 'sessions')
            ->with('parent', 'round', 'discipline', 'branch', 'room', 'instructor', 'interval')->latest();
        /*
        if (!$this->show_filter) {
            $groupsQuery->where(function ($query) {
                $query->whereNotNull('parent_id')
                    ->where('is_upgraded', 0);
            })->orWhere(function ($query) {
                $query->whereNull('parent_id')
                    ->where('is_upgraded', 0);
            });
        }
        */
        if($this->course_id){
            $groupsQuery->where('course_id', $this->course_id);
        }
        if($this->track_id){
            $groupsQuery->where('track_id', $this->track_id);
        }
        if($this->branch_id){
            $groupsQuery->where('branch_id', $this->branch_id);
        }
        if($this->discipline_id){
            $groupsQuery->where('discipline_id', $this->discipline_id);
        }
        if($this->timeframe_id){
            $groupsQuery->where('timeframe_id', $this->timeframe_id);
        }
        if ($this->round_id) {
            $groupsQuery->where('round_id', $this->round_id);
        }
        if ($this->sub_round_id) {
            $groupsQuery->where('sub_round_id', $this->sub_round_id);
        }
        if ($this->interval_id) {
            $groupsQuery->where('interval_id', $this->interval_id);
        }
        if ($this->room_id) {
            $groupsQuery->where('room_id', $this->room_id);
        }
        if($this->days){
            $groupsQuery->where('days', $this->days);
        }
        if ($this->instructor_id) {
            $groupsQuery->where('instructor_id', $this->instructor_id);
        }
        if ($this->admin_id) {
            $groupsQuery->where('admin_id', $this->admin_id);
        }
        if ($this->level_id) {
            //dd($this->level_id);
            $groupsQuery->where('level_id', $this->level_id);
        }

        $groups = $groupsQuery->paginate($this->per_page);

        $this->shown_groups = $groups->pluck('id')->toArray();

        // if ($this->status) {
        //     $groups->where('status', $this->status)->all();
        //     dd($groups);
        // }

        return view('livewire.groups.index', compact('groups'));
    }
}
