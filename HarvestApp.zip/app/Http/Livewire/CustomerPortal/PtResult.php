<?php

namespace App\Http\Livewire\CustomerPortal;

use App\Models\PlacementApplicant;
use Livewire\Component;

class PtResult extends Component
{
    public $customer;

    public function mount()
    {
        $this->customer = auth()->user();
    }

    public function render()
    {
        $ptApplicant = PlacementApplicant::where('mobile', $this->customer->mobile_1)->latest()->first();

        return view('livewire.customer-portal.pt-result', compact('ptApplicant'));
    }
}
