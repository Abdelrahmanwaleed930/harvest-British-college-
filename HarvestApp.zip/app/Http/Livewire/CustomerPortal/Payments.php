<?php

namespace App\Http\Livewire\CustomerPortal;

use Livewire\Component;
use App\Models\SubPayment;
use App\Models\LeadPayment;

class Payments extends Component
{
    public $customer,
        $active = 'paid';

    public function mount()
    {
        $this->customer = auth()->user();
    }

    public function render()
    {
        if($this->active == 'paid'){
            $allRevenue = LeadPayment::leftJoin('payment_plans', 'payment_plans.id', 'lead_payments.payment_plan_id')
                ->leftJoin('employees', 'employees.id', 'lead_payments.employee_id')
                ->leftJoin('leads', 'leads.id', 'lead_payments.lead_id')
                ->leftJoin('branches', 'branches.id', 'leads.branch_id')
                ->where('lead_payments.lead_id', $this->customer->id)
                ->where('lead_payments.payment_plan_id',2)
                ->whereIn('lead_payments.paymentable_type', ['App\Models\Offer','App\Models\ServiceFee']);
           
            $allRevenue = $allRevenue->select([
                'lead_payments.id',
                'lead_payments.amount',
                'lead_payments.created_at',
                'leads.id as leadId',
                'leads.name as leadName',
                'leads.mobile_1 as leadPhone',
                'payment_plans.id as planeId',
                'payment_plans.title as planeTitle',
                'lead_payments.id as InvoiceNo',
                'lead_payments.paymentable_type',
                'lead_payments.amount as total',
                'lead_payments.employee_id',
                'lead_payments.discount',
                'lead_payments.rest',
                'lead_payments.paymentable_id',
                'branches.id as branchId',
                'branches.name as branchName',
                'employees.id as employeeId',
                'employees.first_name',
                'employees.middle_name',
                'employees.last_name'
            ])->orderBy('lead_payments.id', 'DESC')->get();
            
            $allSubPayment = SubPayment::leftJoin('lead_payments', 'lead_payments.id', 'sub_payments.lead_payment_id')
                ->leftJoin('payment_methods', 'payment_methods.id', 'sub_payments.payment_method_id')
                ->leftJoin('payment_plans', 'payment_plans.id', 'lead_payments.payment_plan_id')
                ->leftJoin('employees', 'employees.id','=', 'sub_payments.employee_id')
                ->leftJoin('leads', 'leads.id', 'lead_payments.lead_id')
                ->leftJoin('branches', 'branches.id', 'leads.branch_id')
                ->where('sub_payments.paid', 1)
                ->where('lead_payments.lead_id', $this->customer->id);
            
                $allSubPayment->whereIn('lead_payments.payment_plan_id', [1,3]);
           
            $allSubPayment = $allSubPayment->select([
                'sub_payments.id',
                'sub_payments.amount',
                'sub_payments.due_date',
                'sub_payments.created_at',
                'sub_payments.lead_payment_id',
                'sub_payments.payment_status',
                'leads.id as leadId',
                'leads.name as leadName',
                'leads.mobile_1 as leadPhone',
                'payment_plans.id as planeId',
                'payment_plans.title as planeTitle',
                'payment_methods.id as methodId',
                'payment_methods.title as methodName',
                'lead_payments.id as InvoiceNo',
                'lead_payments.paymentable_type',
                'lead_payments.amount as total',
                'lead_payments.employee_id',
                'lead_payments.discount',
                'lead_payments.paymentable_id',
                'lead_payments.rest',
                'branches.id as branchId',
                'branches.name as branchName',
                'employees.id as employeeId',
                'employees.first_name',
                'employees.middle_name',
                'employees.last_name'
            ])->orderBy('sub_payments.id', 'DESC')->get();
            
            //dd($allRevenue);
        }elseif($this->active == 'unpaid'){
            
            $allSubPayment = SubPayment::leftJoin('lead_payments', 'lead_payments.id', 'sub_payments.lead_payment_id')
                ->leftJoin('payment_methods', 'payment_methods.id', 'sub_payments.payment_method_id')
                ->leftJoin('payment_plans', 'payment_plans.id', 'lead_payments.payment_plan_id')
                ->leftJoin('employees', 'employees.id','=', 'sub_payments.employee_id')
                ->leftJoin('leads', 'leads.id', 'lead_payments.lead_id')
                ->leftJoin('branches', 'branches.id', 'leads.branch_id')
                ->where('sub_payments.paid', 0)
                ->where('lead_payments.lead_id', $this->customer->id);
            
                $allSubPayment->whereIn('lead_payments.payment_plan_id', [1,3]);
           
            $allSubPayment = $allSubPayment->select([
                'sub_payments.id',
                'sub_payments.amount',
                'sub_payments.due_date',
                'sub_payments.created_at',
                'sub_payments.lead_payment_id',
                'sub_payments.payment_status',
                'leads.id as leadId',
                'leads.name as leadName',
                'leads.mobile_1 as leadPhone',
                'payment_plans.id as planeId',
                'payment_plans.title as planeTitle',
                'payment_methods.id as methodId',
                'payment_methods.title as methodName',
                'lead_payments.id as InvoiceNo',
                'lead_payments.paymentable_type',
                'lead_payments.amount as total',
                'lead_payments.employee_id',
                'lead_payments.discount',
                'lead_payments.paymentable_id',
                'lead_payments.rest',
                'branches.id as branchId',
                'branches.name as branchName',
                'employees.id as employeeId',
                'employees.first_name',
                'employees.middle_name',
                'employees.last_name'
            ])->orderBy('sub_payments.id', 'DESC')->get();
            
            $allRevenue = [];
        }else{
            
            $allRevenue = [];
            $allSubPayment = [];
        }
         
        //dd($allRevenue);
        return view('livewire.customer-portal.payments', compact('allRevenue','allSubPayment'));
    }
}
