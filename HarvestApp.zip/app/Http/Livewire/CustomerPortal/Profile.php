<?php

namespace App\Http\Livewire\CustomerPortal;

use Livewire\Component;
use Laracasts\Flash\Flash;
use Illuminate\Support\Facades\Hash;

class Profile extends Component
{
    public $customer,
        $old_password,
        $password,
        $password_confirmation;

    public function mount()
    {
        $this->customer = auth()->user();
    }

    protected function rules()
    {
        $rules = [
            'old_password' => 'required',
            'password' => 'required|confirmed',
        ];

        return $rules;
    }

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
    }

    public function save()
    {
        $data = $this->validate();

        if (Hash::check($data['old_password'], $this->customer->password)) {
            $this->customer->update(['password' => $data['password']]);

            Flash::success('Password saved successfully.');
        } else {
            Flash::error('Wrong Old Password.');
        }
    }

    public function render()
    {
        return view('livewire.customer-portal.profile');
    }
}
