<?php

namespace App\Http\Livewire\KidsPlacementTest;

use App\Models\Branch;
use App\Models\Lead;
use App\Models\PlacementKidsApplicant;
use Livewire\Component;

class Applicant extends Component
{
    public $name, $email, $mobile, $branch_id, $gender, $job, $university, $branches;

    public function mount($branchId)
    {
        $this->branch_id = $branchId;
    }

    protected function rules()
    {
        $rules = [
            'name' => 'required',
            'email' => 'required|email',
            'mobile' => 'required|digits:11|starts_with:0',
            'branch_id' => 'required',
            'gender' => 'required',
            'job' => 'nullable',
            'university' => 'nullable',
        ];

        return $rules;
    }
    
    protected $messages = 
    [
        'required' => 'يجب قبول هذا الحقل.',
        'email' => 'يجب أن يكون عنوان بريد إلكتروني صحيح.',
    ];

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
    }

    public function save()
    {
        /*
        $data = $this->validate();

        $applicant = PlacementKidsApplicant::updateOrCreate([
            'mobile' => $data['mobile']
        ], $data);

        Lead::firstOrCreate([
            'mobile_1' => $data['mobile']
        ], [
            'name' => ['en' => $data['name'], 'ar' => $data['name']],
            'gender' => $data['gender'],
            'mobile_1' => $data['mobile'],
            'email' => $data['email'],
            'lead_source_id' => 1,
            'branch_id' => $data['branch_id'],
            'password' => 'Harvest@123',
        ]);
        */
        $this->emitUp('registered');
    }

    public function render()
    {
        return view('livewire.kids-placement-test.applicant');
    }
}
