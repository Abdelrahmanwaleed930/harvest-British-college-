<?php

namespace App\Http\Livewire\KidsPlacementTest;

use App\Models\PlacementKidsAnswer;
use App\Models\PlacementKidsQuestion;
use Livewire\Component;

class Listening extends Component
{
    public $applicant,$questions, $answers = [],$shown_ques,$show_next_msg = false;

    private $limit = 10, $paragraphLimit = 2, $point = 1;

    public function mount($applicant)
    {
        $this->applicant = $applicant;

        $paragraphs = PlacementKidsQuestion::where('skill', 'Listening')->whereNull('parent_id')
            ->with('children.answers')
            ->limit($this->paragraphLimit)->inRandomOrder()->get()->map(function ($para) {
                $para->setRelation('children', $para->children->take(5));
                return $para;
            });
        $questions = collect();
        foreach($paragraphs as $paragraph){
            foreach($paragraph->children as $question){
                $questions->push($question);
            }
        }
        $this->questions = $questions;
        
        $this->shown_ques = $questions[0]->id;
    }

    public function previosBtn($key)
    {
        $this->shown_ques = $this->questions[($key - 1)]['id'];
        $this->show_next_msg = false;
    }
    
    public function updatedAnswers()
    {
        $key = count(array_keys($this->answers));
        if($key < count($this->questions)){
            //dd($this->questions[$key]);
            $this->shown_ques = $this->questions[$key]['id'];
            $this->show_next_msg = false;
        }
    }
    
    public function nextBtn($key)
    {
        if(array_key_exists($this->questions[$key]['id'],$this->answers)){
            $this->shown_ques = $this->questions[($key + 1)]['id'];
        }else{
            $this->show_next_msg = true;
        }
    }
    
    protected function rules()
    {
        return [
            'answers' => 'array|size:' . $this->limit
        ];
    }

    protected $messages = [
        'array' => 'يجب إجابة كل الاسئلة',
        'size' => 'يجب إجابة كل الاسئلة',
    ];

    public function save()
    {
        $this->validate();

        $correctCount = PlacementKidsAnswer::whereIn('id', array_values($this->answers))->sum('is_correct', 1);

        $score = $correctCount * $this->point;

        $this->applicant->update(['listening_score' => $score]);

        $this->emitUp('next');
    }

    public function render()
    {
        return view('livewire.kids-placement-test.listening');
    }
}
