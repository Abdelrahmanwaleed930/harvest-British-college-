<?php

namespace App\Http\Livewire\KidsPlacementTest;

use App\Models\PlacementKidsAnswer;
use App\Models\PlacementKidsQuestion;
use Livewire\Component;

class Vocabulary extends Component
{
    public $applicant, $questions, $answers = [],$shown_ques,$show_next_msg = false;

    private $limit = 20, $point = 0.5;

    public function mount($applicant)
    {
        $this->applicant = $applicant;

        $questions = PlacementKidsQuestion::where('skill', 'Vocabulary')->with('answers')->limit($this->limit)->inRandomOrder()->get();
        $this->shown_ques = $questions[0]->id;
        $this->questions = $questions;
    }
    
    public function previosBtn($key)
    {
        $this->shown_ques = $this->questions[($key - 1)]->id;
        $this->show_next_msg = false;
    }
    
    public function updatedAnswers()
    {
        $key = count(array_keys($this->answers));
        if($key < count($this->questions)){
            $this->shown_ques = $this->questions[$key]->id;
            $this->show_next_msg = false;
        }
    }
    
    public function nextBtn($key)
    {
        if(array_key_exists($this->questions[$key]->id,$this->answers)){
            $this->shown_ques = $this->questions[($key + 1)]->id;
        }else{
            $this->show_next_msg = true;
        }
    }
    
    protected function rules()
    {
        return [
            'answers' => 'array|size:' . $this->limit
        ];
    }

    protected $messages = [
        'array' => 'يجب إجابة كل الاسئلة',
        'size' => 'يجب إجابة كل الاسئلة',
    ];

    public function save()
    {
        //dd('ddd');
        $this->validate();

        $correctCount = PlacementKidsAnswer::whereIn('id', array_values($this->answers))->sum('is_correct', 1);

        $score = $correctCount * $this->point;

        $this->applicant->update(['vocabulary_score' => $score]);
        //dd('dddd');
        $this->emitUp('next');
    }

    public function render()
    {
        return view('livewire.kids-placement-test.vocabulary');
    }
}
