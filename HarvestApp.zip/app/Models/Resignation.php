<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Resignation extends Model
{
    use HasFactory;

    public $table = 'resignation';

    /**
     * Dates array.
     *
     * @var array
     */

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $fillable = [
        'employee_id',
        'hire_date',
        'date_of_resign',
        'Reason',
        'branch_id',
        'status'
        
    ];

    public function employee()
    {
        return $this->belongsTo(Employee::class,'employee_id');
    }



    public function branch()
    {
        return $this->belongsTo(Branch::class,'branch_id');
    }

}
