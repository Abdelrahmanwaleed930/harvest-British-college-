<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;


/**
 * Class ExtraItem
 * @package App\Models
 * @version July 8, 2021, 9:20 pm UTC
 *
 * @property \App\Models\ItemCategory $itemCategory
 * @property \App\Models\PaymentMethod $paymentMethod
 * @property integer $item_category_id
 * @property integer $payment_plan_id
 * @property string $name
 * @property number $price
 */
class ITItem extends Model
{
    use SoftDeletes;

    public $table = 'it_items';

    protected $dates = ['deleted_at'];

    public $fillable = [
        'item_category_id',
        'name',
        'status',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'item_category_id' => 'integer',
        'name' => 'string',
        'status' => 'integer',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'item_category_id' => 'required',
        'name' => 'required',
        'status' => 'required',
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function itemCategory()
    {
        return $this->belongsTo(\App\Models\ITItemCategory::class,'item_category_id','id');
    }
    
}
