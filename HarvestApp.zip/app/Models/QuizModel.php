<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QuizModel extends Model
{
    use HasFactory;
    
    public $table = 'quiz_model';

   public $fillable = [
        'track_id',
        'course_id',
        'title',
        'level_id',
        'skills',
    ];
    public function quiz_model_questions()
    {
        return $this->hasMany(\App\Models\QuizModelQuestion::class ,'quiz_model_id');

    }
    public function quiz_model_timeframe()
    {
        return $this->hasMany(\App\Models\QuizModelTimeframe::class ,'quiz_model_id');

    }
    public function level()
    {
        return $this->belongsTo(\App\Models\StageLevel::class);
    }
    public function course()
    {
        return $this->belongsTo(\App\Models\Track::class, 'course_id');
    }
    public function track()
    {
        return $this->belongsTo(\App\Models\Track::class);
    }
}
