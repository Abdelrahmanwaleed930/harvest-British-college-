<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;


/**
 * Class Offer
 * @package App\Models
 * @version May 8, 2021, 3:01 pm UTC
 *
 * @property string $title
 */
class Offer extends Model
{
    use SoftDeletes;

    public $table = 'offers';

    protected $dates = ['deleted_at'];

    public $fillable = [
        'title',
        'title_ar',
        'fees',
        'start_date',
        'end_date',
        'track_id',
        'has_levels',
        'num_levels',
        'image',
        'show_in',
        'status',
        'include_books',
        'course_id',
        'payment_plan_id',
        'full_desc',
        'full_desc_ar',
        'order_by',
        'short_desc',
        'short_desc_ar',
        'duration',
        'offer_status',
        'lead_date',
        'offer_type',
        'offer_ty',
        'best_offer',
    ];
    
    public static $rules = [
        'title' => 'required',
        'fees' => 'required|integer',
        'start_date' => 'required',
        'end_date' => 'required',
        'track_id' => 'required',
        'course_id' => 'required',
        'show_in' => 'nullable',
        'include_books' => 'nullable',
        'has_levels' => 'required',
        'payment_plan_id' => 'required',
        'timeframes' => 'required|array',
        'intervals' => 'nullable|array',
        'branches' => 'required|array',
        'disciplines' => 'required|array',
        'items' => 'nullable|array',
        'num_levels' => 'nullable|integer',
        'services' => 'nullable|array',
        'duration' => 'nullable',
        'offer_status' => 'required',
        'lead_date' => 'required',
        'offer_type' => 'required',
        'offer_ty' => 'required',
       
    ];
    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function track()
    {
        return $this->belongsTo(\App\Models\Track::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function course()
    {
        return $this->belongsTo(\App\Models\Track::class, 'course_id');
    }
    
    public function checkReservation($user_id)
    {
        $check = LeadPayment::where('lead_id',$user_id)->where('paymentable_type','App\Models\Offer')->where('paymentable_id',$this->id)->where('created_at','like','%'.date('Y-m-d').'%')->first();
        if($check != null && $check != ''){
            return false;
        }else{
            return true;
        }
    }
    
    public function getPaymentAmount()
    {
        if($this->payment_plan_id == 1){
            return $this->installment->deposit;
        }elseif($this->payment_plan_id == 3){
            return $this->installment->deposit;
        }else{
            $this->fees;
        }
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function paymentPlan()
    {
        return $this->belongsTo(\App\Models\PaymentPlan::class);
    }

    /**
     * The timeframes that belong to the Offer
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function timeframes(): BelongsToMany
    {
        return $this->belongsToMany(Timeframe::class, 'offer_timeframes', 'offer_id', 'timeframe_id');
    }

    /**
     * The intervals that belong to the Offer
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function intervals(): BelongsToMany
    {
        return $this->belongsToMany(Interval::class, 'offer_intervals', 'offer_id', 'interval_id');
    }

    /**
     * The branches that belong to the Offer
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function branches(): BelongsToMany
    {
        return $this->belongsToMany(Branch::class, 'offer_branches', 'offer_id', 'branch_id');
    }

    /**
     * The disciplines that belong to the Offer
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function disciplines(): BelongsToMany
    {
        return $this->belongsToMany(DisciplineCategory::class, 'offer_disciplines', 'offer_id', 'discipline_id');
    }

    /**
     * The items that belong to the Offer
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function items(): BelongsToMany
    {
        return $this->belongsToMany(ExtraItem::class, 'offer_items', 'offer_id', 'item_id');
    }

    /**
     * The services that belong to the Offer
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function services(): BelongsToMany
    {
        return $this->belongsToMany(ServiceFee::class, 'offer_services', 'offer_id', 'service_id');
    }

    /**
     * Get the installment.
     */
    public function installment()
    {
        return $this->morphOne(\App\Models\Installment::class, 'installmentable');
    }

    /**
     * Get the leadPayments.
     */
    public function leadPayments()
    {
        return $this->morphMany(\App\Models\LeadPayment::class, 'paymentable');
    }
    
    
    public function getcalcAmountAttribute()
    {
        //dd('ddd');
        $items = $this->items;
        $services = $this->services;
        //dd($this,$items,$services);
        $total_amount = 0;
        if ($items) {
            $total_amount += $items->sum('price');
        }
        if($this->has_levels == 1){
            if ($services) {
                $total_amount += $services->sum('fees');
            }
        }else{
            $course_id = $this->course_id;
            $services_data = ServiceFee::whereHas('trainingService', function ($query) use ($course_id) {
                $query->where('course_id', $course_id);
            })->with('trainingService')->get()->pluck('trainingService.title', 'id');
            
            if($services_data != null && count($services_data) > 0){
                //dd(array_key_first($this->services_data->toArray()));
                $service = ServiceFee::find(array_key_first($services_data->toArray()));
                $book = ExtraItem::where('item_category_id',1)->first();
                if($this->include_books == 1){
                    $total_amount += $this->num_levels * ($service->fees + $book->price);
                }else{
                    $total_amount += $this->num_levels * $service->fees;
                }
                
            }
        }
        
        return $total_amount;
    }
}
