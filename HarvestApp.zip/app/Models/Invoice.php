<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;


/**
 * Class Interval
 * @package App\Models
 * @version May 19, 2021, 11:50 pm UTC
 *
 * @property string $name
 * @property string $time
 * @property string $pattern
 * @property integer $sort
 * @property integer $status
 */
class Invoice extends Model
{
    use SoftDeletes;

    public $table = 'invoices';

    protected $dates = ['deleted_at'];

    public $fillable = [
        'branch_id',
        'lead_id',
        'employee_id',
        'total_price',
        'total_discount',
        'print_count',
        'payment_method_id',
        'reference_num',
        'payment_status',
        'upload_bill',
        'payment_method',
        'merchantRefNumber',
        'platform',
        'coupon',
        'coupon_discount',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'branch_id' => 'integer',
        'lead_id' => 'integer',
        'employee_id' => 'integer',
        'total_price' => 'integer',
        'total_discount' => 'integer',
        'print_count' => 'integer',
        'payment_method_id' => 'integer',
        'payment_status' => 'string',
        'reference_num' => 'string',
        'upload_bill' => 'string',
        'payment_method' => 'string',
        'merchantRefNumber' => 'string',
        'platform' => 'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'branch_id' => 'required',
        'lead_id' => 'required',
        'employee_id' => 'required',
        'total_price' => 'required',
        'total_discount' => 'required',
        'payment_method_id' => 'required',
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     **/
    public function lead_payments()
    {
        return $this->hasMany(\App\Models\LeadPayment::class, 'invoice_id');
    }
    
    public function updatePaymentStatus($payment_status,$reference_num = null)
    {
        $this->payment_status = $payment_status;
        $this->reference_num = $reference_num;
        $this->save();
        
        $lead_payments = $this->lead_payments;
        if($lead_payments != null && count($lead_payments) > 0){
            foreach($lead_payments as $lead_payment){
                if($lead_payment->merchantRefNumber != null && $lead_payment->merchantRefNumber != ''){
                    $lead_payment->payment_status = $payment_status;
                    $lead_payment->reference_num = $reference_num;
                    $lead_payment->save();
                    
                    $sub_payments = $lead_payment->subPayments;
                    if($sub_payments != null && count($sub_payments) > 0){
                        foreach($sub_payments as $sub_payment){
                            if($sub_payment->merchantRefNumber != null && $sub_payment->merchantRefNumber != ''){
                                $sub_payment->payment_status = $payment_status;
                                $sub_payment->reference_num = $reference_num;
                                $sub_payment->save();
                            }
                        }
                    }
                }else{
                    
                    $sub_payments = $lead_payment->subPayments;
                    if($sub_payments != null && $sub_payments){
                        foreach($sub_payments as $sub_payment){
                            if($sub_payment->merchantRefNumber != null && $sub_payment->merchantRefNumber != ''){
                                $sub_payment->payment_status = $payment_status;
                                $sub_payment->reference_num = $reference_num;
                                $sub_payment->save();
                            }
                        }
                    }
                }
            }
        }
    }
    
    public function paymentMethod()
    {
        return $this->belongsTo(\App\Models\PaymentMethod::class,'payment_method_id','id');
    }
    
    public function branch()
    {
        return $this->belongsTo(\App\Models\Branch::class);
    }
    
    public function lead()
    {
        return $this->belongsTo(\App\Models\Lead::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function employee()
    {
        return $this->belongsTo(\App\Models\Employee::class);
    }



}
