<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;


/**
 * Class ExtraItem
 * @package App\Models
 * @version July 8, 2021, 9:20 pm UTC
 *
 * @property \App\Models\ItemCategory $itemCategory
 * @property \App\Models\PaymentMethod $paymentMethod
 * @property integer $item_category_id
 * @property integer $payment_plan_id
 * @property string $name
 * @property number $price
 */
class WHTransferedItem extends Model
{
    use SoftDeletes;

    public $table = 'wh_transfered_items';

    protected $dates = ['deleted_at'];

    public $fillable = [
        'item_category_id',
        'item_id',
        'from_place_id',
        'to_place_id',
        'item_count',
        'employee_id',
        'details',
        'notes',
        'balance_from',
        'balance_to'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'item_category_id' => 'integer',
        'item_id' => 'integer',
        'from_place_id' => 'integer',
        'to_place_id' => 'integer',
        'item_count' => 'integer',
        'employee_id' => 'integer',
        'details' => 'string',
        'notes' => 'string',
        'balance_from' => 'string',
        'balance_to' => 'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'item_category_id' => 'required',
        'item_id' => 'required',
        'from_place_id' => 'required',
        'to_place_id' => 'required',
        'item_count' => 'required',
        'employee_id' => 'required',
        'balance_from' => 'nullable',
        'balance_to' => 'nullable',
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function itemCategory()
    {
        return $this->belongsTo(\App\Models\WHItemCategory::class,'item_category_id','id');
    }
    
    public function item()
    {
        return $this->belongsTo(\App\Models\WHItem::class,'item_id','id');
    }
    
    public function fromPlace()
    {
        return $this->belongsTo(\App\Models\Place::class,'from_place_id','id');
    }
    
    public function toPlace()
    {
        return $this->belongsTo(\App\Models\Place::class,'to_place_id','id');
    }
    
    public function employee()
    {
        return $this->belongsTo(\App\Models\Employee::class,'employee_id','id');
    }
}
