<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;


class LeadSourceTrack extends Model
{
    use HasFactory;
    public $table = 'lead_source_track';

    public $fillable = [
        'lead_id',
        'lead_source_b_id',
        'lead_source_a_id',
        'lead_source_c_id',
        'branch_id',
        'employee_id',
        'track_id'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'lead_id' => 'integer',
        'lead_source_b_id' => 'integer',
        'lead_source_a_id' => 'integer',
        'lead_source_c_id' => 'integer',
        'branch_id' => 'integer',
        'employee_id' => 'integer',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'lead_id' => 'required',
        'lead_source_b_id' => 'nullable',
        'lead_source_a_id' => 'required',
        'lead_source_c_id' => 'nullable',
        'branch_id' => 'required',
        'employee_id' => 'required',
    ];
     public function lead(): BelongsTo
    {
        return $this->belongsTo(Lead::class, 'lead_id');
    }

    /**
     * Get the lead source associated with this lead source track.
     */
    public function leadSourceA(): BelongsTo
    {
        return $this->belongsTo(LeadSource::class, 'lead_source_a_id'); // Adjust for the correct field if needed
    }
      public function branch(): BelongsTo
{
    return $this->belongsTo(Branch::class, 'branch_id');
}

public function employee(): BelongsTo
{
    return $this->belongsTo(Employee::class, 'employee_id');
}

public function leadSourceB(): BelongsTo
{
    return $this->belongsTo(LeadSource::class, 'lead_source_b_id');
}

public function leadSourceC(): BelongsTo
{
    return $this->belongsTo(LeadSource::class, 'lead_source_c_id');
}
public function track()
{
    return $this->belongsTo(Track::class);
}
}
