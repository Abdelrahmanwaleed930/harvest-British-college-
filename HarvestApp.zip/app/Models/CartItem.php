<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CartItem extends Model
{
    //
    protected $table = 'cart_items';
    
    protected $fillable = ['cart_id','item_id','item_type','item_title_ar','item_title_en','item_image','price','option_price','primary_price',
                            'total_price'];

    public function getItem()
    {
        if($this->item_type == 'offer'){
            return $this->belongsTo('App\Models\Offer','item_id','id');
        }
        elseif($this->item_type == 'training_service'){
            return $this->belongsTo('App\Models\TrainingService','item_id','id');
        }
        elseif($this->item_type == 'extra_item'){
            return $this->belongsTo('App\Models\ExtraItem','item_id','id');
        }
        else{
            return null;
        }
    }
    
}
    