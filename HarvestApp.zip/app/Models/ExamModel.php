<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExamModel extends Model
{
    // use HasFactory;
    use SoftDeletes;
    public $table = 'exam_model';

    public $fillable = [
        'track_id',
        'course_id',
        'title',
        'level_id',
    ];
    public function exam_model_questions()
    {
        return $this->hasMany(\App\Models\ExamModelQuestion::class ,'exam_model_id');

    }

    

    public function level()
    {
        return $this->belongsTo(\App\Models\StageLevel::class);
    }
    public function course()
    {
        return $this->belongsTo(\App\Models\Track::class, 'course_id');
    }
    public function track()
    {
        return $this->belongsTo(\App\Models\Track::class);
    }
}
