<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class SubPayment
 * @package App\Models
 * @version July 11, 2021, 4:03 am UTC
 *
 * @property \App\Models\PaymentMethod $paymentMethod
 * @property integer $lead_id
 * @property integer $amount
 * @property integer $payment_plan_id
 * @property string $reference_num
 */
class SubPayment extends Model
{
    use SoftDeletes;
    
    public $table = 'sub_payments';

    protected $dates = ['deleted_at'];

    public $fillable = [
        'lead_payment_id',
        'amount',
        'payment_method_id',
        'reference_num',
        'payment_date',
        'branch_id',
        'employee_id',
        'owner_id',
        'due_date',
        'paid',
        'count',
        'delay_fees',
        'payment_status',
        'fawryFees',
        'paymentMethod',
        'merchantRefNumber',
        'upload_bill',
        'type',
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function leadPayment()
    {
        return $this->belongsTo(\App\Models\LeadPayment::class);
    }
    public function getleadPayment()
    {
        return $this->belongsTo(\App\Models\LeadPayment::class,'lead_payment_id');
    }
    
    public function branch()
    {
        return $this->belongsTo(\App\Models\Branch::class);
    }
    
    public function employee()
    {
        return $this->belongsTo(\App\Models\Employee::class,'employee_id');
    }
    public function Owner()
    {
        return $this->belongsTo(\App\Models\Employee::class,'owner_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function payment_method()
    {
        return $this->belongsTo(\App\Models\PaymentMethod::class);
    }
}
