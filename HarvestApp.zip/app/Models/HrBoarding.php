<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HrBoarding extends Model
{
    use HasFactory;

    protected $table = 'hr_boarding';
    
    public $fillable = [
         'employee_id',
         'job_id',
         'branch_id',
         'employee_code',
         'hr_type',
         ];
         
     public static $rules = [
        'employee_id' => 'required',
        'job_id' => 'required',
        'branch_id' => 'required',
        'employee_code' => 'required',
        'hr_type' => 'required',
    ];
         
    public function HrBoardingSectionsEmployee()
    {
        return $this->hasMany('\App\Models\HrBoardingSectionsEmployee','hr_boarding_id');
    }    
    public function employee()
    {
        return $this->belongsTo('\App\Models\Employee','employee_id');
    }  
    public function branch()
    {
        return $this->belongsTo('\App\Models\Branch','branch_id');
        
    }  
    public function Job()
    {
        return $this->belongsTo('\App\Models\Job','job_id');
        
    }  
}
