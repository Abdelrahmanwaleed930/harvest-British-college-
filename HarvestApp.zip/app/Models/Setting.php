<?php

namespace App\Models;

use Eloquent as Model;

class Setting extends Model
{

    public $table = 'settings';

    public $fillable = [
        'default_lang',
        'latitude',
        'longitude',
        'contact_email',
        'telephone',
        'mobile',
        'facebook',
        'linkedin',
        'youtube',
        'instgram',
        'twitter',
        'whatsapp',
        'vimeo_client_id',
        'vimeo_client_secret',
        'vimeo_access_token',
        'placement_test_time',
        'placement_test_repeat',
        'followers',
        'students',
        'instructors',
        'courses',
        'app_store',
        'google_play'
    ];
    
    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'default_lang' => 'string',
        'latitude' => 'string',
        'longitude' => 'string',
        'contact_email' => 'string',
        'telephone' => 'string',
        'mobile' => 'string',
        'facebook' => 'string',
        'linkedin' => 'string',
        'youtube' => 'string',
        'instgram' => 'string',
        'twitter' => 'string',
        'whatsapp' => 'string',
        'vimeo_client_id' => 'string',
        'vimeo_client_secret' => 'string',
        'vimeo_access_token' => 'string',
        'placement_test_time' => 'integer',
        'placement_test_repeat' => 'integer',
        'followers' => 'integer',
        'students' => 'integer',
        'instructors' => 'integer',
        'courses' => 'integer',
        'app_store' => 'string',
        'google_play' => 'string',
        
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'default_lang' => 'required',
        'contact_email' => 'required',
        'telephone' => 'required',
        'mobile' => 'required',
        'facebook' => 'required',
        'linkedin' => 'required',
        'app_store' => 'required',
        'google_play' => 'required',
    ];
}