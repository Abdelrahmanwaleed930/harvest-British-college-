<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HrBoardingSections extends Model
{
    use HasFactory;
    protected $table = 'hr_boarding_sections';
    
    public $fillable = [
         'title',
         'type',
        
         ];
         
     public static $rules = [
        'title' => 'required',
        'type' => 'required',
       
    ];
    public function HrBoardingSectionsEmployee()
    {
        return $this->hasMany('\App\Models\HrBoardingSectionsEmployee','hr_boarding_sections_id');
    }    
     public function HrBoardingSectionsTopics()
    {
        return $this->hasMany('\App\Models\HrBoardingSectionsTopics','hr_boarding_sections_id');
    }   
}
