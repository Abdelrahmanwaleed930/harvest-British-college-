<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;


/**
 * Class ExtraItem
 * @package App\Models
 * @version July 8, 2021, 9:20 pm UTC
 *
 * @property \App\Models\ItemCategory $itemCategory
 * @property \App\Models\PaymentMethod $paymentMethod
 * @property integer $item_category_id
 * @property integer $payment_plan_id
 * @property string $name
 * @property number $price
 */
class ExtraItem extends Model
{
    use SoftDeletes;

    public $table = 'extra_items';

    protected $dates = ['deleted_at'];

    public $fillable = [
        'track_id',
        'item_category_id',
        'payment_plan_id',
        'name',
        'name_ar',
        'full_desc',
        'full_desc_ar',
         'home_desc_en',
        'home_desc_ar',
        'image',
        'status',
        'price',
        'send_operation_inquiry'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'item_category_id' => 'integer',
        'payment_plan_id' => 'integer',
        'name' => 'string',
        'name_ar' => 'string',
        'full_desc' => 'string',
        'full_desc_ar' => 'string',
         'home_desc_en' => 'string',
        'home_desc_ar' => 'string',
        'image' => 'string',
        'status' => 'integer',
        'price' => 'integer',
        'send_operation_inquiry' => 'integer',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'item_category_id' => 'required',
        'payment_plan_id' => 'required',
        'name' => 'required',
        'name_ar' => 'required',
        'status' => 'required',
        'price' => 'required',
        'send_operation_inquiry' => 'nullable',
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function itemCategory()
    {
        return $this->belongsTo(\App\Models\ItemCategory::class);
    }
    
    public function track()
    {
        return $this->belongsTo(\App\Models\Track::class);
    }
    
    public function checkReservation($user_id)
    {
        if(in_array($this->item_category_id,[1,2])){
           $check = LeadPayment::where('lead_id',$user_id)
                            ->where('paymentable_type','App\Models\ExtraItem')
                            ->where('paymentable_id',$this->id)
                            ->first(); 
        }else{
            $check = LeadPayment::where('lead_id',$user_id)
                            ->where('paymentable_type','App\Models\ExtraItem')
                            ->where('paymentable_id',$this->id)
                            ->where('created_at','like','%'.date('Y-m-d').'%')
                            ->first();
        }
        
        if($check != null && $check != ''){
            return false;
        }else{
            return true;
        }
    }
    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function paymentPlan()
    {
        return $this->belongsTo(\App\Models\PaymentPlan::class);
    }

    /**
     * Get the installment.
     */
    public function installment()
    {
        return $this->morphOne(\App\Models\Installment::class, 'installmentable');
    }

    /**
     * Get the leadPayments.
     */
    public function leadPayments()
    {
        return $this->morphMany(\App\Models\LeadPayment::class, 'paymentable');
    }
}
