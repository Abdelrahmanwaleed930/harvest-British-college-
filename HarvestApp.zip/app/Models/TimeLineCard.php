<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TimeLineCard extends Model
{
    use HasFactory;
     
    public $table = 'timeline_card';



    public $fillable = [
        'instructor_id',
        'group_id',
        'session_id',
        'level_id',
        'no_of_student',
        'score',
        
    ];
    
     
    public function SectionsTimeLineCard()
    {
        return $this->hasMany('\App\Models\SectionsTimeLineCard','timeline_card_id');
    }   
    public function instructor()
    {
        return $this->belongsTo('\App\Models\Employee','instructor_id');
    }  
    
    public function group()
    {
        return $this->belongsTo('\App\Models\Group','group_id');
    }  
    public function group_sessions()
    {
        return $this->belongsTo('\App\Models\GroupSession','session_id');
    }  
    public function branch()
    {
        return $this->belongsTo('\App\Models\Branch','branch_id');
        
    }  
     public function level()
    {
        return $this->belongsTo('\App\Models\StageLevel','level_id');
    }  
}
