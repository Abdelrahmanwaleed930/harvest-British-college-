<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;


/**
 * Class CustomerJob
 * @package App\Models
 * @version May 20, 2021, 12:19 am UTC
 *
 * @property string $name
 * @property integer $status
 */
class City extends Model
{
    use SoftDeletes;


    public $table = 'cities';
    

    protected $dates = ['deleted_at'];



    public $fillable = [
        'gov_id',
        'name',
        'status'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'gov_id' => 'integer',
        'name' => 'string',
        'status' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'gov_id' => 'required',
        'name' => 'required',
        'status' => 'required'
    ];

    public function Governorate()
    {
        return $this->belongsTo(Governorate::class,'gov_id','id');
    }
    
}
