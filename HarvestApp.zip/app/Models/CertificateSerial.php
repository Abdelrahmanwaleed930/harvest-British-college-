<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CertificateSerial extends Model
{
    use HasFactory;
     public $table = 'certificate_serial';




    public $fillable = [
        'serial_number',
        'name',
        'level',
        'Grade',
        'issued_on',
        'email',
        'phone',
        'photo',
        'type'
        
    ];
}
