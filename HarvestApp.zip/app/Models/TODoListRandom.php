<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TODoListRandom extends Model
{
    use HasFactory;
    public $table = 'To_Do_List_Random';
     public $fillable = [
        'name',
        'type',
        'start_date',
        'end_date',
        'employee_id',
        'to_do_list_id',
        'note',
        'status',
    ];
    
    protected $casts = [
        'id' => 'integer',
        'start_date' => 'string',
        'end_date' => 'string',
        'type' => 'string',
        'employee_id' => 'integer',
        'to_do_list_id' => 'integer',
        'note' => 'string',
        'status' => 'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'start_date' => 'required',
        'end_date' => 'required',
        'employee_id' => 'required',
        'to_do_list_id' => 'required',
        'type' => 'required',
        'note' => 'nullable',
        'status' => 'nullable',
    ];
     public function TODoList()
    {
        return $this->belongsTo(TODoList::class, 'to_do_list_id');
    }
     public function employee()
    {
        return $this->belongsTo(Employee::class, 'employee_id');
    }
    
    
}
