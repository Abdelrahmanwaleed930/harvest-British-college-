<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmployeeFingers extends Model
{
    use HasFactory;
    public $table = 'employee_finger_ids';

    public $fillable = [
        'employee_id',
        'branch_finger_id',
        'employee_finger_id',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'employee_id' => 'integer',
        'employee_finger_id' => 'integer',
        'branch_finger_id' => 'integer',

        
    ];
    
    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'employee_id' => 'required',
        'branch_finger_id' => 'required',
        'employee_finger_id' => 'required',
        
    ];
    
    public function employee()
    {
        return $this->belongsTo(Employee::class,'employee_id');
    }

}
