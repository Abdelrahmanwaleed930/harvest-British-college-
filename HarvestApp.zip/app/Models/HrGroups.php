<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HrGroups extends Model
{
    use HasFactory;
    
     protected $table ='hr_groups';
     public $fillable = [
        'department_id',
        'start_date',
        'end_date',
        'time_from',
        'time_to',
        'trainer_id',
        'status',
        'session_count',
    ];
    public function hr_group_trainee(){
        return $this->hasMany(HrGroupTrainee::class,'hr_group_id');
    }
    public function hr_group_session(){
        return $this->hasMany(HrGroupSession::class,'hr_group_id');
    }
    public function hr_group_session_attendance(){
        return $this->hasMany(HrGroupSessionAttendance::class,'hr_group_id');
    }
    public function employee()
    {
        return $this->belongsTo(Employee::class,'trainer_id');
    }
    public function department()
    {
        return $this->belongsTo(Department::class,'department_id');
    }
}
