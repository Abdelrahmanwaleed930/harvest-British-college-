<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SurveySections extends Model
{
    use HasFactory;
    protected $table = 'survey_sections';
    
    public $fillable = [
         'title',
         'title_ar',
         'type',
        
         ];
         
     public static $rules = [
        'title' => 'required',
        'title_ar' => 'nullable',
        'type' => 'nullable',
       
    ];
    public function SurveySectionsStudent()
    {
        return $this->hasMany('\App\Models\SurveySectionsStudent','survey_sections_id');
    }    
     public function SurveySectionsTopic()
    {
        return $this->hasMany('\App\Models\SurveySectionsTopic','survey_sections_id');
    }   
}
