<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SurveySectionsTopic extends Model
{
    use HasFactory;
    protected $table = 'survey_sections_topic';
    
    public $fillable = [
         'title',
         'title_ar',
         'survey_sections_id',
         ];
         
     public static $rules = [
        'title' => 'required',
        'title_ar' => 'nullable',
        'survey_sections_id' => 'required',
    ];
    public function SurveySections()
    {
        return $this->belongsTo('\App\Models\SurveySections','survey_sections_id');
        
    } 
    public function SurveySectionTopicAnswer()
    {
        return $this->HasMany('\App\Models\SurveySectionTopicAnswer','survey_section_topic_id');
        
    } 
    
}
