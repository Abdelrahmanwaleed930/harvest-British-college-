<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SafeOperation extends Model
{
    use HasFactory;
    public $table = 'safe_operation';
    public $fillable = [
        'safe_id',
        'operation_type',
        'amount',
        'source'
    ];

    public function safe()
    {
        return $this->belongsTo(Safe::class,'safe_id');
    }
}
