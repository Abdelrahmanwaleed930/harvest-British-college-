<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;


/**
 * Class CustomerJob
 * @package App\Models
 * @version May 20, 2021, 12:19 am UTC
 *
 * @property string $name
 * @property integer $status
 */
class ContactUs extends Model
{
    use SoftDeletes;


    public $table = 'contact_us_form';

    // protected $dates = ['deleted_at'];

    public $fillable = [
        'name',
        'email',
        'phone',
        'message'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'name' => 'string',
        'email' => 'string',
        'phone' => 'string',
        'message' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'name' => 'required',
        'email' => 'required',
        'phone' => 'required',
        'message' => 'required'
    ];

    
}
