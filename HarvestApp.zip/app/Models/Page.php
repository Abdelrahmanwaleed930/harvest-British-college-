<?php

namespace App\Models;

use Eloquent as Model;

class Page extends Model
{
    // use SoftDeletes;

    public $table = 'pages';

    public $fillable = [
        'title_en',
        'text_en',
        'link_en',
        'title_ar',
        'text_ar',
        'link_ar',
        'status',
    ];
    
    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'title_en' => 'string',
        'text_en' => 'string',
        'link_en' => 'string',
        'title_ar' => 'string',
        'status' => 'string',
        'text_ar' => 'string',
        'link_ar' => 'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        //'image' => 'required',
        'title_en' => 'required',
        'title_ar' => 'required',
        'text_en' => 'required',
        'text_ar' => 'required',
        'status' => 'required'
    ];
}