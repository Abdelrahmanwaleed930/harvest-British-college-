<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Branch
 * @package App\Models
 * @version May 8, 2021, 2:55 pm UTC
 *
 * @property string $name
 * @property string $address
 * @property string $phone
 */
class EmployeeAttendance extends Model
{

    public $table = 'employee_attendance';

    public $fillable = [
        'employee_id',
        'day',
        'interval_id',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'employee_id' => 'integer',
        'day' => 'integer',
        'interval_id' => 'integer'
    ];
    
    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'employee_id' => 'required',
        'day' => 'required',
        'interval_id' => 'required',
    ];
    
}
