<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SurveySectionsStudent extends Model
{
    use HasFactory;
    protected $table = 'survey_sections_student';
    public $fillable = [
         'survey_id',
         'survey_sections_id',
         'survey_sections_topic_id',
         'survey_section_topic_answer_id',
         'comment',
         ];
         
     public static $rules = [
        'survey_id' => 'required',
        'survey_sections_id' => 'required',
        'survey_sections_topic_id' => 'required',
        'survey_section_topic_answer_id' => 'required',
        'comment' => 'nullable',
    ];
    public function Survey()
    {
        return $this->belongsTo('\App\Models\Survey','survey_id');
        
    } public function SurveySections()
    {
        return $this->belongsTo('\App\Models\SurveySections','survey_sections_id');
        
    }
    public function SurveySectionsTopic()
    {
        return $this->belongsTo('\App\Models\SurveySectionsTopic','survey_sections_topic_id');
        
    }
    public function SurveySectionTopicAnswer()
    {
        return $this->belongsTo('\App\Models\SurveySectionTopicAnswer','survey_section_topic_answer_id');
        
    }
}
