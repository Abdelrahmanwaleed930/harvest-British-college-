<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;



/**
 * Class PlacementApplicant
 * @package App\Models
 * @version May 28, 2021, 1:51 pm UTC
 *
 * @property string $name
 * @property string $email
 * @property string $mobile
 * @property string $gender
 * @property string $job
 * @property string $university
 * @property number $vocabulary_score
 * @property number $grammar_score
 * @property number $reading_score
 * @property number $writing_score
 * @property number $listening_score
 * @property number $speaking_score
 * @property integer $level
 * @property string $notes
 * @property integer $status
 */
class PlacementKidsApplicant extends Model
{

    public $table = 'placement_kids_applicants';

    public static $PT_levels = [
                        "17" => "Kidzy Diploma 1",
                        "18" => "Kidzy Diploma 2",
                    ];

    public $fillable = [
        'name',
        'email',
        'mobile',
        'branch_id',
        'lead_id',
        'track_id',
        'instructor_id',
        'gender',
        'job',
        'university',
        'vocabulary_score',
        'grammar_score',
        'reading_score',
        'writing_score',
        'listening_score',
        'speaking_score',
        'level',
        'notes',
        'status',
        'finish',
        'finish_date',
        'remain_duration'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'lead_id' => 'integer',
        'track_id' => 'integer',
        'name' => 'string',
        'email' => 'string',
        'mobile' => 'string',
        'gender' => 'string',
        'job' => 'string',
        'university' => 'string',
        'vocabulary_score' => 'decimal:1',
        'grammar_score' => 'decimal:1',
        'reading_score' => 'decimal:1',
        'listening_score' => 'decimal:1',
        'speaking_score' => 'decimal:1',
        'writing_score' => 'decimal:1',
        'level' => 'integer',
        'notes' => 'string',
        'status' => 'string',
        'finish' => 'string',
        'finish_date' => 'string',
        'remain_duration' => 'integer',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        // 'vocabulary_score' => 'numeric|between:0,99.5',
        // 'grammar_score' => 'numeric|between:0,99.5',
        // 'reading_score' => 'numeric|between:0,99.5',
        'writing_score' => 'numeric|between:0,99.5',
        'listening_score' => 'numeric|between:0,99.5',
        'speaking_score' => 'numeric|between:0,99.5',
        'level' => 'integer'
    ];

    /**
     * Get the branch that owns the PlacementApplicant
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }
    public function lead()
    {
        return $this->belongsTo(Lead::class ,'lead_id');
    }
    public function track()
    {
        return $this->belongsTo(Track::class ,'track_id');
    }
    public function instructor(): BelongsTo
    {
        return $this->belongsTo(Employee::class,'instructor_id','id');
    }
    
    public function answers()
    {
        return $this->hasMany('App\Models\KidsApplicantAnswer', 'placement_applicant_id');
    }
    public function getLead()
    {
        return Lead::where('mobile_1',$this->mobile)->first();
    }
    
    public function cases()
    {
        return $this->hasMany(kids_pt_application_case::class,'kids_pt_application_id','id');
    }
    
    public function lastcase()
    {
        return $this->hasOne(kids_pt_application_last_case::class,'kids_pt_application_id','id');
    }
    public function lastFollowup()
    {
        return kids_pt_application_last_case::where('kids_pt_application_id',$this->id)->orderBy('created_at','desc')->first();
    }
}
