<?php

namespace App\Models;

use Eloquent as Model;

/**
 * Class LabelType
 * @package App\Models
 * @version May 9, 2021, 2:29 pm UTC
 *
 * @property \App\Models\Label $label
 * @property string $name
 * @property integer $label_id
 */
class LabelType extends Model
{

    public $table = 'label_types';

    public $fillable = [
        'name',
        'name_ar',
        'label_id',
        'category',
        'status',
        'feedback',
        'feedback_date',
        'action',
        'action_date',
        'type'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'name' => 'string',
        'name_ar' => 'string',
        //'label_id' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'name' => 'required',
        'name_ar' => 'required',
        //'label_id' => 'required'
        'category' => 'required',
    ];



    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    /*

    
    public function label()
    {
        return $this->belongsTo(\App\Models\Label::class);
    }*/
}
