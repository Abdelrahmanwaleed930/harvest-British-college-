<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Survey extends Model
{
    use HasFactory;
    protected $table = 'survey';
    
    public $fillable = [
         'branch_id',
         'course_id',
         'level_id',
         'days',
         'type',
         'student_id',
         'instructor_id',
         'interval_id',
         ];
         
     public static $rules = [
        'branch_id' => 'nullable',
        'course_id' => 'nullable',
        'level_id' => 'nullable',
        'days' => 'nullable',
        'type' => 'nullable',
        'student_id' => 'nullable',
        'instructor_id' => 'nullable',
        'interval_id' => 'nullable',
    ];
         
    public function SurveySectionsStudent()
    {
        return $this->hasMany('\App\Models\SurveySectionsStudent','survey_id');
    } 
    public function course()
    {
        return $this->belongsTo(\App\Models\Track::class, 'course_id');
    }
    
    public function lead()
    {
        return $this->belongsTo('\App\Models\Lead','student_id');
    }  
    public function branch()
    {
        return $this->belongsTo('\App\Models\Branch','branch_id');
        
    } 
    public function instructor()
    {
        return $this->belongsTo(\App\Models\Employee::class, 'instructor_id');
    }
     public function interval()
    {
        return $this->belongsTo(\App\Models\Interval::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     **/
    public function level()
    {
        return $this->belongsTo(\App\Models\StageLevel::class,'level_id','id');
    } 
}
