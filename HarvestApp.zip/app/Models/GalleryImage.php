<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Class Feedback
 * @package App\Models
 * @version November 19, 2021, 6:15 am EET
 *
 * @property string $name
 * @property integer $label_type_id
 * @property integer $status
 */
class GalleryImage extends Model
{

    public $table = 'gallery_images';

    public $fillable = [
        'image',
        'gallery_id',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'image' => 'string',
        'gallery_id' => 'integer',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        
    ];

    /**
     * Get the labelType that owns the Feedback
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function labelType(): BelongsTo
    {
        return $this->belongsTo(Gallery::class,'gallery_id','id');
    }
}
