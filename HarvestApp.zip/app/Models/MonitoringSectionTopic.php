<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MonitoringSectionTopic extends Model
{
    use HasFactory;
    protected $table = 'monitoring_sections_topic';
    public $fillable = [
         'title',
         'score',
         'good',
         'fair',
         'verygood',
         'excellent',
         'low',
         'monitoring_sections_id',
         ];
         
          protected $casts = [
        'id' => 'integer',
        'title' => 'string',
        'score' => 'float',
        'good' => 'float',
        'fair' => 'float',
        'verygood' => 'float',
        'excellent' => 'float',
        'low' => 'float',
        'monitoring_sections_id' => 'integer',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'id' => 'integer',
        'title' => 'required',
        'score' => 'required',
        'good' => 'required',
        'fair' => 'required',
        'verygood' => 'required',
        'excellent' => 'required',
        'low' => 'required',
        'monitoring_sections_id' => 'required',
    ];
}
