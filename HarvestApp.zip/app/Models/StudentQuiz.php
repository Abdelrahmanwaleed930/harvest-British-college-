<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StudentQuiz extends Model
{
    use HasFactory;
     public $table = 'student_quiz';

    public $fillable = [
        'student_id',
        'group_id',
        'lead_id',
        'track_id',
        'course_id',
        'level_id',
        'step',
        'session_id',
        'section1_score',
        'section2_score',
        'finish',
        'notes',
        'status',
        'quiz_model_id'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'student_id' => 'integer',
        'group_id' => 'integer',
        'lead_id' => 'integer',
        'track_id' => 'integer',
        'course_id' => 'integer',
        'level_id' => 'integer',
        'step' => 'integer',
        'section1_score' => 'decimal:1',
        'section2_score' => 'decimal:1',
        
        'finish' => 'integer',
        'notes' => 'string',
        'status' => 'string',
        'quiz_model_id' => 'integer',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        
        'section1_score' => 'numeric|between:0,99.5',
        'section2_score' => 'numeric|between:0,99.5',
        
        
    ];

    /**
     * Get the branch that owns the PlacementApplicant
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function student()
    {
        return $this->belongsTo(GroupStudent::class,'student_id','id');
    }
    public function group()
    {
        return $this->belongsTo(Group::class,'group_id','id');
    }
    public function lead()
    {
        return $this->belongsTo(Lead::class,'lead_id','id');
    }
    
    public function track()
    {
        return $this->belongsTo(Track::class,'track_id','id');
    }
    public function course()
    {
        return $this->belongsTo(Track::class,'course_id','id');
    }
    public function level()
    {
        return $this->belongsTo(StageLevel::class,'level_id','id');
    }
    public function session()
    {
        return $this->belongsTo(GroupSession::class,'session_id','id');
    }
    public function quiz_model()
    {
        return $this->belongsTo(QuizModel::class,'quiz_model_id');
    }

    public function answers()
    {
        return $this->hasMany('App\Models\StudentQuizAnswer', 'student_quiz_id');
    }
}
