<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExpenseType extends Model
{
    use HasFactory;

    public $table = 'expense_types';
    public $fillable = [
        'name',
        'parent_id'
    ];
    
    public function getParent()
    {
        return $this->belongsTo('App\Models\ExpenseType','parent_id','id');
    }
}
