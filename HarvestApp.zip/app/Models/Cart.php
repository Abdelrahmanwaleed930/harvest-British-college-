<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Auth;

class Cart extends Model
{
    //
    protected $table = 'cart';
    
    protected $fillable = ['lead_id','session_lead','service_charge','delivery_cost','vat','primary_price','vat_cost','service_charge_cost',
                            'coupon','coupon_discount','coupon_cost','offer_discount','net_price','total_price'];

    public function getUser()
    {
        return $this->belongsTo('App\Models\Lead','lead_id','id');
    }
    
    public function getItems()
    {
        return $this->hasMany('App\Models\CartItem','cart_id','id');
    }
    
    public function calculateTotalPrice()
    {
        $cart_items = CartItem::where('cart_id',$this->id)->get();
        $primary_price = 0;
        foreach($cart_items as $cart_item){
            $primary_price += $cart_item->total_price;
        }
        $this->primary_price = $primary_price;
        $this->total_price = $primary_price;
        
        if($this->delivery_cost != null && $this->delivery_cost != 0 && $this->delivery_cost > 0){
            $this->total_price += $this->delivery_cost;
        }
        if($this->vat_cost != null && $this->vat_cost != 0 && $this->vat_cost > 0){
            $this->total_price += $this->vat_cost;
        }
        if($this->service_charge_cost != null && $this->service_charge_cost != 0 && $this->service_charge_cost > 0){
            $this->total_price += $this->service_charge_cost;
        }
        if($this->coupon_cost != null && $this->coupon_cost != 0 && $this->coupon_cost > 0){
            $this->net_price = $this->total_price - $this->coupon_cost;
            //dd($this->net_price,$this->total_price,$this->coupon_cost);
        }
        if($this->offer_discount != null && $this->offer_discount != 0 && $this->offer_discount > 0){
            if($this->net_price != null && $this->net_price != 0 && $this->net_price > 0){
                $this->net_price -= $this->net_price;
            }else{
                $this->net_price = $this->total_price - $this->offer_discount;
            }
        }
        
        $this->save();
    }
    
    public function addCartItem($request)
    {
        $price = 0;
        $check_item = null;
        if($request->item_type == 'offer'){
            $item = Offer::where('id',$request->item_id)->where('end_date','>=',date('Y-m-d'))->whereIn('show_in',['website','both'])->where('status',1)->first();
            /*
            if(Auth::check()){
                $check_item = PackageUser::where('lead_id',Auth::user()->id)->where('package_id',$item->id)->where('expire_date','>=',date('Y/m/d', strtotime('+3 days')))->first();
            }
            */
            
            if($item != null && $item != ''){
                if($item->payment_plan_id == 1){
                    $price = $item->installment->deposit;
                }elseif($item->payment_plan_id == 3){
                    $price = $item->installment->deposit;
                }else{
                    $price = $item->fees;
                }
                
                if($item -> fees > 0 && $item -> fees != null){
                    $price = $item -> fees;
                }
            }
        }
        elseif($request->item_type == 'trainingServices'){
            $item = TrainingService::where('id',$request->item_id)->where('status',1)->first();
            /*
            if(Auth::check()){
                $check_item = CourseRegister::where('course_id',$item->id)->where('lead_id',Auth::user()->id)->first();
                if(! $check_item){
                    $check_item = PackageCourse::where('course_id',$item->id)->where('lead_id',Auth::user()->id)->where('package_expire_date','>=',date('Y/m/d'))->first();
                }
            }*/
            if($item ->getFees-> fees > 0 && $item ->getFees-> fees != null){
                $price = $item ->getFees-> fees;
            }
        }
        elseif($request->item_type == 'extra_item'){
            $item = ExtraItem::where('id',$request->item_id)->where('status',1)->first();
            if($item -> price > 0 && $item -> price != null){
                $price = $item -> price;
            }
        }
        else{
            
        }
        //dd($item);
        if($item != null && $item != ''){
            $cart_item = new CartItem;
            $cart_item -> cart_id = $this->id;
            $cart_item -> item_id = $request->item_id;
            $cart_item -> item_type = $request->item_type;
            $cart_item -> item_image = $request->item_image;
            $cart_item -> item_title_ar = $request->item_title_ar;
            $cart_item -> item_title_en = $request->item_title_en;
            $cart_item -> price = $price;
            $cart_item -> save();
            
            $cart_item -> primary_price = $cart_item->price;
            $cart_item -> total_price = $cart_item -> primary_price;
            $cart_item -> save();
            
            $this->coupon = null;
            $this->coupon_discount = null;
            $this->coupon_cost = null;
            $this->net_price = null;
            $this->save();
        }
    }
    
}