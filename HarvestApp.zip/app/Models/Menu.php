<?php

namespace App\Models;

use Eloquent as Model;

class Menu extends Model
{
    // use SoftDeletes;

    public $table = 'menus';

    public $fillable = [
        'title_en',
        'title_ar',
        'position_type',
        'parent_id',
        'type',
        'type_value',
        'order_by',
        'image',
        'status',
        'meta_keywords',
        'meta_description',
    ];
    
    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'title_en' => 'string',
        'title_ar' => 'string',
        'position_type' => 'string',
        'parent_id' => 'integer',
        'type' => 'string',
        'image' => 'string',
        'type_value' => 'string',
        'order_by' => 'integer',
        'status' => 'integer',
        'meta_keywords' => 'string',
        'meta_description' => 'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        //'image' => 'required',
        'title_en' => 'required',
        'title_ar' => 'required',
        'position_type' => 'required',
        'type' => 'required',
        'order_by' => 'required',
        'status' => 'required'
    ];
    
    public function getParent()
    {
        return $this->belongsTo('App\Models\Menu','parent_id','id');
    }
    
    public function getTypeValue()
    {
        if($this->type == 'page'){
            $value = Page::find($this->type_value)->title_en;
        }elseif($this->type == 'link'){
            $value = $this->type_value;
        }
        else{
            $value = '';
        }
        
        return $value;
    }
    
    public function getSubMenus()
    {
        return $this->hasMany('App\Models\Menu','parent_id','id');
    }
}