<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Monitoring extends Model
{
    use HasFactory;
    
    protected $table = 'monitoring';
    public $fillable = [
         'instructor_id',
         'senior_id',
         'level_id',
         'group_id',
         'session_id',
         'branch_id',
         'score',
         ];
         
         
    public function SectionsMonitoring()
    {
        return $this->hasMany('\App\Models\SectionsMonitoring','monitoring_id');
    }    
    
    public function instructor()
    {
        return $this->belongsTo('\App\Models\Employee','instructor_id');
    }  
    public function level()
    {
        return $this->belongsTo('\App\Models\StageLevel','level_id');
    }  
    public function senior()
    {
        return $this->belongsTo('\App\Models\Employee','senior_id');
    }  
    public function group()
    {
        return $this->belongsTo('\App\Models\Group','group_id');
    }  
    public function group_sessions()
    {
        return $this->belongsTo('\App\Models\GroupSession','session_id');
    }  
    public function branch()
    {
        return $this->belongsTo('\App\Models\Branch','branch_id');
        
    }  
         
         
}
