<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VacationHistory extends Model
{
    use HasFactory;
    public $table = 'vacation_histories';
    public $fillable = [
        'employee_id',
        'vacations_id',
        'type',
        'start',
        'end',
        'days',
        'status',
        'confirmed_by_id',
        'confirm_mang',
        'department_id',
    ];
    public function employee()
    {
        return $this->belongsTo(Employee::class,'employee_id');
    }
    public function confirmed_by()
    {
        return $this->belongsTo(Employee::class,'confirmed_by_id');
    }
    public function vacation()
    {
        return $this->belongsTo(Vacation::class,'vacations_id');
    }
    public function department()
    {
        return $this->belongsTo(Department::class,'department_id');
    }

}
