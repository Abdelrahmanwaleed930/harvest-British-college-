<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RefundRequest extends Model
{
    use HasFactory;
    
    public $table = 'refund_request';

    
    public $fillable = [
        'lead_id',
        'employee_id',
        'branch_id',
        'method_id',
        'amount',
        'note',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'lead_id' => 'integer',
        'employee_id' => 'integer',
        'branch_id' => 'integer',
        'method_id' => 'integer',
        'amount' => 'integer',
        'note' => 'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'lead_id' => 'required',
        'branch_id' => 'nullable',
        'method_id' => 'required',
        'employee_id' => 'nullable',
        'amount' => 'required',
        'note' => 'nullable',
    ];
    
    
    public function Lead()
    {
        return $this->belongsTo(Lead::class, 'lead_id');
    }
    public function Employee()
    {
        return $this->belongsTo(Employee::class, 'employee_id');
    }
    
    public function Branch()
    {
        return $this->belongsTo(Branch::class, 'branch_id');
    }
    
    public function PaymentMethod()
    {
        return $this->belongsTo(PaymentMethod::class, 'method_id');
    }
    
}
