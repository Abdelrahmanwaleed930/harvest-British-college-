<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ItCurrentItems extends Model
{
    use HasFactory;
    
    public $table = 'it_current_items';


    public $fillable = [
        'it_items_categories_id',
        'it_item_id',
        'branch_id',
        'employee_id',
        'created_by_id',
        'balance'
    ];
    public function ititemCategory()
    {
        return $this->belongsTo(\App\Models\ITItemCategory::class,'it_items_categories_id','id');
    }
    
    public function ititem()
    {
        return $this->belongsTo(\App\Models\ITItem::class,'it_item_id','id');
    }
    
    public function branch()
    {
        return $this->belongsTo(\App\Models\Branch::class,'branch_id','id');
    }
    
    public function created_by()
    {
        return $this->belongsTo(\App\Models\Employee::class,'created_by_id','id');
    }
    public function employee()
    {
        return $this->belongsTo(\App\Models\Employee::class,'employee_id','id');
    }
}
