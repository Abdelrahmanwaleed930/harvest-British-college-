<?php

namespace App\Models;

use Eloquent as Model;

class PeopleOpinion extends Model
{
    // use SoftDeletes;

    public $table = 'people_opinions';

    public $fillable = [
        'name_en',
        'text_en',
        'job_title_en',
        'name_ar',
        'text_ar',
        'job_title_ar',
        'image',
        'order_by',
        'status',
    ];
    
    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'name_en' => 'string',
        'text_en' => 'string',
        'job_title_en' => 'string',
        'name_ar' => 'string',
        'image' => 'string',
        'status' => 'integer',
        'order_by' => 'integer',
        'text_ar' => 'string',
        'job_title_ar' => 'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        //'image' => 'required',
        'name_en' => 'required',
        'name_ar' => 'required',
        'order_by' => 'required',
        'status' => 'required'
    ];
}