<?php

namespace App\Models;

use Spatie\Permission\Traits\HasRoles;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use DB;
use Carbon\Carbon;
use DateTime;


/**
 * Class Employee
 * @package App\Models
 * @version May 8, 2021, 9:51 am UTC
 *
 * @property string $first_name
 * @property string $last_name
 * @property string $mobile
 * @property string $email
 * @property string $password
 * @property string $branch
 * @property string $position
 */
class Employee extends Authenticatable
{
    use HasFactory, Notifiable, SoftDeletes, HasRoles;

    /**
     * Table name.
     *
     * @var string
     */
    public $table = 'employees';

    /**
     * Dates array.
     *
     * @var array
     */
    protected $dates = ['deleted_at'];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $fillable = [
        'first_name',
        'last_name',
        'mobile',
        'email',
        'password',
        // 'branch_id',
        'department_id',
        'phone',
        'address',
        'national_id',
        'teaching_band',
        'up_to_level',
        'emergency_name',
        'emergency_phone',
        'emergency_relation',
        'image',
        'middle_name',
        'nationality',
        'gender',
        'birth_date',
        'country',
        'governorate',
        'city',
        'area',
        'last_gradute_level',
        'university',
        'facilty',
        'facilty_department',
        'gradute_year',
        'experience',
        'starting_salary',
        'statues',
        'hiring_date',
        'employee_plan',
        'salary_plan',
        'status',
        'academic_certificate_image',
        'birth_certificate_image',
        'passport_image',
        'number_of_insurance',
        'criminal_status_image',
        'labor_office_notice',
        'educational_certificate_image',
        'military_status_image',
        'social_insurance_stamp',
        'cv',
        'academic_certificate_image_mimeType',
        'birth_certificate_image_mimeType',
        'passport_image_mimeType',
        'number_of_insurance_mimeType',
        'criminal_status_image_mimeType',
        'labor_office_notice_mimeType',
        'educational_certificate_image_mimeType',
        'military_status_image_mimeType',
        'social_insurance_stamp_mimeType',
        'cv_mimeType',
        'account_Type',
        'job_id',
        'izabella_code',
        'pass'
    ];  

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'first_name' => 'string',
        'last_name' => 'string',
        'mobile' => 'string',
        'email' => 'string',
        //'status' => 'string',
        // 'branch_id' => 'integer',
        'department_id' => 'integer',
        'job_id' => 'integer',
        // 'finger_id' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'first_name' => 'required',
        'last_name' => 'required',
        'mobile' => 'required',
        //'email' => 'required|email|unique:employees,email',
        //'password' => 'required|confirmed',
        'department_id' => 'required',
        'job_id' => 'required',
        'branches' => 'required|array',
        'places' => 'nullable|array',
        'phone' => 'required',
        'address' => 'required',
        'national_id' => 'required',
        // 'teaching_band' => 'required',
        // 'up_to_level' => 'required',
        'emergency_name' => 'required',
        'emergency_phone' => 'required',
        'emergency_relation' => 'required',
        'account_Type' => 'required',
        'current_branch'=>'required',
        'izabella_code'=>'nullable',
        'pass'=>'nullable',
        // 'finger_id'=>'nullable',
        //'roles' => 'required|array',
        //'status' => 'required',
    ];

    /**
     * Set password encryption.
     *
     * @param String $val
     * @return void
     */
    public function setPasswordAttribute($val)
    {
        if ($val) {
            $this->attributes['password'] = bcrypt($val);
        }
    }
    public function HrBoarding()
    {
        return $this->hasMany('\App\Models\HrBoarding','employee_id');
    }  
    public function Group()
    {
        return $this->hasMany('\App\Models\Group','instructor_id');
    }  
    public function LeadPayment()
    {
        return $this->hasMany('\App\Models\LeadPayment','owner_id');
    }  
    
    public function getJobs()
    {
        return Job::where('department_id', $this->department_id)->pluck('title','id')->toArray();
    }
    
    public function getRoles()
    {
        return DB::table('model_has_roles')->where('model_type','App\Models\Employee')->where('model_id',$this->id)->pluck('role_id')->toArray();
    }

    /**
     * Get employee name.
     *
     * @return void
     */
    public function getNameAttribute()
    {
        return $this->attributes['first_name'] . ' ' . $this->attributes['middle_name'] . ' ' . $this->attributes['last_name'];
    }
    
    public function getActualCustomers($branches_ids = null)
    {
        $instructor_groups = Group::where('instructor_id',$this->id)->whereHas('subRound',function($query){
            $query->where('start_date','<',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
        });
        if($branches_ids != null && $branches_ids != ''){
            $instructor_groups->whereIn('branch_id',$branches_ids);
        }
        
        $instructor_groups = $instructor_groups->withCount('students')->get();
        return $instructor_groups->sum('students_count');
    }
    
    public function getActualPlan($branches_ids = null)
    {
        $instructor_groups = Group::where('instructor_id',$this->id)->whereHas('subRound',function($query){
            $query->where('start_date','<',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
        });
        if($branches_ids != null && $branches_ids != ''){
            $instructor_groups->whereIn('branch_id',$branches_ids);
        }
        
        $instructor_groups = $instructor_groups->select('days',DB::raw('count(*) as intervalcount,MAX(interval_id) as intervalid'))->groupBy('days')->get();
        $plan = ['days' => 0,'hours' => 0,'intervalcount' => 0];
        foreach($instructor_groups as $instructor_group){
            $plan['intervalcount'] += $instructor_group->intervalcount;
            $day = 0;
            if($instructor_group->days == 1){
                $plan['days'] += 1;
                $day = 1;
            }
            if(in_array($instructor_group->days,[2,3,4])){
                $plan['days'] += 2;
                $day = 2;
            }
            if(in_array($instructor_group->days,[5,6])){
                $plan['days'] += 3;
                $day = 3;
            }
            if(in_array($instructor_group->intervalid,[11,12,13])){
                $plan['hours'] += 4 * $instructor_group->intervalcount * $day;
            }else{
                $plan['hours'] += 2 * $instructor_group->intervalcount * $day;
            }
        }
        return $plan;
    }
    
    public function getPlan()
    {
        $employee_attendances = DB::table('employee_attendance')->select('day',DB::raw('count(*) as intervalcount,MAX(interval_id) as intervalid'))->where('employee_id',$this->id)->groupBy('day')->get();
        $plan = ['days' => 0,'hours' => 0,'intervalcount' => 0];
        foreach($employee_attendances as $employee_attendance){
            $plan['intervalcount'] += $employee_attendance->intervalcount;
            $day = 0;
            if($employee_attendance->day == 1){
                $plan['days'] += 1;
                $day = 1;
            }
            if(in_array($employee_attendance->day,[2,3,4])){
                $plan['days'] += 2;
                $day = 2;
            }
            if(in_array($employee_attendance->day,[5,6])){
                $plan['days'] += 3;
                $day = 3;
            }
            if(in_array($employee_attendance->intervalid,[11,12,13])){
                $plan['hours'] += 4 * $employee_attendance->intervalcount * $day;
            }else{
                $plan['hours'] += 2 * $employee_attendance->intervalcount * $day;
            }
        }
        return $plan;
    }

    public function getImageAttribute($val)
    {
        if ($val) {
            return url('uploads/profile_picture/'.$val);
        }
        return null;
    }

    public function attendances()
    {
        return $this->hasMany('\App\Models\EmployeeAttendance','employee_id','id');
    }
    /**
     * The branches that belong to the Employee
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function branches(): BelongsToMany
    {
        return $this->belongsToMany(Branch::class, 'branches_employees', 'employee_id', 'branch_id');
    }
    

    public function current_branch()
    {
        return Branch::where('id' , $this->current_branch)->pluck('name')->first();
    }
    public function branch()
    {
        return Branch::where('id' , $this->current_branch)->first();
    }
    
    public function places(): BelongsToMany
    {
        return $this->belongsToMany(Place::class, 'places_employees', 'employee_id', 'place_id');
    }

    /**
     * Get the department that owns the Employee
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function department(): BelongsTo
    {
        return $this->belongsTo(Department::class);
    }

    /**
     * Get the job that owns the Employee
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function job(): BelongsTo
    {
        return $this->belongsTo(Job::class);
    }
    public function job_application_cases()
    {
        return $this->hasMany(JobApplicationCase::class);
    }

    public function safe()
    {
        return $this->hasMany(Safe::class)->where('is_manager',0);
    }
    public function branchSafe()
    {
        return $this->hasMany(Safe::class)->where('is_manager','=',1);
    }
    public function getavg()
    {
       $count =0;
       
       if($this->academic_certificate_image !=null)
       {$count++;}
       if($this->birth_certificate_image !=null)
       {$count++;}
       if($this->national_id !=null)
       {$count++;}
       if($this->number_of_insurance !=null)
       {$count++;}
       if($this->criminal_status_image !=null)
       {$count++;}
       if($this->labor_office_notice_mimeType !=null)
       {$count++;}
       if($this->educational_certificate_image_mimeType !=null)
       {$count++;}
       if($this->military_status_image_mimeType !=null)
       {$count++;}
       if($this->social_insurance_stamp_mimeType !=null)
       {$count++;}
       return $count;
    }
    public function getsumlabel($employee_id ,$label_id ,$date){
        // return $date;
        $registration_from=null;
        $reg_to=null;

        if ($date && $date != null && $date != '') {
            $daterange = explode(' - ',$date);
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
            
        }
        if ($registration_from != null && $registration_to != '')
         {
            
             return $count = JobApplicationCase::where('label_type_id',$label_id)
             ->whereHas('employee',function($quary)use ($employee_id){
                 $quary->where('account_Type', 'H.Q Account')->where('status',1)->where('employee_id',$employee_id);
             })->whereBetween('created_at', [$registration_from, $registration_to])->count();
         }
                

        else{
            return $count = JobApplicationCase::where('label_type_id',$label_id)
            ->whereHas('employee',function($quary)use ($employee_id){
                $quary->where('account_Type', 'H.Q Account')->where('status',1)->where('employee_id',$employee_id);
            })->where('created_at','like','%'.date('Y-m-d').'%')->count();
        
        }
        
          

    }
    public function total ($employee_id , $date)
    {
        $registration_from=null;
        $reg_to=null;

        if ($date && $date != null && $date != '') {
            $daterange = explode(' - ',$date);
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
            
        }
        if ($registration_from != null && $registration_to != '')
         {
            
            return $count = JobApplicationCase::whereHas('employee',function($quary)use ($employee_id){
                $quary->where('account_Type', 'H.Q Account')->where('status',1)->where('employee_id',$employee_id);
            })->whereBetween('created_at', [$registration_from, $registration_to])->count();
         }
                

        else{
            return $count = JobApplicationCase::whereHas('employee',function($quary)use ($employee_id){
                $quary->where('account_Type', 'H.Q Account')->where('status',1)->where('employee_id',$employee_id);
            })->where('created_at','like','%'.date('Y-m-d').'%')->count();
        }
      

    }
    public function agent($id)
    {
        $datenow = Carbon::now();
         $monthName = $datenow->format('F');
         
        date_add($datenow,date_interval_create_from_date_string("1 days"));

         $month_number = date("n",strtotime($monthName));
          $date = $monthName.' 1 2023';
         $firstday= date('Y-m-d', strtotime($date));
         
          $countemployee =Employee::where('account_Type', 'Operations Account')
                 ->where('status',1)->where('current_branch' ,$this->current_branch)->groupBy('id')->get()->count();
                 
                 
        $branch = Branch::where('status',1)->where('id',$this->current_branch)->first();
             
          if($id == 0){
            return $branch->targetcash(1);
          }
          elseif($id == 1)
          {
                $safe = Safe::where('employee_id',$this->id)->where('status' ,1)->pluck('id');
              
              if($safe)
              {
                    $sum_target =SafeOperation::whereIn('safe_id',$safe)
                  ->whereBetween('created_at',[$firstday,  date_format($datenow,"Y-m-d")])
                  ->where('operation_type' ,'income')->where('source' ,'!=','transfer')->get()->sum('amount');
                  
                  if($countemployee != 0 ){
                    $target = $branch->targetcash(1); 
                    
                   if($sum_target >= $target ){
                       $bouns = ($target * 2)/100;

                       return $bouns;
                   }
                   else{
                       return  'Not Done';
                   }
                   
                  }
                  else{
                      return 'No Emplyee';
                  }
                  
                  
              }
              else{
                  return 'No Safe Found';
              }
          }
          elseif($id == 2){
               $safe = Safe::where('employee_id',$this->id)->where('status' ,1)->pluck('id');
              if($safe)
              {
                   return $sum_target =SafeOperation::whereIn('safe_id',$safe)
                  ->whereBetween('created_at',[$firstday,  date_format($datenow,"Y-m-d")])
                  ->where('operation_type' ,'income')->where('source' ,'!=','transfer')->get()->sum('amount');
                  
              }
              else{
                  return 'No Safe Found';
              }
          }
              
          
          
    }
    public function totalcall($type ,$date){
        $registration_from=null;
        $reg_to=null;

        if ($date && $date != null && $date != '') {
            $daterange = explode(' - ',$date);
            $registration_from = date_format(date_create($daterange[0]),'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
            
        }
        if ($registration_from != null && $registration_to != '')
         {
            if($type == 1){return LeadCase::where('type',1)->where('employee_id',$this->id)->whereBetween('created_at', [$registration_from, $registration_to])    ->count();}
            elseif($type == 2){return LeadCase::where('type',2)->where('employee_id',$this->id)->whereBetween('created_at', [$registration_from, $registration_to])->count();}
            elseif($type == 3){return LeadCase::where('type',3)->where('employee_id',$this->id)->whereBetween('created_at', [$registration_from, $registration_to])->count();}
            elseif($type == 4){return LeadCase::where('type',4)->where('employee_id',$this->id)->whereBetween('created_at', [$registration_from, $registration_to])->count();}
             
         }

        else{
            if($type == 1){return LeadCase::where('type',1)->where('employee_id',$this->id)->where('created_at','like','%'.date('Y-m-d').'%')    ->count();}
            elseif($type == 2){return LeadCase::where('type',2)->where('employee_id',$this->id)->where('created_at','like','%'.date('Y-m-d').'%')->count();}
            elseif($type == 3){return LeadCase::where('type',3)->where('employee_id',$this->id)->where('created_at','like','%'.date('Y-m-d').'%')->count();}
            elseif($type == 4){return LeadCase::where('type',4)->where('employee_id',$this->id)->where('created_at','like','%'.date('Y-m-d').'%')->count();}
        }
        
    }
    
    public function gettotalattendance($date){
        
        $registration_from=null;
        $reg_to=null;
        $reg_from=null;
        $registration_to = null;
        if ($date && $date != null && $date != '') {
            $daterange = explode(' - ',$date);
            $reg_from = date_create($daterange[0]);
            date_add($reg_from,date_interval_create_from_date_string("1 days"));
            $registration_from = date_format($reg_from ,'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
            
           
            
        }
        if ($registration_from != null && $registration_to != ''){
            $GroupId = GroupSession::whereBetween('date', [$registration_from, $registration_to])->withCount('attendances')
           ->where('instructor_id',$this->id)->pluck('group_id')->ToArray();
            
            $sessions = GroupSession::whereBetween('date', [$registration_from, $registration_to])
           ->where('instructor_id',$this->id)->pluck('id')->ToArray();
            
           $todaygroup = GroupSession::whereBetween('date', [$registration_from, $registration_to])->where('instructor_id',$this->id)
           ->with('makeup')->get(); 
        }
        else{
            $GroupId = GroupSession::where('date',date('Y-m-d'))/*->withCount('attendances')*/
            ->where('instructor_id',$this->id)->pluck('group_id')->ToArray();
            
             $sessions = GroupSession::where('date',date('Y-m-d'))/*->withCount('attendances')*/
            ->where('instructor_id',$this->id)->pluck('id')->ToArray();
            
            $todaygroup = GroupSession::where('date',date('Y-m-d'))->where('instructor_id',$this->id)->/*with('makeup')->distinct()->*/get();
        }
        
        $counttodaygroup=$todaygroup->count();
        $noofattendance = GroupSessionAttendance::whereIn('group_session_id',$sessions)
        //   ->WhereNotNull('attendance')->count();
          ->where(function($query){
                 $query->WhereNotNull('attendance');
             })->get()->count();
          
        $noofgroupattendance = GroupSession::whereIn('id',$sessions)/*->distinct()->where('instructor_id',$this->id)*/
           ->whereHas('attendances',function($query){
                 $query->WhereNotNull('attendance');
             })->get()->count(); 
             
        $emptygroup = Group::where('instructor_id',$this->id)->whereHas('subRound',function($query){
                    $query->where('start_date','<',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'));
                })->doesntHave('students')->get()->count(); 
        
        return ['counttodaygroup' => $counttodaygroup,'noofattendance' => $noofattendance,'noofgroupattendance' => $noofgroupattendance , 'emptygroup' => $emptygroup];
        /*if($id == 1)
        {
          $counttodaygroup=$todaygroup->count();
          return $counttodaygroup;
        }elseif($id == 2){
           
          $noofattendance = GroupSessionAttendance::whereIn('group_session_id',$sessions)
          ->WhereNotNull('attendance')->count();
         
            return $noofattendance;
        }elseif($id == 3){
            $noofgroupattendance = GroupSession::whereIn('id',$sessions)->distinct()->where('instructor_id',$this->id)
           ->whereHas('attendances',function($query){
                 $query->WhereNotNull('attendance');
             })->get()->count(); 
            return $noofgroupattendance;
        }*/
        
       
    }
    
    public function getmissingbook( $date,$sub_round ){
        $registration_from=null;
        $reg_to=null;
        $reg_from=null;
        $registration_to = null;
        if ($date && $date != null && $date != '') {
            $daterange = explode(' - ',$date);
            $reg_from = date_create($daterange[0]);
            date_add($reg_from,date_interval_create_from_date_string("1 days"));
            $registration_from = date_format($reg_from ,'Y-m-d');
            $reg_to  = date_create($daterange[1]);
            date_add($reg_to,date_interval_create_from_date_string("1 days"));
            $registration_to= date_format($reg_to,"Y-m-d");
        }
        $Group = Group::where('instructor_id',$this->id)->pluck('id')->ToArray();
        
        $count = 0;
        $sessions = Group::whereIn('id',$Group);
           
        $todaygroups = Group::whereIn('id',$Group);
          
        $noofattends = Group::whereIn('id',$Group);
        if($sub_round != null && $sub_round != ' '){
             
             $sessions->where('sub_round_id',$sub_round );
           
             $todaygroups->where('sub_round_id',$sub_round);
               
             $noofattends->where('sub_round_id',$sub_round);
             $count++;
        }
        
        if ($registration_from != null && $registration_to != ' '){
            
            $sessions->whereHas('sessions', function ($query) use ($registration_from ,$registration_to) {
               $query->whereBetween('date', [$registration_from, $registration_to]); 
            });
            
            $todaygroups->whereHas('sessions', function ($query) use ($registration_from ,$registration_to) {
               $query->whereBetween('date', [$registration_from, $registration_to]); 
            });
            
            $noofattends->whereHas('sessions', function ($query) use ($registration_from ,$registration_to) {
               $query->whereBetween('date', [$registration_from, $registration_to]); 
            });
            $count++;
        }
        if($count == 0){
            $sessions->whereHas('sessions', function ($query)  {
                $query->where('date',date('Y-m-d'));
            });
            
            $todaygroups->whereHas('sessions', function ($query)  {
                $query->where('date',date('Y-m-d'));
            });
           
            $noofattends->whereHas('sessions', function ($query)  {
                $query->where('date',date('Y-m-d'));
            });
            
        }
        
        $sessions = $sessions->pluck('id')->ToArray();
          
        $todaygroups = $todaygroups->pluck('id')->ToArray();
          
        $noofattends = $noofattends->pluck('id')->ToArray();
        
        // start count group
        $countgroup=Group::whereIn('id',$todaygroups)->get()->count();
        // end count group
        
        // start count sessions
        $countsessions = GroupSession::whereIn('group_id',$sessions)->get()->count();
        // end count sessions
        
        // start count missing
        $counttofattend=GroupSession::whereIn('group_id',$noofattends)->where('show_book',1)->get()->count();
        //end count missing
        
        return ['countsessions' => $countsessions,'countgroup' => $countgroup, 'counttofattend' => $counttofattend];
       
    }
    

}
