<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;


/**
 * Class OperationVacation
 * @package App\Models
 * @version May 21, 2021, 10:15 pm UTC
 *
 * @property string $title
 * @property integer $has_transaction_number
 * @property integer $status
 */
class OperationVacation extends Model
{
    use SoftDeletes;

    public $table = 'operation_vacations';

    protected $dates = ['deleted_at'];

    public $fillable = [
        'title',
        'from_date',
        'to_date',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'title' => 'string',
        'from_date' => 'string',
        'to_date' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'title' => 'required',
        'from_date' => 'required',
        'to_date' => 'required'
    ];
}
