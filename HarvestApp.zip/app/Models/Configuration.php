<?php

namespace App\Models;

use Eloquent as Model;

class Configuration extends Model
{
    // use SoftDeletes;


    public $table = 'configurations';

    public $fillable = [
        'name',
        'logo',
        'icon',
        'address',
        'bg_image',
        'home_image',
        'about',
        'meta_desc',
        'meta_key',
        'meta_title',
        'lang',
        'video',
        'online_desc',
        'offline_desc'
    ];
    
    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'name' => 'string',
        'logo' => 'string',
        'icon' => 'string',
        'address' => 'string',
        'home_image' => 'string',
        'bg_image' => 'string',
        'about' => 'string',
        'meta_desc' => 'string',
        'meta_key' => 'string',
        'meta_title' => 'string',
        'lang' => 'string',
        'video' => 'string',
        'online_desc'=>'string',
        'offline_desc'=>'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'name' => 'required',
        'address' => 'required',
    ];
}