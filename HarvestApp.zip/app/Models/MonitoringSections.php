<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MonitoringSections extends Model
{
    use HasFactory;
    
    public $fillable = [
         'title',
         'description',
         ];
     public function SectionsMonitoring()
    {
        return $this->hasMany('\App\Models\SectionsMonitoring','monitoring_sections_id');
    }    
     public function MonitoringSectionTopic()
    {
        return $this->hasMany('\App\Models\MonitoringSectionTopic','monitoring_sections_id');
    }    
    
}
