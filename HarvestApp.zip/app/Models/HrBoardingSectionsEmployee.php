<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HrBoardingSectionsEmployee extends Model
{
    use HasFactory;
     protected $table = 'hr_boarding_sections_employee';
    public $fillable = [
         'title',
         'hr_boarding_id',
         'hr_boarding_sections_id',
         'hr_boarding_sections_topics_id',
         'type',
         'status',
         'notes',
         'statement',
         ];
         
     public static $rules = [
        'title' => 'required',
        'hr_boarding_id' => 'required',
        'hr_boarding_sections_id' => 'required',
        'hr_boarding_sections_topics_id' => 'required',
        'type' => 'nullable',
        'status' => 'nullable',
        'notes' => 'nullable',
        'statement' => 'nullable',
    ];
    public function HrBoarding()
    {
        return $this->belongsTo('\App\Models\HrBoarding','hr_boarding_id');
        
    } public function HrBoardingSections()
    {
        return $this->belongsTo('\App\Models\HrBoardingSections','hr_boarding_sections_id');
        
    } public function HrBoardingSectionsTopics()
    {
        return $this->belongsTo('\App\Models\HrBoardingSectionsTopics','hr_boarding_sections_topics_id');
        
    } 
}
