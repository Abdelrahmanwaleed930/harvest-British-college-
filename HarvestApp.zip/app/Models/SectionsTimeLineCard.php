<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SectionsTimeLineCard extends Model
{
    use HasFactory;
    protected $table = "sections_timeline_card";
     public $fillable = [
         'timeline_card_id',
         'timeline_card_sections_id',
         'functions',
         'objective',
         'statement',
         'score'
         ];
         
    public function TimeLineCard()
    {
        return $this->belongsTo('\App\Models\TimeLineCard','timeline_card_id');
    }      
    public function TimeLineCardSections()
    {
        return $this->belongsTo('\App\Models\TimeLineCardSections','timeline_card_sections_id');
    }      
}
